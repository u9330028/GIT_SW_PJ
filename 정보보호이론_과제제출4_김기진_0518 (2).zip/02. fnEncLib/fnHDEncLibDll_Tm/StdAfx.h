// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__707FC9EB_1370_429E_9121_4B6C6D874B8A__INCLUDED_)
#define AFX_STDAFX_H__707FC9EB_1370_429E_9121_4B6C6D874B8A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#pragma comment(lib, "..\\Lib\\fnHDEncLib.lib")

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <time.h>
#include <sys/timeb.h>
#include <string.h>
#ifndef XDllExport
	#ifdef __cplusplus
		#define XDllExport   extern "C" __declspec( dllexport )
	#else 
		#define XDllExport __declspec( dllexport )
	#endif
#endif




// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__707FC9EB_1370_429E_9121_4B6C6D874B8A__INCLUDED_)
