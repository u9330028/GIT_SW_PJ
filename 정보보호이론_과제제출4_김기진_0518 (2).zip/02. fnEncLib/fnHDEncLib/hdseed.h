/*--------------------------------------------------------------------*/
/*                                                                    */
/*--------------------------------------------------------------------*/

#ifndef _HDSEED_H
#define _HDSEED_H


/********************** Include files *****************************/

#include <stdlib.h>
#include <string.h>


/******************** Endian Definitions **************************/

#define BIG_ENDIAN 		/* Motorora,ibm370,Sparc,risc based */
/* #define LITTLE_ENDIAN	 Intel,Dec,Alpha */

#define _TEST_

/******************* Constant Definitions *************************/

#define KEY_LEN				16
#define SSKEY_BLOCK_LEN			46
#define ENC_BLOCK_LEN			32

#define ERR_MST_KEY_INDEX		1	/* ������Ű Index�� 00 ~ 9 �̾�� �� */
#define ERR_SVR_HASH			2	/* Client �� Server Hash���� ����    */	
#define ERR_BLOCK_LEN			3	/* ��ȣȭ ���� ���� ����             */
#define ERR_ENC_DATA_KIND		4	/* ��ȣȭ ���� ���� ����             */
#define ERR_ETC_PROC			5	/* ��ȣȭ ����                       */

/**************** Function Prototype Declarations *****************/

int	UnPack(BYTE *sData, int sLen, BYTE *dData);
int	Pack(BYTE *sData, int sLen, BYTE *dData);

int	HD_CKeyInit(BYTE *s1Key, int *s1Len, BYTE *s1Idx, BYTE *mk_table, BYTE *wKey, int wLen);
int	HD_GetHashCode(BYTE *datetime, long amnt, BYTE *dData);
int	HD_EncSeed(BYTE *wKey, BYTE *wIdx, BYTE *sData, int sLen, BYTE *dData, int *dLen);
int	HD_DecSeed(BYTE *wKey, int wIdx, BYTE *mk_tabale, BYTE *sData, int sLen, BYTE *pwd, BYTE *acnt, BYTE *hData);
int	HD_SetRspCode(int eCode);

/******************************************************************/
#endif
