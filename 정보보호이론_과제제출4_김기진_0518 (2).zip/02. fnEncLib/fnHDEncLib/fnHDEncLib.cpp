/* **************************************************************************
//
// Nautilus Hyosung Inc. 2016 All Rights Reserved
//
// ���ϸ� : fnHDEncLib.cpp
// ��  �� : Dll ����
// ��  �� : 2016/05/20 �ű��ۼ�
// �ۼ��� : ����� (��ƿ����ȿ��)
// *************************************************************************/

#include "stdafx.h"
#include "fnHDEncLib.h"

/////////////////////////////////////////////////////////////////////////////
// Entry point for the DLL application
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


int  CALLBACK fnHD_CKeyInit(BYTE *s1Key, int *s1Len, BYTE *s1Idx, BYTE *mk_table, BYTE *wKey, int wLen)
{
	return HD_CKeyInit(s1Key, s1Len, s1Idx, mk_table, wKey, wLen);
}

int  CALLBACK fnHD_GetHashCode(BYTE *datetime, long amnt, BYTE *dData)
{
	return HD_GetHashCode(datetime, amnt, dData);
}

int  CALLBACK fnHD_EncSeed(BYTE *wKey, BYTE *wIdx, BYTE *sData, int sLen, BYTE *dData, int *dLen)
{
	return HD_EncSeed(wKey, wIdx, sData, sLen, dData, dLen);
}

int  CALLBACK fnHD_DecSeed(BYTE *wKey, int wIdx, BYTE *mk_tabale, BYTE *sData, int sLen, BYTE *pwd, BYTE *acnt, BYTE *hData)
{
	return HD_DecSeed(wKey, wIdx, mk_tabale, sData, sLen, pwd, acnt, hData);
}

int  CALLBACK fnHD_SetRspCode(int eCode)
{
	return HD_SetRspCode(eCode);
}
