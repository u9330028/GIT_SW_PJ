//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Sock.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SOCK_DIALOG                 102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_RCLIENT                     1000
#define IDC_RSERVER                     1001
#define IDC_ESERVNAME                   1002
#define IDC_ESERVADDR                   1003
#define IDC_STATICMSG                   1003
#define IDC_ESERVPORT                   1004
#define IDC_BCONNECT                    1005
#define IDC_EMSG                        1006
#define IDC_BSEND                       1007
#define IDC_ESENT                       1008
#define IDC_ERECVD                      1009
#define IDC_STATICPORT                  1010
#define IDC_STATICNAME                  1011
#define IDC_STATICTYPE                  1012
#define IDC_BCLOSE                      1013
#define IDC_LSENT                       1016
#define IDC_LRECVD                      1017
#define IDC_LIST1                       1018
#define IDC_FSend                       1019
#define IDC_EDIT1                       1020
#define IDC_Receive                     1021
#define IDC_BUTTON1                     1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
