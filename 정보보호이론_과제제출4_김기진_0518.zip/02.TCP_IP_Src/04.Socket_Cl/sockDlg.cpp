// SockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Sock.h"
#include "SockDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockDlg dialog

CSockDlg::CSockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSockDlg)
	m_sMessage = _T("");
//	m_sRecvd = _T("");
//	m_sSent = _T("");
	m_sName = _T("");
	m_iType = -1;
	m_iPort = 0;
	RRcount=0;
	SendCheck = 0;
	SRcount=0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSockDlg)
	DDX_Control(pDX, IDC_Receive, m_ctrlReceive);
	DDX_Control(pDX, IDC_EDIT1, m_ctrlSand);

	DDX_Control(pDX, IDC_BCONNECT, m_ctlConnect);
	DDX_Text(pDX, IDC_EMSG, m_sMessage);
	DDX_Text(pDX, IDC_ESERVNAME, m_sName);
	DDX_Radio(pDX, IDC_RCLIENT, m_iType);
	DDX_Text(pDX, IDC_ESERVPORT, m_iPort);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSockDlg, CDialog)
	//{{AFX_MSG_MAP(CSockDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RCLIENT, OnRType)
	ON_BN_CLICKED(IDC_BCONNECT, OnBconnect)
	ON_BN_CLICKED(IDC_BSEND, OnBsend)
	ON_BN_CLICKED(IDC_BCLOSE, OnBclose)
	ON_BN_CLICKED(IDC_FSend, OnFSend)
	ON_BN_CLICKED(IDC_RSERVER, OnRType)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSockDlg message handlers

BOOL CSockDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	// Initialize the control variables
	m_iType = 0;
	m_sName = "150.214.111.203";
	m_iPort = 4000;
	m_bConnected = FALSE;
	// Update the controls
	UpdateData(FALSE);
	// Set the socket dialog pointers
	m_sConnectSocket.SetParent(this);
	m_sListenSocket.SetParent(this);
	m_sListenSocket.Create(m_iPort);
		// Listen for connection requests
	m_sListenSocket.Listen();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSockDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSockDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSockDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSockDlg::OnRType() 
{
	// TODO: Add your control notification handler code here
	// Sync the controls with the variables
	UpdateData(TRUE);
	// Which mode are we in?
	if (m_iType == 0)	// Set the appropriate text on the button
		m_ctlConnect.SetWindowText("C&onnect");
	else
		m_ctlConnect.SetWindowText("&Listen");
}

void CSockDlg::OnBconnect() 
{
	// TODO: Add your control notification handler code here
	// Sync the variables with the controls
	UpdateData(TRUE);
	// Disable the connection and type controls
	GetDlgItem(IDC_BCONNECT)->EnableWindow(FALSE);
	GetDlgItem(IDC_ESERVNAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_ESERVPORT)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATICNAME)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATICPORT)->EnableWindow(FALSE);
	GetDlgItem(IDC_RCLIENT)->EnableWindow(FALSE);
	GetDlgItem(IDC_RSERVER)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATICTYPE)->EnableWindow(FALSE);
	// Are we running as client or server?
	if (m_iType == 0)
	{
		// Client, create a default socket
		m_sConnectSocket.Create();
		// Open the connection to the server
		m_sConnectSocket.Connect(m_sName, m_iPort);
	}
/*
	else
	{
		// Server, create a socket bound to the port specified
		m_sListenSocket.Create(m_iPort);
		// Listen for connection requests
		m_sListenSocket.Listen();
	}
*/
}

void CSockDlg::OnAccept()
{
	if (m_bConnected)
	{
		// Create a rejection socket
		CAsyncSocket sRjctSock;
		// Create a message to send
		CString strMsg = "Too many connections, try again later.";
		// Accept using the rejection socket
		m_sListenSocket.Accept(sRjctSock);
		// Send the rejection message
		sRjctSock.Send(LPCTSTR(strMsg), strMsg.GetLength());
		// Close the socket
		sRjctSock.Close();
	}
	else
	{
		// Accept the connection request
		m_sListenSocket.Accept(m_sConnectSocket);
		m_bConnected = TRUE;
		// Enable the text and message controls
		GetDlgItem(IDC_EMSG)->EnableWindow(TRUE);
		GetDlgItem(IDC_BSEND)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATICMSG)->EnableWindow(TRUE);
	}
}

void CSockDlg::OnConnect()
{
	// Enable the text and message controls
	GetDlgItem(IDC_EMSG)->EnableWindow(TRUE);
	GetDlgItem(IDC_BSEND)->EnableWindow(TRUE);
	GetDlgItem(IDC_STATICMSG)->EnableWindow(TRUE);
	GetDlgItem(IDC_BCLOSE)->EnableWindow(TRUE);
}

void CSockDlg::OnClose()
{
	// Close the connected socket
	m_sConnectSocket.Close();
	m_bConnected = FALSE;
	// Disable the message sending controls
	GetDlgItem(IDC_EMSG)->EnableWindow(FALSE);
	GetDlgItem(IDC_BSEND)->EnableWindow(FALSE);
	GetDlgItem(IDC_STATICMSG)->EnableWindow(FALSE);
	GetDlgItem(IDC_BCLOSE)->EnableWindow(FALSE);
	// Are we running in Client mode?
	if (m_iType == 0)
	{
		// Yes, so enable the connection configuration controls
		GetDlgItem(IDC_BCONNECT)->EnableWindow(TRUE);
		GetDlgItem(IDC_ESERVNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_ESERVPORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATICNAME)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATICPORT)->EnableWindow(TRUE);
		GetDlgItem(IDC_RCLIENT)->EnableWindow(TRUE);
		GetDlgItem(IDC_RSERVER)->EnableWindow(TRUE);
		GetDlgItem(IDC_STATICTYPE)->EnableWindow(TRUE);
	}
}

void CSockDlg::OnReceive()
{
//�޴���.
// �޼��� �ޱ�.
//if (SendCheck == 0)

//if ���� �ޱ� �����̶��.
if (SendCheck == 0)
OnRReceive();


//������ �ޱ�.
//if ������ ���� �޴����̶��.
if (SendCheck == 1)
OnSReceive();
/*
CFile f; 
char temp[1025] = "";
byte file[1025]="";
//LONG nFileSize; 
int iRcvd;
int RCount=0;
CString st = "";
Count++;
//if(Count != 3)

m_sConnectSocket.Receive(temp,10);
*/
/*
ASSERT( f.Open("c:\\test.txt", CFile::modeCreate | CFile::modeWrite) ); 




if( Count == 1) 
{
//ASSERT( f.Open("c:\\led.bmp", CFile::modeCreate | CFile::modeWrite | CFile::typeBinary ) ); 
m_sConnectSocket.Receive(temp,10);
nFileSize = atoi(temp);

}

LONG nRecvFileSize = 0; 
//while( nRecvFileSize >= nFileSize ) 
if ( Count  > 1 )
{
while ( nRecvFileSize < nFileSize ) 
{ 
int nRecvSize; 
//m_sConnectSocket.Receive(file,nFileSize);
if( nFileSize - nRecvFileSize >= 1024 ) 
{ 
nRecvSize = 1024; 
} 
else 
{ 
nRecvSize = nFileSize - nRecvFileSize; 
} 
RCount++;
int i;
i =m_sConnectSocket.Receive(file,nRecvSize);
st.Format("%d , %d %d\n",nRecvSize,RCount,i);
RSize+=st;
m_ctrlReceive.SetWindowText(RSize);
	UpdateData(FALSE);
f.Write( file, nRecvSize ); 
nRecvFileSize += nRecvSize; 
}
f.Close(); 
Count=0;
}
*/
//RecvInfo( temp, nRecvSize ); 
/*
if ( Count > 1 )
{
m_sConnectSocket.Receive(temp,nFileSize);
//Ctext=temp;
m_ctrlReceive.SetWindowText(temp);
f.Write( temp,nFileSize ); 
//nRecvFileSize += nRecvSize; 
//} 
//Count=0;
f.Close(); 
}
*/
//*/
	/*
	char *pBuf = new char[1025];
	int iBufSize = 1024;
	int iRcvd;
	CString strRecvd;

	// Receive the message
	iRcvd = m_sConnectSocket.Receive(pBuf, iBufSize);
	// Did we receive anything?
	if (iRcvd == SOCKET_ERROR)
	{
	}
	else
	{
		// Truncate the end of the message
		pBuf[iRcvd] = NULL;
		// Copy the message to a CString
		strRecvd = pBuf;
		// Add the message to the received list box
		m_ctlRecvd.AddString(strRecvd);
		// Sync the variables with the controls
		UpdateData(FALSE);
	}
	*/
}

void CSockDlg::OnSend()
{
}

void CSockDlg::OnBsend() 
{
	// TODO: Add your control notification handler code here
	int iLen;
	int iSent;

	// Sync the controls with the variables
	UpdateData(TRUE);
	// Is there a message to be sent?
	if (m_sMessage != "")
	{
		// Get the length of the message
		iLen = m_sMessage.GetLength();
		// Send the message
		iSent = m_sConnectSocket.Send(LPCTSTR(m_sMessage), iLen);
		// Were we able to send it?
		if (iSent == SOCKET_ERROR)
		{
		}
		else
		{
			// Add the message to the list box.
			m_ctrlSand.GetWindowText(m_sMessage);
			// Sync the variables with the controls
			UpdateData(FALSE);
		}
	}
}

void CSockDlg::OnBclose() 
{
	// TODO: Add your control notification handler code here
	// Call the OnClose function
	OnClose();
}

void CSockDlg::OnFSend() 
{
	// TODO: Add your control notification handler code here

	//	return	FALSE;

CFile f; 
char temp[1025]="";
byte file[1025]="";
CString filename;
CString st;
int nRead;
int Size;
int SendCount=0;
SendCheck = 1;
//wsprintf( temp, "%s",m_strFileToSend); 
wsprintf( temp,"%s",m_strFileToSend); 
m_sConnectSocket.Send(temp,20);
/*
ASSERT( f.Open("c:\\home3.gif",CFile::modeRead) ); 

nFileSize = f.GetLength(); 
wsprintf( temp, "%010d", nFileSize ); 
//m_ctrlSand.SetWindowText(temp);
			// Sync the variables with the controls
//			UpdateData(FALSE);

//SendInfo( temp, 10 ); // ������ ũ�⸦ ���� �����ϴ�. 
m_sConnectSocket.Send(temp, 10);

while( nFileSize ) 
{ 
	SendCount++;
	int i;
nRead = f.Read( file,1024); 
i = m_sConnectSocket.Send(file, nRead);
//SendInfo( temp, nRead ); 
st.Format("%d ,%d, %d\n",nRead,SendCount,i);
SandSize+=st;
m_ctrlSand.SetWindowText(SandSize);
			// Sync the variables with the controls
			UpdateData(FALSE);
nFileSize -= nRead; 
} 
f.Close(); 	
*/
}


void CSockDlg::OnButton1() 
{
int i;
static char BASED_CODE szFilter[] = "All Files (*.*) | *.* ||";
	CFileDialog	dlg(TRUE, NULL, "*.*", 0, szFilter, this);
dlg.DoModal();
m_strFileToSend = dlg.GetFileName();
m_strFileName = dlg.GetPathName();
//m_strFileToSend.SetAt(3,'');
m_ctrlSand.SetWindowText(m_strFileName);
			// Sync the variables with the controls
			UpdateData(FALSE);
}
//�ޱ� ����
void CSockDlg::OnRReceive()
{
//CFile f; 
char temp[1025] = "";
byte file[1025]="";
//LONG nFileSize; 
int iRcvd;
int Size;
int RCount=0;
CString st = "";
RRcount++;
//���Ͽ� �̸��� ũ�⸦  �޴´�.
if (RRcount == 1)
{
m_sConnectSocket.Receive(temp,20);
st.Format("%s",temp);
RRmessage = RRmessage + st;
m_ctrlReceive.SetWindowText(RRmessage);
//�޾Ҵٴ� �޼����� ������.
wsprintf( temp,"%s","���� ����"); 
//Size = strlen(temp);
//temp="�޼��� ����";
m_sConnectSocket.Send(temp,20);
}
if (RRcount == 2)
{
	//���� ũ�⸦ �޴´�.
	m_sConnectSocket.Receive(temp,10);	
	//st.Format("%d",temp);
	//RRmessage = RRmessage + st;
	m_ctrlReceive.SetWindowText(temp);
ASSERT( f.Open("c:\\"+RRmessage, CFile::modeCreate | CFile::modeWrite  ) ); 
m_sConnectSocket.Send("T",1);
nFileSize = atoi(temp);
}

if (RRcount == 3)
{
	int nRecvSize; 
//m_sConnectSocket.Receive(file,nFileSize);
	if( nFileSize - nRecvFileSize >= 1024 ) 
	{ 
		nRecvSize = 1024; 
	} 
	else 
	{ 
		nRecvSize = nFileSize - nRecvFileSize; 
	} 
//RCount++;
	int i;
	i =m_sConnectSocket.Receive(file,nRecvSize);
//st.Format("%d , %d %d\n",nRecvSize,RCount,i);
//RSize+=st;
//m_ctrlReceive.SetWindowText(RSize);
//	UpdateData(FALSE);
	f.Write( file, nRecvSize ); 
	nRecvFileSize += nRecvSize; 
m_sConnectSocket.Send("T",1);
RRcount=2;
if (nRecvFileSize == nFileSize)
{
//f.Close();
}
}
}

void CSockDlg::OnSReceive()
{
char temp[1025] ="";
byte file[1025]="";
//CFile f; 
SRcount ++;
LONG nRead;
CString st;
if (SRcount == 1)
{
	//�޾Ҵٴ� �޼��� ����.

m_sConnectSocket.Receive(temp,20);
m_ctrlReceive.SetWindowText(temp);
   //���� ũ�� ����.
ASSERT( f.Open(m_strFileName,CFile::modeRead) ); 
nFileSize = f.GetLength(); 
wsprintf(temp, "%010d", nFileSize); 
m_ctrlSand.SetWindowText(temp);
m_sConnectSocket.Send(temp,10);
}

if(SRcount == 2)
{

m_sConnectSocket.Receive(temp,1);
st.Format("%s",temp);
//int i;
//i=st.GetLength();
//st.Format("%d",i);
if (st == "T")
{

//	SendCount++;
int i;
nRead = f.Read( file,1024); 
m_sConnectSocket.Send(file, nRead);

			UpdateData(FALSE);
nFileSize -= nRead; 
SRcount=1;
if (nFileSize == 0 )
{
f.Close();
m_ctrlSand.SetWindowText("���� ���� �Ϸ�.");
OnClose();
SRcount = 3;
}
}
}

}

void CSockDlg::OnMReceive()
{

}
