#ifndef	___multimedia_re_timers___
#define	___multimedia_re_timers___


#include	<mmsystem.h>

//class CRetransTimer;
#include "MyReTimer.h"

class CMMReTimers //: public CObject
{
public:
	
	CMMReTimers(UINT resolution);
	virtual ~CMMReTimers();

	UINT	getTimerRes() { return timerRes; };

	BOOL	startTimer ( CMyReTimer *pReTimer, UINT period, bool oneShot = FALSE);
	BOOL	stopTimer();

	void timerProc() { m_pParent->TimerProc(); };
	// virtual void timerProc() { m_pParent.TimerProc(timerID) };
protected:
	CMyReTimer *m_pParent;
	UINT	timerRes;
	UINT	timerId;
};


#endif