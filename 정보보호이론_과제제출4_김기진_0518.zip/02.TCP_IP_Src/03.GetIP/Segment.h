// Segment.h: interface for the CSegment class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEGMENT_H__A0C69191_AC73_4EA5_928C_F483292FC4B3__INCLUDED_)
#define AFX_SEGMENT_H__A0C69191_AC73_4EA5_928C_F483292FC4B3__INCLUDED_

//#include "SendingTimer.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "packet.h"
//#include "SegBuf.h"	// Added by ClassView
//#include "SendingTimer.h"

class CSegBuf;

class CSegment : public CObject
{
public:
	BOOL m_bRetrans;

	int SetSegInfo(void *seg, int nSegLen, CSegBuf *pSegBuf, BOOL bRetrans=FALSE);
	void RcvSegment(Segment Seg);
	TcpHdr	m_TcpHdr;
	Segment	m_TcpSegment;
	UINT GetSeqNo();
//	CSendingTimer * m_pSendingTimer;
	CSegBuf *m_pSegBuf;
	BOOL	m_nSegLen;
	UINT m_SeqNo;
	// BOOL SendSegment(void *seg, int nSegType, int nDelay, CSegBuf *pSegBuf) ;

	CSegment();
	virtual ~CSegment();

};

#endif // !defined(AFX_SEGMENT_H__A0C69191_AC73_4EA5_928C_F483292FC4B3__INCLUDED_)
