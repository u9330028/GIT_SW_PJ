// MyTimer.h: interface for the CMyTimer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYTIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_)
#define AFX_MYTIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TimeInfo.h"
//
#include "SegBuf.h"

class CMMTimers;
class CMyTimer  
{
public:
	BOOL DeleteTimeInfo(UINT seqNo);
	void DeleteAllTimeInfo();
//	CTimeInfo * FindTimeInfo(UINT nSeqNo);
	int m_nTempIdx;
	UINT m_nGranuality;
	void StartTimer(int nTimerID, int nGranuality=0);
	CSegBuf * m_pParent;
	void TimerProc();
	int m_nTimerType;
	CMMTimers * m_pTimer;
	CObList m_ListTimeInfo;
	void AddTimer(TimeInfo t, BOOL bSort=FALSE, int nSortMode = SORT_BY_SEQ_NO);
	CMyTimer(CSegBuf *pParent);
	virtual ~CMyTimer();

};

#endif // !defined(AFX_MYTIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_)
