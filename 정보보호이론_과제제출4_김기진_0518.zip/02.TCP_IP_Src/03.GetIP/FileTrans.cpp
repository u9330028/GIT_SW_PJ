// FileTrans.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "FileTrans.h"
#include "definition.h"
#include "packet.h"
#include "SimpleTCP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileTrans

CFileTrans::CFileTrans(CWnd *pParentWnd)
{
	//Create(NULL, "", WS_CHILD, CRect(0, 0, 0, 0), m_pParentWnd, m_Socket);
	m_pParentWnd = pParentWnd;
	if (!Create(NULL, "", WS_CHILD, CRect(0, 0, 0, 0), pParentWnd, m_hFile))
		AfxMessageBox("������ ��������");
	
	m_nSendingStatus = FILE_NONE_STATUS;
	m_hFile = HFILE_ERROR;
	m_pTCP = NULL;
	m_nEndingSeqNo = 0;
}

CFileTrans::~CFileTrans()
{
	if (HFILE_ERROR != m_hFile)
		_lclose(m_hFile);
}


BEGIN_MESSAGE_MAP(CFileTrans, CWnd)
	//{{AFX_MSG_MAP(CFileTrans)
	ON_MESSAGE(WM_SENDING_AVAILABLE, OnSendingAvailableNotify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFileTrans message handlers

LONG CFileTrans::OnSendingAvailableNotify(WPARAM wParam, LPARAM lParam)
{
	//("���� ���� �ҷ���");
	TRACE("OnSendingAvailableNotify EVENT �߻�\n");
	BOOL bFirstTrans = FALSE;
	UINT AckNo = 0;
	UINT nAvailableWndSize = 0;

	if (wParam == FIRST_CALL_FILE_TRANSFER )
	{
		bFirstTrans = TRUE;	// ���� ������ ACK������..
		AckNo = lParam;
		TRACE("Sending File Info, First File Trans Ack No : %d\n", AckNo);
		SendFileInfo(bFirstTrans, AckNo);
		m_nSendingStatus = FILE_SENDING;
	}
	else if(wParam == NORMAL_CALL_FILE_TRANSFER )
	{
		BOOL bNotEnded;
		nAvailableWndSize = LOWORD(lParam);
		TRACE("OnSendingAvailableNotify=>nAvailableWndSize:%d\n",nAvailableWndSize);
		for ( UINT i = 0; i < nAvailableWndSize; i ++ )
		{
			bNotEnded = ReadFile(bFirstTrans, AckNo);	
			if ( !bNotEnded )	
			{ // if file transfer is ended..
				// m_bSending = FALSE; -> ���߿� ACK�ް� �ؾ����� ������?
				if (HFILE_ERROR != m_hFile ) 
				{
					_lclose(m_hFile);		
					m_hFile = HFILE_ERROR;
				}
				// �������� ������ ������ seq��ȣ���� 
				// -> ���߿� ACK �޾Ƽ� ���� ���� ���˱�����
				SetEndingSeqNo(m_pTCP->m_curSeqNo-1);	
				m_nSendingStatus = FILE_SEND_FINISHED;
				TRACE ("���� ���� �� seq���� ���� : seq no : %d\n",m_pTCP->m_curSeqNo-1);
								
				// �������� ������ �˷���.
				// FIN ���� �Ѱ���. �������� . ���� ���� ���⼭ ����. ACK �ٹް� �� �Ŀ�.
				return 1;
			}
		}
	}
	return 0;
}

BOOL CFileTrans::ReadFile(BOOL bFirstTrans, UINT AckNo)
{
	if (HFILE_ERROR != m_hFile )
	{
		char pBlock[DATA_GRAM_SIZE];
		int	nRead = _lread(m_hFile, pBlock, sizeof(pBlock));
		
		if (0 < nRead) {
			TRACE("ReadFile => %d\n", nRead);
			SendSegment(nRead, pBlock );
			return TRUE;
		}
		else 
		{ // file sending eneded..
			TRACE("ReadFile => %d:Ended\n", nRead);
			return FALSE;
		}
	}
	return TRUE;
}

BOOL CFileTrans::ReadyToSend(CSimpleTCP *pTCP)
{
	m_nSendingStatus = FILE_READY_TO_SEND;
	
	if ( pTCP == NULL ) return FALSE;
	m_pTCP = pTCP;

	OFSTRUCT	os;
	os.cBytes = sizeof(os);
	if (HFILE_ERROR == (m_hFile = OpenFile(m_strFullName, &os, OF_READ)))
		return	FALSE;
	_llseek(m_hFile, 0, 0);
	return TRUE;
}

int CFileTrans::SendSegment(int nRead, char pBlock[])
{
	Segment fileSeg;

	m_pTCP->InitSegment((void*)&fileSeg, SEG_SIZE );
	memcpy(fileSeg.data, pBlock, nRead);
	m_pTCP->SendSegment(&fileSeg, (nRead+HEADER_SIZE) );
	return 0;
}

void CFileTrans::SetEndingSeqNo(UINT nSeqNo)
{
	m_nEndingSeqNo = nSeqNo;
}

void CFileTrans::SendFileInfo(BOOL bFirstTrans, UINT nAckNo)
{
	Segment fileSeg;
	// �������̸� ����.
	//char pBlock[FILE_INFO_SIZE];
	
	m_pTCP->InitSegment((void*)&fileSeg, SEG_SIZE );
	
	// �������̸� ����.
	sprintf(fileSeg.data,"%s&%d*", // format => filename&filesize**
		m_strFileName.GetBuffer(m_strFileName.GetLength()),m_nFileSize);
	
	if ( bFirstTrans )
	{
		fileSeg.tcphdr.basetcphdr.ACK = 1;
		fileSeg.tcphdr.basetcphdr.AckNo = nAckNo;
	}
	fileSeg.tcphdr.basetcphdr.Stream = S_FILE_TRANS_REQ_MODE;
	m_pTCP->SendSegment(&fileSeg, SEG_SIZE );
}
