#if !defined(AFX_FILETRANS_H__2B1BC18B_94BD_49BC_9719_A046669E8FB3__INCLUDED_)
#define AFX_FILETRANS_H__2B1BC18B_94BD_49BC_9719_A046669E8FB3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileTrans.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFileTrans window
class CSimpleTCP;

class CFileTrans : public CWnd
{
// Construction
public:
	CFileTrans(CWnd *pParentWnd=NULL);
	
	HFILE m_hFile;
	
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileTrans)
	//}}AFX_VIRTUAL

// Implementation
public:
	CString m_strFullName;
	void SendFileInfo(BOOL bFirstTrans, UINT nAckNo);
	void SetEndingSeqNo(UINT nSeqNo);
	UINT m_nEndingSeqNo;
	CSimpleTCP *m_pTCP;
	int SendSegment(int nRead,char pBlock[]);
	UINT m_nSendingStatus;
	BOOL ReadyToSend(CSimpleTCP *pTCP);
	BOOL ReadFile(BOOL bFirstTrans, UINT AckNo);
	CWnd * m_pParentWnd;
	LONG OnSendingAvailableNotify(WPARAM wParam, LPARAM lParam);
	LONG m_nFileSize;
	CString m_strFileName;
	virtual ~CFileTrans();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFileTrans)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILETRANS_H__2B1BC18B_94BD_49BC_9719_A046669E8FB3__INCLUDED_)
