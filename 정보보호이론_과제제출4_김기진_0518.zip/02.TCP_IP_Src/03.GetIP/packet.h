#include "definition.h"
#ifndef _PACKET_H
#define _PACKET_H

/*****************************************************/
// Tcp basic header format.
typedef struct BaseTcpHdr_tag {
	UINT	SeqNo;
	UINT	AckNo;
	UINT	SYN:1,
			FIN:1,
			ACK:1,
			TotalLen:8,
			Stream:4,	// operation mode
			Reserved:1,
			CheckSum:16;
} BaseTcpHdr;

// Tcp header option.
typedef struct TcpHdrOpt_tag {
	double time_stamp;
} TcpHdrOpt;

// Tcp Header. ( used by ACK, SYN, FIN )
typedef struct TcpHdr_tag {
	BaseTcpHdr	basetcphdr;
	TcpHdrOpt	hdrOpt;
} TcpHdr;

#define HEADER_SIZE sizeof(struct TcpHdr_tag)

// Tcp Segment format.
typedef struct Segment_tag {
	TcpHdr	tcphdr;
	char	data[DATA_GRAM_SIZE];
} Segment;

#define PAD_SIZE 6
#define SEG_SIZE (sizeof(struct Segment_tag)-PAD_SIZE)
/*****************************************************/

/*
typedef struct FileInfo_tag {
	LONG m_nFileSize;
	char strFileName[FILE_NAME_SIZE];
} FileInfo;
#define FILEINFO_SIZE (sizeof(struct FileInfo_tag))
*/
/*****************************************************/
typedef struct TEST_TAG {
	UINT	SeqNo;
	UINT	AckNo;
	UINT	SYN:1,
			FIN:1,
			ACK:1,
			TotalLen:8,
			Reserved:5,
			CheckSum:16;
	double time_stamp;
	char	data[DATA_GRAM_SIZE];

} TestSeg;

#define TEST_SIZE sizeof(struct TEST_TAG)

typedef struct database_tag {
	float time;
	float data;
} Database;

typedef struct TimeInfo_tag 
{
	UINT SeqNo;
	UINT Expires;
	BOOL bRetrans;
} TimeInfo;

#endif