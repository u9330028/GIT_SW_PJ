// SimpleTCP.cpp : implementation file
//
#include "stdafx.h"
#include "SimpleTCPDemo.h"

#include "SimpleTCP.h"

#include "definition.h"
#include "packet.h"
#include "FileTrans.h"
#include "SimpleTCPDemoView.h"
//#include "MainFrm.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCP

CSimpleTCP::CSimpleTCP(CWnd *pParentWnd)
{
	m_bSimulEnded = FALSE;
	m_nFinForAckNo = -1;
	m_bConnected = FALSE;
	m_curSeqNo = 0;
//	m_nAckedNo = -1;
	m_bWorkMode = -1;
	
	m_nLocalPort = 0;
	m_nDstPort = 0;

	m_segBuf.m_pTCP = this; // segbuf �����ڿ� �̳�� ��� ���� ȣ��Ǵ��� üũ��.....
	m_tcpSlidingWnd.m_pTCP = this;
	m_calRTO.m_pTCP = this;
	m_reTimer.m_pTCP = this;
	m_errorGen.m_pTCP = this;
	m_rttTimer.m_pTCP = this;
	m_RcvBuf.m_pTCP = this;

	m_reTimer.m_pSegBuf = &m_segBuf;

	m_pParentWnd = pParentWnd;
	m_pSendingFile = NULL;
	m_AppMode = NONE_MODE;		// application mode
	m_TCPStatus = CLOSED;

	m_tempDBSeqNo.data = 0.0;
	m_tempDBSeqNo.time = 0.0;
	m_tempDBCwnd.data = 0.0;
	m_tempDBCwnd.time = 0.0;

	m_reTimer.StartTimer(TIMER_TYPE_RETRANS,RETRANS_GRANUALITY);
	m_rttTimer.StartTimer(TIMER_TYPE_RTT, RTT_GRANUALITY);
}

CSimpleTCP::~CSimpleTCP()
{
//	Close();
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CSimpleTCP, CAsyncSocket)
	//{{AFX_MSG_MAP(CSimpleTCP)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCP member functions

void CSimpleTCP::OnReceive(int nErrorCode) 
{
	BOOL bError = FALSE;

	if ( m_bWorkMode == CLIENT )
	{
		TcpHdr rcvHdr;
		CString svrIP;
		UINT	svrPort;
		BOOL	bDupack = FALSE;

		InitSegment((void*)&rcvHdr, HEADER_SIZE );

		ReceiveFrom ( &rcvHdr, HEADER_SIZE, svrIP, svrPort );
		
		// Error Checking �κ� �߰� �ؾ���.
		if (m_bSimulEnded) goto EXIT_ONRECEIVE;

		if ( bError = m_errorGen.ErrorChecking(&rcvHdr))
			goto EXIT_ONRECEIVE;
		if ( rcvHdr.basetcphdr.FIN == 1 && m_TCPStatus == FIN_WAIT )
		{
			SendFINorACK(rcvHdr.basetcphdr.SeqNo+1);
			m_reTimer.DelTimeInfoForAck( rcvHdr.basetcphdr.AckNo, bDupack );
			m_segBuf.ReleaseBufForACK ( rcvHdr.basetcphdr.AckNo );
			m_bSimulEnded = TRUE;
			goto EXIT_ONRECEIVE;
			
		}
		if ( m_nFinForAckNo == rcvHdr.basetcphdr.AckNo && rcvHdr.basetcphdr.ACK==1)
		{
			m_TCPStatus = FIN_WAIT;
			History("Current Simple TCP Status : FIN_WAIT", BORA);
			goto EXIT_ONRECEIVE;
		}
		if ( rcvHdr.basetcphdr.ACK == 1 )
		{

			TRACE("\n\n\n/**************************************************************/\n");
			History("\n\n\n/**************************************************************/",0);
			TRACE("ACK Received => ACK no : %d, SERVER SEQ NO : %d\n", rcvHdr.basetcphdr.AckNo, rcvHdr.basetcphdr.SeqNo);
			
			bDupack = m_tcpSlidingWnd.IsDupack(rcvHdr.basetcphdr.AckNo);
			
			if ( bDupack ) {
				m_strTemp.Format("Duplicated ACK Received => ACK no : %d, SERVER SEQ NO : %d\n", rcvHdr.basetcphdr.AckNo, rcvHdr.basetcphdr.SeqNo);
				History(m_strTemp,RED);
			}
			else {
				m_strTemp.Format("Normal ACK Received => ACK no : %d, SERVER SEQ NO : %d\n", rcvHdr.basetcphdr.AckNo, rcvHdr.basetcphdr.SeqNo);
				History(m_strTemp,BLACK);
			}
			
			//--------------------------------------------/
			BOOL bUpdateRTO=FALSE;
			
			if (!bDupack) {
				 bUpdateRTO = m_rttTimer.RTTUpdate(rcvHdr.basetcphdr.AckNo);
			}
			else {
				m_strTemp.Format("No RTO Update for duplicate ACK"); 
				History(m_strTemp,BLUE);
			}
			if ( bUpdateRTO )
				m_calRTO.UpdateRTO ( rcvHdr, &m_reTimer, &m_rttTimer, bDupack );
			//--------------------------------------------/

			m_reTimer.DelTimeInfoForAck( rcvHdr.basetcphdr.AckNo, bDupack );
			m_segBuf.ReleaseBufForACK ( rcvHdr.basetcphdr.AckNo );
//			if ( m_TCPStatus == ESTABLISHED )
			m_tcpSlidingWnd.updateSlidingWnd(rcvHdr);

			if ( m_TCPStatus == ESTABLISHED ) {
				double elapsetime = (clock()-m_dDataStartTime)/CLOCKS_PER_SEC;
				RecordCwnd(m_tcpSlidingWnd.getCurCwnd(), elapsetime/(2.2));
				TRACE("Called RecordedCwnd : %d, %lf\n",m_tcpSlidingWnd.getCurCwnd(), elapsetime);
			}
			if ( bDupack ) // ���Ḧ ����.
				goto EXIT_ONRECEIVE;
		}
		
		if ( m_TCPStatus == ESTABLISHED )
		{
			if ( m_AppMode == FILE_TRANS_MODE && m_pSendingFile )
			{
				//if ( ((CFileTrans *)m_pSendingFile)->m_bSending )
				if ( m_segBuf.GetCount() > 0 )
					TransBufferedSeg(rcvHdr.basetcphdr.AckNo);

				if ( ((CFileTrans *)m_pSendingFile)->m_nSendingStatus == FILE_SENDING )
				{
					WORD nAvailableWnd = (WORD)m_tcpSlidingWnd.GetAvailWnd();
					//m_pSendingFile->PostMessage(WM_SENDING_AVAILABLE, 
					//	NORMAL_CALL_FILE_TRANSFER, MAKELPARAM(nAvailableWnd,0) );
					m_pSendingFile->SendMessage(WM_SENDING_AVAILABLE, 
						NORMAL_CALL_FILE_TRANSFER, MAKELPARAM(nAvailableWnd,0) );
				}
				if ( (((CFileTrans *)m_pSendingFile)->m_nSendingStatus==FILE_SEND_FINISHED) 
					&& (rcvHdr.basetcphdr.ACK == 1))
				{
					if ( rcvHdr.basetcphdr.AckNo == ((CFileTrans *)m_pSendingFile)->m_nEndingSeqNo)
					{
						m_pParentWnd->SendMessage(WM_FILE_TRANS_ENDED);
						// FIN ������ ���� ����..
					}
				}
			}
		}

		if ( ( rcvHdr.basetcphdr.SYN==1) && (m_TCPStatus==SYN_SENT) )
		{
			TRACE("�����κ��� SYN �޾ҽ��ϴ�.\n");
			// 
			m_TCPStatus = ESTABLISHED;
			History("Current Simple TCP Status : ESTABLISHED",BORA);
			// m_nAckedNo = rcvHdr.basetcphdr.ACK;
			// m_tcpSlidingWnd.SetAckedNo ( rcvHdr.basetcphdr.AckNo );

			// ����Ÿ�� ������ ���� ������. ACK ������. ����Ÿ ���׸�Ʈ��.

			if ( m_AppMode == FILE_TRANS_MODE && m_pSendingFile )
			{
				// ù ���� ����Ÿ �׷� ���۽ÿ��� ACK�� ���� ������.
				//m_pSendingFile->PostMessage(WM_SENDING_AVAILABLE, 
				//	FIRST_CALL_FILE_TRANSFER, rcvHdr.basetcphdr.SeqNo+1 );

				//------- ó�� ������ ����Ÿ�� ������ ������ �ð����� Cwnd ���� ---
				//m_dStartTime = clock();
				m_dDataStartTime = clock();
				RecordCwnd();
				//--------------------------------------------------------
				m_pSendingFile->SendMessage(WM_SENDING_AVAILABLE, 
					FIRST_CALL_FILE_TRANSFER, rcvHdr.basetcphdr.SeqNo+1 );
			}
			else 
			{
				TcpHdr tcphdr;
				InitSegment( (void*)&tcphdr, HEADER_SIZE );
				tcphdr.basetcphdr.ACK = 1;
				tcphdr.basetcphdr.AckNo = rcvHdr.basetcphdr.SeqNo+1;
				SendSegment(&tcphdr, HEADER_SIZE );
			}
		}
	}
	else if ( m_bWorkMode == SERVER ) 
	{
		CString cliIP;
		UINT	cliPort;
		Segment rcvSeg;
	
		CString temp;
		
		/*--------------------------------------------------*/
		InitSegment(&rcvSeg, SEG_SIZE );
		// first, get header information..
		
		int i = 0;
		//i = ReceiveFrom ( &(rcvSeg.tcphdr), HEADER_SIZE, cliIP, cliPort );
		DWORD dwReadLen;
		IOCtl(FIONREAD, &dwReadLen);
		// if ( dwReadLen == 
		TRACE("\n\n\n/**************************************************************/\n");
		//i = ReceiveFrom ( &rcvSeg, SEG_SIZE, cliIP, cliPort );
		//TRACE("ReceiveFrom => %d bytes readed \n", i);
		i = ReceiveFrom ( &rcvSeg, dwReadLen, cliIP, cliPort );
		TRACE("ReceiveFrom => %d bytes readed \n", i);
		// m_strTemp.Format("ReceiveFrom => %d bytes readed \n", i);
		//History(m_strTemp,0);
		/*--------------------------------------------------*/
		// Error Checking �κ� �߰� �ؾ���.
		if ( m_bSimulEnded ) goto EXIT_ONRECEIVE;
		if ( bError = m_errorGen.ErrorChecking(&rcvSeg))
			goto EXIT_ONRECEIVE;
		
		// TRUE : ���� ����. FALSE : ����->��Ŷ ������ ����.

		/*--------------------------------------------------*/
		if ( m_TCPStatus == ESTABLISHED && rcvSeg.tcphdr.basetcphdr.FIN == 1 )
		{
			SendACK(TRUE,FALSE,FALSE);
			Sleep(1000);
			SendACK(TRUE,FALSE,TRUE);
			History("Application closes connection", BLACK);
			History("Current Simple TCP Status : CLOSE_WAIT",BORA);
			m_TCPStatus = CLOSE_WAIT;
			goto EXIT_ONRECEIVE;
		}
		if ( m_TCPStatus == CLOSE_WAIT && rcvSeg.tcphdr.basetcphdr.ACK == 1 )
		{
			History("Current Simple TCP Status : CLOSEED",BORA);
			m_TCPStatus = CLOSED;
			m_bSimulEnded = TRUE;
			goto EXIT_ONRECEIVE;
		}
		if ( m_TCPStatus == ESTABLISHED )
		{
			
			BOOL bInOrder = FALSE;

			m_strTemp.Format("SERVER: data Received => CLIENT SEQ NO : %d\n",rcvSeg.tcphdr.basetcphdr.SeqNo);
			History(m_strTemp, BLACK);
			bInOrder = m_RcvBuf.CheckOrder( rcvSeg ) ;
			
			if ( bInOrder == FALSE ) // ���� �ȸ����� ����. ���� ������ 
			{
				TRACE("���ù� ���� ��������\n");
				m_RcvBuf.AddSegment(rcvSeg);
				// dupack ��������.
				
			}
			else 
			{
				// ���⿡ ����� �³� app�� �÷��ְ�����..
				//	m_RcvBuf.m_nRecentSentAckedNo += 1; // < �̰� �ӽ÷�,,

				// ���۸��Ȱ� �÷��ش�.
				m_RcvBuf.RcvInOrderSeq(rcvSeg.tcphdr.basetcphdr.SeqNo);
				// app�� �˷� �ش�. �׷��� �Ʒ��� ��ƾ�� ��� ó�������????????
				TRACE("���ù� ���� ����\n");
				
				
			}
			SendACK(bInOrder);
			goto EXIT_ONRECEIVE;
		}
		if ( (m_TCPStatus==SYN_RCVD) && (rcvSeg.tcphdr.basetcphdr.ACK==1) )
		{
			// Establishing connection.
			// Three-way handshake.
			TRACE ("Ŭ���̾�Ʈ�� ���� ������\n");
			m_TCPStatus = ESTABLISHED;
			History("Current Simple TCP Status : ESTABLISHED",BORA);
			History("Connection established", YEL);
			// ���� �˻��ؼ� ����Ÿ ������ app�� ������ �Ѵ�.
			// ����� �׳� ���Ϸ� ���� �ִ�.
			if ( rcvSeg.tcphdr.basetcphdr.TotalLen > HEADER_SIZE )
			{
				//if ( m_AppMode == FILE_TRANS_MODE )
				//	TRACE("SERVER : App File Sending\n");
				if ( rcvSeg.tcphdr.basetcphdr.Stream == S_FILE_TRANS_REQ_MODE)
				{

					ReceiveFile(rcvSeg);
				}
			}
			SendACK(TRUE);
			/*
			else if ( m_bConnected == TRUE ) // Closing connection.
			{								 // 
				TRACE ("Ŭ���̾�Ʈ�� ���� ������\n");
				m_bConnected = FALSE;
			}
			*/
			goto EXIT_ONRECEIVE;
		}
		/*--------------------------------------------------*/
		
		// ���� ������..
		temp.Format("[%s] %d: %s", cliIP, cliPort, rcvSeg.data);
		TRACE ("[%s] %d: %s\n", cliIP, cliPort, rcvSeg.data);
		// AfxMessageBox(temp);
		
		if ( (m_TCPStatus==CLOSED) && (rcvSeg.tcphdr.basetcphdr.SYN == 1) )
		{
			SetDstInfo (cliPort, cliIP) ;
			//AfxGetMainWnd()->GetActiveView()
			//( (CWnd *)m_pParentWnd )
			((CSimpleTCPDemoView*)m_pParentWnd) -> RcvClientInfo(cliPort, cliIP);

			TRACE("SERVER : SYN �޾ҽ��ϴ�.\n");
			
			m_TCPStatus = SYN_RCVD;
			History("Current Simple TCP Status : SYN_RCVD",BORA);
		//	TcpHdr tcphdr;
				
		//	InitSegment( (void*)&tcphdr, HEADER_SIZE );

		//	tcphdr.basetcphdr.SYN = 1;
		//	tcphdr.basetcphdr.ACK = 1;
		//	tcphdr.basetcphdr.AckNo = m_RcvBuf.GetSendingAckNo();
//			tcphdr.basetcphdr.TotalLen = HEADER_SIZE;
			SendACK(TRUE, TRUE);
			// SendSegment(&tcphdr, HEADER_SIZE, FALSE, rcvSeg.tcphdr.hdrOpt.time_stamp );
		}
		
	}
	else { 
		; 
	}

	EXIT_ONRECEIVE:
		CAsyncSocket::OnReceive(nErrorCode);
}

// ���� �������� �������� SYN������ 
int CSimpleTCP::ConnectToServer(CString dstIP, int dstPort, UINT nLocalPort)
{
//	int clientPort = 7789;
	//m_clientsocket.Create ( clientPort, SOCK_DGRAM );

	if ( m_nLocalPort == 0)
	{
		m_nLocalPort = nLocalPort;
	}

	if ( m_bWorkMode == CLIENT )
	{
		if ( m_bConnected == FALSE ) // ���� �������� SYN����.
		{
			TcpHdr tcphdr;

			if ( !Create ( m_nLocalPort, SOCK_DGRAM ) ) {
				AfxMessageBox ("���� ���� ����");
				TRACE("Error no : %d", GetLastError());
				return -1;
			}
			
			SetDstInfo(dstPort, dstIP);
			InitSegment( (void*)&tcphdr, HEADER_SIZE ) ;
			tcphdr.basetcphdr.SYN = 1;
			tcphdr.basetcphdr.TotalLen = HEADER_SIZE ;
			m_TCPStatus = SYN_SENT;
			History("Current Simple TCP Status : SYN_SENT",BORA);
			SendSegment(&tcphdr, HEADER_SIZE ) ;
		}
	}
	else if ( m_bWorkMode = SERVER )
	{
		AfxMessageBox("�����ε� �� �Լ� ȣ�� !! ");
	}
	return 0;
}

void CSimpleTCP::InitSegment(void *seg, int nSize)
{
	if ( nSize == HEADER_SIZE )
	{
		TcpHdr *p;
		p = (TcpHdr *)seg;
		memset ( p, 0, nSize);
	}
	else if ( nSize == SEG_SIZE )
	{
		Segment *p;
		p = (Segment *)seg;
		memset ( p, 0, nSize);
	}
}

int CSimpleTCP::SendSegment(void *seg, int nActualSize, BOOL bRetrans, double time_stamp )//, int dstPort, CString dstIP)
{
	int nSendingSize = 0;
	UINT nSeqNo = -1;

	if (nActualSize == HEADER_SIZE )
		nSendingSize = HEADER_SIZE ;
	else if ( nActualSize > HEADER_SIZE)
		nSendingSize = SEG_SIZE ;
	else TRACE ("Sending to abnormal Packet Size !!\n");

	if ( nActualSize == HEADER_SIZE )
	{
		TcpHdr *p;
		p = (TcpHdr *)seg;

		p->basetcphdr.CheckSum = 0xFFFF;
		if ( !bRetrans ) 
		{
			p->basetcphdr.SeqNo = m_curSeqNo;
			nSeqNo = m_curSeqNo;
		}
		else {
			nSeqNo = p->basetcphdr.SeqNo;
		}

		p->basetcphdr.TotalLen = nActualSize;
		
		if ( m_bWorkMode == CLIENT ) // Ŭ���̾�Ʈ�� ������ Ÿ�ӽ����� ����.
			p->hdrOpt.time_stamp = (double)clock() ;
		else // ������ Ŭ���̾�Ʈ�� time stamp ���.
			p->hdrOpt.time_stamp = time_stamp ;
		/*
		if ( m_bWorkMode == SERVER )
			m_RcvBuf.m_nRecentSentAck = p->basetcphdr.AckNo;
			*/
	}
	else if ( nActualSize > HEADER_SIZE )
	{
		Segment *p;
		p = (Segment *)seg;

		p->tcphdr.basetcphdr.CheckSum = 0xFFFF;
		if ( !bRetrans ) 
		{	p->tcphdr.basetcphdr.SeqNo = m_curSeqNo;
			nSeqNo = m_curSeqNo;
		}
		else {
			nSeqNo = p->tcphdr.basetcphdr.SeqNo;
		}
		p->tcphdr.basetcphdr.TotalLen = nActualSize ;

		if ( m_bWorkMode == CLIENT ) // Ŭ���̾�Ʈ�� ������ Ÿ�ӽ����� ����.
			p->tcphdr.hdrOpt.time_stamp = (double)clock() ;
		else // ������ Ŭ���̾�Ʈ�� time stamp ���.
			p->tcphdr.hdrOpt.time_stamp = time_stamp ;
		/*
		if ( m_bWorkMode == SERVER )
			m_RcvBuf.m_nRecentSentAck = p->tcphdr.basetcphdr.AckNo;
			*/
	} else { AfxMessageBox("��Ŷ ũ�� �̻�~!!"); }

	int RTO;
	BOOL	bError = FALSE;
	int nDelay = 0;

	if ( m_bWorkMode == CLIENT )
	{
		RTO = m_calRTO.GetMiliSecRTO();
		// ������ Ÿ�̸�
		TimeInfo t;
		t.Expires = RTO;
		if ( bRetrans ) 
		{	// �������� ��쿡�� �ڽ��� ������ ��ȣ ����.
			if ( nActualSize == HEADER_SIZE )
			{	t.SeqNo = ((TcpHdr*)seg)->basetcphdr.SeqNo;
				nSeqNo = ((TcpHdr*)seg)->basetcphdr.SeqNo;
			}
			else
			{	t.SeqNo = ((Segment*)seg)->tcphdr.basetcphdr.SeqNo;
				nSeqNo = ((Segment*)seg)->tcphdr.basetcphdr.SeqNo;
			}
		}
		else
		{
			t.SeqNo = m_curSeqNo; // ó�� �����ϴ� ����Ÿ�� ���ο� ������ ��ȣ ����.
			nSeqNo = m_curSeqNo;

		}
		if (bRetrans)	// ������ ��� TRUE..
			t.bRetrans = TRUE;
		else 
			t.bRetrans = FALSE;

		m_reTimer.AddTimer(t);// granuality�� �ְ� sorting�� �ؾ�������,,,,, �� ��
	//	m_reTimer.AddTimer(m_curSeqNo, nDelay+3000);
		TRACE ("CLIENT : RE Timer inserted : %d\n", RTO) ;
	}
	// ������ ����
	nDelay = m_delayGen.GetDelay();
	// ���� ���� ����.
	bError = m_errorGen.ErrorFilter(seg, nActualSize);
	//m_pTCP->RecordSeq(pSeg->m_SeqNo, m_pTCP->GetETime());
	//m_pTCP->RecordSeqCWnd(m_pTCP->m_tcpSlidingWnd.GetAvailWnd(), m_pTCP->GetETime());
	RecordSeq((float)(nSeqNo), GetETime());
	RecordSeqCWnd(m_tcpSlidingWnd.getCurCwnd(), GetETime());	
	// m_AppMode�� Ack�� ����Ÿ ���� �Ⱥ����� ����̸� window���� ������Ʈ ���ʿ�
	// ����. ( �Ʒ� �κ� ������ �ʿ��� �������..
	if ( (m_bWorkMode == CLIENT) &&
		(m_TCPStatus == ESTABLISHED) &&
		(m_AppMode == FILE_TRANS_MODE)
		) 
	{
		m_tcpSlidingWnd.AdjustSentWndForSending();
//		if ( bRetrans && m_tcpSlidingWnd.m_nDupackNum > 0 ) {
//			m_tcpSlidingWnd.m_nDupackNum -- ;
//			TRACE("Current m_nDupackNum %d ", m_tcpSlidingWnd.m_nDupackNum);
//		}
	}
	
	// Sending ���ۿ� ����.
	m_segBuf.SendSegment( seg, nSendingSize, m_nDstPort, m_strDstIP, nDelay, bError, bRetrans );
	
	TRACE("\n\n\n/**************************************************************/\n");
	TRACE("SENT SEGMENT => Sending Buffer size : %d\n", m_segBuf.m_ListSeg.GetCount() );

	History("\n\n\n/**************************************************************/\n", BLACK);
	if ( m_bWorkMode == CLIENT )
	{
		if ( !bRetrans )
			m_strTemp.Format("Sending %d-th packet at %f simulation time by normal transmission", nSeqNo, GetETime());
		else
			m_strTemp.Format("Sending %d-th packet at %f simulation time by retransmission by timeout", nSeqNo, GetETime());
		History(m_strTemp, BLACK);
	}

	
	// Start RTT Estimate,,
	if ( !m_rttTimer.IsWorking() && !bRetrans )
		m_rttTimer.RttStart(m_curSeqNo);
	
	if ( !bRetrans)
		m_curSeqNo = ( m_curSeqNo ++ ) %  SEQ_MAX ;
	
	if ( m_bWorkMode == CLIENT )
		TRACE ("Client current incremented seq no : %d\n", m_curSeqNo) ;
	else
		TRACE ("Server current incremented seq no : %d\n", m_curSeqNo) ;

	return 0;
}

void CSimpleTCP::SetDstInfo(UINT nDstPort, CString strDstIP)
{
	m_nDstPort = nDstPort;
	m_strDstIP = strDstIP;
}

void CSimpleTCP::RetransTimerExpired(UINT nExpiredSeqNo)
{
	// RTO update
	// sRTT �� ������Ʈ ���ϰ� RTO�� �ι�,,
	// �׸���,, �ٽ� ����,,
	m_calRTO.TimerExpired();
	m_tcpSlidingWnd.TimerExpired();

	TRACE("Retrans Timer Expired : expired seqNo : %d, CWND:%d\n", nExpiredSeqNo, m_tcpSlidingWnd.GetAvailWnd());
	m_strTemp.Format("Retrans Timer Expired and Retransmission => expired seqNo : %d", nExpiredSeqNo);
	History(m_strTemp,0);

	RetransSeg(nExpiredSeqNo);
}
// for using server only
void CSimpleTCP::SendACK(BOOL bInOrder, BOOL bSYNFlag, BOOL bFINFlag) 
{
	TcpHdr tcphdr;
				
	InitSegment( (void*)&tcphdr, HEADER_SIZE );
	
	m_strTemp.Format("\n\n/************************************************************/");
	History(m_strTemp, BLACK);

	// tcphdr.basetcphdr.SYN = 1;
	tcphdr.basetcphdr.ACK = 1;
	tcphdr.basetcphdr.SYN = bSYNFlag;
	tcphdr.basetcphdr.FIN = bFINFlag;

	if ( bInOrder ) {// normal ack
		tcphdr.basetcphdr.AckNo = m_RcvBuf.GetSendingAckNo();
		if (bFINFlag )
			m_strTemp.Format("Sending FIN packet at %f", GetETime());
		else
			m_strTemp.Format("Sending normal ACK packet expecting %d-th data packet from sender at %f",
			tcphdr.basetcphdr.AckNo, GetETime());
		History(m_strTemp, BLACK);
	}
	else {// dupack
		tcphdr.basetcphdr.AckNo = m_RcvBuf.GetRecentAckNo();
		m_strTemp.Format("Sending duplicate ACK packet expecting %d-th data packet from sender at %f",
			tcphdr.basetcphdr.AckNo, GetETime());
		History(m_strTemp, RED);
	}
	tcphdr.basetcphdr.TotalLen = HEADER_SIZE;
	SendSegment(&tcphdr, HEADER_SIZE );
}

BOOL CSimpleTCP::GetWorkMode()
{
	return m_bWorkMode;
}

void CSimpleTCP::SendFile(CWnd *pFile, CString dstIP, int nServerPort, UINT nLocalPort)
{
	if ( !pFile ) { TRACE("Wrong File Operation\n"); return; }
	
	m_pSendingFile = pFile;
	((CFileTrans *)m_pSendingFile)->ReadyToSend(this);
	ConnectToServer(dstIP, nServerPort, nLocalPort);
}

void CSimpleTCP::ReceiveFile(Segment seg)
{
	((CSimpleTCPDemoView *)m_pParentWnd)->ReceiveFile(seg);
}
BOOL CSimpleTCP::RecordSeq(float SeqNo, double time)
{
	CSimpleTCPDemoView *pParent = NULL;
	pParent = (CSimpleTCPDemoView*)m_pParentWnd;
	m_tempDBSeqNo.data = (float)SeqNo;
	m_tempDBSeqNo.time = (float)time;
	return pParent->AddChartData(m_tempDBSeqNo, SEQNO, CHART_SEQ);
}

BOOL CSimpleTCP::RecordSeqCWnd(int nCWnd, double time)
{
	CSimpleTCPDemoView *pParent = NULL;
	pParent = (CSimpleTCPDemoView*)m_pParentWnd;
	m_tempDBCwnd.data = (float)nCWnd;
	m_tempDBCwnd.time = (float)time;
	return pParent->AddChartData(m_tempDBCwnd, CWND, CHART_SEQ);
}

BOOL CSimpleTCP::RecordCwnd(double nCwnd, double time)//CWND,CHART_CWND); <- ������ ���߿� �ʿ���..
{
	CSimpleTCPDemoView *pParent = NULL;
	pParent = (CSimpleTCPDemoView*)m_pParentWnd;

	float ACKGAP = 0.5;
	int RTT = 2;

	if (nCwnd == 0.0) 
		nCwnd = m_tcpSlidingWnd.getCurCwnd();
	if (time == 0.0)
		time = ((clock()-m_dDataStartTime)/CLOCKS_PER_SEC)/1000; //getcurtimeMili();

	int recentT = (int)pParent->GetChartPtr()->GetRecentRecTime(CWND,CHART_CWND);

	if ( (recentT==((int)time)))
	{	// �߰� �� ����.->��� ���������� ������Ʈ
		m_tempDBCwnd.data = (float)nCwnd;
		m_tempDBCwnd.time = (float)time;//(int)(time/RTT);
		TRACE("updated chart %f\n", time);
		return pParent->AddChartData(m_tempDBCwnd, CWND,CHART_CWND, STAT_UPDATE);
	}
	else
	{	// �߰� �ؾ���->��̿� �ϳ��� �߰�.
		m_tempDBCwnd.data = (float)nCwnd;
		m_tempDBCwnd.time = (float)time;//(int)(time/RTT);//time;
		TRACE("added chart %f\n", time);
		return pParent->AddChartData(m_tempDBCwnd, CWND,CHART_CWND, STAT_ADD);
	}
//	m_tempDBCwnd.data = nCwnd;
//	m_tempDBCwnd.time = time;

	// get recent inserted time.
	

	
//	pParent->AddChartData(m_tempDBCwnd, CWND,CHART_CWND);

}

double CSimpleTCP::GetETime()
{
	//return (clock()-m_dStartTime)/CLOCKS_PER_SEC;
	return (clock()-m_dSimulStartTime)/CLOCKS_PER_SEC;
}

void CSimpleTCP::History(CString strMsg, int nMsgType)
{
	((CSimpleTCPDemoView*)m_pParentWnd)->History(strMsg, nMsgType);
}

double CSimpleTCP::GetSystemTime()
{
	return ((CSimpleTCPDemoView*)m_pParentWnd)->GetSystemTime();
}

void CSimpleTCP::RetransSeg(UINT nSeqNo)
{
	TcpHdr hdr;
	Segment seg;

	CSegment *pSeg = NULL;
	pSeg = m_segBuf.GetSegment(nSeqNo);
	
	if (pSeg==NULL) {  
		AfxMessageBox("������ �Ϸ��µ� ���׸�Ʈ ����?"); 
		return; 
	}
	
	// pSeg->m_bRetrans = TRUE;

	if ( m_tcpSlidingWnd.GetAvailWnd() <= 0 ) 
	{	// ���� ������ ����������� ������ Ÿ�̸� ������ return;
		TimeInfo t;
		t.SeqNo = pSeg->m_SeqNo;
		t.Expires = m_calRTO.GetMiliSecRTO();
		t.bRetrans = TRUE;
		m_reTimer.AddTimer(t);
		m_strTemp.Format("No Available Window So RTO is doubled");
		History(m_strTemp, YEL);
		return;
	}

	if ( pSeg->m_nSegLen == HEADER_SIZE )
	{
		hdr = pSeg->m_TcpHdr;
	//	m_segBuf.DeleteSegment(nExpiredSeqNo);
		SendSegment(&hdr, hdr.basetcphdr.TotalLen, TRUE);
	}
	else 
	{
		seg = pSeg->m_TcpSegment;
	//	m_segBuf.DeleteSegment(nExpiredSeqNo);
		SendSegment(&seg, seg.tcphdr.basetcphdr.TotalLen, TRUE);
	}
}

void CSimpleTCP::TransBufferedSeg(int nAckedNo)
{
	WORD nAvailWnd = (WORD)m_tcpSlidingWnd.GetAvailWnd();
	int nBuf = m_segBuf.GetCount();
	
	int nSeqNo = nAckedNo;

	CSegment *pSeg = NULL;
	TRACE ("TransBufferedSeg �ҷ��� : Acked No : %d,Buf:%d,AvailWnd:%d",nSeqNo,nBuf,nAvailWnd);
	for ( int i = 0; i < nBuf && i < nAvailWnd; i++)
	{
		pSeg = m_segBuf.GetSegment( nSeqNo + i );
		if ( !pSeg)
			continue;
		if ( pSeg->m_bRetrans ) 
		{
			RetransSeg(nSeqNo + i);
			TRACE ("***** Seding Bufferd retrans data : %dth\n", nSeqNo + i);
		}
	}
}

void CSimpleTCP::CloseSocket()
{
	SendFINorACK(0); //FIN ����.
}

void CSimpleTCP::SendFINorACK(UINT nAckNo)
{
	TcpHdr tcphdr;
				
	InitSegment( (void*)&tcphdr, HEADER_SIZE );
	
	m_strTemp.Format("\n\n/************************************************************/");
	History(m_strTemp, BLACK);

	// tcphdr.basetcphdr.SYN = 1;
	if ( m_bWorkMode == CLIENT && m_TCPStatus == ESTABLISHED )
	{
		tcphdr.basetcphdr.FIN = 1;
		m_strTemp.Format("Sending FIN packet at %f", GetETime());
		History(m_strTemp, RED);
		m_TCPStatus = CLOSING;
		m_nFinForAckNo = m_curSeqNo + 1;
		History("Application closes connection", BLACK);
		History("Current Simple TCP Status : CLOSING", BORA);
		
	}
	if (  m_bWorkMode == CLIENT && m_TCPStatus == FIN_WAIT )
	{
		tcphdr.basetcphdr.ACK = 1;
		tcphdr.basetcphdr.AckNo = nAckNo;
		m_strTemp.Format("Sending ACK packet(Ack no:%d) response for receiver's FIN at %f",
			tcphdr.basetcphdr.AckNo, GetETime());
		History(m_strTemp, BLACK);
		m_TCPStatus = CLOSED;
		History("Current Simple TCP Status : CLOSED",BORA);
	}
	tcphdr.basetcphdr.TotalLen = HEADER_SIZE;
	SendSegment(&tcphdr, HEADER_SIZE );
	
}

