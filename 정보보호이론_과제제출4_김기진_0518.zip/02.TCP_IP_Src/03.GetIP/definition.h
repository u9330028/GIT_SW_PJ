#ifndef _DEFINITION_H
#define _DEFINITION_H

// Working mode
#define SERVER 0
#define CLIENT 1

#define SEQ_MAX ((UINT)2147483647)//((UINT)4294967296)

// App operation mode
#define NONE_MODE 0
#define FILE_TRANS_MODE 1

// socket trans mode
#define S_NORMAL_MODE	0
#define S_FILE_TRANS_REQ_MODE	1
#define S_FILE_TRANS_MODE		2

/*----- file trans status ---*/
// file transfer status
#define FILE_NONE_STATUS	0
// for sender
#define FILE_READY_TO_SEND	1
#define FILE_SEND_FINISHED	2
#define FILE_SENDING		3
// for receiver
#define FILE_READY_TO_RCV	4
#define FILE_RECEIVING		5
/*---------------------------*/

// window message
#define WM_SENDING_AVAILABLE (WM_USER + 1)
#define WM_FILE_TRANS_ENDED (WM_USER + 2)

// size information
#define DATA_GRAM_SIZE 42
#define FILE_INFO_SIZE 38 // DATA_GRAM_SIZE -sizeof(LONG);

// file seding mode
#define FIRST_CALL_FILE_TRANSFER 1
#define NORMAL_CALL_FILE_TRANSFER 2

/*------- tcp status -------*/
#define CLOSED		1
#define ESTABLISHED 2
// #define 

// server
#define LISTENNING	10
#define SYN_RCVD	11
#define CLOSE_WAIT	12

// client
#define SYN_SENT	111
#define CLOSING		112
#define FIN_WAIT	113

/*---------------------------*/

/*---------------------------*/
// application env..
/*---------------------------*/
// minumum size limit.
#define APPWIDTH 700
#define APPHEIGHT 600

//----------------------------
#define MAX_DB_SIZE 500

// type of chart data
#define CWND		1
#define SEQNO		2

// mode of chart drawing
#define CHART_CWND	1
#define CHART_SEQ	2

#define STAT_UPDATE 1
#define STAT_ADD	2


// timer type
#define TIMER_TYPE_DELAY 1
#define TIMER_TYPE_RETRANS	2
#define TIMER_TYPE_RTT		3
// timer sort mode
#define SORT_BY_SEQ_NO 1
#define SORT_BY_EXPIRES 2

#define DELAY_GRANUALITY	1
#define RETRANS_GRANUALITY	500
#define RTT_GRANUALITY		500
// network param.
#define OPT_DELAY_FIXED		0
#define OPT_DELAY_RANDOM	1
#define OPT_DELAY_NONE		2
#define OPT_ERROR_FIXED		0
#define OPT_ERROR_SEQ		1
#define OPT_ERROR_NONE		2

#define ERROR_SEQ_NO_MAX 100

#define BLACK 0
#define RED 1
#define BLUE 2
#define BORA 3
#define YEL 4
#endif