#if !defined(AFX_STATCHART_H__72088D44_4C56_4859_AD67_843C12F4FC96__INCLUDED_)
#define AFX_STATCHART_H__72088D44_4C56_4859_AD67_843C12F4FC96__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatChart.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStatChart window
#include "Scatter.h"
#include "packet.h"	// Added by ClassView

class CStatChart : public CWnd
{
// Construction
public:
	CStatChart();

// Attributes
public:
	enum {MARK_SIZE = 3};
// Operations
public:
//	float x[5];
//	float y[5];

	COLORREF m_nBkColor;
	CLinear<float> m_Linear;
//	CTPoint<float> pt[5];
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStatChart)
	//}}AFX_VIRTUAL

// Implementation
public:
	float m_cwnd_db_time[MAX_DB_SIZE];
	float m_cwnd_db_data[MAX_DB_SIZE];
	float m_seqno_db_time[MAX_DB_SIZE];
	float m_seqno_db_data[MAX_DB_SIZE];

//	Database m_seqno_db[MAX_DB_SIZE];
	int m_nCwndDBSize;
	int m_nSeqNoSize;

	BOOL m_bCanDraw;
	void RecalcSize();
	BOOL m_bGrid;
	BOOL m_bTitle;
	void DrawFrame(CRect& rect, COLORREF cr, const char* Title);
	void DrawChart(CRect& rect);
	virtual ~CStatChart();

	// Generated message map functions
protected:
	//{{AFX_MSG(CStatChart)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATCHART_H__72088D44_4C56_4859_AD67_843C12F4FC96__INCLUDED_)
