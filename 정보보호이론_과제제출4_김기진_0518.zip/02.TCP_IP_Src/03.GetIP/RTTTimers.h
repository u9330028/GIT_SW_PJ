#ifndef	___multimedia_rtt_timers___
#define	___multimedia_rtt_timers___


#include	<mmsystem.h>

//class CRetransTimer;
//#include "MyTimer.h"
#include "RTTEstimator.h"

class CRTT_Timer //: public CObject
{
public:
	
	CRTT_Timer(UINT resolution);
	virtual ~CRTT_Timer();

	UINT	getTimerRes() { return timerRes; }

	BOOL	startTimer ( CRTTEstimator *pParent, UINT period, bool oneShot = FALSE);
	BOOL	stopTimer();

	void timerProc() { m_pParent->TimerProcTick(); }
	// virtual void timerProc() { m_pParent.TimerProc(timerID) };
protected:
	CRTTEstimator *m_pParent;
	UINT	timerRes;
	UINT	timerId;
};


#endif