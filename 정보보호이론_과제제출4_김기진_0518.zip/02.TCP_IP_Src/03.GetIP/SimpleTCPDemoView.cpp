// SimpleTCPDemoView.cpp : implementation of the CSimpleTCPDemoView class
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"

#include "SimpleTCPDemoDoc.h"
#include "SimpleTCPDemoView.h"
#include "FileTrans.h"
#include "FileRcv.h"
#include "SimpleTCP.h"
//#include "StatChart.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoView

IMPLEMENT_DYNCREATE(CSimpleTCPDemoView, CFormView)

BEGIN_MESSAGE_MAP(CSimpleTCPDemoView, CFormView)
	//{{AFX_MSG_MAP(CSimpleTCPDemoView)
	ON_BN_CLICKED(IDC_BTN_NETWORK_PARAMETER, OnBtnNetworkParameter)
	ON_BN_CLICKED(IDC_BTN_FILE_SELECT, OnBtnFileSelect)
	ON_BN_CLICKED(IDC_OPT_WORKINGMODE_SERVER, OnOptWorkingmodeServer)
	ON_BN_CLICKED(IDC_OPT_WORKINGMODE_CLIENT, OnOptWorkingmodeClient)
	ON_BN_CLICKED(IDC_BTN_WORK, OnBtnWork)
	ON_BN_CLICKED(IDC_BTN_EXIT, OnBtnExit)
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_MESSAGE(WM_FILE_TRANS_ENDED, OnFileTransEnded)
	ON_BN_CLICKED(IDC_BTN_TEST, OnBtnTest)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoView construction/destruction

CSimpleTCPDemoView::CSimpleTCPDemoView()
	: CFormView(CSimpleTCPDemoView::IDD)
{
	//{{AFX_DATA_INIT(CSimpleTCPDemoView)
	m_nWorkingMode = -1;
	m_strLocalIP = _T("");
	m_nWorkingPortNo = 0;
	m_nDstPortNo = 0;
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	m_pTabTcpHistory = NULL;
	m_pStatChart = NULL;
	m_pStatSeq = NULL;

}

CSimpleTCPDemoView::~CSimpleTCPDemoView()
{
	if ( m_pServerSocket )
		delete m_pServerSocket;
	if ( m_pClientSocket )
		delete m_pClientSocket;
	if ( m_pSendingFile )
		delete m_pSendingFile;
	if ( m_pRcvFile )
		delete m_pRcvFile;
}

void CSimpleTCPDemoView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSimpleTCPDemoView)
	DDX_Control(pDX, IDC_ENV_ERROR, m_ctrlEnvError);
	DDX_Control(pDX, IDC_ENV_DELAY, m_ctrlEnvDelay);
	DDX_Control(pDX, IDC_TAB_HISTORY_STATISTICS, m_ctrlWediTab);
	DDX_Control(pDX, IDC_DST_PORT_LABEL, m_ctrlDstPortLabel);
	DDX_Control(pDX, IDC_IP_DST, m_ctrlDstIP);
	DDX_Control(pDX, IDC_BTN_WORK, m_ctrlBtnWork);
	DDX_Control(pDX, IDC_SELECTED_FILENAME, m_ctrlSelectedFileName);
	DDX_Radio(pDX, IDC_OPT_WORKINGMODE_SERVER, m_nWorkingMode);
	DDX_Text(pDX, IDC_LOCAL_IP_LABEL, m_strLocalIP);
	DDX_Text(pDX, IDC_EDIT_WORKING_PORT_NUM, m_nWorkingPortNo);
	DDX_Text(pDX, IDC_EDIT_DST_PORT_NUM, m_nDstPortNo);
	//}}AFX_DATA_MAP
}

BOOL CSimpleTCPDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CSimpleTCPDemoView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	InitVariable(); // InitBaseEnv�� ���� �ٲ�� �ȵ�.
	InitBaseEnv();
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoView printing

BOOL CSimpleTCPDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSimpleTCPDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSimpleTCPDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CSimpleTCPDemoView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoView diagnostics

#ifdef _DEBUG
void CSimpleTCPDemoView::AssertValid() const
{
	CFormView::AssertValid();
}

void CSimpleTCPDemoView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

/*
CSimpleTCPDemoDoc* CSimpleTCPDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimpleTCPDemoDoc)));
	return (CSimpleTCPDemoDoc*)m_pDocument;
}
*/
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoView message handlers
#define DFL_SERVER_PORT 7788
#define DFL_CLIENT_PORT 7799

void CSimpleTCPDemoView::InitVariable()
{
	m_dSysStartTime = clock();
//	m_pTCPHistory = NULL;
	m_pSendingFile = NULL;
	m_pRcvFile = NULL;
	m_pClientSocket = NULL;
	m_pServerSocket = NULL;

	//
	m_nWorkingMode = SERVER;
	if ( m_nWorkingMode == SERVER )
	{ m_nWorkingPortNo = DFL_SERVER_PORT; m_nDstPortNo = 0; }
	else
	{ m_nWorkingPortNo = DFL_CLIENT_PORT; m_nDstPortNo = DFL_SERVER_PORT; }

	BYTE ip4,ip3,ip2,ip1;	
	m_strLocalIP = GetLocalIP(ip4,ip3,ip2,ip1);
	m_ctrlDstIP.SetAddress(ip4,ip3,ip2,ip1);
	
	CString temp;
	temp.Format("fixed : (%dms)", m_NetParam.m_nFixedDelay);
	m_ctrlEnvDelay.SetWindowText(temp);
	temp.Format("fixed rate : (%4.2f)", m_NetParam.m_fFixedRate);
	m_ctrlEnvError.SetWindowText(temp);
	UpdateData(FALSE);

	if ( m_pClientSocket )
	{
		m_pClientSocket->m_delayGen.SetDelayParam (
			m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
			m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
		);
		m_pClientSocket->m_errorGen.SetErrorParam (
			m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
			m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
		);
	}
	if ( m_pServerSocket )
	{
		m_pServerSocket->m_delayGen.SetDelayParam (
			m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
			m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
		);
		m_pServerSocket->m_errorGen.SetErrorParam (
			m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
			m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
		);
	}
}

void CSimpleTCPDemoView::InitBaseEnv()
{
	m_ctrlWediTab.SetNormalColor(RGB(100, 100, 100));
	m_ctrlWediTab.SetMouseOverColor(RGB(255, 255, 255));
	m_pTabTcpHistory = new CTcpHistoryDlg;
	m_pTabTcpHistory -> Create( CTcpHistoryDlg::IDD, &m_ctrlWediTab);
	m_ctrlWediTab.AddTab(m_pTabTcpHistory, "Simple TCP History", 0);

//	m_ctrlWediTab.SetNormalColor(RGB(100, 100, 100));
//	m_ctrlWediTab.SetMouseOverColor(RGB(255, 255, 255));
//	m_ctrlWediTab.SetNormalColor(RGB(100, 100, 100));
//	m_ctrlWediTab.SetSelectedColor(RGB(0, 0, 255));
	//m_ctrlWediTab.SetSelectedColor(RGB(50, 50, 50));
//	m_ctrlWediTab.SetMouseOverColor(RGB(255, 255, 255));

	
	m_pStatChart = new CStatChartDlg;
	m_pStatChart -> Create( CStatChartDlg::IDD, &m_ctrlWediTab);
	m_ctrlWediTab.AddTab(m_pStatChart, "CWND", 0);
	m_ctrlWediTab.SetNormalColor(RGB(100, 100, 100));
	m_ctrlWediTab.SetMouseOverColor(RGB(255, 255, 255));
	m_pStatSeq = new CStatSeqDlg;
	m_pStatSeq -> Create( CStatSeqDlg::IDD, &m_ctrlWediTab);
	m_ctrlWediTab.AddTab(m_pStatSeq, "Sequence number", 0);
	m_ctrlWediTab.SetNormalColor(RGB(100, 100, 100));
	m_ctrlWediTab.SetMouseOverColor(RGB(255, 255, 255));

	SendMessage(WM_SIZE,0,0);
}

BOOL CSimpleTCPDemoView::GetFileInfo(CFileRcv *pRcvFile, Segment *seg)
{
	/*------------------------------*/
	// Setting File Information
	CString tempT;
	tempT.Format("%s", seg->data);
	
	int j = tempT.Find('*', 0);

	CString strFileInfo;
	CString	fileSize; 
	
	if ( j == -1 ) return FALSE;

	strFileInfo = tempT.Left(j);
	
	int nDalPos = strFileInfo.Find('&', 0);
	
	m_pRcvFile->m_strFileName = strFileInfo.Left(nDalPos);
	fileSize = strFileInfo.Right( strFileInfo.GetLength() - nDalPos - 1);
	
	m_pRcvFile->m_nFileSize = atol(fileSize);
	/*------------------------------*/

	TRACE("GetFileInfo: %s %ld",m_pRcvFile->m_strFileName, m_pRcvFile->m_nFileSize);


//	str	

	/*
	HFILE	hFile;
	OFSTRUCT	os;
	os.cBytes = sizeof(os);
	if (HFILE_ERROR == (hFile = OpenFile(szFile, &os, OF_CREATE)))
		return	FALSE;
	m_nFileLength = nLength;
	m_nTotalTransfer = 0;
	AttachFile(HFILE_ERROR, hFile);
	*/
	return TRUE;
}

void CSimpleTCPDemoView::ReceiveFile(Segment seg)
{
	if ( m_pRcvFile ) 
	{AfxMessageBox("������ �ް� �ִ� ���Դϴ�."); return; }

	m_pRcvFile = new CFileRcv(this);
	if ( !m_pRcvFile ) 
	{ AfxMessageBox("Out of memory!!"); return; }
	if (!GetFileInfo(m_pRcvFile, &seg)) 
		{ AfxMessageBox("���� �����̻�!!");return; }
	TRACE ("���� ��û ����. name:%s, size:%d", 
		m_pRcvFile->m_strFileName,m_pRcvFile->m_nFileSize);
}

LONG CSimpleTCPDemoView::OnFileTransEnded(WPARAM wParam, LPARAM lParam)
{
//	AfxMessageBox("TCP layer file trans ended");
	m_pClientSocket->CloseSocket();
	return 0;
}

void CSimpleTCPDemoView::OnBtnNetworkParameter() 
{
	if ( IDOK!=m_NetParam.DoModal()) return;
	
	CString temp;

	if (m_NetParam.m_nOptDelay == OPT_DELAY_FIXED)
	{
		temp.Format("Fixed : (%dms)", m_NetParam.m_nFixedDelay);
		m_ctrlEnvDelay.SetWindowText(temp);
	}
	else if (m_NetParam.m_nOptDelay == OPT_DELAY_RANDOM)
	{
		temp.Format("Random : (%dms~%dms)", 
			m_NetParam.m_nDelayRdLow, m_NetParam.m_nDelayRdHigh);
		m_ctrlEnvDelay.SetWindowText(temp);
	}
	else 
	{
		temp.Format("No Delay");
		m_ctrlEnvDelay.SetWindowText(temp);
	}

	if (m_NetParam.m_nOptError == OPT_ERROR_FIXED)
	{
		temp.Format("Fixed : (%4.2f)", m_NetParam.m_fFixedRate);
		m_ctrlEnvError.SetWindowText(temp);
	}
	else if (m_NetParam.m_nOptError == OPT_ERROR_SEQ)
	{
		temp.Format("Seq No : (%s)", m_NetParam.m_strErrorSeqNo);
		m_ctrlEnvError.SetWindowText(temp);
	}
	else
	{
		temp.Format("No Error Rate");
		m_ctrlEnvError.SetWindowText(temp);
	}

	if ( m_pClientSocket)
	{
		m_pClientSocket->m_delayGen.SetDelayParam (
			m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
			m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
			);
	
		m_pClientSocket->m_errorGen.SetErrorParam (
			m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
			m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
			);
	}
	if ( m_pServerSocket)
	{
		m_pServerSocket->m_delayGen.SetDelayParam (
			m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
			m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
			);
	
		m_pServerSocket->m_errorGen.SetErrorParam (
			m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
			m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
			);
	}
}

void CSimpleTCPDemoView::OnBtnFileSelect() 
{
	RevokeFileSelDlg();
}

BOOL CSimpleTCPDemoView::RevokeFileSelDlg()
{
	char BASED_CODE szFilter[] = "���� ���� ���� |*.*|";
	POSITION Position = NULL;
	CString strFullPath, strSubPath;
	CString strListItem;
	char strFileNameBuffer[4096];				// ���� ������ �̸����� �����ϴ� �κ�..
	
	memset(strFileNameBuffer, 0, 4096);

	CFileDialog dlg(TRUE, "*.*", 
		"������ ���� �ϼ���",
		OFN_HIDEREADONLY |     
		OFN_READONLY |
		// OFN_ALLOWMULTISELECT |
		OFN_FILEMUSTEXIST
		, szFilter, this);
	// AfxMessageBox(DefaultFileName);
    dlg.m_ofn.lpstrTitle = "�� ������ ���� �ϼ��� ��";
	dlg.m_ofn.lpstrFile = strFileNameBuffer;
	dlg.m_ofn.nMaxFile = 4096;

	int i = dlg.DoModal();		// ���� �����ϴ� �޷α׸� ����.
	if ( i == IDOK )
	{
		CString strFileName;
		strFileName = dlg.GetFileName();
		//AfxMessageBox(strFileName);
		// AfxMessageBox(dlg.GetPathName());
		m_ctrlSelectedFileName.SetWindowText(strFileName);
		// TRACE("Size : %d",GetFileSize(dlg.GetPathName()));
		if ( m_pSendingFile ) return FALSE;
		m_pSendingFile = new CFileTrans(this);
		m_pSendingFile->m_nFileSize = GetFileSize(dlg.GetPathName()) ;
		m_pSendingFile->m_strFileName = dlg.GetFileName();
		m_pSendingFile->m_strFullName = dlg.GetPathName();
	}
	return TRUE;
}

LONG CSimpleTCPDemoView::GetFileSize(CString strFile)
{
	CFile file;
	CFileStatus fileState;
	LONG	fileSize = 0;

	if ( file.Open( (LPCTSTR)strFile, CFile::modeRead | CFile::shareDenyNone )  == FALSE )
		return (LONG)(-1);
	file.GetStatus(fileState);
	fileSize = fileState.m_size;
	file.Close();

	return fileSize;
}

CString CSimpleTCPDemoView::GetLocalIP(BYTE &ip4,BYTE &ip3,BYTE &ip2,BYTE &ip1)
{
	TCHAR stTemp[255];
	CString temp;
	
	gethostname( stTemp, 255 );
	hostent *pHostent = gethostbyname( stTemp );
	IN_ADDR inAddr;
	CopyMemory( &inAddr, pHostent->h_addr_list[0], pHostent->h_length );
//	temp = inet_ntoa (*(struct in_addr *)*pHostent->h_addr_list);

	temp.Format("%03d.%03d.%03d.%03d", inAddr.S_un.S_un_b.s_b1, inAddr.S_un.S_un_b.s_b2,
		inAddr.S_un.S_un_b.s_b3, inAddr.S_un.S_un_b.s_b4 );
	ip4 = inAddr.S_un.S_un_b.s_b1;
	ip3 = inAddr.S_un.S_un_b.s_b2;
	ip2 = inAddr.S_un.S_un_b.s_b3;
	ip1 = inAddr.S_un.S_un_b.s_b4;

	return temp;
}

void CSimpleTCPDemoView::OnOptWorkingmodeServer() 
{
	m_nWorkingMode = SERVER;
	m_ctrlDstPortLabel.SetWindowText("Client Port :");
	m_ctrlBtnWork.SetWindowText("&Listen");
	UpdateData(FALSE);
}

void CSimpleTCPDemoView::OnOptWorkingmodeClient() 
{
	m_nWorkingMode = CLIENT;

	m_nWorkingPortNo = DFL_CLIENT_PORT;
	m_ctrlDstPortLabel.SetWindowText("Server Port :");
	m_ctrlBtnWork.SetWindowText("&Connect");
	if ( m_nDstPortNo == 0 )
		m_nDstPortNo = DFL_SERVER_PORT;
	UpdateData(FALSE);

}

void CSimpleTCPDemoView::OnBtnWork() 
{
	UpdateData();
	// if ( !(m_nDstPortNo > 0) & m_nWorkingMode == CLIENT) { AfxMessageBox("���� ��Ʈ ��ȣ�� ����� �Է����ּ���"); return;}
	if ( !(m_nWorkingPortNo > 0) ) { AfxMessageBox("��Ʈ ��ȣ�� ����� �Է����ּ���"); return;}

	if ( m_nWorkingMode == CLIENT)
	{
		if ( (m_nDstPortNo <= 0)) { AfxMessageBox("���� ��Ʈ ��ȣ�� ����� �Է����ּ���"); return;}

		BYTE ip4, ip3, ip2, ip1;
		CString tempServerIP;

		m_ctrlDstIP.GetAddress(ip4,ip3,ip2,ip1);
		tempServerIP.Format("%d.%d.%d.%d",ip4, ip3, ip2, ip1 );

		m_strDstIP = tempServerIP;

		if ( !m_pClientSocket)
			m_pClientSocket = new CSimpleTCP(this);
/*
		if ( m_pClientSocket ) { 
			AfxMessageBox("������ ���� �ֽ��ϴ�.");
			return;
		}
		m_pClientSocket = new CSimpleTCP(this);
*/
		m_pClientSocket -> m_bWorkMode = CLIENT;	//�Է� ���ڵ��� �ٱ������.
		m_pClientSocket -> m_AppMode = FILE_TRANS_MODE;

		m_pClientSocket->m_dSimulStartTime = clock();	
		/*---------------------------*/
		if ( m_pClientSocket )
		{
			m_pClientSocket ->m_delayGen.SetDelayParam (
				m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
				m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
			);
			m_pClientSocket ->m_errorGen.SetErrorParam (
				m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
				m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
			);
		}
		/*
		if ( m_pServerSocket )
		{
			m_pServerSocket ->m_delayGen.SetDelayParam (
				m_NetParam.m_nOptDelay, m_NetParam.m_nFixedDelay,
				m_NetParam.m_nDelayRdLow, m_NetParam.m_nFixedDelay
			);
			m_pServerSocket ->m_errorGen.SetErrorParam (
				m_NetParam.m_nOptError, m_NetParam.m_fFixedRate,
				m_NetParam.m_arErrorSeqNo, m_NetParam.m_nNumOfErrorSeqNo
			);
		}
		*/
		/*---------------------------*/
		if ( !m_pSendingFile ) { AfxMessageBox("�����̸��� ���׿�"); return; }
		m_pClientSocket -> SendFile(m_pSendingFile, tempServerIP, m_nDstPortNo, m_nWorkingPortNo );
	}	
	else
	{
		// int serverPort = 7788;
		m_pServerSocket = new CSimpleTCP(this);
		m_pServerSocket->m_bWorkMode = SERVER;
		
		m_pServerSocket->m_dSimulStartTime = clock();

		if ( m_pServerSocket->Create(m_nWorkingPortNo, SOCK_DGRAM) )
			TRACE ( "Listening...\n");
	}
	
	m_ctrlBtnWork.EnableWindow(FALSE);
}

void CSimpleTCPDemoView::RcvClientInfo(UINT cliPort, CString cliIP)
{
	m_nDstPortNo = cliPort;
	m_strDstIP = cliIP;

	BYTE ip4,ip3,ip2,ip1;	
	
	sscanf(m_strDstIP, "%d.%d.%d.%d", &ip4, &ip3, &ip2, &ip1);
	m_ctrlDstIP.SetAddress(ip4,ip3,ip2,ip1);

	UpdateData(FALSE);
}

void CSimpleTCPDemoView::OnBtnExit() 
{
	AfxGetMainWnd()->SendMessage(WM_CLOSE);	
	//ExitWindows(0);
}

void CSimpleTCPDemoView::OnDestroy() 
{
	CFormView::OnDestroy();
	
	if ( m_pTabTcpHistory )
		delete m_pTabTcpHistory ;
	if ( m_pStatChart )
		delete m_pStatChart ;
	if ( m_pStatSeq )
		delete m_pStatSeq ;
}

void CSimpleTCPDemoView::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);

	CRect   m_rcClient;
	GetClientRect(&m_rcClient);	

	if (m_ctrlWediTab.m_hWnd) {		// ����Ʈ�� ũ�� �̵�
		m_ctrlWediTab.SendMessage(WM_SIZE, 0, 0);
	}
}

void CSimpleTCPDemoView::OnBtnTest() 
{
	/*
	Database db;
	double time ;
	static float j = 0;
	
//	j += (rand()%3);

//	for ( int i = 0; i < 10; i ++)
//	{
		db.data = rand()%50 + (rand()%10);
		time = (clock() / CLOCKS_PER_SEC)%100;
		db.time = time;//rand()%58;
		m_pStatChart->AddCwnd(db);

		db.data = rand()%50 + (rand()%10);
		db.time = (clock() / CLOCKS_PER_SEC)%100;
		m_pStatChart->AddSeqNo(db);
		
//	}
//	m_pStatChart->m_ctrlChart.m_bCanDraw = TRUE;
*/

}

BOOL CSimpleTCPDemoView::AddChartData(Database db, int nType, int nMode, int nUpdateMode)
{
	if ( nMode==CHART_CWND )
	{
		if ( nType == CWND ) {
			if ( nUpdateMode == STAT_ADD ) {
				m_pStatChart->AddCwnd(db);
			}
			else if (nUpdateMode == STAT_UPDATE)
			{
				m_pStatChart->UpdateCwnd(db);
			}

		}
		else AfxMessageBox("�� �̻�Ÿ?CWND");
	}
	if ( nMode==CHART_SEQ)
	{
		if ( nType == SEQNO )
		{
			if ( nUpdateMode == STAT_ADD ) {
				m_pStatSeq->AddSeqNo(db);
			}
			else if (nUpdateMode == STAT_UPDATE)
			{
				m_pStatSeq->UpdateSeq(db);
			}
		}
		else if ( nType == CWND )
		{
			if ( nUpdateMode == STAT_ADD ) {
				m_pStatSeq->AddCwnd(db);
			}
			else if (nUpdateMode == STAT_UPDATE)
			{
			//	m_pStatSeq->UpdateSeq(db);
			}
		}
		else AfxMessageBox("�� �̻�Ÿ?CHART_CWND");
	}
	
	return TRUE;
}

CStatChartDlg * CSimpleTCPDemoView::GetChartPtr()
{
	return m_pStatChart;
}

static COLORREF crColor[5] = {RGB(0,0,0), RGB(200,0,0), RGB(0,0,200), RGB(239, 83, 239),RGB(127, 127, 0)} ;

void CSimpleTCPDemoView::History(CString strMsg, int nMsgType)
{
//	#define NORMAL 1
//#define DUPACK 2
	// #define RTOEXP 3
//	COLORREF crColor;
//	crColor = RGB(127, 127, 0);
	COLORREF Color = crColor[nMsgType];
	strMsg += "\r\n";
	m_pTabTcpHistory->m_ctrlTCPHistory.AddText(strMsg, Color );
}

double CSimpleTCPDemoView::GetSystemTime()
{
	return (double)((clock()-m_dSysStartTime)/CLOCKS_PER_SEC);
}

CStatSeqDlg * CSimpleTCPDemoView::GetSeqChartPtr()
{
	return m_pStatSeq;
}
