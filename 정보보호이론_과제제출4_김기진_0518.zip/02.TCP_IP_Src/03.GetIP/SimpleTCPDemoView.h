// SimpleTCPDemoView.h : interface of the CSimpleTCPDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLETCPDEMOVIEW_H__BE603A7C_52F9_4895_A8A5_6EF6AA0360B0__INCLUDED_)
#define AFX_SIMPLETCPDEMOVIEW_H__BE603A7C_52F9_4895_A8A5_6EF6AA0360B0__INCLUDED_


//#include "SimpleTCP.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "MyRichEdit.h"	// Added by ClassView
#include "Segment.h"
#include "TcpHistoryDlg.h"
#include "StatChartDlg.h"
#include "StatSeqDlg.h"
#include "WediTabCtrl.h"
#include "ModifyNetParam.h"	// Added by ClassView

//#include "FileTrans.h"	// Added by ClassView
//#include "FileRcv.h"

class CFileTrans;
class CFileRcv;
class CSimpleTCP;
//class CTcpHistoryDlg;
// class CStatChart;
class CSimpleTCPDemoView : public CFormView
{
protected: // create from serialization only
	CSimpleTCPDemoView();
	DECLARE_DYNCREATE(CSimpleTCPDemoView)

public:
	//{{AFX_DATA(CSimpleTCPDemoView)
	enum { IDD = IDD_SIMPLETCPDEMO_FORM };
	CStatic	m_ctrlEnvError;
	CStatic	m_ctrlEnvDelay;
	CWediTabCtrl	m_ctrlWediTab;
	CStatic	m_ctrlDstPortLabel;
	CIPAddressCtrl	m_ctrlDstIP;
	CButton	m_ctrlBtnWork;
	CEdit	m_ctrlSelectedFileName;
	int		m_nWorkingMode;
	CString	m_strLocalIP;
	UINT	m_nWorkingPortNo;	// �ڱ� �ڽ��� ��Ʈ ��ȣ.
	UINT	m_nDstPortNo;
	//}}AFX_DATA

// Attributes
public:
//	CSimpleTCPDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleTCPDemoView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	CStatSeqDlg * GetSeqChartPtr();
	double m_dSysStartTime;
	double GetSystemTime();
	void History(CString strMsg, int nMsgType);
	CModifyNetParam m_NetParam;
	CStatChartDlg * GetChartPtr();
	BOOL AddChartData(Database db, int nType, int nMode=CHART_CWND,int nUpdateMode=STAT_ADD);
	void RcvClientInfo(UINT cliPort, CString cliIP);
	CString m_strDstIP;
	CString GetLocalIP(BYTE &ip4,BYTE &ip3,BYTE &ip2,BYTE &ip1);
	LONG GetFileSize(CString strFile);
	BOOL RevokeFileSelDlg();
	LONG OnFileTransEnded(WPARAM wParam, LPARAM lParam);
	void ReceiveFile(Segment seg);
	BOOL GetFileInfo(CFileRcv *pRcvFile, Segment *seg);
	
	CSimpleTCP * m_pServerSocket;
	CSimpleTCP * m_pClientSocket;
	CFileTrans * m_pSendingFile;
	CFileRcv * m_pRcvFile;

	void InitVariable();

	//CMyRichEdit * m_pTCPHistory;
//	CMyRichEdit m_ctrlTCPHistory;
	void InitBaseEnv();
	virtual ~CSimpleTCPDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	CTcpHistoryDlg *m_pTabTcpHistory;
	CStatChartDlg *m_pStatChart;
	CStatSeqDlg *m_pStatSeq;
	//{{AFX_MSG(CSimpleTCPDemoView)
	afx_msg void OnBtnNetworkParameter();
	afx_msg void OnBtnFileSelect();
	afx_msg void OnOptWorkingmodeServer();
	afx_msg void OnOptWorkingmodeClient();
	afx_msg void OnBtnWork();
	afx_msg void OnBtnExit();
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBtnTest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/*
#ifndef _DEBUG  // debug version in SimpleTCPDemoView.cpp
inline CSimpleTCPDemoDoc* CSimpleTCPDemoView::GetDocument()
   { return (CSimpleTCPDemoDoc*)m_pDocument; }
#endif
*/
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLETCPDEMOVIEW_H__BE603A7C_52F9_4895_A8A5_6EF6AA0360B0__INCLUDED_)
