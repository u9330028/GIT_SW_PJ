// RcvBuf.cpp: implementation of the CRcvBuf class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCP.h"
#include "RcvBuf.h"
#include "packet.h"
#include "Segment.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRcvBuf::CRcvBuf()
{
	m_nRecentSentAckedNo = 0;
}

CRcvBuf::~CRcvBuf()
{
	DeleteAllRcvBuf();
}

UINT CRcvBuf::GetSendingAckNo()
{
	m_nRecentSentAckedNo ++ ;
	return m_nRecentSentAckedNo;
}

BOOL CRcvBuf::CheckOrder(Segment RcvSeg)
{
	return ( m_nRecentSentAckedNo == RcvSeg.tcphdr.basetcphdr.SeqNo) ;
}

// seq��ȣ��� �����Ͽ� �ִ´�.
BOOL CRcvBuf::AddSegment(Segment Seg)
{
	CSegment *pSeg=NULL, *pHead;
	pSeg = new CSegment();
	if ( pSeg == NULL ) return FALSE;

	pSeg->RcvSegment(Seg);
	
	m_strTemp.Format("Receiving %dth packet buffered current time : %f", Seg.tcphdr.basetcphdr.SeqNo, m_pTCP->GetETime());
	m_pTCP->History(m_strTemp, BLUE);

	
	if ( m_ListRcvBuf.IsEmpty() )
	{		m_ListRcvBuf.AddTail(pSeg);
	}
	else 
	{
		POSITION head, prev;
		for ( head = m_ListRcvBuf.GetHeadPosition(); (prev=head)!=NULL;)
		{
			pHead = (CSegment*)m_ListRcvBuf.GetNext(head);
			if ( pHead->m_SeqNo > Seg.tcphdr.basetcphdr.SeqNo )
			{
				m_ListRcvBuf.InsertBefore(head,pSeg);
			}
			if ( head == NULL )
				m_ListRcvBuf.InsertAfter(prev, pSeg);
		}
	}
	
	return TRUE;
}



UINT CRcvBuf::GetRecentAckNo()
{
	return m_nRecentSentAckedNo;
}

void CRcvBuf::DeleteAllRcvBuf()
{
	CSegment *pSeg = NULL;
	
	POSITION pos, prev;

	for ( pos = m_ListRcvBuf.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListRcvBuf.GetNext(pos);
		if ( pSeg ) 
		{
			delete pSeg;
			pSeg = NULL;
		}
	}
	m_ListRcvBuf.RemoveAll();	
	TRACE("Delete All Rcved Segment \n") ;
}

int CRcvBuf::RcvInOrderSeq(UINT nSeqNo)
{
	if ( m_ListRcvBuf.IsEmpty() ) 
		return 0;
	
	CSegment *pSeg = NULL;
	POSITION pos, prev;
	int nDeleted = 0;
	UINT nNextSeqNo = nSeqNo+1;

	for ( pos = m_ListRcvBuf.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListRcvBuf.GetNext(pos);
		if ( pSeg->m_SeqNo == nNextSeqNo )
		{
			nDeleted ++ ;
			// APP�� ����Ÿ �����.
			TRACE ("Delete RcvBuf : seq no %d\n", pSeg->m_SeqNo) ;
			m_strTemp.Format("Delete RcvBuf : seq no %d\n", pSeg->m_SeqNo) ;
			m_pTCP->History(m_strTemp, BLACK);

			delete pSeg;
			nNextSeqNo ++;
			m_ListRcvBuf.RemoveAt(prev);
			
		}
	}
	m_nRecentSentAckedNo = nNextSeqNo-1;
	m_strTemp.Format("Current m_nRecentSentAckedNo : %d", m_nRecentSentAckedNo );
	m_pTCP->History(m_strTemp, BLUE);
	return nDeleted;
}
