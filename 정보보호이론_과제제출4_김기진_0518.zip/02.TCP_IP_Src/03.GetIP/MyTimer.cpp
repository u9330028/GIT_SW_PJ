// MyTimer.cpp: implementation of the CMyTimer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "Simple.h"
//#include "Time_testDlg.h"
#include "MyTimer.h"
#include "mmTimers.h"
#include "SegBuf.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
//#include "definition.h"

CMyTimer::CMyTimer(CSegBuf *pParent)
{
	m_nTimerType = TIMER_TYPE_DELAY;
	m_pParent = pParent;
	m_pTimer = NULL;
	m_nGranuality = 0;

	m_nTempIdx = 0;
}

CMyTimer::~CMyTimer()
{
	m_pTimer->stopTimer();

	if ( m_pTimer)
		delete m_pTimer;

}

void CMyTimer::AddTimer(TimeInfo t, BOOL bSort, int nSortMode) // sorted by seqno or expire time
{
	CTimeInfo *pInfo=NULL, *pTail = NULL;
	pInfo = new CTimeInfo(t);
	
	if ((m_ListTimeInfo.IsEmpty()) || (bSort == FALSE)) //�ϳ��� ������ �׳� �ִ´�.
		m_ListTimeInfo.AddTail(pInfo);
	else{
		m_nTempIdx ++;

		POSITION tail, prev;
		for ( tail = m_ListTimeInfo.GetTailPosition(); (prev=tail) != NULL;)
		{
			pTail = (CTimeInfo*)m_ListTimeInfo.GetPrev(tail);
			if ( nSortMode == SORT_BY_SEQ_NO )
			{
				if (pTail->m_nSeqNo <= t.SeqNo) { // �߰�.
					m_ListTimeInfo.InsertAfter(tail,pInfo);
					break;
				}
				

			}
			else if (nSortMode == SORT_BY_EXPIRES )
			{
				if (pTail->m_nExpires <= (int)t.Expires ) { // �߰�.
					m_ListTimeInfo.InsertAfter(tail,pInfo);
					TRACE("SORT BY EXPIRES added seq no : %d,expires:%d, idx:%d\n", t.SeqNo,t.Expires, m_nTempIdx);
					break;
				}	
				if ( tail == NULL) 
				{
					m_ListTimeInfo.InsertBefore(prev,pInfo);
					TRACE("SORT BY EXPIRES added seq no : %d,expires:%d, idx:%d \n", t.SeqNo,t.Expires, m_nTempIdx);
				}
				
			}
		}
	}
	//pTail = pTailm_ListTimeInfo.GetTail();
	//m_ListTimeInfo.AddTail(pInfo);
}

void CMyTimer::TimerProc()
{
	CTimeInfo *pInfo = NULL;
	float res = 0;
	if ( m_ListTimeInfo.GetCount() == 0 ) return;

	POSITION	cur, prev;
//	pos = m_ListTimeInfo.GetHeadPosition();

//	pInfo = m_ListTimeInfo.GetNext(&pos);


	for ( cur = m_ListTimeInfo.GetHeadPosition(); (prev=cur)!=NULL; )
	{
		pInfo = (CTimeInfo *)m_ListTimeInfo.GetNext(cur);
	//	TRACE("CMyTimer : CTimeInfo ȣ��� pInfo seqno : %d\n", pInfo->m_nSeqNo );

		if ( pInfo->Tick(m_nGranuality) ) {	// expire �Ǿ�����..
			((CSegBuf*)m_pParent)->DelayTimerExpired(m_nTimerType, pInfo->m_nSeqNo);
			pInfo = (CTimeInfo *)m_ListTimeInfo.GetAt(prev);
			delete pInfo;
			pInfo = NULL;
			m_ListTimeInfo.RemoveAt(prev);
		}
	}
}

void CMyTimer::StartTimer( int nTimerID, int nGranuality)
{
	m_nGranuality = nGranuality;
	m_pTimer = new CMMTimers(0);
	m_pTimer->startTimer(this, nGranuality);
}
/*
CTimeInfo * CMyTimer::FindTimeInfo(UINT nSeqNo)
{
	CTimeInfo *pInfo = NULL;
	
	POSITION pos, prev;

	for ( pos = m_ListTimeInfo.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pInfo = (CTimeInfo *)m_ListTimeInfo.GetNext(pos);
		if ( pInfo->m_nSeqNo == nSeqNo)
		{
			return pInfo;
		}
	}
	return NULL;
}
*/
void CMyTimer::DeleteAllTimeInfo()
{
		
	POSITION cur;
	CTimeInfo *pInfo = NULL;
	for ( cur = m_ListTimeInfo.GetHeadPosition(); cur !=NULL; )
	{
		
		pInfo = (CTimeInfo *)m_ListTimeInfo.GetNext(cur);
		TRACE("CMyTimer destroy: CTimeInfo ȣ��� pInfo seqno : %d\n", pInfo->m_nSeqNo );
		delete pInfo;	
		pInfo = NULL;
	}
	m_ListTimeInfo.RemoveAll();
}
/*
BOOL CMyTimer::DeleteTimeInfo(UINT seqNo)
{
	return TRUE
}
*/