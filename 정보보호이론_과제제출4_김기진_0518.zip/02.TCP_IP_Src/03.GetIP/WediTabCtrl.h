#if !defined(AFX_WEDITABCTRL_H__164A6A21_7CFE_11D4_8FE9_0010B5543865__INCLUDED_)
#define AFX_WEDITABCTRL_H__164A6A21_7CFE_11D4_8FE9_0010B5543865__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WediTabCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWediTabCtrl window
#include <afxtempl.h>

// #include "define.h"

class CWediTabCtrl : public CTabCtrl
{
// Construction
public:
	CWediTabCtrl();

// Attributes
public:

protected:
	CArray<BOOL, BOOL> m_arrayStatusTab; //** enabled Y\N
// Operations
public:
	void AddTab(CWnd* pWnd, LPTSTR lpszCaption, int iImage =0);
	void EnableTab(int iIndex, BOOL bEnable = TRUE);
	void DeleteAllTabs();
	void DeleteTab(int iIndex);
	void SetTopLeftCorner(CPoint pt);
	BOOL IsTabEnabled(int iIndex);
	BOOL SelectTab(int iIndex);

	void SetDisabledColor(COLORREF cr);
	void SetSelectedColor(COLORREF cr);
	void SetNormalColor(COLORREF cr);
	void SetMouseOverColor(COLORREF cr);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWediTabCtrl)
	protected:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL m_bForceOverColor;
	BOOL IsMultiLine();
	virtual ~CWediTabCtrl();
	// Generated message map functions
protected:
	int m_iSelectedTab;

	POINT m_ptTabs;
	COLORREF m_crNormal;
	COLORREF m_crSelected;
	COLORREF m_crDisabled;
	COLORREF m_crMouseOver;

	int m_iIndexMouseOver;

	BOOL m_bMouseOver;
	BOOL m_bColorMouseOver;
	BOOL m_bColorNormal;
	BOOL m_bColorDisabled;
	BOOL m_bColorSelected;
	
	//{{AFX_MSG(CWediTabCtrl)
	afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WEDITABCTRL_H__164A6A21_7CFE_11D4_8FE9_0010B5543865__INCLUDED_)
