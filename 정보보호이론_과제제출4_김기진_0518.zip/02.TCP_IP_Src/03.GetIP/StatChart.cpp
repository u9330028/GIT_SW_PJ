// StatChart.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "StatChart.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStatChart

CStatChart::CStatChart()
{
	m_bTitle = TRUE;
	m_bGrid = TRUE;
	m_bCanDraw = TRUE;

	m_Linear.EnableMemoryDraw(TRUE);
	m_Linear.EnableLegend(TRUE);
	m_Linear.SetRange(0,0,40,40);
	//m_Linear.SetXAxisNumOfBlock(10);
	m_nBkColor = m_Linear.GetBackColor();
	m_Linear.SetBackColor(m_nBkColor);

	m_nCwndDBSize = 0;
	m_nSeqNoSize = 0;
/*
	x[0]  = 5;
	y[0]  = 70;
	x[1]  = 30;
	y[1]  = 30;
	x[2]  = 40;
	y[2]  = 4;
	x[3]  = 70;
	y[3]  = 50;
	x[4]  = 80;
	y[4]  = 80;
		
	pt[0] = CTPoint<float>(4,  20); 
	pt[1] = CTPoint<float>(35, 40); 
	pt[2] = CTPoint<float>(50,  4); 
	pt[3] = CTPoint<float>(60, 60); 
	pt[4] = CTPoint<float>(75, 85);
	*/
}

CStatChart::~CStatChart()
{
}


BEGIN_MESSAGE_MAP(CStatChart, CWnd)
	//{{AFX_MSG_MAP(CStatChart)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CStatChart message handlers

void CStatChart::OnPaint() 
{
//	CPaintDC dc(this); // device context for painting
	if (!m_bCanDraw)
		return;
	CDC *pDC = GetDC();
	
	m_Linear.BeginDraw(pDC->m_hDC);//dc.GetSafeHdc());
	CRect rect;
	GetClientRect(&rect);
	DrawChart(rect);
	m_Linear.EndDraw(pDC->m_hDC);//dc.GetSafeHdc());
	ReleaseDC(pDC);
}

void CStatChart::DrawChart(CRect &rect)
{
	// m_Linear.SetRatio(0,0,1,1);
	DrawFrame(rect, RGB(255, 0, 0), "Congetion Window");
	//float x[5] = {3, 13, 22, 42, 77};
	//float y[5] = {34, 6, 23, 33, 23};
	/*
	m_Linear.Lines(x, y, 5, RGB(0, 0, 255), 1, "Line 1");
	m_Linear.Markers(x, y, 5, RGB(255, 0, 0), m_Linear.CROSS, 2, "Food");
	m_Linear.Lines(pt, 5, RGB(0, 128, 255), 3, "Line 3");
	m_Linear.Markers(pt, 5, RGB(255, 0, 255), m_Linear.FCIRCLE, 4, "Dog");
	*/

	m_Linear.Lines(m_cwnd_db_time,m_cwnd_db_data, m_nCwndDBSize, RGB(0, 0, 255), 1, "Line 1");
	m_Linear.Markers(m_cwnd_db_time, m_cwnd_db_data, m_nCwndDBSize, RGB(255, 0, 0), m_Linear.FTRIANGLE, 2, "CWND",MARK_SIZE);

	m_Linear.Lines(m_seqno_db_time, m_seqno_db_data, m_nSeqNoSize, RGB(0, 128, 255), 3, "Line 2");
	m_Linear.Markers(m_seqno_db_time,m_seqno_db_data, m_nSeqNoSize, RGB(255, 0, 255), m_Linear.FCIRCLE, 3, "Seq No.", MARK_SIZE);
	//TRACE(" size1 : %f data:%f time:%f\n", m_nSeqNoSize,m_seqno_db_data,m_seqno_db_time );
}

void CStatChart::DrawFrame(CRect &rect, COLORREF cr, const char *Title)
{
	m_Linear.RecalcRects(rect);
//	if (m_bBoundary)
//		m_Linear.DrawBoundary(cr, 2);
	if (m_bTitle)
	{
		m_Linear.XAxisTitle("Time",m_Linear.BOTTOM,10);
		m_Linear.YAxisTitle("CWND Size",m_Linear.LEFT,10);
		m_Linear.Title(Title,m_Linear.TOP,8);
	}
	m_Linear.Axes();
	if (m_bGrid)
		m_Linear.Grid();
}


void CStatChart::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	if(cx <= 0 || cy <= 0)
		return;

	RecalcSize();
}

void CStatChart::RecalcSize()
{
	CRect rect;
	GetClientRect(&rect);
	/*
	CSize sizeTotal;
	if(fabs(m_fXScale - 1) < 0.000001 && fabs(m_fYScale - 1) < 0.000001)
	{	
		GetClientRect(rect);
		sizeTotal = rect.Size();
		SetScaleToFitSize(sizeTotal); // make it similar to CView
	}
	else
	{
		sizeTotal   = GetTotalSize();
		rect.left   = rect.top = 0;
        rect.right  = sizeTotal.cx;
        rect.bottom = sizeTotal.cy;
		SetScrollSizes(m_nMapMode, sizeTotal);
	}
	*/
	
	if(m_bCanDraw)
		m_Linear.RecalcRects(rect);
		
}

BOOL CStatChart::OnEraseBkgnd(CDC* pDC) 
{
	return CWnd::OnEraseBkgnd(pDC);
	
	// TODO: Add your message handler code here and/or call default
//	if (!m_bCanDraw || !m_Linear.m_bMemoryDraw)
//		return CWnd::OnEraseBkgnd(pDC);
//	return TRUE;
	
}
