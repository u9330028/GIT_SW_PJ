// CalRTO.h: interface for the CCalRTO class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALRTO_H__E55B3608_A811_495B_A696_0216B27F2485__INCLUDED_)
#define AFX_CALRTO_H__E55B3608_A811_495B_A696_0216B27F2485__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "packet.h"
// #include "MyReTimer.h"

#define RTT_DELTA	0.125
#define RTT_RAW		0.25

// #include "SimpleTCPDemoView.h"
class CSimpleTCP;
class CMyReTimer;
class CRTTEstimator;
class CCalRTO  
{
public:
	void TimerExpired();
	CString m_strTemp;
	CSimpleTCP * m_pTCP;
	void UpdateRTO ( TcpHdr rcvHdr, CMyReTimer *pReTimer,CRTTEstimator *pRTT, BOOL bDupack );
	int GetMiliSecRTO();
	double m_RTO;	// retransmit timeout.
	double m_rttVar;	// round-trip time variance.
	double m_sRTT; // smoothed round-trip time.
	CCalRTO();
	virtual ~CCalRTO();

};

#endif // !defined(AFX_CALRTO_H__E55B3608_A811_495B_A696_0216B27F2485__INCLUDED_)
