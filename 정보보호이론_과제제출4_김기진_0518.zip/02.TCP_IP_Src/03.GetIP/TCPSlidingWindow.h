// TCPSlidingWindow.h: interface for the CTCPSlidingWindow class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TCPSLIDINGWINDOW_H__FD457101_2A0C_45A3_B151_06B678455FDC__INCLUDED_)
#define AFX_TCPSLIDINGWINDOW_H__FD457101_2A0C_45A3_B151_06B678455FDC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "packet.h"
class CSimpleTCP;
class CTCPSlidingWindow  
{
public:
	BOOL m_bFirstDupack;
//	UINT m_nDupackNum;
	UINT m_nDupackSeqNo;
	BOOL IsDupack(UINT nAckedNo);
	void TimerExpired();
	CSimpleTCP * m_pTCP;
	CString m_strTemp;
	int AdjustSentWndForSending();
	UINT GetAckedNo();
	int GetAvailWnd();
	//int m_AvailWnd;
	void SetAckedNo(UINT nAckedNo);
	UINT m_nAckedNo;		// recent Acked seq no.
//	UINT m_nLastSentNo;		// last sent seq no.
	
	UINT m_nSentNum;		// num of sent segment in current cwnd.

	int m_aWndSize;			// advertized window size.	
	int m_maxCWndSize;		// maximum congestion wnd size
	int updateSlidingWnd(TcpHdr rcvHdr);//, UINT nAckedNo );
	int getCurCwnd();
	double m_curWndSize;		// current window size.
	UINT m_ssthreshold;
	CTCPSlidingWindow();
	virtual ~CTCPSlidingWindow();

protected:
	void congestionControl();
};

#endif // !defined(AFX_TCPSLIDINGWINDOW_H__FD457101_2A0C_45A3_B151_06B678455FDC__INCLUDED_)
