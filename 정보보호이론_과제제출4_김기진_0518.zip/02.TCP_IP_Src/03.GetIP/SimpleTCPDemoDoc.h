// SimpleTCPDemoDoc.h : interface of the CSimpleTCPDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLETCPDEMODOC_H__73246585_9174_452D_98C0_6E64D81A1351__INCLUDED_)
#define AFX_SIMPLETCPDEMODOC_H__73246585_9174_452D_98C0_6E64D81A1351__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CSimpleTCPDemoDoc : public CDocument
{
protected: // create from serialization only
	CSimpleTCPDemoDoc();
	DECLARE_DYNCREATE(CSimpleTCPDemoDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleTCPDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSimpleTCPDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSimpleTCPDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLETCPDEMODOC_H__73246585_9174_452D_98C0_6E64D81A1351__INCLUDED_)
