#if !defined(AFX_TCPHISTORYDLG_H__58131894_DAE8_4A93_99DD_40198837DEE8__INCLUDED_)
#define AFX_TCPHISTORYDLG_H__58131894_DAE8_4A93_99DD_40198837DEE8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TcpHistoryDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTcpHistoryDlg dialog
#include "MyRichEdit.h"

class CTcpHistoryDlg : public CDialog
{
// Construction
public:
	void InitVariable();
	CTcpHistoryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTcpHistoryDlg)
	enum { IDD = IDD_TCP_HISTORY };
	CMyRichEdit	m_ctrlTCPHistory;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTcpHistoryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTcpHistoryDlg)
		virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPHISTORYDLG_H__58131894_DAE8_4A93_99DD_40198837DEE8__INCLUDED_)
