#if !defined(AFX_MODIFYNETPARAM_H__82098E2B_C7B0_4ADE_8945_026649C3C186__INCLUDED_)
#define AFX_MODIFYNETPARAM_H__82098E2B_C7B0_4ADE_8945_026649C3C186__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ModifyNetParam.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CModifyNetParam dialog
#include "definition.h"

class CModifyNetParam : public CDialog
{
// Construction
public:
	UINT m_nNumOfErrorSeqNo;
	int m_arErrorSeqNo[100];
	void UpdateInputSeqNo(CString strSeqNo);
	CModifyNetParam(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CModifyNetParam)
	enum { IDD = IDD_MODIFY_NET_PARAMETER };
	CEdit	m_ctrlFixedDelay;
	CEdit	m_ctrlSeqNo;
	CEdit	m_ctrlFixedRate;
	CEdit	m_ctrlDelayRdLow;
	CEdit	m_ctrlDelayRdHigh;
	UINT	m_nFixedDelay;
	UINT	m_nDelayRdHigh;
	UINT	m_nDelayRdLow;
	float	m_fFixedRate;
	CString	m_strErrorSeqNo;
	int		m_nOptDelay;
	int		m_nOptError;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModifyNetParam)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CModifyNetParam)
	afx_msg void OnOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnOptionDelayFixed();
	afx_msg void OnOptionDelayRandom();
	afx_msg void OnOptionErrorFixed();
	afx_msg void OnOptionErrorSeqno();
	afx_msg void OnOptionDelayNone();
	afx_msg void OnOptionErrorNone();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODIFYNETPARAM_H__82098E2B_C7B0_4ADE_8945_026649C3C186__INCLUDED_)
