// StatChartDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "StatChartDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStatChartDlg dialog


CStatChartDlg::CStatChartDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStatChartDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStatChartDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CStatChartDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStatChartDlg)
	DDX_Control(pDX, IDC_STATIC_CGST_CONTROL, m_ctrlChart);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStatChartDlg, CDialog)
	//{{AFX_MSG_MAP(CStatChartDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStatChartDlg message handlers

void CStatChartDlg::OnCancel()
{;}

void CStatChartDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	CRect rect;
	// �� ��Ʈ���� ũ�⸦ �����´�.
	GetParent()->GetClientRect(&rect);

	
//	((CTabCtrl *)GetParent())->GetItemRect(0, &item_rect);	// �������� ũ��� ��� ����.
	
//	if (((CWediTabCtrl *)GetParent())->IsMultiLine())
//		rect.top += 6 + item_rect.Height() * 2;	// ��Ƽ���� ���
//	else	rect.top += 6 + item_rect.Height();	// ��Ƽ �ƴ� ��� 

	rect.top += 25; //+ item_rect.Height();	// ��Ƽ �ƴ� ��� 
	rect.left += 5;
	rect.bottom -= 5;		
	rect.right -= 5;

	//rect.bottom -= (rect.Height()*1/2 + 5) ;

	MoveWindow(&rect);				// �Ǵ��̾�α� ũ�� ����
	GetClientRect(&rect);			// ����� ���� ũ�⸦ �ٽ��о�ͼ� 
	
	if(m_ctrlChart.m_hWnd) {		// Ʈ�� ũ�⺯��
		//rect.bottom -= (rect.Height()*2/3 + 5) ;
		m_ctrlChart.MoveWindow(&rect);	// ���̾�α׿� ���� ũ���
	}
	
}

BOOL CStatChartDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CStatChartDlg::AddData(UINT data)
{
//	m_ctrlChart.m_Linear.AddD
}

BOOL CStatChartDlg::AddSeqNo(Database db)
{
	m_ctrlChart.m_bCanDraw = FALSE;
	m_ctrlChart.m_seqno_db_data[m_ctrlChart.m_nSeqNoSize] = db.data;
	m_ctrlChart.m_seqno_db_time[m_ctrlChart.m_nSeqNoSize] = db.time;
	m_ctrlChart.m_nSeqNoSize++;
	m_ctrlChart.m_bCanDraw = TRUE;	
	m_ctrlChart.SendMessage(WM_PAINT);
	if ( m_ctrlChart.m_nSeqNoSize >= MAX_DB_SIZE)
		return FALSE;
	return TRUE;
}

BOOL CStatChartDlg::AddCwnd(Database db)
{
	m_ctrlChart.m_bCanDraw = FALSE;	
	m_ctrlChart.m_cwnd_db_data[m_ctrlChart.m_nCwndDBSize] = db.data;
	m_ctrlChart.m_cwnd_db_time[m_ctrlChart.m_nCwndDBSize] = db.time;
	m_ctrlChart.m_nCwndDBSize++;
	m_ctrlChart.m_bCanDraw = TRUE;	
	m_ctrlChart.SendMessage(WM_PAINT);
	if ( m_ctrlChart.m_nCwndDBSize >= MAX_DB_SIZE)
		return FALSE;
	return TRUE;
}

float CStatChartDlg::GetRecentRecTime(int nType, int nMode)
{
	if ( nMode == CHART_CWND)
	{
		if ( nType == CWND )
		{
			int idx = m_ctrlChart.m_nCwndDBSize;
			
			if ( (idx - 1) <0) return -1; // �ϳ��� ����Ÿ�� �ִ� ���.

			return (int)(m_ctrlChart.m_cwnd_db_time[idx-1]);
		}
	}
	return 1.0;
}

BOOL CStatChartDlg::UpdateCwnd(Database db)
{
	m_ctrlChart.m_bCanDraw = FALSE;	
	
	int idx = m_ctrlChart.m_nCwndDBSize-1;
	if (idx < 0) return FALSE;

	m_ctrlChart.m_cwnd_db_data[idx] = db.data;
	// m_ctrlChart.m_cwnd_db_time[m_ctrlChart.m_nCwndDBSize] = db.time;
	//m_ctrlChart.m_nCwndDBSize++;
	m_ctrlChart.m_bCanDraw = TRUE;	
	m_ctrlChart.SendMessage(WM_PAINT);
	//if ( m_ctrlChart.m_nCwndDBSize >= MAX_DB_SIZE)
	//	return FALSE;
	return TRUE;
}
