// ErrorGenerator.h: interface for the CErrorGenerator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ERRORGENERATOR_H__C37BC124_5FD5_4FC0_BE4D_03281CD1D3FB__INCLUDED_)
#define AFX_ERRORGENERATOR_H__C37BC124_5FD5_4FC0_BE4D_03281CD1D3FB__INCLUDED_

#include "SimpleTCP.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CErrorGenerator  
{
private:
	BOOL IsError(UINT nSeqNo);
public:
	int m_nHitCount;
	BOOL ErrorChecking(void *seg);
	CSimpleTCP *m_pTCP;
	CString m_strTemp;
	BOOL ErrorFilter(void *seg, int nActualLen);
	BOOL GetFixedError();

	UINT m_nNumOfErrorSeqNo;
	int m_arErrorSeqNo[100];
	int		m_nOptError;
	float	m_fFixedRate;

	void SetErrorParam(int nOptError, float fFixedRate, int m_arErrorSeqNo[],UINT nNumOfErrorSeqNo);
	CErrorGenerator();
	virtual ~CErrorGenerator();

};

#endif // !defined(AFX_ERRORGENERATOR_H__C37BC124_5FD5_4FC0_BE4D_03281CD1D3FB__INCLUDED_)
