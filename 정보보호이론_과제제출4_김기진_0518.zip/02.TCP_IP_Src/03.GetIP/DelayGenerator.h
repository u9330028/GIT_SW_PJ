// DelayGenerator.h: interface for the CDelayGenerator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DELAYGENERATOR_H__2BD0D2BF_E5FA_4DE7_9050_0D55CB6B0CFF__INCLUDED_)
#define AFX_DELAYGENERATOR_H__2BD0D2BF_E5FA_4DE7_9050_0D55CB6B0CFF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDelayGenerator  
{
public:
	UINT GetRandDelay();
	int		m_nOptDelay;
	UINT	m_nFixedDelay;
	UINT	m_nDelayRdHigh;
	UINT	m_nDelayRdLow;

	void SetDelayParam(int nOptDelay, UINT nFixedDelay, UINT nDelayRdLow, UINT nDelayRdHigh);
	int m_nDelayType;
	UINT GetDelay();
	CDelayGenerator();
	virtual ~CDelayGenerator();

};

#endif // !defined(AFX_DELAYGENERATOR_H__2BD0D2BF_E5FA_4DE7_9050_0D55CB6B0CFF__INCLUDED_)
