// TimeInfo.cpp: implementation of the CTimeInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
// #include "time_test.h"
#include "TimeInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTimeInfo::CTimeInfo(TimeInfo t)
{
	m_nExpires = t.Expires;
	m_nSeqNo = t.SeqNo;
	m_bRetrans = t.bRetrans;
}

CTimeInfo::~CTimeInfo()
{

}
BOOL CTimeInfo::Tick(int nGranu)
{
	m_nExpires -= nGranu;
	if ( m_nExpires <= 0 ) 
		return TRUE;
	return FALSE;
}
BOOL CTimeInfo::IsRetrans()
{
	return m_bRetrans;
}