#include	"StdAfx.h"
#include	"mmReTimers.h"
#include	"MyReTimer.h"

CMMReTimers::CMMReTimers(UINT resolution) : timerRes(0), timerId(0)
{
	TIMECAPS	tc;

	if (TIMERR_NOERROR == timeGetDevCaps(&tc,sizeof(TIMECAPS)))
	{
		timerRes = min(max(tc.wPeriodMin,resolution),tc.wPeriodMax);
		timeBeginPeriod(timerRes);
	}
}


CMMReTimers::~CMMReTimers()
{
	stopTimer();
	if (0 != timerRes)
	{
		timeEndPeriod(timerRes);
		timerRes = 0;
	}
}


extern "C"
void
CALLBACK
internalReTimerProc(UINT id,UINT msg,DWORD dwUser,DWORD dw1,DWORD dw2)
{
	CMMReTimers *	timer = (CMMReTimers *)dwUser;

	timer->timerProc();
}


BOOL CMMReTimers::startTimer(CMyReTimer *pReTimer, UINT period, bool oneShot)
{
	bool		res = false;
	MMRESULT	result;

	if ( pReTimer == NULL ) 
	{
		AfxMessageBox("��");
		return FALSE;
	}
	m_pParent = pReTimer;
	
	result = timeSetEvent(period,timerRes,internalReTimerProc,(DWORD)this,oneShot ? TIME_ONESHOT : TIME_PERIODIC);
	if (NULL != result)
	{
		timerId = (UINT)result;
		res = true;
	}

	return res;
}


BOOL CMMReTimers::stopTimer()
{
	MMRESULT	result;

	result = timeKillEvent(timerId);
	if (TIMERR_NOERROR == result)
		timerId = 0;

	return TIMERR_NOERROR == result;
}

