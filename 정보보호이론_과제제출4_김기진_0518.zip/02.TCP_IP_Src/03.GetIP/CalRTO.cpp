// CalRTO.cpp: implementation of the CCalRTO class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "SimpleTCP.h"
#include "CalRTO.h"
// #include "RetransTimer.h"
//#include "MMTimers.h"
#include "MyReTimer.h"
#include "SimpleTCPDemoView.h"
#include "definition.h"

#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCalRTO::CCalRTO()
{
	//m_rttDelta = 0.25;
	//m_rttRaw = 0.125;
	m_pTCP = NULL;
	m_sRTT = 0;
	m_rttVar = 3;
	m_RTO = m_sRTT + 2 * m_rttVar ; // init value : A + 2D.
}

CCalRTO::~CCalRTO()
{

}

int CCalRTO::GetMiliSecRTO()
{
	return (int)(m_RTO * ((double)1000)) ;
}

void CCalRTO::UpdateRTO ( TcpHdr rcvHdr, CMyReTimer *pReTimer, CRTTEstimator *pRTT, BOOL bDupack )
{
	UINT nRcvAckNo;
//	BOOL bRetrans;	// retransmission ??
	CTimeInfo *pInfo;
	BOOL bRetrans = FALSE;

	nRcvAckNo = rcvHdr.basetcphdr.AckNo;

	// finding �Ѵ� retimer���� ���� retransmisstion�Ѱ��̸� karn �˰� ���� ����
	// �ƴϸ� ���߽� �˰����� ����.
	if ( bDupack ) 
	{ 
		m_strTemp.Format("No RTO Update for duplicate ACK", BLUE); 
		return;
	}

	pInfo = pReTimer->FindTimeInfo( nRcvAckNo - 1 ) ;
	if ( pInfo )
	{
		bRetrans = pInfo->IsRetrans();
/*		
		// Ÿ�̸� ���� �������, Cumulative ACK �̹Ƿ� ������ ���´� Ÿ�̸ӵ鵵 ���� ����.
		pReTimer->DeleteTimer( nRcvAckNo - 1 ) ;
*/

		if ( bRetrans )
		{
			TRACE("Karn's Algorithm applied : No Update RTO\n");
			m_pTCP->History("Karn's Algorithm applied : No Update RTO",BORA);
		}
		else
		{
			// Jacopson algorithm ..
			double sentT;
			double curT;
			double sampleRTT ;
			
			sentT = rcvHdr.hdrOpt.time_stamp; // �� �κ� ������ ���� �ð��� �����ͼ� ��� �ؾ���.
			curT = clock();
			
			m_strTemp.Format("Time stamp round trip time : %f", (curT - sentT) / CLOCKS_PER_SEC );
			m_pTCP->History(m_strTemp, YEL);

			sampleRTT = pRTT->GetTickCount() + 0.5;
	
			m_strTemp.Format("Sampled RTT : %5.2f", sampleRTT);
			m_pTCP->History(m_strTemp, BORA);
			
			
			if ( nRcvAckNo == 1 )	// for initial data segment.
			{
				m_sRTT = sampleRTT;
				m_rttVar = m_sRTT / 2;
				m_RTO = m_sRTT + 4 * m_rttVar;
				TRACE("Initial Updated RTO : %f \n", m_RTO);
			}
			else if ( nRcvAckNo >= 2 )
			{
				double Err;

				Err = sampleRTT - m_sRTT;
				m_sRTT = m_sRTT + RTT_DELTA*Err ;
				m_rttVar = m_rttVar + RTT_RAW*(fabs(Err) - m_rttVar);
				m_RTO = m_sRTT + 4 * m_rttVar;

				TRACE("Updated RTO : %f \n", m_RTO);
				m_strTemp.Format("Updated RTO : %f \n", m_RTO);
				m_pTCP->History(m_strTemp,BLUE);

			}
			else { 
				TRACE("This is test text : abnormal ACK No \n");
			}
		}
	}
}


void CCalRTO::TimerExpired()
{
	m_RTO = m_RTO*2.0;
}
