#if !defined(AFX_STATSEQDLG_H__9D3ED6CC_4BFA_4ABB_A29B_A498CC5ECF6F__INCLUDED_)
#define AFX_STATSEQDLG_H__9D3ED6CC_4BFA_4ABB_A29B_A498CC5ECF6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatSeqDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStatSeqDlg dialog
#include "StatChart.h"
class CStatSeqDlg : public CDialog
{
// Construction
public:
	BOOL AddCwnd(Database db);
	BOOL UpdateSeq(Database db);
	BOOL AddSeqNo(Database db);
	float GetRecentRecTime(int nType, int nMode);
	CStatSeqDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStatSeqDlg)
	enum { IDD = IDD_TCP_SEQ };
	CStatChart	m_ctrlSeqChart;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStatSeqDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStatSeqDlg)
	virtual void OnCancel();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATSEQDLG_H__9D3ED6CC_4BFA_4ABB_A29B_A498CC5ECF6F__INCLUDED_)
