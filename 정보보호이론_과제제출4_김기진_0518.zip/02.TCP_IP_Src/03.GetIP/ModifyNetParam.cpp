// ModifyNetParam.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "ModifyNetParam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CModifyNetParam dialog


CModifyNetParam::CModifyNetParam(CWnd* pParent /*=NULL*/)
	: CDialog(CModifyNetParam::IDD, pParent)
{
	//{{AFX_DATA_INIT(CModifyNetParam)
	m_nFixedDelay = 1000;
	m_nDelayRdHigh = 1000;
	m_nDelayRdLow = 50;
	m_fFixedRate = 0.05f;
	m_strErrorSeqNo = _T("4-9-20");
	m_nOptDelay = 0;
	m_nOptError = 0;
	//}}AFX_DATA_INIT
	m_nNumOfErrorSeqNo = 0;
	for (int i = 0; i < ERROR_SEQ_NO_MAX; i ++)
		m_arErrorSeqNo[i] = 0;
}


void CModifyNetParam::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModifyNetParam)
	DDX_Control(pDX, IDC_DELAY_FIXED_VALUE, m_ctrlFixedDelay);
	DDX_Control(pDX, IDC_ERROR_SEQ_NO, m_ctrlSeqNo);
	DDX_Control(pDX, IDC_ERROR_FIXED_RATE, m_ctrlFixedRate);
	DDX_Control(pDX, IDC_DELAY_RANDOM_LOW, m_ctrlDelayRdLow);
	DDX_Control(pDX, IDC_DELAY_RANDOM_HIGH, m_ctrlDelayRdHigh);
	DDX_Text(pDX, IDC_DELAY_FIXED_VALUE, m_nFixedDelay);
	DDX_Text(pDX, IDC_DELAY_RANDOM_HIGH, m_nDelayRdHigh);
	DDV_MinMaxUInt(pDX, m_nDelayRdHigh, 10, 10000);
	DDX_Text(pDX, IDC_DELAY_RANDOM_LOW, m_nDelayRdLow);
	DDV_MinMaxUInt(pDX, m_nDelayRdLow, 10, 10000);
	DDX_Text(pDX, IDC_ERROR_FIXED_RATE, m_fFixedRate);
	DDV_MinMaxFloat(pDX, m_fFixedRate, 1.e-006f, 1.f);
	DDX_Text(pDX, IDC_ERROR_SEQ_NO, m_strErrorSeqNo);
	DDX_Radio(pDX, IDC_OPTION_DELAY_FIXED, m_nOptDelay);
	DDX_Radio(pDX, IDC_OPTION_ERROR_FIXED, m_nOptError);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CModifyNetParam, CDialog)
	//{{AFX_MSG_MAP(CModifyNetParam)
	ON_BN_CLICKED(IDOK, OnOk)
	ON_BN_CLICKED(IDC_OPTION_DELAY_FIXED, OnOptionDelayFixed)
	ON_BN_CLICKED(IDC_OPTION_DELAY_RANDOM, OnOptionDelayRandom)
	ON_BN_CLICKED(IDC_OPTION_ERROR_FIXED, OnOptionErrorFixed)
	ON_BN_CLICKED(IDC_OPTION_ERROR_SEQNO, OnOptionErrorSeqno)
	ON_BN_CLICKED(IDC_OPTION_DELAY_NONE, OnOptionDelayNone)
	ON_BN_CLICKED(IDC_OPTION_ERROR_NONE, OnOptionErrorNone)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModifyNetParam message handlers

void CModifyNetParam::OnOk() 
{
	UpdateData();
	UpdateInputSeqNo(m_strErrorSeqNo);

	CDialog::OnOK();
}

BOOL CModifyNetParam::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_nOptDelay = OPT_DELAY_FIXED;
	m_nOptError = OPT_ERROR_FIXED;

	OnOptionDelayFixed();
	OnOptionErrorFixed();

	for ( int i = 0; i < ERROR_SEQ_NO_MAX; i ++)
		m_arErrorSeqNo[i] = 0;

	UpdateData();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CModifyNetParam::OnOptionDelayFixed() 
{
	m_nOptDelay = OPT_DELAY_FIXED ;
	m_ctrlFixedDelay.EnableWindow();
	m_ctrlDelayRdHigh.EnableWindow(FALSE);
	m_ctrlDelayRdLow.EnableWindow(FALSE);
	
	UpdateData(FALSE);
}

void CModifyNetParam::OnOptionDelayRandom() 
{
	m_nOptDelay = OPT_DELAY_RANDOM ;
	m_ctrlFixedDelay.EnableWindow(FALSE);
	m_ctrlDelayRdHigh.EnableWindow();
	m_ctrlDelayRdLow.EnableWindow();

	UpdateData(FALSE);
}
void CModifyNetParam::OnOptionDelayNone() 
{
	m_nOptDelay = OPT_DELAY_NONE ;
	m_ctrlFixedDelay.EnableWindow(FALSE);
	m_ctrlDelayRdHigh.EnableWindow(FALSE);
	m_ctrlDelayRdLow.EnableWindow(FALSE);
}

void CModifyNetParam::OnOptionErrorFixed() 
{
	m_nOptError = OPT_ERROR_FIXED;
	m_ctrlFixedRate.EnableWindow();
	m_ctrlSeqNo.EnableWindow(FALSE);
	UpdateData(FALSE);
}

void CModifyNetParam::OnOptionErrorSeqno() 
{
	m_nOptError = OPT_ERROR_SEQ;
	m_ctrlFixedRate.EnableWindow(FALSE);
	m_ctrlSeqNo.EnableWindow();
	UpdateData(FALSE);
}

void CModifyNetParam::OnOptionErrorNone() 
{
	m_nOptError = OPT_ERROR_NONE;

	m_ctrlFixedRate.EnableWindow(FALSE);
	m_ctrlSeqNo.EnableWindow(FALSE);
	
}

void CModifyNetParam::UpdateInputSeqNo(CString strSeqNo)
{
	BOOL bOut = FALSE;
	
	m_nNumOfErrorSeqNo = 0;
	m_strErrorSeqNo.TrimLeft();
	m_strErrorSeqNo.TrimRight();
	
	int start = 0, next = 0;
	int strlen = m_strErrorSeqNo.GetLength();

	CString temp;
	
	TRACE(m_strErrorSeqNo);
	// check one seq no..
	if ( m_strErrorSeqNo.GetLength() > 0 
		&& m_strErrorSeqNo.Find('-') < 0)
	{
		m_arErrorSeqNo[m_nNumOfErrorSeqNo] = atoi(LPCTSTR(m_strErrorSeqNo));
		m_nNumOfErrorSeqNo++;	// �����̹Ƿ� �ϳ��� �ǹ�.
		return;
	}
	
	while (!bOut)
	{
		next = m_strErrorSeqNo.Find('-');
		if (next < 0) {
			bOut = TRUE;
			m_arErrorSeqNo[m_nNumOfErrorSeqNo] = atoi(LPCTSTR(m_strErrorSeqNo));
			m_nNumOfErrorSeqNo++;	// �����̹Ƿ� �ϳ��� �ǹ�.
			return;
		}
		temp = m_strErrorSeqNo.Mid(0, next);
		m_arErrorSeqNo[m_nNumOfErrorSeqNo] = atoi(LPCTSTR(temp));
		m_strErrorSeqNo = m_strErrorSeqNo.Right(strlen-next-1);
		strlen = strlen - next-1;
		m_nNumOfErrorSeqNo++;

				
	}
}

