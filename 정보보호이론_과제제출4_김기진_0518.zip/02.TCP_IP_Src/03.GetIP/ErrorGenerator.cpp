// ErrorGenerator.cpp: implementation of the CErrorGenerator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCP.h"
#include "ErrorGenerator.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CErrorGenerator::CErrorGenerator()
{
	m_nNumOfErrorSeqNo = 0;
	memset(m_arErrorSeqNo, -1, sizeof(int)*ERROR_SEQ_NO_MAX);
	m_nOptError = 0;
	m_fFixedRate = 0.0;

	m_pTCP = NULL;
	m_nHitCount = 0;
}

CErrorGenerator::~CErrorGenerator()
{

}

void CErrorGenerator::SetErrorParam(int nOptError, float fFixedRate, int arErrorSeqNo[],UINT nNumOfErrorSeqNo)
{
	m_nNumOfErrorSeqNo = nNumOfErrorSeqNo;
	memcpy(m_arErrorSeqNo, arErrorSeqNo, sizeof(int)*nNumOfErrorSeqNo);
	m_nOptError = nOptError;
	m_fFixedRate = fFixedRate;
	m_nHitCount = 0;
}

BOOL CErrorGenerator::IsError(UINT nSeqNo)
{
	BOOL bError = FALSE;
	UINT temp;

	if ( m_nOptError == OPT_ERROR_FIXED )
	{
		bError =  GetFixedError();
		return bError;
	}
	else if ( m_nOptError == OPT_ERROR_SEQ)
	{
		for ( int i = 0; i < m_nNumOfErrorSeqNo; i ++ )
		{
			temp = m_arErrorSeqNo[i];
			if ( (nSeqNo - temp) == 0 ) 
			{
				m_arErrorSeqNo[i] = -1; // ���߿� ���� �־�� ��.
				//m_nNumOfErrorSeqNo--;
				return TRUE;
			}
		}
	}
	else {
		return FALSE;
	}
	return FALSE;	
}

BOOL CErrorGenerator::ErrorFilter(void *seg, int nActualLen)
{
	BOOL bError = FALSE;

	if (seg == NULL) return FALSE;
	if ( nActualLen == HEADER_SIZE )
	{
		TcpHdr *p = NULL;
		p = (TcpHdr *)seg;
		bError = IsError(p->basetcphdr.SeqNo);
		if ( bError ) 
		{
			p->basetcphdr.CheckSum = 0x0000;
			m_strTemp.Format("Error Created for Seq No : %d",p->basetcphdr.SeqNo);
			m_pTCP->History(m_strTemp, BLUE);
		}
		else 
			p->basetcphdr.CheckSum = 0xFFFF;
	}
	else {
		Segment *p = NULL;
		p = (Segment *)seg;
		bError = IsError(p->tcphdr.basetcphdr.SeqNo);
		if ( bError ) 
		{
			p->tcphdr.basetcphdr.CheckSum = 0x0000;
			m_strTemp.Format("Error Created for Seq No : %d",p->tcphdr.basetcphdr.SeqNo);
			m_pTCP->History(m_strTemp, BLUE);
		}
		else 
			p->tcphdr.basetcphdr.CheckSum = 0xFFFF;
	}
	return bError;
}

// if error => TRUE
BOOL CErrorGenerator::GetFixedError() 
{
	int errRate = 0;

	errRate = (int)(m_fFixedRate * 100);

	srand((unsigned)time(NULL));
//	int temp = rand();
	int temp = rand() % 101;
	// i = rand()%temp;
	if ( errRate <= temp ) 
		return FALSE;
	else 
		return TRUE;
//	int temp = (int)(1.0/m_fFixedRate);
	
/*
	if ( i == 1) 
		return TRUE;
	else 
		return FALSE;
		*/
}

// if error, return TRUE;
BOOL CErrorGenerator::ErrorChecking(void *seg)
{
	if (seg==NULL)return TRUE;

	Segment *pSeg = NULL;
	pSeg = (Segment*) seg;
	if ( pSeg->tcphdr.basetcphdr.CheckSum != 0xFFFF)
	{
		m_strTemp.Format("Error Packet => Seq No:%d", pSeg->tcphdr.basetcphdr.SeqNo);
		m_pTCP->History(m_strTemp, BLUE);
		return TRUE;
	}
	else {
		return FALSE;
	}
}
