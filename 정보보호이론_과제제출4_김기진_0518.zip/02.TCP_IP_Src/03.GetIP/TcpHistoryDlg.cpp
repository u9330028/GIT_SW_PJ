// TcpHistoryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "TcpHistoryDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTcpHistoryDlg dialog


CTcpHistoryDlg::CTcpHistoryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTcpHistoryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTcpHistoryDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CTcpHistoryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTcpHistoryDlg)
	
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTcpHistoryDlg, CDialog)
	//{{AFX_MSG_MAP(CTcpHistoryDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTcpHistoryDlg message handlers

void CTcpHistoryDlg::OnCancel()
{;}

BOOL CTcpHistoryDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	InitVariable();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTcpHistoryDlg::InitVariable()
{
// setting rich edit
	CRect rc;
	CWnd *pWnd = GetDlgItem(IDC_STATIC_HISTORY_RICHEDIT);
	pWnd->GetWindowRect(&rc);
	ScreenToClient(&rc);
/*
	m_pTCPHistory = new CMyRichEdit;
	m_pTCPHistory->Create(WS_VISIBLE | WS_CHILD |WS_BORDER | WS_HSCROLL | 
					WS_CLIPCHILDREN | WS_VSCROLL | ES_MULTILINE | ES_AUTOHSCROLL | ES_READONLY |
					ES_AUTOVSCROLL |ES_LEFT | ES_WANTRETURN, rc, this,IDC_STATIC_HISTORY_RICHEDIT  );
*/
	
	m_ctrlTCPHistory.Create(WS_VISIBLE | WS_CHILD |WS_BORDER | WS_HSCROLL | 
					WS_CLIPCHILDREN | WS_VSCROLL | ES_MULTILINE | ES_AUTOHSCROLL | ES_READONLY |
					ES_AUTOVSCROLL |ES_LEFT | ES_WANTRETURN, rc, this,IDC_STATIC_HISTORY_RICHEDIT  );
	
}

void CTcpHistoryDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

	CRect rect, item_rect;
	// �� ��Ʈ���� ũ�⸦ �����´�.
	GetParent()->GetClientRect(&rect);

	
//	((CTabCtrl *)GetParent())->GetItemRect(0, &item_rect);	// �������� ũ��� ��� ����.
	
//	if (((CWediTabCtrl *)GetParent())->IsMultiLine())
//		rect.top += 6 + item_rect.Height() * 2;	// ��Ƽ���� ���
//	else	rect.top += 6 + item_rect.Height();	// ��Ƽ �ƴ� ��� 

	rect.top += 25; //+ item_rect.Height();	// ��Ƽ �ƴ� ��� 
	rect.left += 5;
	rect.bottom -= 5;		
	rect.right -= 5;

	MoveWindow(&rect);				// �Ǵ��̾�α� ũ�� ����
	GetClientRect(&rect);			// ����� ���� ũ�⸦ �ٽ��о�ͼ� 
	if(m_ctrlTCPHistory.m_hWnd)		// Ʈ�� ũ�⺯��
		m_ctrlTCPHistory.MoveWindow(&rect);	// ���̾�α׿� ���� ũ���
}
