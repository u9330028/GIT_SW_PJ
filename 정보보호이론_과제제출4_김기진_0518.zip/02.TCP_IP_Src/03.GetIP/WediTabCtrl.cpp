// WediTabCtrl.cpp : implementation file
//

#include "stdafx.h"
//#include "WediClient.h"
#include "WediTabCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWediTabCtrl

CWediTabCtrl::CWediTabCtrl()
{
	m_bForceOverColor = FALSE;
	m_iSelectedTab = 0;
	m_ptTabs.x = 4;
	m_ptTabs.y = 28;

	m_crSelected = 0;
	m_crDisabled = 0;
		m_crNormal = 0;
	m_crMouseOver = 0;

	m_bColorSelected  = false;
	m_bColorDisabled  = false;
	m_bColorNormal    = false;
	m_bColorMouseOver = false;


	m_iIndexMouseOver = -1;

	m_bMouseOver = false;
}

CWediTabCtrl::~CWediTabCtrl()
{
	m_arrayStatusTab.RemoveAll();
}


BEGIN_MESSAGE_MAP(CWediTabCtrl, CTabCtrl)
	//{{AFX_MSG_MAP(CWediTabCtrl)
	ON_NOTIFY_REFLECT(TCN_SELCHANGE, OnSelchange)
	ON_NOTIFY_REFLECT(TCN_SELCHANGING, OnSelchanging)
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
	ON_WM_SIZE()
	ON_WM_DRAWITEM()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWediTabCtrl message handlers

/*
HBRUSH CWediTabCtrl::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CTabCtrl::OnCtlColor(pDC, pWnd, nCtlColor);
	
	
	if (nCtlColor == CTLCOLOR_SCROLLBAR )  {
		HBRUSH hbr = CreateSolidBrush(WEDIDLGBGCOLOR);
		return hbr;
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
*/

void CWediTabCtrl::OnSelchange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int iNewTab = GetCurSel();

	if (!IsTabEnabled(iNewTab)) {
		SetCurSel(m_iSelectedTab);
	}
	else {
		TCITEM item;
		CWnd* pWnd;

		item.mask = TCIF_PARAM;
		
		// hide the current tab
		GetItem(m_iSelectedTab, &item);
		pWnd = reinterpret_cast<CWnd*> (item.lParam);
		ASSERT_VALID(pWnd);
		pWnd->ShowWindow(SW_HIDE);
		
		// show the selected tab
		GetItem(iNewTab, &item);
		pWnd = reinterpret_cast<CWnd*> (item.lParam);
		ASSERT_VALID(pWnd);
		pWnd->ShowWindow(SW_SHOW);
	}
	*pResult = 0;
}
void CWediTabCtrl::AddTab(CWnd* pWnd, LPTSTR lpszCaption, int iImage)
{
	ASSERT_VALID(pWnd);

	TCITEM item;
	item.mask = TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE;
	item.lParam = (LPARAM)pWnd;
	item.pszText = lpszCaption;
	item.iImage = iImage;

	int iIndex = m_arrayStatusTab.GetSize();
	InsertItem(iIndex, &item);

	pWnd->SetWindowPos(NULL, m_ptTabs.x, m_ptTabs.y, 0, 0,
		SWP_FRAMECHANGED | SWP_NOSIZE | SWP_NOZORDER);
	pWnd->ShowWindow(iIndex ? SW_HIDE : SW_SHOW);
	
	// �ʱ⿡�� ���� ����
	m_arrayStatusTab.Add(TRUE);
}

void CWediTabCtrl::OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult) 
{
	m_iSelectedTab = GetCurSel();
	
	*pResult = 0;
}
void CWediTabCtrl::DeleteTab(int iIndex)
{
	ASSERT(iIndex < m_arrayStatusTab.GetSize());
	m_arrayStatusTab.RemoveAt(iIndex);
	DeleteItem(iIndex);
}

void CWediTabCtrl::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CRect rect = lpDrawItemStruct->rcItem;
	rect.top += ::GetSystemMetrics(SM_CYEDGE);

	int nTabIndex = lpDrawItemStruct->itemID;

	if(nTabIndex < 0) return;
	int cursel;
	cursel = GetCurSel();
	BOOL bSelected = ( nTabIndex == cursel);

	COLORREF crSelected = m_bColorSelected ? m_crSelected : GetSysColor(COLOR_BTNTEXT);
	COLORREF crNormal = m_bColorNormal ? m_crNormal : GetSysColor(COLOR_BTNTEXT);
	COLORREF crDisabled = m_bColorDisabled ? m_crDisabled : GetSysColor(COLOR_GRAYTEXT);

	char label[64];
	TC_ITEM item;
	item.mask = TCIF_TEXT | TCIF_IMAGE;
	item.pszText = label;
	item.cchTextMax = 63;
	if (!GetItem(nTabIndex, &item))
		return ;
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	if (!pDC)
		return;

	int nSavedDC = pDC ->SaveDC();

	CRect rectItem;
	POINT pt;

	GetItemRect(nTabIndex, &rectItem);
	GetCursorPos( &pt );
	ScreenToClient( &pt );

	if ( rectItem.PtInRect(pt))
		m_iIndexMouseOver = nTabIndex;

	pDC->SetBkMode(TRANSPARENT);
//	pDC->FillSolidRect(rect, WEDIDLGBGCOLOR);
	//pDC->FillSolidRect( rect, ::GetSysColor(COLOR_BTNFACE));

	CImageList* pImageList = GetImageList();
	if (pImageList && item.iImage >= 0 ) {
		rect.left += pDC ->GetTextExtent(_T(" ")).cx;

		IMAGEINFO info;
		pImageList->GetImageInfo(item.iImage, &info);
		CRect ImageRect(info.rcImage);
		int nYpos = rect.top;

		pImageList->Draw(pDC, item.iImage, CPoint(rect.left, nYpos), ILD_TRANSPARENT);
		rect.left += ImageRect.Width();
	}
	if (!IsTabEnabled(nTabIndex)) {
		pDC->SetTextColor( crDisabled);
		rect.top -= ::GetSystemMetrics(SM_CYEDGE);
		rect.top += 2;	// 2��ŭ �� ����
		pDC->DrawText(label, rect, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
	}
	else {
		if (bSelected)
			pDC->SetTextColor(crSelected);
		else {
			if (m_bColorMouseOver && nTabIndex == m_iIndexMouseOver) {
				pDC->SetTextColor(m_crMouseOver);
			}
			else {
				pDC ->SetTextColor(crNormal);
			}
		}
		rect.top -= ::GetSystemMetrics(SM_CYEDGE);
		rect.top += 2;	// 2��ŭ �� ����
		pDC->DrawText(label, rect, DT_SINGLELINE | DT_VCENTER | DT_CENTER);
	}
	pDC->RestoreDC(nSavedDC);
}

BOOL CWediTabCtrl::IsTabEnabled(int iIndex)
{
	ASSERT(iIndex < m_arrayStatusTab.GetSize());
	return m_arrayStatusTab[iIndex];
}

void CWediTabCtrl::EnableTab(int iIndex, BOOL bEnable)
{
	ASSERT(iIndex < m_arrayStatusTab.GetSize());

	if (m_arrayStatusTab[iIndex] != bEnable)
	{
		m_arrayStatusTab[iIndex] = bEnable;

		CRect rect;

		GetItemRect(iIndex, &rect);
		InvalidateRect(rect);
	}
}
void CWediTabCtrl::DeleteAllTabs()
{
	m_arrayStatusTab.RemoveAll();
	
	DeleteAllItems();
}

void CWediTabCtrl::SetTopLeftCorner(CPoint pt)
{
	m_ptTabs.x = pt.x;
	m_ptTabs.y = pt.y;
}
BOOL CWediTabCtrl::SelectTab(int iIndex)
{
	ASSERT(iIndex < m_arrayStatusTab.GetSize());

	if(GetCurSel() == iIndex)
		return TRUE;

	if (m_arrayStatusTab[iIndex])
	{
		TCITEM item;
		CWnd* pWnd;
		item.mask = TCIF_PARAM;

		GetItem(GetCurSel(), &item);
		pWnd = reinterpret_cast<CWnd*> (item.lParam);
		ASSERT_VALID(pWnd);
		pWnd->ShowWindow(SW_HIDE);

		SetCurSel(iIndex);
		GetItem(iIndex, &item);
		pWnd = reinterpret_cast<CWnd*> (item.lParam);
		ASSERT_VALID(pWnd);
		pWnd->ShowWindow(SW_SHOW);

		return TRUE;
	}
	return FALSE;
}

void CWediTabCtrl::SetDisabledColor(COLORREF cr) 
{
	m_bColorDisabled = true;
	m_crDisabled = cr;
}

void CWediTabCtrl::SetSelectedColor(COLORREF cr)
{
	m_bColorSelected = true;
	m_crSelected = cr;
}

void CWediTabCtrl::SetNormalColor(COLORREF cr)
{
	m_bColorNormal = true;
	m_crNormal = cr;
}

void CWediTabCtrl::SetMouseOverColor(COLORREF cr) 
{
	m_bColorMouseOver = true;
	m_crMouseOver = cr;
}

void CWediTabCtrl::PreSubclassWindow() 
{
	CTabCtrl::PreSubclassWindow();
	ModifyStyle(0, TCS_OWNERDRAWFIXED);
}

void CWediTabCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_bColorMouseOver)
	{
		SetTimer(1, 10, NULL);

		if (m_iIndexMouseOver != -1)
		{
			CRect rectItem;
			GetItemRect(m_iIndexMouseOver, rectItem);
			if (!rectItem.PtInRect(point))
			{
				CRect rectOldItem;
				GetItemRect(m_iIndexMouseOver, rectOldItem);
				m_iIndexMouseOver = -1;
				InvalidateRect(rectOldItem);
				return;
			}
		}
		if (!m_bMouseOver)
		{
			TCHITTESTINFO hitTest;
		
			m_bMouseOver = true;
			m_bForceOverColor = true;
			hitTest.pt = point;

			int iItem = HitTest(&hitTest);
			if (iItem != -1 && m_arrayStatusTab[iItem])
			{
				RECT rectItem;
				GetItemRect(iItem, &rectItem);

				InvalidateRect(&rectItem);
			}
		}
	}
	
	CTabCtrl::OnMouseMove(nFlags, point);
}

void CWediTabCtrl::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	POINT pt;
	GetCursorPos(&pt);
	CRect rectItem, rectScreen;

	GetItemRect(m_iIndexMouseOver, rectItem);
	rectScreen = rectItem;
	ClientToScreen(rectScreen);

	if (!rectScreen.PtInRect(pt))
	{
		KillTimer(1);
		m_bMouseOver = false;
		m_iIndexMouseOver = -1;
		InvalidateRect(rectItem);
	}
	CTabCtrl::OnTimer(nIDEvent);
}

void CWediTabCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CTabCtrl::OnSize(nType, cx, cy);
	CRect rect;
	GetParent()->GetClientRect(&rect);

	rect.top += 5;
	rect.left += 240;
	rect.bottom -= 5;		// ��ư���� �������� ������ ���� ����
	rect.right -= 5;

	MoveWindow(&rect);	// ����Ʈ�� ũ�� ����


	TCITEM item;

	int i = m_arrayStatusTab.GetSize();
	
	CWnd *pWnd = NULL;
	
	for ( int idx = 0; idx < m_arrayStatusTab.GetSize(); idx ++)
	{	GetItem(idx, &item);
		pWnd = reinterpret_cast<CWnd*> (item.lParam);
		ASSERT_VALID(pWnd);
		pWnd->SendMessage(WM_SIZE, 0, 0);
	}
}

BOOL CWediTabCtrl::IsMultiLine()
{
	CRect item_rect, rect_array[4];
	BOOL bMultiLine = FALSE;	// ���� ��Ƽ���� �����Ѵ�.

	//GetClientRect(&rect);	// �� ��Ʈ���� ũ�⸦ ���� �����´�.
	
	for(int i = 0; i < GetItemCount(); i++)
	{
		GetItemRect(i, &item_rect);
		rect_array[i] = item_rect;
	}
	// ���ݸ� ���� ....
	// if ( (rect_array[0].top + rect_array[1].top - rect_array[2].top - rect_array[3].top) != 0)
	//	IsMultiLine = TRUE;		// �ΰ����� ������ �ΰ� ���� 0�ƴϸ� ��Ƽ�̴�.
	return bMultiLine;

}
