// StatSeqDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "StatSeqDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStatSeqDlg dialog


CStatSeqDlg::CStatSeqDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStatSeqDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStatSeqDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CStatSeqDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStatSeqDlg)
	DDX_Control(pDX, IDC_STATIC_SEQ_CWND, m_ctrlSeqChart);
	//}}AFX_DATA_MAP
}
void CStatSeqDlg::OnCancel()
{;}


BEGIN_MESSAGE_MAP(CStatSeqDlg, CDialog)
	//{{AFX_MSG_MAP(CStatSeqDlg)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStatSeqDlg message handlers

void CStatSeqDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
		CRect rect;
	// �� ��Ʈ���� ũ�⸦ �����´�.
	GetParent()->GetClientRect(&rect);

	
//	((CTabCtrl *)GetParent())->GetItemRect(0, &item_rect);	// �������� ũ��� ��� ����.
	
//	if (((CWediTabCtrl *)GetParent())->IsMultiLine())
//		rect.top += 6 + item_rect.Height() * 2;	// ��Ƽ���� ���
//	else	rect.top += 6 + item_rect.Height();	// ��Ƽ �ƴ� ��� 

	rect.top += 25; //+ item_rect.Height();	// ��Ƽ �ƴ� ��� 
	rect.left += 5;
	rect.bottom -= 5;		
	rect.right -= 5;

	// rect.bottom -= (rect.Height()*1/2 + 5) ;

	MoveWindow(&rect);				// �Ǵ��̾�α� ũ�� ����
	GetClientRect(&rect);			// ����� ���� ũ�⸦ �ٽ��о�ͼ� 
	
	if(m_ctrlSeqChart.m_hWnd) {		// Ʈ�� ũ�⺯��
		//rect.bottom -= (rect.Height()*2/3 + 5) ;
		m_ctrlSeqChart.MoveWindow(&rect);	// ���̾�α׿� ���� ũ���
	}
	
	
}

float CStatSeqDlg::GetRecentRecTime(int nType, int nMode)
{
	if ( nMode == CHART_SEQ)
	{
		if ( nType == CWND )
		{
			int idx = m_ctrlSeqChart.m_nCwndDBSize;
			
			if ( (idx - 1) <0) return -1; // �ϳ��� ����Ÿ�� �ִ� ���.

			return (int)(m_ctrlSeqChart.m_cwnd_db_time[idx-1]);
		}
	}
	return 1.0;
}

BOOL CStatSeqDlg::AddSeqNo(Database db)
{
	m_ctrlSeqChart.m_bCanDraw = FALSE;
	m_ctrlSeqChart.m_seqno_db_data[m_ctrlSeqChart.m_nSeqNoSize] = db.data;
	m_ctrlSeqChart.m_seqno_db_time[m_ctrlSeqChart.m_nSeqNoSize] = db.time;
	m_ctrlSeqChart.m_nSeqNoSize++;
	m_ctrlSeqChart.m_bCanDraw = TRUE;	
	m_ctrlSeqChart.SendMessage(WM_PAINT);
	if ( m_ctrlSeqChart.m_nSeqNoSize >= MAX_DB_SIZE)
		return FALSE;
	return TRUE;
}

BOOL CStatSeqDlg::UpdateSeq(Database db)
{
	m_ctrlSeqChart.m_bCanDraw = FALSE;	
	
	int idx = m_ctrlSeqChart.m_nCwndDBSize-1;
	if (idx < 0) return FALSE;

	m_ctrlSeqChart.m_cwnd_db_data[idx] = db.data;
	// m_ctrlSeqChart.m_cwnd_db_time[m_ctrlSeqChart.m_nCwndDBSize] = db.time;
	//m_ctrlSeqChart.m_nCwndDBSize++;
	m_ctrlSeqChart.m_bCanDraw = TRUE;	
	m_ctrlSeqChart.SendMessage(WM_PAINT);
	//if ( m_ctrlSeqChart.m_nCwndDBSize >= MAX_DB_SIZE)
	//	return FALSE;
	return TRUE;
}

BOOL CStatSeqDlg::AddCwnd(Database db)
{
	m_ctrlSeqChart.m_bCanDraw = FALSE;	
	m_ctrlSeqChart.m_cwnd_db_data[m_ctrlSeqChart.m_nCwndDBSize] = db.data;
	m_ctrlSeqChart.m_cwnd_db_time[m_ctrlSeqChart.m_nCwndDBSize] = db.time;
	m_ctrlSeqChart.m_nCwndDBSize++;
	m_ctrlSeqChart.m_bCanDraw = TRUE;	
	m_ctrlSeqChart.SendMessage(WM_PAINT);
	if ( m_ctrlSeqChart.m_nCwndDBSize >= MAX_DB_SIZE)
		return FALSE;
	return TRUE;
}
