#ifndef	___multimedia_timers___
#define	___multimedia_timers___


#include	<mmsystem.h>

//class CRetransTimer;
#include "MyTimer.h"

class CMMTimers //: public CObject
{
public:
	
	CMMTimers(UINT resolution);
	virtual ~CMMTimers();

	UINT	getTimerRes() { return timerRes; };

	BOOL	startTimer ( CMyTimer *pReTimer, UINT period, bool oneShot = FALSE);
	BOOL	stopTimer();

	void timerProc() { m_pParent->TimerProc(); };
	// virtual void timerProc() { m_pParent.TimerProc(timerID) };
protected:
	CMyTimer *m_pParent;
	UINT	timerRes;
	UINT	timerId;
};


#endif