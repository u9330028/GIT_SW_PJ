// TimeInfo.h: interface for the CTimeInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TIMEINFO_H__F1D44F3B_BB17_4B99_B7BB_8921EFBA04A2__INCLUDED_)
#define AFX_TIMEINFO_H__F1D44F3B_BB17_4B99_B7BB_8921EFBA04A2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "definition.h"
#include "packet.h"

class CTimeInfo : public CObject
{
public:
	BOOL m_bRetrans;
	BOOL IsRetrans();
	BOOL Tick(int nGranu);
	UINT m_nSeqNo;
	LONG m_nExpires;
	CTimeInfo(TimeInfo t);
	virtual ~CTimeInfo();

};

#endif // !defined(AFX_TIMEINFO_H__F1D44F3B_BB17_4B99_B7BB_8921EFBA04A2__INCLUDED_)
