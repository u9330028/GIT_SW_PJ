// SimpleTCPDemoDoc.cpp : implementation of the CSimpleTCPDemoDoc class
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"

#include "SimpleTCPDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoDoc

IMPLEMENT_DYNCREATE(CSimpleTCPDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CSimpleTCPDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CSimpleTCPDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoDoc construction/destruction

CSimpleTCPDemoDoc::CSimpleTCPDemoDoc()
{
	// TODO: add one-time construction code here

}

CSimpleTCPDemoDoc::~CSimpleTCPDemoDoc()
{
}

BOOL CSimpleTCPDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoDoc serialization

void CSimpleTCPDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoDoc diagnostics

#ifdef _DEBUG
void CSimpleTCPDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSimpleTCPDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSimpleTCPDemoDoc commands
