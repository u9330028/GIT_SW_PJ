// MyRichEdit.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "MyRichEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyRichEdit

CMyRichEdit::CMyRichEdit()
{
}

CMyRichEdit::~CMyRichEdit()
{
}


BEGIN_MESSAGE_MAP(CMyRichEdit, CRichEditCtrl)
	//{{AFX_MSG_MAP(CMyRichEdit)
	ON_WM_CREATE()
	ON_CONTROL_REFLECT(EN_SETFOCUS, OnSetfocus)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyRichEdit message handlers

void CMyRichEdit::AddText(CString &strTextIn, COLORREF &crNewColor)
{
	int iTotalTextLength = GetWindowTextLength();
	SetSel(iTotalTextLength, iTotalTextLength);
	ReplaceSel((LPCTSTR)strTextIn);
	int iStartPos = iTotalTextLength;

	CHARFORMAT cf;
	cf.cbSize		= sizeof(CHARFORMAT);
	cf.dwMask		= CFM_COLOR | CFM_UNDERLINE | CFM_BOLD;
	cf.dwEffects	= (unsigned long)~( CFE_AUTOCOLOR | CFE_UNDERLINE | CFE_BOLD);
	cf.crTextColor	= crNewColor;//RGB(0, 0, 0);
//	SetSelectionCharFormat(cf);

	int iEndPos = GetWindowTextLength();
	SetSel(iStartPos, iEndPos);
	SetSelectionCharFormat(cf);
	HideSelection(TRUE, FALSE);

	LineScroll(2);
	Invalidate();
}


int CMyRichEdit::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CRichEditCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CHARFORMAT cf;

	cf.cbSize = sizeof (CHARFORMAT);  
	cf.dwMask = CFM_FACE | CFM_SIZE; 
	//cf.dwEffects; 
	cf.yHeight = 180; 
	//cf.yOffset; 
	//cf.crTextColor=RGB(250,0,0); 
	//cf.bCharSet; 
	//cf.bPitchAndFamily; 
	sprintf(cf.szFaceName, "MS Sans Serif"); 
 
	SetDefaultCharFormat(cf); 
	
	return 0;
}

void CMyRichEdit::OnSetfocus() 
{
	Invalidate();
	
}
