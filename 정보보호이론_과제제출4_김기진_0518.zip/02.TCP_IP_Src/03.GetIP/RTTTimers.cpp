#include	"StdAfx.h"
#include	"RTTTimers.h"
#include	"RTTEstimator.h"

CRTT_Timer::CRTT_Timer(UINT resolution) : timerRes(0), timerId(0)
{
	TIMECAPS	tc;

	if (TIMERR_NOERROR == timeGetDevCaps(&tc,sizeof(TIMECAPS)))
	{
		timerRes = min(max(tc.wPeriodMin,resolution),tc.wPeriodMax);
		timeBeginPeriod(timerRes);
	}
}


CRTT_Timer::~CRTT_Timer()
{
	stopTimer();
	if (0 != timerRes)
	{
		timeEndPeriod(timerRes);
		timerRes = 0;
	}
}


extern "C"
void
CALLBACK
internalTickTimerProc(UINT id,UINT msg,DWORD dwUser,DWORD dw1,DWORD dw2)
{
	CRTT_Timer *	timer = (CRTT_Timer *)dwUser;

	timer->timerProc();
}


BOOL CRTT_Timer::startTimer(CRTTEstimator *pParent, UINT period, bool oneShot)
{
	bool		res = false;
	MMRESULT	result;

	if ( pParent == NULL ) 
	{
		AfxMessageBox("��");
		return FALSE;
	}
	m_pParent = pParent;
	
	result = timeSetEvent(period,timerRes,internalTickTimerProc,(DWORD)this,oneShot ? TIME_ONESHOT : TIME_PERIODIC);
	if (NULL != result)
	{
		timerId = (UINT)result;
		res = true;
	}

	return res;
}


BOOL CRTT_Timer::stopTimer()
{
	MMRESULT	result;

	result = timeKillEvent(timerId);
	if (TIMERR_NOERROR == result)
		timerId = 0;

	return TIMERR_NOERROR == result;
}

