// TCPSlidingWindow.cpp: implementation of the CTCPSlidingWindow class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCP.h"
#include "TCPSlidingWindow.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTCPSlidingWindow::CTCPSlidingWindow()
{
	m_maxCWndSize = 32;	// initial maximum congestion window size
	m_curWndSize = 1;	// initial congestion window size
	m_ssthreshold = 16;
	m_aWndSize = 100;	// always advertizement window size of receiver

	m_nAckedNo = 0;
	m_nSentNum = 0;		// for ACK : decrement, for Sending : increment.
	m_pTCP = NULL;
//	m_nDupackNum = 0;	// Received dupacket num.
	m_bFirstDupack = FALSE;
	m_nDupackSeqNo = 0;
}

CTCPSlidingWindow::~CTCPSlidingWindow()
{

}

int CTCPSlidingWindow::getCurCwnd()
{
	return (int)(m_curWndSize);// + 0.5); // half-rounding
}

int CTCPSlidingWindow::updateSlidingWnd ( TcpHdr rcvHdr)
{
	int nNotArrivedAck;
	UINT nCurAck;
	
	nCurAck = rcvHdr.basetcphdr.AckNo;
	
	// if cur ACK no is lower than prev ACK no,
	// discard window processing due to cumulative ACK
	if ( nCurAck < m_nAckedNo )
		return getCurCwnd();

	// calculate culmulative ack gap.
	nNotArrivedAck = nCurAck - m_nAckedNo - 1 ;
	
	TRACE("updataSliding Wnd=> nNotArrivedAck : %d, nCurACK:%d - m_nAckedNo:%d - 1 \n", 
		nNotArrivedAck, nCurAck, m_nAckedNo);

	if ( rcvHdr.basetcphdr.SYN == 1 ) // ���߿� �� �˻� ��ġ�� ���ľ� ��. 17�� ��.
	{	// �ʱ� ���ῡ ���� SYN�� ���� ������ SYN�̸� Cwnd ������Ʈ ����,

		m_nAckedNo = nCurAck;
		TRACE ("don't update window for connection setup => cur AckNo:%d\n",nCurAck);
		return getCurCwnd();
	}
		
	if ( m_nDupackSeqNo < nCurAck ) {
//		m_pTCP->History("m_bFirstDupack : FALSE", BLUE);
		m_bFirstDupack = FALSE;
	}

	if ( nNotArrivedAck >= 0 )
	{	// in order normal ACK : nNotArrivedAck == 0
		// Sliding window update for Not Arrived ACK
		// => (due to Culmulative ACK) : nNotArrivedAck > 0
			// retransmission ���� ��..............
//		TRACE("m_nDupackNum : %d, nNotArrivedAck:%d\n", m_nDupackNum , nNotArrivedAck);

//		if ( m_bFirstDupack && m_nDupackNum == 0 ) {
//			TRACE("m_nDupackNum : %d, m_bFirstDupack:FALSE");
//			m_bFirstDupack = FALSE;
//		}
		for ( int i = -1; i < nNotArrivedAck; i ++ )
		{
			if ( m_curWndSize < m_ssthreshold )
				m_curWndSize = m_curWndSize + 1.0;
			else if ( ( m_curWndSize >= m_ssthreshold) 
				&& ( m_curWndSize < m_maxCWndSize ))
			{
				m_curWndSize = m_curWndSize + (1.0/(int)m_curWndSize);
			}
			else // cwnd ��ȭ ����.
				m_curWndSize = (double)m_maxCWndSize;

		}
		m_nAckedNo = nCurAck;
		// gap �� ���°��  -1, �ִٸ� (gap+1)��ŭ ����
		m_nSentNum = m_nSentNum - (nNotArrivedAck+1);
		TRACE("updateSlidingWnd =>���� ������ ũ��:%f, ���纸����ũ��Ʈ����(m_nSentNum) :%d\n",m_curWndSize, m_nSentNum);
		m_strTemp.Format("Receiving a normal ACK for %dth data packet at %fsec", nCurAck-1, m_pTCP->GetETime());
		m_pTCP->History(m_strTemp,BLACK);
		m_strTemp.Format("Updated window size : %d, Current ssthreshold : %d", m_curWndSize, m_ssthreshold );

	}
	else if ( m_nAckedNo == nCurAck ) 
	{	// duplicate ACK
		if ( !m_bFirstDupack) { // && m_nDupackNum == 0 ) 
			m_bFirstDupack = TRUE;
			m_nDupackSeqNo = nCurAck;
		}
//		m_nDupackNum ++;

//		TRACE ("Duplicate ACK ���� m_bFirstDupack:%d, m_nDupackNum:%d\n", m_bFirstDupack, m_nDupackNum);
		TRACE ("Duplicate ACK ���� dupack no:%d\n", nCurAck);
		m_strTemp.Format("Receiving a duplicate ACK for %dth data packet at %fsec", nCurAck-1, m_pTCP->GetETime());
		m_pTCP->History(m_strTemp,RED);
		congestionControl();
	}
	else
	{ TRACE ( " �̻��� ������ ������ ����"); }

	m_strTemp.Format("Current WindowSize : %d, sshreshold : %d", int(m_curWndSize), m_ssthreshold );
	m_pTCP->History(m_strTemp, RED);

	return getCurCwnd();
}

void CTCPSlidingWindow::congestionControl()
{
	m_ssthreshold = max ((int)(min(m_curWndSize,m_aWndSize) / 2), 2 );
	m_curWndSize = 1;
	
	if ( m_bFirstDupack )
	{
		m_nSentNum = 0;
		m_bFirstDupack = FALSE;
	}


	m_strTemp.Format("Congestion Control Applied", RED);
	m_pTCP->History(m_strTemp,BLUE);
}

void CTCPSlidingWindow::SetAckedNo(UINT nAckedNo)
{
	m_nAckedNo = nAckedNo;
}

int CTCPSlidingWindow::GetAvailWnd()
{
	int nAvailWnd = 0;
	
//	nAvailWnd = min( m_curWndSize - (m_nLastSentNo - m_nAckedNo + 1), 
//					(int)m_curWndSize );
	nAvailWnd = min ( (int)(m_curWndSize - m_nSentNum), (int)m_curWndSize );
	TRACE("GetAvailWnd �ҷ��� : ������ ���� ũ�� %d\n", nAvailWnd );
	return nAvailWnd;
}

UINT CTCPSlidingWindow::GetAckedNo()
{
	return m_nAckedNo;
}

int CTCPSlidingWindow::AdjustSentWndForSending()
{
	m_nSentNum ++;	// increment for every sending.
		
	TRACE("Sended so ,,increment m_nSentNum : %d\n", m_nSentNum);
	return m_nSentNum;
}

void CTCPSlidingWindow::TimerExpired()
{
	congestionControl();
	
}

BOOL CTCPSlidingWindow::IsDupack(UINT nAckedNo)
{
	return (m_nAckedNo == nAckedNo);
}
