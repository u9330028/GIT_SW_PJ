//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleTCPDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SIMPLETCPDEMO_FORM          101
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_SIMPLETYPE                  129
#define IDD_TCP_HISTORY                 130
#define IDD_TCP_CHART                   131
#define IDD_MODIFY_NET_PARAMETER        132
#define IDD_TCP_SEQ                     133
#define IDC_BTN_WORK                    1000
#define IDC_BTN_EXIT                    1001
#define IDC_OPT_WORKINGMODE_SERVER      1003
#define IDC_OPT_WORKINGMODE_CLIENT      1004
#define IDC_BTN_FILE_SELECT             1005
#define IDC_ENV_DELAY                   1008
#define IDC_ENV_ERROR                   1009
#define IDC_BTN_NETWORK_PARAMETER       1010
#define IDC_EDIT_DST_PORT_NUM           1011
#define IDC_EDIT_WORKING_PORT_NUM       1012
#define IDC_DST_PORT_LABEL              1013
#define IDC_LOCAL_IP_LABEL              1014
#define IDC_SELECTED_FILENAME           1015
#define IDC_DST_IP_LABEL                1016
#define IDC_IP_DST                      1017
#define IDC_STATIC_HISTORY_RICHEDIT     1018
#define IDC_TAB_HISTORY_STATISTICS      1019
#define IDC_STATIC_CGST_CONTROL         1020
#define IDC_BTN_TEST                    1023
#define IDC_OPTION_ERROR_FIXED          1024
#define IDC_OPTION_ERROR_SEQNO          1025
#define IDC_OPTION_DELAY_FIXED          1026
#define IDC_OPTION_DELAY_RANDOM         1027
#define IDC_DELAY_FIXED_VALUE           1029
#define IDC_DELAY_RANDOM_LOW            1030
#define IDC_DELAY_RANDOM_HIGH           1031
#define IDC_ERROR_FIXED_RATE            1032
#define IDC_ERROR_SEQ_NO                1033
#define IDC_OPTION_ERROR_NONE           1034
#define IDC_STATIC_SEQ_CWND             1035
#define IDC_OPTION_DELAY_NONE           1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
