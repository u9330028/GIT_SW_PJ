// RcvBuf.h: interface for the CRcvBuf class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RCVBUF_H__9E7E8E0B_77D2_462F_9387_299E9EA5064B__INCLUDED_)
#define AFX_RCVBUF_H__9E7E8E0B_77D2_462F_9387_299E9EA5064B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "packet.h"
#include "SimpleTCP.h"	// Added by ClassView

class CRcvBuf  
{
public:
	CString m_strTemp;
	CSimpleTCP *m_pTCP;
	int RcvInOrderSeq(UINT nSeqNo);
	void DeleteAllRcvBuf();
	UINT GetRecentAckNo();
	CObList m_ListRcvBuf;
	BOOL AddSegment(Segment Seg);
	BOOL CheckOrder(Segment pRcvSeg);
	UINT GetSendingAckNo();
	UINT m_nRecentSentAckedNo;
	CRcvBuf();
	virtual ~CRcvBuf();

};

#endif // !defined(AFX_RCVBUF_H__9E7E8E0B_77D2_462F_9387_299E9EA5064B__INCLUDED_)
