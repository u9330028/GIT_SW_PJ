// SegBuf.cpp: implementation of the CSegBuf class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "SegBuf.h"
#include "SimpleTCP.h"
#include "Segment.h"
#include "definition.h"
#include "MyTimer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSegBuf::CSegBuf()
{
	m_pTCP = NULL;
	m_pSendingTimer = new CMyTimer(this);
	m_pSendingTimer->StartTimer(TIMER_TYPE_DELAY, DELAY_GRANUALITY);
}

CSegBuf::~CSegBuf()
{
	DeleteAllSegment();
	if ( m_pSendingTimer )
		delete m_pSendingTimer;
}
/*
void CSegBuf::RetransSegment(UINT nSeqNo)
{

	TRACE("Retransmit Seq No : %d\n", nSeqNo);
	
	m_pTCP->History("Retrans Timer Expired and Retransmission => expired seqNo : %d",0);
}
*/
void CSegBuf::DeleteSegment(UINT nSeqNo)
{
	CSegment *pSeg = NULL;
	
	POSITION pos, prev;

	for ( pos = m_ListSeg.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListSeg.GetNext(pos);
		if ( pSeg->m_SeqNo == nSeqNo)
		{
			delete pSeg;
			m_ListSeg.RemoveAt(prev);
			TRACE ( "CSegBuf : Delete Segment : current array size : %d\n", m_ListSeg.GetCount()) ;
		}
	}
}

BOOL CSegBuf::SendSegment ( void *seg, int nSize, int nDstPort, 
		CString strDstIP, int nDelay, BOOL bError, BOOL bRetrans )
{
	if ( seg == NULL) 
		return FALSE;

	m_strDstIP = strDstIP;
	m_nDstPort = nDstPort;

	TimeInfo t;
	// Segment *p_seg;

	t.Expires = nDelay;
	if (nSize == HEADER_SIZE ) 	
		t.SeqNo = ((TcpHdr*)seg)->basetcphdr.SeqNo; //���� ���� ����.
	else 
		t.SeqNo = ((Segment*)seg)->tcphdr.basetcphdr.SeqNo; //���� ���� ����.
	if (bRetrans) 
		t.bRetrans = TRUE;

	if (t.SeqNo < 0) return FALSE;

	//CSegment *pSeg = new CSegment()seg, nSize, nDelay, this);

	// �������ϴ� ���� ���� Ÿ�̸� �����ϰ� ���� �Ѵ�. �̹� �Ҵ���� ���۰� �����Ƿ�.
	if ( bRetrans )  {
		if ( nSize == HEADER_SIZE ) {
			CSegment* p = GetSegment( ((TcpHdr*)seg)->basetcphdr.SeqNo);
			if (!p) {AfxMessageBox("��? ���̳�"); return FALSE;}
			p->SetSegInfo(seg, nSize,this, TRUE);
		}
		else
		{
			CSegment *p = GetSegment(((Segment*)seg)->tcphdr.basetcphdr.SeqNo);
			if (!p) {AfxMessageBox("��? ���̳�"); return FALSE;}
			p->SetSegInfo(seg, nSize,this, TRUE);
		}
		m_pSendingTimer->AddTimer(t);
		return TRUE;
	}
	// if not retransmission, allocate segment.
	CSegment *pSeg = new CSegment();
	if ( pSeg == NULL ) return FALSE;

	pSeg->SetSegInfo(seg,nSize,this, FALSE);
	
	try {
		m_ListSeg.AddTail(pSeg);
		// Send Segment���� ���� �����Ѵ�.
	//	pSeg->SendSegment(seg, nSize, nDelay, this);
		m_pSendingTimer->AddTimer(t);

	} catch ( CMemoryException *er) {
		AfxMessageBox ("Out of Memory");
		if ( pSeg ) {
			delete pSeg;
			pSeg = NULL;
		}
		er -> Delete();
		return FALSE;
	}
	return TRUE;
}

void CSegBuf::DelayTimerExpired(int TimerID, UINT seqNo) // delay timer expire�� �ҷ�����.
{
	CSegment *pSeg = NULL;
	TcpHdr seg_hdr;
	Segment seg_data;
	int	nSize;
	BOOL bSendingOK = FALSE;

	pSeg = GetSegment(seqNo);

	if (pSeg == NULL) 
	{ 
		m_strTemp.Format("Delayed expired buf no segment : seq no :%d", seqNo);
		TRACE(m_strTemp);
		//AfxMessageBox(m_strTemp); 
		return; 
	}
	
	/********** ������ ��� �׳� ������. ***********/
	if ( m_pTCP->GetWorkMode() == SERVER )
	{
		nSize = pSeg->m_nSegLen;
		seg_hdr = pSeg->m_TcpHdr;
		SendToUdp((void*)&seg_hdr, nSize);
		// In Server mode, delete sending segment because of no retransmittion.
		DeleteSegment(seqNo);
		TRACE ("Delay Timer Expired => Seq No : %d\n", seqNo );
		return;
	}
	/***********************************************/
	/*
	// Ŭ���̾�Ʈ�� ������ �����찡 �־�� ������ �ִ�.
	if ( m_pTCP->m_tcpSlidingWnd.GetAvailWnd() == 0) {
		m_strTemp.Format("Delay Timer Expired but nothing available window");
		m_pTCP->History(m_strTemp,0);
		return;
	}	
	*/
	
	nSize = pSeg->m_nSegLen;
	
	if ( pSeg->m_nSegLen == SEG_SIZE ) 
	{
		seg_data = pSeg->m_TcpSegment;
		SendToUdp((void*)&seg_data, nSize);
	}
	else if ( pSeg->m_nSegLen == HEADER_SIZE )
	{
		seg_hdr = pSeg->m_TcpHdr;
		SendToUdp((void*)&seg_hdr, nSize);
	}
	TRACE ("Delay Timer Expired => Seq No : %d\n", seqNo );
}

CSegment * CSegBuf::GetSegment(UINT nSeqNo)
{
	CSegment *pSeg = NULL;
	
	POSITION pos, prev;

	for ( pos = m_ListSeg.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListSeg.GetNext(pos);
		if ( pSeg->m_SeqNo == nSeqNo)
		{
			TRACE ( "GetSegment : current array size : %d\n",m_ListSeg.GetCount() ) ;
			
			return pSeg;
		}
	}

	return NULL;
}

void CSegBuf::DeleteAllSegment()
{
	CSegment *pSeg = NULL;
	
	POSITION pos, prev;

	for ( pos = m_ListSeg.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListSeg.GetNext(pos);
		if ( pSeg ) 
		{
			delete pSeg;
			pSeg = NULL;
			TRACE ( "GetSegment : current array size : %d\n",m_ListSeg.GetCount() ) ;
		}
	}
	m_ListSeg.RemoveAll();
	TRACE("Delete All Segment \n") ;
}

int CSegBuf::ReleaseBufForACK(UINT nRcvAckNo)
{
	// Ÿ�̸� ���� �������, Cumulative ACK �̹Ƿ� ������ ���´� Ÿ�̸ӵ鵵 ���� ����.
	CSegment *pSeg= NULL;

	int nDeleted = 0;
	int delseqno = 0;
		
	POSITION pos, prev;

	for ( pos = m_ListSeg.GetHeadPosition(); (prev=pos) != NULL;)
	{
		pSeg = (CSegment *)m_ListSeg.GetNext(pos);
		if ( pSeg->m_SeqNo < nRcvAckNo )
		{
			nDeleted ++;
			delseqno = pSeg->m_SeqNo;
			delete pSeg;
			m_ListSeg.RemoveAt(prev);
			TRACE ("Release Buffer for ACK => rcvAckNo:%d, del seq no:%d\n", nRcvAckNo, delseqno) ;
		}
	}
	return nDeleted;
}

int CSegBuf::SendToUdp(void *seg, int nSize)
{
	/*
	// m_AppMode�� Ack�� ����Ÿ ���� �Ⱥ����� ����̸� window���� ������Ʈ ���ʿ�
	// ����. ( �Ʒ� �κ� ������ �ʿ��� �������..
	if ( (m_pTCP->GetWorkMode() == CLIENT) &&
		(m_pTCP->m_TCPStatus == ESTABLISHED) &&
		(m_pTCP->m_AppMode == FILE_TRANS_MODE) // ���߿� ��忡 ���� ��� �߰��ؾ���.
		) 
	{
		m_pTCP->m_tcpSlidingWnd.AdjustSentWndForSending();
	}
	*/
	return m_pTCP->SendTo(seg, nSize, m_nDstPort, m_strDstIP.GetBuffer(m_strDstIP.GetLength()));
}

int CSegBuf::GetCount()
{
	return m_ListSeg.GetCount();
}
