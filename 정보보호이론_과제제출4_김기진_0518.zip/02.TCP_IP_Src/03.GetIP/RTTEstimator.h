// RTTEstimator.h: interface for the CRTTEstimator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RTTESTIMATOR_H__272C79C4_662D_4C9B_95DE_5D4D3EE6813B__INCLUDED_)
#define AFX_RTTESTIMATOR_H__272C79C4_662D_4C9B_95DE_5D4D3EE6813B__INCLUDED_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRTT_Timer;
class CSimpleTCP;

class CRTTEstimator  
{
protected:

public:
	UINT m_nSeqNo;
	UINT GetRTT();
	CSimpleTCP *m_pTCP;
	UINT m_nGranuality;
	BOOL IsWorking();
	CString m_strTemp;
	UINT m_nRTT;
	BOOL RTTUpdate(int nAckNo);
	BOOL m_bRttWorking;
	void RttStart(UINT nSeqNo);
	UINT GetTickCount();
//	UINT m_nStartTickCount;
	void TimerProcTick();
	UINT m_nTickCount;
	void StartTimer(int nTimerID, int nGranuality);
	CRTT_Timer *m_rttTimer;
	CRTTEstimator();
	virtual ~CRTTEstimator();

};

#endif // !defined(AFX_RTTESTIMATOR_H__272C79C4_662D_4C9B_95DE_5D4D3EE6813B__INCLUDED_)
