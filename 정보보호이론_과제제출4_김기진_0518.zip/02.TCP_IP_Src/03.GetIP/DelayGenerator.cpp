// DelayGenerator.cpp: implementation of the CDelayGenerator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCP.h"
#include "DelayGenerator.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDelayGenerator::CDelayGenerator()
{
	m_nOptDelay = 0;
	m_nFixedDelay = 1000;
	m_nDelayRdHigh = 1000;
	m_nDelayRdLow = 50;

}

CDelayGenerator::~CDelayGenerator()
{
	
}

#define OPT_DELAY_FIXED		0
#define OPT_DELAY_RANDOM	1
#define OPT_DELAY_NONE		2

UINT CDelayGenerator::GetDelay()
{

	if ( m_nOptDelay == OPT_DELAY_FIXED )
	{
		return m_nFixedDelay;
	}
	else if ( m_nOptDelay == OPT_DELAY_RANDOM )
	{
		return GetRandDelay();
	}
	else {
		return 0;
	}
	return 0;	
}

void CDelayGenerator::SetDelayParam(int nOptDelay, UINT nFixedDelay, UINT nDelayRdLow, UINT nDelayRdHigh)
{
	m_nOptDelay = nOptDelay;
	m_nFixedDelay = nFixedDelay ;

	if ( nDelayRdHigh < nDelayRdLow ) {
		m_nDelayRdHigh = nDelayRdLow;
		m_nDelayRdLow = nDelayRdHigh;
	}
	else {
		m_nDelayRdHigh = nDelayRdHigh;
		m_nDelayRdLow = nDelayRdLow;
	}
}

UINT CDelayGenerator::GetRandDelay()
{
	srand((unsigned)time(NULL));
	return (rand() % ( m_nDelayRdHigh - m_nDelayRdLow + 1) + m_nDelayRdLow);
}
