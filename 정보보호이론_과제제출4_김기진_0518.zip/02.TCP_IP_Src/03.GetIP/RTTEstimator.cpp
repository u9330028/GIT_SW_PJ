// RTTEstimator.cpp: implementation of the CRTTEstimator class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCPDemo.h"
#include "RTTEstimator.h"
#include "RTTTimers.h"
#include "SimpleTCP.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRTTEstimator::CRTTEstimator()
{
	m_nTickCount = 0;
	m_rttTimer = NULL;
	m_bRttWorking = FALSE;
	m_nRTT = 0;
	m_nGranuality = 500;
}

CRTTEstimator::~CRTTEstimator()
{
	if (m_rttTimer)
		delete m_rttTimer;
}

void CRTTEstimator::StartTimer(int nTimerID, int nGranuality)
{
	m_nGranuality = nGranuality;
	m_rttTimer = new CRTT_Timer(0);
	m_rttTimer->startTimer(this, nGranuality);
}


void CRTTEstimator::TimerProcTick()
{
	m_nTickCount ++;
}

UINT CRTTEstimator::GetTickCount()
{
	return m_nTickCount;
}

void CRTTEstimator::RttStart(UINT nSeqNo)
{
	m_bRttWorking = TRUE;
	m_nSeqNo = nSeqNo;
	// m_nStartTickCount = m_nTickCount;
	m_nTickCount = 0;
}

// �����Ǹ� TRUE;
BOOL CRTTEstimator::RTTUpdate(int nAckNo)
{
	if ( m_bRttWorking & ( (nAckNo-1)==m_nSeqNo) ) 
	{
		m_bRttWorking = FALSE;
		m_nRTT = GetTickCount()*500;
		m_strTemp.Format("Sampled Tick Count : %d", GetTickCount());
		m_pTCP->History(m_strTemp, BLACK);

		return TRUE;
	}
	else if ( (nAckNo-1) > m_nSeqNo  )
	{
		m_bRttWorking = FALSE;
		return FALSE;
	}
	else
		return FALSE;
}

BOOL CRTTEstimator::IsWorking()
{
	return m_bRttWorking;
}

UINT CRTTEstimator::GetRTT()
{
	return m_nRTT;
}
