#if !defined(AFX_STATCHARTDLG_H__39D0352C_5244_4926_B382_C859F17E6ABE__INCLUDED_)
#define AFX_STATCHARTDLG_H__39D0352C_5244_4926_B382_C859F17E6ABE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatChartDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStatChartDlg dialog
#include "StatChart.h"

class CStatChartDlg : public CDialog
{
// Construction
public:
	BOOL UpdateCwnd(Database db);
	float GetRecentRecTime(int nType, int nMode);	// nType : CWND or SEQNO, nMode : CHART_CWND or CHART..
	BOOL AddCwnd(Database db);
	BOOL AddSeqNo(Database db);
	
	int m_nTemp;
	void AddData(UINT data);
	CStatChartDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStatChartDlg)
	enum { IDD = IDD_TCP_CHART };
	CStatChart	m_ctrlChart;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStatChartDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStatChartDlg)
		virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATCHARTDLG_H__39D0352C_5244_4926_B382_C859F17E6ABE__INCLUDED_)
