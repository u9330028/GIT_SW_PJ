// Segment.cpp: implementation of the CSegment class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleTCP.h"
#include "Segment.h"
#include "SegBuf.h"
#include "packet.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSegment::CSegment()
{
	
	m_nSegLen = 0;
	m_pSegBuf = NULL;
	m_SeqNo = 0;
	m_bRetrans = FALSE;
}
CSegment::~CSegment()
{

}



UINT CSegment::GetSeqNo()
{
	return m_SeqNo;
}

void CSegment::RcvSegment(Segment Seg)
{
	int nSegLen;

	nSegLen = Seg.tcphdr.basetcphdr.TotalLen;
	
	if ( nSegLen == HEADER_SIZE )
		m_nSegLen = HEADER_SIZE ;
	else
		m_nSegLen = SEG_SIZE ;
		
	if ( m_nSegLen == SEG_SIZE)
	{
		memcpy(&m_TcpSegment, &Seg, SEG_SIZE);
		memset(&m_TcpHdr, 0, HEADER_SIZE);
		
		m_SeqNo = Seg.tcphdr.basetcphdr.SeqNo;
	}
	else if ( nSegLen == HEADER_SIZE)
	{
		memcpy(&m_TcpHdr, &Seg, HEADER_SIZE);
		memset(&m_TcpSegment, 0, SEG_SIZE);

		m_SeqNo = Seg.tcphdr.basetcphdr.SeqNo;
	}
	
}

int CSegment::SetSegInfo(void *seg, int nSegLen, CSegBuf *pSegBuf,BOOL bRetrans)
{
	m_nSegLen = nSegLen;

	if (seg == NULL) return -1;

	if ( nSegLen == SEG_SIZE)
	{
		memcpy(&m_TcpSegment, seg, SEG_SIZE);
		memset(&m_TcpHdr, 0, HEADER_SIZE);
		
		m_SeqNo = ((Segment *)seg)->tcphdr.basetcphdr.SeqNo;
		m_pSegBuf = pSegBuf;
		m_bRetrans = bRetrans;
		// delay timer start
		
	}
	else if(nSegLen == HEADER_SIZE)
	{
		memcpy(&m_TcpHdr, seg, HEADER_SIZE);
		memset(&m_TcpSegment, 0, SEG_SIZE);

		m_SeqNo = ((TcpHdr *)seg)->basetcphdr.SeqNo;
		m_pSegBuf = pSegBuf;
		m_bRetrans = bRetrans;
		// delay timer start
	}
	return m_SeqNo;
}
