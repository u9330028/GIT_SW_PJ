#if !defined(AFX_SIMPLETCP_H__55957027_F4A2_448F_9915_E4EAA8001DC0__INCLUDED_)
#define AFX_SIMPLETCP_H__55957027_F4A2_448F_9915_E4EAA8001DC0__INCLUDED_

#include "DelayGenerator.h"	// Added by ClassView
#include "TCPSlidingWindow.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SimpleTCP.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CSimpleTCP command target
#include "packet.h"
//#include "RetransTimer.h"
#include "CalRTO.h"	// Added by ClassView
#include "SegBuf.h"
#include "RcvBuf.h"	// Added by ClassView
#include "MyReTimer.h"
#include "ErrorGenerator.h"	// Added by ClassView
#include "RTTEstimator.h"
//#include "Segment.h"	// Added by ClassView
//#include "SimpleTCPDemoView.h"
//class CSimpleTCPDemoView; 

class CSimpleTCP : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CSimpleTCP(CWnd *pParentWnd = NULL);
	virtual ~CSimpleTCP();

// Overrides
public:
	BOOL RecordSeqCWnd(int nCWnd, double time);
	BOOL RecordSeq(float SeqNo, double time);
	BOOL m_bSimulEnded;
	UINT m_nFinForAckNo;
	void SendFINorACK(UINT nAckNo);
	void CloseSocket();
	void TransBufferedSeg(int nAckedNo);
	void RetransSeg(UINT nSeqNo);
	double m_dDataStartTime;
	CRTTEstimator m_rttTimer;
	CString m_strTemp;
	double GetSystemTime();
	CErrorGenerator m_errorGen;
	CDelayGenerator m_delayGen;
	void History(CString strMsg, int nMsgType);
	double GetETime();
	double m_dSimulStartTime;
	BOOL RecordCwnd(double nCwnd=0, double time=0.0);
	Database m_tempDBSeqNo;
	Database m_tempDBCwnd;
	UINT m_nLocalPort;
	void ReceiveFile(Segment seg);
	int m_TCPStatus;
	int m_AppMode;
	CWnd * m_pSendingFile;
	// CWnd * m_pMainWnd;		// Main Frame pointer
	void SendFile(CWnd *m_pFile, CString dstIP, int nServerPort, UINT nLocalPort);
	CWnd * m_pParentWnd;
	BOOL GetWorkMode();
	void SendACK(BOOL bInOrder, BOOL bSYNFlag=FALSE, BOOL bFINFlag=FALSE); // only server used
	CRcvBuf m_RcvBuf;
	CSegBuf m_segBuf;
	void RetransTimerExpired(UINT nExpiredSeqNo);
	CMyReTimer m_reTimer;
	CTCPSlidingWindow m_tcpSlidingWnd;
	void SetDstInfo(UINT nDstPort, CString strDstIP);
	CString m_strDstIP;
	UINT m_nDstPort;
	int SendSegment ( void *seg, int nSize, BOOL bRetrans=FALSE, double time_stamp=-1);// , int dstPort, CString dstIP);
	CCalRTO m_calRTO;
	void InitSegment(void *seg, int size);
	int m_bWorkMode;
	UINT m_curSeqNo;
	BOOL m_bConnected;
	int ConnectToServer(CString dstIP, int dstPort, UINT nLocalPort);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleTCP)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CSimpleTCP)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLETCP1_H__55957027_F4A2_448F_9915_E4EAA8001DC0__INCLUDED_)
