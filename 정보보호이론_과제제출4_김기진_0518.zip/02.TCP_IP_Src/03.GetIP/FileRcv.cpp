// FileRcv.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleTCP.h"
#include "FileRcv.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileRcv

CFileRcv::CFileRcv(CWnd *pParentWnd)
{
	
	m_pParentWnd = pParentWnd;
	if (!Create(NULL, "", WS_CHILD, CRect(0, 0, 0, 0), pParentWnd, m_hFile))
		AfxMessageBox("������ ��������");
	
//	m_nReceivingStatus = FILE_NONE_STATUS;
	m_hFile = HFILE_ERROR;
//	m_pTCP = NULL;
}

CFileRcv::~CFileRcv()
{
}


BEGIN_MESSAGE_MAP(CFileRcv, CWnd)
	//{{AFX_MSG_MAP(CFileRcv)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFileRcv message handlers
