#if !defined(AFX_FILERCV_H__81ACD1FD_DD5F_486E_84EC_F3B8184D8ECF__INCLUDED_)
#define AFX_FILERCV_H__81ACD1FD_DD5F_486E_84EC_F3B8184D8ECF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FileRcv.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFileRcv window

class CFileRcv : public CWnd
{
// Construction
public:
	CFileRcv(CWnd *pParentWnd=NULL);
	HFILE m_hFile;
	LONG m_nFileSize;
	CString m_strFileName;
// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileRcv)
	//}}AFX_VIRTUAL

// Implementation
public:
	CWnd * m_pParentWnd;
//	UINT m_nReceivingStatus;

	virtual ~CFileRcv();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFileRcv)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILERCV_H__81ACD1FD_DD5F_486E_84EC_F3B8184D8ECF__INCLUDED_)
