// MyReTimer.h: interface for the CMyReTimer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYRETIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_)
#define AFX_MYRETIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TimeInfo.h"
//#include "SimpleTCP.h"	// Added by ClassView
//#include "SegBuf.h"	// Added by ClassView
//
//#include "SegBuf.h"
class CSimpleTCP;
class CMMReTimers;
class CSegBuf;

class CMyReTimer  
{
public:
	CSegBuf *m_pSegBuf;
	CString m_strTemp;
	CSimpleTCP * m_pTCP;
	void DeleteAllTimeInfo();
	CTimeInfo * FindTimeInfo(UINT nSeqNo);
	int DelTimeInfoForAck(UINT nRcvAckNo, BOOL bDupack);
	int m_nTempIdx;
	UINT m_nGranuality;
	void StartTimer(int nTimerID, int nGranuality=0);
//	CSegBuf * m_pParent;
	void TimerProc();
	int m_nTimerType;
	CMMReTimers * m_pReTimer;
	CObList m_ListTimeInfo;
	void AddTimer(TimeInfo t, BOOL bSort=FALSE, int nSortMode = SORT_BY_SEQ_NO);
	CMyReTimer();//CSegBuf* pParent);
	virtual ~CMyReTimer();

};

#endif // !defined(AFX_MYTIMER_H__F34637FD_0C69_4F0A_80A4_5E2867DEBD08__INCLUDED_)
