// SegBuf.h: interface for the CSegBuf class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEGBUF_H__20D57372_4522_4CD9_BAD9_7586C16508B4__INCLUDED_)
#define AFX_SEGBUF_H__20D57372_4522_4CD9_BAD9_7586C16508B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "Segment.h"

class CSimpleTCP;
class CSegment;
class CMyTimer;
class CSegBuf  
{
public:
	int GetCount();
	int SendToUdp(void *seg, int nSize);
	CString m_strTemp;
	CMyTimer *m_pSendingTimer;
	int ReleaseBufForACK(UINT nRcvAckNo);
	void DeleteAllSegment();
	CSegment * GetSegment(UINT seqNo);
	int m_nDstPort;
	CString m_strDstIP;
	void DelayTimerExpired(int TimerID, UINT seqNo);
	
	CObList m_ListSeg;

	CSimpleTCP *m_pTCP;
	
	BOOL SendSegment(void *seg, int nSize, int m_nDstPort, 
		CString strDstIP, int nDelay, BOOL bError, BOOL bRetrans=FALSE);

	void DeleteSegment(UINT nSeqNo);
	//void RetransSegment(UINT nSeqNo);
	CSegBuf();
	virtual ~CSegBuf();

};

#endif // !defined(AFX_SEGBUF_H__20D57372_4522_4CD9_BAD9_7586C16508B4__INCLUDED_)
