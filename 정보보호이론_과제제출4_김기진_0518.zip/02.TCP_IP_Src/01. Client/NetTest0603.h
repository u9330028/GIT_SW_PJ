// NetTest0603.h : main header file for the NETTEST0603 application
//

#if !defined(AFX_NETTEST0603_H__B36CB76A_0D48_4D72_91C6_2493A602A0F0__INCLUDED_)
#define AFX_NETTEST0603_H__B36CB76A_0D48_4D72_91C6_2493A602A0F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CNetTest0603App:
// See NetTest0603.cpp for the implementation of this class
//

class CNetTest0603App : public CWinApp
{
public:
	CNetTest0603App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetTest0603App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CNetTest0603App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETTEST0603_H__B36CB76A_0D48_4D72_91C6_2493A602A0F0__INCLUDED_)
