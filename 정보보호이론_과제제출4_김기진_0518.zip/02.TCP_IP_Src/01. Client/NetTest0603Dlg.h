// NetTest0603Dlg.h : header file
//

#if !defined(AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_)
#define AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NetWallTalk.h"
/////////////////////////////////////////////////////////////////////////////
// CNetTest0603Dlg dialog

class CNetTest0603Dlg : public CDialog
{
// Construction
public:
	CNetWallTalk* m_pNetWallTalk;                               // CNetWallTalk�� ������ ������Ʈ 
	CNetTest0603Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CNetTest0603Dlg)
	enum { IDD = IDD_NETTEST0603_DIALOG };
	CIPAddressCtrl	m_CtrlIPAddress;
	UINT	m_SocketPort;
	CString	m_szSendStr;
	int		m_nMode;
	CString	m_szReceiveStr;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetTest0603Dlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int AppendReceiveStr(CString sData);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNetTest0603Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
    afx_msg LRESULT OnMsgAccept(WPARAM wParam, LPARAM lParam);          // ���� ����(��������ϰ�� onAccept���Ž�)
	afx_msg LRESULT OnMsgClose(WPARAM wParam, LPARAM lParam);	        // ���� ����(����, Ŭ���̾�Ʈ ����� ��� onClose���Ž�)
	afx_msg LRESULT OnMsgReceive(WPARAM wParam, LPARAM lParam);	        // ������ ���Ž�(����, Ŭ���̾�Ʈ ����� ��� onReceive���Ž�)
	afx_msg void OnRadioClient();
	afx_msg void OnRadioServer();
	afx_msg void OnBTNSet();
	afx_msg void OnBTNSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_)
