// NetTest0603Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "NetTest0603.h"
#include "NetTest0603Dlg.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetTest0603Dlg dialog

CNetTest0603Dlg::CNetTest0603Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNetTest0603Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNetTest0603Dlg)
	m_SocketPort = 0;
	m_szSendStr = _T("");
	m_nMode = -1;
	m_szReceiveStr = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CNetTest0603Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNetTest0603Dlg)
	DDX_Control(pDX, IDC_IPAddress, m_CtrlIPAddress);
	DDX_Text(pDX, IDC_EditPort, m_SocketPort);
	DDX_Text(pDX, IDC_EditSend, m_szSendStr);
	DDX_Radio(pDX, IDC_RadioClient, m_nMode);
	DDX_Text(pDX, IDC_ReceiveStr, m_szReceiveStr);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNetTest0603Dlg, CDialog)
	//{{AFX_MSG_MAP(CNetTest0603Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
    ON_MESSAGE(NET_MSG_ACCEPT,  OnMsgAccept)            // ���� ����
	ON_MESSAGE(NET_MSG_CLOSE,   OnMsgClose)             // ���� ����
	ON_MESSAGE(NET_MSG_RECEIVE, OnMsgReceive)           // �������� ���� ���ŵǴ� ������
	ON_BN_CLICKED(IDC_RadioClient, OnRadioClient)
	ON_BN_CLICKED(IDC_RadioServer, OnRadioServer)
	ON_BN_CLICKED(IDC_BTNSet, OnBTNSet)
	ON_BN_CLICKED(IDC_BTNSend, OnBTNSend)
	ON_BN_CLICKED(IDC_BTNSendRecv, OnBTNSendRecv)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetTest0603Dlg message handlers

BOOL CNetTest0603Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
    CString Temp;
    Temp.Format("SocketTest (%s)",CNetWallTalk::GetLocalIP());
    SetWindowText(Temp);                                            // ���̾�α��� Text�� �����Ѵ�."SocketTest(IP Address)"
    
    m_nMode = 0;                                                    // ó�������� Client�� �Ѵ�.
    UpdateData(FALSE);

    (CEdit*)(GetDlgItem(IDC_EditSend))->EnableWindow(FALSE);        // ���ۿ����͸� ���̺� ��Ų��.
    (CButton*)(GetDlgItem(IDC_BTNSend))->EnableWindow(FALSE);       // ���۹����� ���̺� ��Ų��.
    
    struct in_addr IPAddress;
    IPAddress.S_un.S_un_b.s_b4 = 192;
    IPAddress.S_un.S_un_b.s_b3 = 168;
    IPAddress.S_un.S_un_b.s_b2 = 190;
    IPAddress.S_un.S_un_b.s_b1 = 140;
    m_CtrlIPAddress.SetAddress(IPAddress.S_un.S_addr);              // IP�ּҸ� �����Ѵ�.

    m_SocketPort = 2001;                                            // ��Ʈ��ȣ�� �����Ѵ�.
    UpdateData(FALSE);
    
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CNetTest0603Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNetTest0603Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNetTest0603Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// CNetWallTalk���� ���� NET_MSG_ACCEPT�� �������� ��� ����Ǵ� �Լ� 
LRESULT CNetTest0603Dlg::OnMsgAccept(WPARAM wParam, LPARAM lParam)
{
    //AfxMessageBox("Accpet");
    CString Temp;

    Temp.Format("����(%s) Ŭ���̾�Ʈ(%s) ����Ǿ����ϴ�.",m_pNetWallTalk->GetServerIPAddress(),
                                                          m_pNetWallTalk->GetClientIPAddress());
    AppendReceiveStr(Temp);

    return 0;
}

// CNetWallTalk���� ���� NET_MSG_CLOSE�� �������� ��� ����Ǵ� �Լ� 
LRESULT CNetTest0603Dlg::OnMsgClose(WPARAM wParam, LPARAM lParam)
{
    //AfxMessageBox("Close");
    CString Temp;

    Temp.Format("������ ���������ϴ�");
    AppendReceiveStr(Temp);

    if(0 == m_nMode)            // Ŭ���̾�Ʈ�� ��츸 
    {
        OnBTNSet();             // ���� ����ó���� �Ѵ�.
    }

    return 0;
}

// CNetWallTalk���� ���� NET_MSG_RECEIVE�� �������� ��� ����Ǵ� �Լ� 
LRESULT CNetTest0603Dlg::OnMsgReceive(WPARAM wParam, LPARAM lParam)
{

    //AfxMessageBox("Receive");
    CString Temp;
    BYTE* pByte;
    UINT Size = m_pNetWallTalk->GetReceiveDataSize();       // ������ �޼��� ����� ��´�.

    pByte = new BYTE[Size + 1];
    
    m_pNetWallTalk->GetReceiveData(pByte, Size);            // ������ �޼����� �����´�.
    pByte[Size] = 0x00;

    Temp.Format("[����]%s",pByte);
    AppendReceiveStr(Temp);
    
    delete pByte;

    return 0;
}


BOOL CNetTest0603Dlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if((pMsg->message == WM_KEYDOWN) && (pMsg->wParam == VK_RETURN))	// ���̾�α� �ڽ����� ���͸� ������ ����Ǵ°��� ���� ���ؼ� 
    {
        return TRUE;
    }

	return CDialog::PreTranslateMessage(pMsg);
}

// Ŭ���̾�Ʈ ���� ������ Ŭ�������� 
void CNetTest0603Dlg::OnRadioClient() 
{
	// TODO: Add your control notification handler code here
	m_nMode = 0;                                            // Ŭ���̾�Ʈ ���� ����

    (CIPAddressCtrl*)(GetDlgItem(IDC_IPAddress))->EnableWindow(TRUE);

}

// ���� ���� ������ Ŭ������ �� 
void CNetTest0603Dlg::OnRadioServer() 
{
	// TODO: Add your control notification handler code here
	m_nMode = 1;                                            // ���� ���� ����

    (CIPAddressCtrl*)(GetDlgItem(IDC_IPAddress))->EnableWindow(FALSE);
}

// ���ἳ�������� Ŭ�������� ����Ǵ� �Լ�
void CNetTest0603Dlg::OnBTNSet() 
{
    // TODO: Add your control notification handler code here
    static BOOL IsSet = FALSE;									// ������ �Ǿ����� �˻��ϴ� ���� 
    CString IPStr;
    CString Temp;

    UpdateData(TRUE);                           // ���Ϸ��α׿� �ִ� ���� �����;���...
    
    CWnd* pWnd = GetDlgItem(IDC_BTNSet);

    if(FALSE == IsSet)							// ������ �Ǿ� ���� ���� ��� 
    {
        
        // ����忡 ���� �ٸ��� ������ �Ѵ�.
        switch(m_nMode)
        {
        case 0:                     // Ŭ���̾�Ʈ ��� �ϰ�� 
            struct in_addr IPAddress;
            m_CtrlIPAddress.GetAddress(IPAddress.S_un.S_addr);                  // ���õ� IP�ּҰ��� �����´�.

            
            IPStr.Format("%d.%d.%d.%d",IPAddress.S_un.S_un_b.s_b4,
                                       IPAddress.S_un.S_un_b.s_b3,
                                       IPAddress.S_un.S_un_b.s_b2,
                                       IPAddress.S_un.S_un_b.s_b1);
            m_pNetWallTalk = new CNetWallTalk(FALSE, m_SocketPort, IPStr);
            
            m_pNetWallTalk->Create(this);
            
            Temp.Format("����(%s) Ŭ���̾�Ʈ(%s) ����Ǿ����ϴ�.",m_pNetWallTalk->GetServerIPAddress(),
                                                                m_pNetWallTalk->GetClientIPAddress());
            AppendReceiveStr(Temp);

            break;
        case 1:                     // ���� ����� ���

            m_pNetWallTalk = new CNetWallTalk(TRUE, m_SocketPort);

            m_pNetWallTalk->Create(this);
            break;
        default:
            AfxMessageBox("���� �̷����� �̷����� �߻����� ���ƾ� �ϴµ�...");
            return;
        }
        

        (CEdit*)(GetDlgItem(IDC_EditSend))->EnableWindow(TRUE);                 // ���ۿ����͸� �ο��̺� ��Ų��.
        (CButton*)(GetDlgItem(IDC_BTNSend))->EnableWindow(TRUE);                // ���۹����� �ο��̺� ��Ų��.


        (CEdit*)(GetDlgItem(IDC_EditPort))->EnableWindow(FALSE);                // ��Ʈ��ȣ�� �޴� �κ��� ���̺�
        (CIPAddressCtrl*)(GetDlgItem(IDC_IPAddress))->EnableWindow(FALSE);      // IP�ּ� �޴� �κ��� ���̺�
        
        (CButton*)(GetDlgItem(IDC_RadioClient))->EnableWindow(FALSE);           // Ŭ���̾�Ʈ ���� ������ ���̺� 
        (CButton*)(GetDlgItem(IDC_RadioServer))->EnableWindow(FALSE);           // ���� ���� ������ ���̺� 

        pWnd->SetWindowText("��������");                                        // ���������� ������ �̸��� �ٲ۴�.

        IsSet = TRUE;                                                           // ������ �Ǿ��������� ������ �Ѵ�.

    }
    else										// ������ �Ǿ��ִ� ��� 
    {
		OnStopTimer();

        (CEdit*)(GetDlgItem(IDC_EditSend))->EnableWindow(FALSE);                 // ���ۿ����͸� ���̺� ��Ų��.
        (CButton*)(GetDlgItem(IDC_BTNSend))->EnableWindow(FALSE);                // ���۹����� ���̺� ��Ų��.


        (CEdit*)(GetDlgItem(IDC_EditPort))->EnableWindow(TRUE);                 // ��Ʈ��ȣ�� �޴� �κ��� �ο��̺�
        if(0 == m_nMode)                // Ŭ���̾�Ʈ ����ΰ�� 
        {
            (CIPAddressCtrl*)(GetDlgItem(IDC_IPAddress))->EnableWindow(TRUE);   // IP�ּ� �޴� �κ��� ���̺�
        }
        else                            // ���� ����� ��� 
        {
            (CIPAddressCtrl*)(GetDlgItem(IDC_IPAddress))->EnableWindow(FALSE);  // IP�ּ� �޴� �κ��� ���̺�
        }
        
        (CButton*)(GetDlgItem(IDC_RadioClient))->EnableWindow(TRUE);            // Ŭ���̾�Ʈ ���� ������ �ο��̺�  
        (CButton*)(GetDlgItem(IDC_RadioServer))->EnableWindow(TRUE);            // ���� ���� ������ �ο��̺� 

        pWnd->SetWindowText("���ἳ��");                                        // ���ἳ������ ������ �̸��� �ٲ۴�.

        IsSet = FALSE;                                                          // ������ �Ǿ��������� ������ �Ѵ�.
		
		if(m_pNetWallTalk)
		{
			delete m_pNetWallTalk;
			m_pNetWallTalk = NULL;
		}

    }
    
}

// ���ú� â�� ������ ��Ʈ���� ����� �Լ� 
int CNetTest0603Dlg::AppendReceiveStr(CString sData)
{
    int RetVal;

    UpdateData(TRUE);
    m_szReceiveStr += sData;            
    m_szReceiveStr += "\r\n";
    UpdateData(FALSE);

    // ��ũ�� �ٸ� �����̴� �κ� 
    CEdit* pEdit = (CEdit*)GetDlgItem(IDC_ReceiveStr);
    int Count = pEdit->GetLineCount();
    pEdit->LineScroll(Count, 1);


    RetVal = m_szReceiveStr.GetLength();
    
    return RetVal;
}

// ���۹����� ������ ��쿡 ó���ϴ� �Լ� 
void CNetTest0603Dlg::OnBTNSend() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
 // SendRecv01();  
    m_pNetWallTalk->SendData((BYTE*)(LPCTSTR)m_szSendStr, strlen((LPCTSTR)m_szSendStr));
    m_szSendStr = "[����]" + m_szSendStr;
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
    UpdateData(FALSE);
}

void CNetTest0603Dlg::OnBTNSendRecv() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_StopTimeFlag = FALSE;   
	m_SendRecvFlag = FALSE;
	m_Timer1 = SetTimer(SET_PING_TIME1, SET_PING_TIME1, NULL);
	m_Timer2 = SetTimer(SET_PING_TIME2, SET_PING_TIME2, NULL);
	m_Timer3 = SetTimer(SET_PING_TIME3, SET_PING_TIME3, NULL);
	m_Timer4 = SetTimer(SET_PING_TIME4, SET_PING_TIME4, NULL);
	m_Timer5 = SetTimer(SET_PING_TIME5, SET_PING_TIME5, NULL);
	m_Timer6 = SetTimer(SET_PING_TIME6, SET_PING_TIME6, NULL);
	m_Timer7 = SetTimer(SET_PING_TIME7, SET_PING_TIME7, NULL);
	m_Timer8 = SetTimer(SET_PING_TIME8, SET_PING_TIME8, NULL);
	m_Timer9 = SetTimer(SET_PING_TIME9, SET_PING_TIME9, NULL);


/*
     m_pNetWallTalk->SendDataT((BYTE*)(LPCTSTR)m_szSendStr, strlen((LPCTSTR)m_szSendStr), 10);
     m_szSendStr = "[����]" + m_szSendStr;
     AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
     m_szSendStr.Empty();
  */
    
    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv01() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1);
	
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0001", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*1 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv02() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0002", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*2 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv03() 
{
	UpdateData(TRUE);
	
	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0003", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));

	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*3 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();


    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv04() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);

	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0004", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));

	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*4 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv05() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);
	    sLen += sizeof(m_TXATM1060.byDummy5);
	
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0005", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy5, 0x35, sizeof(m_TXATM1060.byDummy5));

	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*5 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv06() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);
	    sLen += sizeof(m_TXATM1060.byDummy5);
	    sLen += sizeof(m_TXATM1060.byDummy6);

	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0006", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy5, 0x35, sizeof(m_TXATM1060.byDummy5));
	memset(m_TXATM1060.byDummy6, 0x36, sizeof(m_TXATM1060.byDummy6));
	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*6 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
	
    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv07() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);
	    sLen += sizeof(m_TXATM1060.byDummy5);
	    sLen += sizeof(m_TXATM1060.byDummy6);
	    sLen += sizeof(m_TXATM1060.byDummy7);

		
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0007", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy5, 0x35, sizeof(m_TXATM1060.byDummy5));
	memset(m_TXATM1060.byDummy6, 0x36, sizeof(m_TXATM1060.byDummy6));
	memset(m_TXATM1060.byDummy7, 0x37, sizeof(m_TXATM1060.byDummy7));

	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*7 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::SendRecv08() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);
	    sLen += sizeof(m_TXATM1060.byDummy5);
	    sLen += sizeof(m_TXATM1060.byDummy6);
	    sLen += sizeof(m_TXATM1060.byDummy7);
	    sLen += sizeof(m_TXATM1060.byDummy8);

		
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0008", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy5, 0x35, sizeof(m_TXATM1060.byDummy5));
	memset(m_TXATM1060.byDummy6, 0x36, sizeof(m_TXATM1060.byDummy6));
	memset(m_TXATM1060.byDummy7, 0x37, sizeof(m_TXATM1060.byDummy7));
	memset(m_TXATM1060.byDummy8, 0x38, sizeof(m_TXATM1060.byDummy8));
	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*8 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();

    UpdateData(FALSE);
}

void CNetTest0603Dlg::SendRecv09() 
{
	UpdateData(TRUE);

	memset(&m_TXATM1060, 0x20, sizeof(m_TXATM1060));
	memset(m_TCPSendBuffer, 0x00, sizeof(m_TCPSendBuffer));
	
    int sLen = sizeof(m_TXATM1060.byTotalSize) + sizeof(m_TXATM1060.byIndex) + sizeof(m_TXATM1060.byDummy1) + sizeof(m_TXATM1060.byDummy2);
	    sLen += sizeof(m_TXATM1060.byDummy3);
	    sLen += sizeof(m_TXATM1060.byDummy4);
	    sLen += sizeof(m_TXATM1060.byDummy5);
	    sLen += sizeof(m_TXATM1060.byDummy6);
	    sLen += sizeof(m_TXATM1060.byDummy7);
	    sLen += sizeof(m_TXATM1060.byDummy8);
	    sLen += sizeof(m_TXATM1060.byDummy9);
		
	Int2Asc(sLen, m_TXATM1060.byTotalSize, sizeof(m_TXATM1060.byTotalSize));
	memcpy(m_TXATM1060.byIndex, "0009", sizeof(m_TXATM1060.byIndex));
	memcpy(m_TXATM1060.byCurDate, GetDate(), 8);
	memcpy(m_TXATM1060.byCurTime, GetTime().GetBuffer(0), 6);
	memset(m_TXATM1060.byDummy1, 0x31, sizeof(m_TXATM1060.byDummy1));
	memset(m_TXATM1060.byDummy2, 0x32, sizeof(m_TXATM1060.byDummy2));
	memset(m_TXATM1060.byDummy3, 0x33, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy4, 0x34, sizeof(m_TXATM1060.byDummy3));
	memset(m_TXATM1060.byDummy5, 0x35, sizeof(m_TXATM1060.byDummy5));
	memset(m_TXATM1060.byDummy6, 0x36, sizeof(m_TXATM1060.byDummy6));
	memset(m_TXATM1060.byDummy7, 0x37, sizeof(m_TXATM1060.byDummy7));
	memset(m_TXATM1060.byDummy8, 0x38, sizeof(m_TXATM1060.byDummy8));
	memset(m_TXATM1060.byDummy9, 0x39, sizeof(m_TXATM1060.byDummy9));
	
	memcpy(m_TCPSendBuffer, m_TXATM1060.byTotalSize, sLen);

	m_TCPSendBuffer[sLen] = TCP_CMD_ETX1;
	m_TCPSendBuffer[sLen+1] = TCP_CMD_ETX2;

    m_pNetWallTalk->SendDataT(m_TCPSendBuffer, sLen + TCP_ETX_LEM, 10);

    m_szSendStr = "[����] => 30 + 2048*9 size";
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
    
	int nRecvLen = 0;
	memset(m_TCPRecvBuffer, 0x00, sizeof(m_TCPRecvBuffer));
	m_pNetWallTalk->RecvDataT(m_TCPRecvBuffer, &nRecvLen, 60);
    m_szSendStr.Format("[����] => 30 + %d size", nRecvLen);
    AppendReceiveStr(m_szSendStr);                  // �α������쿡 �����..������ �����...
    m_szSendStr.Empty();
	
    UpdateData(FALSE);
	
}


void CNetTest0603Dlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	
	if(m_SendRecvFlag)
		return;

	if(m_StopTimeFlag)
	{
		KillTimer(nIDEvent);
		return;
	}

	switch(nIDEvent)
	{
	case SET_PING_TIME1:
		KillTimer(m_Timer1);
		m_SendRecvFlag = TRUE;
		SendRecv01();
		m_SendRecvFlag = FALSE;
		m_Timer1 = SetTimer(SET_PING_TIME1, SET_PING_TIME1, NULL);
		break;
	case SET_PING_TIME2:
		KillTimer(m_Timer2);
		m_SendRecvFlag = TRUE;
		SendRecv02();
		m_SendRecvFlag = FALSE;
		m_Timer2 = SetTimer(SET_PING_TIME2, SET_PING_TIME2, NULL);
		break;
	case SET_PING_TIME3:
		KillTimer(m_Timer3);
		m_SendRecvFlag = TRUE;
		SendRecv03();
		m_SendRecvFlag = FALSE;
		m_Timer3 = SetTimer(SET_PING_TIME3, SET_PING_TIME3, NULL);
	case SET_PING_TIME4:
		KillTimer(m_Timer4);
		m_SendRecvFlag = TRUE;
		SendRecv04();
		m_SendRecvFlag = FALSE;
		m_Timer4 = SetTimer(SET_PING_TIME4, SET_PING_TIME4, NULL);	
		break;
	case SET_PING_TIME5:
		KillTimer(m_Timer5);
		m_SendRecvFlag = TRUE;
		SendRecv05();
		m_SendRecvFlag = FALSE;
		m_Timer1 = SetTimer(SET_PING_TIME5, SET_PING_TIME5, NULL);
		break;
	case SET_PING_TIME6:
		KillTimer(m_Timer6);
		m_SendRecvFlag = TRUE;
		SendRecv06();
		m_SendRecvFlag = FALSE;
		m_Timer2 = SetTimer(SET_PING_TIME6, SET_PING_TIME6, NULL);
		break;
	case SET_PING_TIME7:
		KillTimer(m_Timer7);
		m_SendRecvFlag = TRUE;
		SendRecv07();
		m_SendRecvFlag = FALSE;
		m_Timer3 = SetTimer(SET_PING_TIME7, SET_PING_TIME7, NULL);
	case SET_PING_TIME8:
		KillTimer(m_Timer8);
		m_SendRecvFlag = TRUE;
		SendRecv08();
		m_SendRecvFlag = FALSE;
		m_Timer8 = SetTimer(SET_PING_TIME8, SET_PING_TIME8, NULL);	
		break;
	case SET_PING_TIME9:
		KillTimer(m_Timer9);
		m_SendRecvFlag = TRUE;
		SendRecv09();
		m_SendRecvFlag = FALSE;
		m_Timer8 = SetTimer(SET_PING_TIME9, SET_PING_TIME9, NULL);	
		break;
	default:
		break;
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CNetTest0603Dlg::OnStopTimer()
{
	m_StopTimeFlag = TRUE;

	KillTimer(m_Timer1);
	KillTimer(m_Timer2);
	KillTimer(m_Timer3);
	KillTimer(m_Timer4);
	KillTimer(m_Timer5);
	KillTimer(m_Timer6);
	KillTimer(m_Timer7);
	KillTimer(m_Timer8);
	KillTimer(m_Timer9);
}

void CAboutDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnClose();
}
