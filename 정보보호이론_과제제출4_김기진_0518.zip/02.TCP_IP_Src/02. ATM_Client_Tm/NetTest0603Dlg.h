// NetTest0603Dlg.h : header file
//

#if !defined(AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_)
#define AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "NetWallTalk.h"
/////////////////////////////////////////////////////////////////////////////
// CNetTest0603Dlg dialog



typedef struct tagTXATM1060 
{
	BYTE	byTotalSize[6];				// send data length
	BYTE	byIndex[4];				// �����ڵ�
	BYTE	byCurDate[10];				// �����ڵ�
	BYTE	byCurTime[10];				// �����ڵ�
	BYTE	byDummy1[2048];
	BYTE	byDummy2[2048];
	BYTE	byDummy3[2048];
	BYTE	byDummy4[2048];
	BYTE	byDummy5[2048];
	BYTE	byDummy6[2048];
	BYTE	byDummy7[2048];
	BYTE	byDummy8[2048];
	BYTE	byDummy9[2048]; //2048 * 9 = 18432 + 30
}TXATM1060 , NEAR *NPTXATM1060 , FAR *LPTXATM1060;

#define SET_PING_TIME1 5000
#define SET_PING_TIME2 15000
#define SET_PING_TIME3 20000
#define SET_PING_TIME4 25000
#define SET_PING_TIME5 30000
#define SET_PING_TIME6 35000
#define SET_PING_TIME7 40000
#define SET_PING_TIME8 45000
#define SET_PING_TIME9 50000

class CNetTest0603Dlg : public CDialog
{
// Construction
public:
	CNetWallTalk* m_pNetWallTalk;                               // CNetWallTalk�� ������ ������Ʈ 
	CNetTest0603Dlg(CWnd* pParent = NULL);	// standard constructor
	TXATM1060 m_TXATM1060;
	BYTE	  m_TCPSendBuffer[TCPBUFFSIZE];
	BYTE	  m_TCPRecvBuffer[TCPBUFFSIZE];

	UINT m_Timer1;
	UINT m_Timer2;
	UINT m_Timer3;
	UINT m_Timer4;
	UINT m_Timer5;
	UINT m_Timer6;
	UINT m_Timer7;
	UINT m_Timer8;
	UINT m_Timer9;

	int	 m_SendRecvFlag;
	int	 m_StopTimeFlag;
	void OnStopTimer();
	void SendRecv01();
	void SendRecv02();
	void SendRecv03();
	void SendRecv04();
	void SendRecv05();
	void SendRecv06();
	void SendRecv07();
	void SendRecv08();
	void SendRecv09();

// Dialog Data
	//{{AFX_DATA(CNetTest0603Dlg)
	enum { IDD = IDD_NETTEST0603_DIALOG };
	CIPAddressCtrl	m_CtrlIPAddress;
	UINT	m_SocketPort;
	CString	m_szSendStr;
	int		m_nMode;
	CString	m_szReceiveStr;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetTest0603Dlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int AppendReceiveStr(CString sData);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNetTest0603Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
    afx_msg LRESULT OnMsgAccept(WPARAM wParam, LPARAM lParam);          // ���� ����(��������ϰ�� onAccept���Ž�)
	afx_msg LRESULT OnMsgClose(WPARAM wParam, LPARAM lParam);	        // ���� ����(����, Ŭ���̾�Ʈ ����� ��� onClose���Ž�)
	afx_msg LRESULT OnMsgReceive(WPARAM wParam, LPARAM lParam);	        // ������ ���Ž�(����, Ŭ���̾�Ʈ ����� ��� onReceive���Ž�)
	afx_msg void OnRadioClient();
	afx_msg void OnRadioServer();
	afx_msg void OnBTNSet();
	afx_msg void OnBTNSend();
	afx_msg void OnBTNSendRecv();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETTEST0603DLG_H__E226EAEE_1257_43D4_8437_9B9D1BE61AD1__INCLUDED_)
