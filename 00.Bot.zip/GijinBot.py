import os
from telegram.ext import Updater, MessageHandler, Filters, CommandHandler
from emoji import emojize
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
import logging

updater = Updater(token='1422975761:AAFPZhKXvqWqwZYli2fjGu05ajeURdEW4EE', use_context=True)
# dispatcher = updater.dispatcher
# updater.start_polling()


smiles = [emojize(':birthday:', use_aliases=True),
          emojize(':heavy_plus_sign:', use_aliases=True),
          emojize(':memo:', use_aliases=True),
          emojize(':information_source:', use_aliases=True),
          emojize(':x:', use_aliases=True),
          emojize(':calendar:', use_aliases=True),
          emojize(':man:', use_aliases=True),
          emojize(':scissors:', use_aliases=True),
          emojize(':clock230:', use_aliases=True),
          emojize(':white_check_mark:', use_aliases=True),
          emojize(':no_entry_sign:', use_aliases=True),
          emojize(':leftwards_arrow_with_hook:', use_aliases=True),
          emojize(':telephone_receiver:', use_aliases=True)]

start_keyboard = ReplyKeyboardMarkup([['(직원) ★생일★ {}'.format(smiles[0])],
                                      ['(가족) ☆생일☆ {}'.format(smiles[1]),
                                       '(친구) ◆생일◆ {}'.format(smiles[2])]],
                                     resize_keyboard=True,
                                     one_time_keyboard=True)

menu_keyboard = ReplyKeyboardMarkup([['Good game{}'.format(smiles[10])]], resize_keyboard=True)
reply_keyboard = [[emojize('딸이얌:heart:', use_aliases=True), emojize('아들이요:alien:', use_aliases=True)]]


dir_now = os.path.dirname(os.path.abspath(__file__))

def handler(update, context):
    # print('result called')
    # data = 'mydata'
    # update.message.reply_text(data)
    print(update.message.text)
  # print(update.message.text)
    text = update.message.text
    chat_id = update.message.chat_id
    print(chat_id)
    print(update.message.text)
    if '모해' in text:
        update.message.reply_text('오빠 생각 ㅎㅎ')
    elif '아잉' in text:
        update.message.reply_text(emojize('아잉:heart_eyes:', use_aliases=True))
    elif '몇시에' in text:
        update.message.reply_text('7시에 보자')
    elif '사진' in text:
        update.message.reply_photo(open('images/go.jpg', 'rb'))
    else:
        # update.message.reply_photo(open('images/go.jpg', 'rb'))
        # update.message.reply_text("got text")
        update.message.reply_text(update.message.text)      
        # update.edit_message_text(chat_id=chat_id, message_id='7시에 보자', text="Seriously, you're on your own, kiddo.")
        # update.message.reply_text('누구니?', reply_markup=ReplyKeyboardMarkup(reply_keyboard,one_time_keyboard=True))
        update.message.reply_text('◎ 생일은 챙기자 ◎ ?', reply_markup=start_keyboard)

# help reply function
def help_command(update, context) :
    update.message.reply_text("무엇을 도와드릴까요?")

def stop_command(update, context) :
    update.message.reply_text("오늘은 이만 끝!!")
    update.stop()

# photo reply function
def get_photo(update, context):
    file_path = os.path.join(dir_now, 'from_telegram.png')
    photo_id = update.message.photo[-1].file_id  # photo 번호가 높을수록 화질이 좋음
    photo_file = context.bot.getFile(photo_id)
    photo_file.download(file_path)
    update.message.reply_text('photo saved')

# file reply function
def get_file(update, context) :
    file_id_short = update.message.document.file_id
    file_url = os.path.join(dir_now, update.message.document.file_name)
    context.bot.getFile(file_id_short).download(file_url)
    update.message.reply_text('file saved')

# error 처리
def error(update, error):
    logging.warning('Update "%s" caused error "%s"', update, error)

help_handler = CommandHandler('help', help_command)
updater.dispatcher.add_handler(help_handler)

help_handler = CommandHandler('stop', stop_command)
updater.dispatcher.add_handler(help_handler)


echo_handler = MessageHandler(Filters.text, handler)
updater.dispatcher.add_handler(echo_handler)

photo_handler = MessageHandler(Filters.photo, get_photo)
updater.dispatcher.add_handler(photo_handler)

file_handler = MessageHandler(Filters.document, get_file)
updater.dispatcher.add_handler(file_handler)

# log all errors
updater.dispatcher.add_error_handler(error)

updater.start_polling(timeout=3, clean=True)
updater.idle()
