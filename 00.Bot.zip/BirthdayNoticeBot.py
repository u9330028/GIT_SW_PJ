import os
import numpy as np
import pandas as pd
from datetime import datetime
from telegram.ext import Updater, MessageHandler, Filters, CommandHandler
from emoji import emojize
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
import logging

updater = Updater(token='1422975761:AAFPZhKXvqWqwZYli2fjGu05ajeURdEW4EE', use_context=True)
# dispatcher = updater.dispatcher
# updater.start_polling()

df = pd.read_excel('./info.xlsx', sheet_name = 0, header=0)
dffamilys = pd.read_excel('./info.xlsx', sheet_name = 1, header=0)
dffriends = pd.read_excel('./info.xlsx', sheet_name = 2, header=0)
dfddmm = df['생년월일']
dffamddmm = dffamilys['생년월일']
dffriddmm = dffriends['생년월일']

dtddmm = datetime.today().strftime('%m%d')

smiles = [emojize(':birthday:', use_aliases=True),
          emojize(':winking_face_with_tongue:', use_aliases=True),
          emojize(':grinning_face_with_big_eyes:', use_aliases=True),          
          emojize(':heavy_plus_sign:', use_aliases=True),
          emojize(':memo:', use_aliases=True),
          emojize(':information_source:', use_aliases=True),
          emojize(':x:', use_aliases=True),
          emojize(':calendar:', use_aliases=True),
          emojize(':man:', use_aliases=True),
          emojize(':scissors:', use_aliases=True),
          emojize(':clock230:', use_aliases=True),
          emojize(':white_check_mark:', use_aliases=True),
          emojize(':no_entry_sign:', use_aliases=True),
          emojize(':leftwards_arrow_with_hook:', use_aliases=True),
          emojize(':telephone_receiver:', use_aliases=True)]

start_keyboard = ReplyKeyboardMarkup([['★ (직원) ★ 생일  {}'.format(smiles[0])],
                                      ['☆ (가족) ☆ 생일  {}'.format(smiles[1]),
                                       '♣ (친구) ♣ 생일  {}'.format(smiles[2])]], resize_keyboard=True, one_time_keyboard=True)

menu_keyboard = ReplyKeyboardMarkup([['Good game{}'.format(smiles[10])]], resize_keyboard=True)
reply_keyboard = [[emojize('딸이얌:heart:', use_aliases=True), emojize('아들이요:alien:', use_aliases=True)]]


dir_now = os.path.dirname(os.path.abspath(__file__))



def handler(update, context):
    # print('result called')
    # data = 'mydata'
    # update.message.reply_text(data)
    # print(update.message.text)
    text = update.message.text
    chat_id = update.message.chat_id
    print("chat_id : {}".format(chat_id))
    print("Request : {}".format(update.message.text))
    # upDate = update
    # conText = context
    dtddmm = datetime.today().strftime('%m%d')
    if '직원' in text:
        covertmmdd(update, context, dfddmm)
        update.message.reply_text('◎ 생일은 챙기자 ◎', reply_markup=start_keyboard)
    elif '가족' in text:
        covertmmddfamilys(update, context, dffamddmm)
        update.message.reply_text('◎ 생일은 챙기자 ◎', reply_markup=start_keyboard)        
    elif '친구' in text:
        covertmmddfriends(update, context, dffriddmm)
        update.message.reply_text('◎ 생일은 챙기자 ◎', reply_markup=start_keyboard)  
    elif '교수' in text:   
        update.message.reply_photo(open('images/go.jpg', 'rb'))
        update.message.reply_text("(교수님 사진) 구글링으로 찾았어요..")                    
    elif '사진' in text:
        update.message.reply_photo(open('images/go.jpg', 'rb'))
        update.message.reply_text("(교수님 사진) 구글링으로 찾았어요..") 
    elif '눈' in text:
        update.message.reply_photo(open('images/iy.jpg', 'rb'))
        update.message.reply_text("눈이 정화 中!!")       
    elif '응원' in text:
        update.message.reply_photo(open('images/doit.jpg', 'rb'))
        update.message.reply_text("넌 정말 할 수 있어! 해봐~")            
    else:
        # update.message.reply_photo(open('images/go.jpg', 'rb'))
        # update.message.reply_text("got text")
        update.message.reply_text(update.message.text)      
        update.message.reply_text('◎ 생일은 챙기자 ◎', reply_markup=start_keyboard)

# help reply function
def help_command(update, context) :
    update.message.reply_text("(직원) / (가족) / (친구)들의 생일을 줄께!")
    update.message.reply_text("생일 {}".format(smiles[0]))
    update.message.reply_text('◎ 생일은 챙기자 ◎', reply_markup=start_keyboard)
def stop_command(update, context) :
    update.message.reply_text("코딩은 노가다! 이제 그만~")
    update.message.reply_text("오늘은 이만 끝!!")
    update.stop()

# photo reply function
def get_photo(update, context):
    file_path = os.path.join(dir_now, 'from_telegram.png')
    photo_id = update.message.photo[-1].file_id  # photo 번호가 높을수록 화질이 좋음
    photo_file = context.bot.getFile(photo_id)
    photo_file.download(file_path)
    update.message.reply_text('photo saved')

# file reply function
def get_file(update, context) :
    file_id_short = update.message.document.file_id
    file_url = os.path.join(dir_now, update.message.document.file_name)
    context.bot.getFile(file_id_short).download(file_url)
    update.message.reply_text('file saved')

# error 처리
def error(update, error):
    logging.warning('Update "%s" caused error "%s"', update, error)

def covertmmdd(update, context, DF):
    i = 0
    nflag = False
    dfdm = DF
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        # print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(df['팀'][i], df['이름'][i], df['직급'][i], df['생년월일'][i])
            # update.message.reply_text("{}!! {}{}님 {}의 생일축하 드립니다".format(df['팀'][i], df['이름'][i], df['직급'][i], df['생년월일'][i]))            
            # # update.message.reply_text('*=*=*=*=*=*=*=\nHAPPY BIRTHDAY\n  TO ♡YOU♡  \n*=*=*=*=*=*=*=\n')
            update.message.reply_text("오늘은 ▣ {} ▣! (직 원 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d')))            
            update.message.reply_text("능력있는 ♥ {}:{}{}님 ♥ 생일을 축하 합니다.".format(df['팀'][i], df['이름'][i], df['직급'][i]))            
            update.message.reply_text('*=*=*=*=*=*=*=\nHAPPY BIRTHDAY\n  TO ♡YOU♡  \n*=*=*=*=*=*=*=\n')
            nflag = True
        i = i+1
    
    if nflag == False:
        update.message.reply_text("오늘은 ▣ {} ▣! (직 원 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d')))  
        update.message.reply_text("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6])) 
        print("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6])) 

def covertmmddfamilys(update, context, DF):
    i = 0
    dfdm = DF
    nflag = False    
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        # print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(dffamilys['팀'][i], dffamilys['이름'][i], dffamilys['직급'][i], dffamilys['생년월일'][i])
            # update.message.reply_text(' ＊ *♠♠♠ * * \n   * ⊙⊙⊙  *\n *  ▣▣▣▣*  *\n  *▣▣▣▣▣ *\n *HappyBirthday*\n')
            update.message.reply_text("오늘은 ▣ {} ▣! (가 족 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d'))) 
            update.message.reply_text("사랑스런 ♥ {}:{}님 ♥의 생일을 축하 드립니다".format(dffamilys['팀'][i], dffamilys['이름'][i]))                
            update.message.reply_text(' ＊ *♠♠♠ * * \n   * ⊙⊙⊙  *\n *  ▣▣▣▣*  *\n  *▣▣▣▣▣ *\n *HappyBirthday*\n')
            nflag = True            
        i = i+1

    if nflag == False:
        update.message.reply_text("오늘은 ▣ {} ▣! (직 원 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d')))  
        update.message.reply_text("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6])) 
        print("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6])) 

def covertmmddfriends(update, context, DF):
    i = 0
    dfdm = DF
    nflag = False    
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        # print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(dffriends['팀'][i], dffriends['이름'][i], dffriends['직급'][i], dffriends['생년월일'][i])
            # update.message.reply_text(' ∴　 +∴∵∴∵+\n 　 ∵ ㆀㆀ ∴ +\n +　+┏llll┓+\n 　 ┏★☆★┓∵\n ∴┏★★★★┓\n  ┏☆☆★☆☆┓+\n ┏*ⓗⓐⓟⓟⓨ*┓\n ⓑⓘⓡⓣⓗⓓⓐⓨ\n')
            update.message.reply_text("오늘은 ▣ {} ▣! (친 구 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d')))            
            update.message.reply_text("멋진나의 ♥ 친구:{} ♥ 이 생일 축하 해!!".format(dffriends['이름'][i]))  
            # update.message.reply_text(' ∴　 +∴∵∴∵+\n 　 ∵ ㆀㆀ ∴ +\n +　+┏llll┓+\n 　 ┏★☆★┓∵\n ∴┏★★★★┓\n  ┏☆☆★☆☆┓+\n ┏*ⓗⓐⓟⓟⓨ*┓\n ⓑⓘⓡⓣⓗⓓⓐⓨ\n')
            update.message.reply_text(' ∴　 +∴∵∴∵+\n 　 ∵ ㆀㆀ ∴ +\n +　+┏llll┓+\n 　 ┏★☆★┓∵\n ∴┏★★★★┓\n  ┏☆☆★☆☆┓+\n ┏*ⓗⓐⓟⓟⓨ*┓\n ⓑⓘⓡⓣⓗⓓⓐⓨ\n')
            nflag = True

        i = i+1

    if nflag == False:
        update.message.reply_text("오늘은 ▣ {} ▣! (직 원 생 일 확 인)".format(datetime.today().strftime('%Y-%m-%d')))  
        update.message.reply_text("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6])) 
        print("▒ {} ▒ 생일자는 없어요! 누구든 ☎ 전화 한번 해봐요".format(smiles[6]))         
# *=*=*=*=*=*=*=
# HAPPY BIRTHDAY
#   TO ♡YOU♡
# *=*=*=*=*=*=*=


# ＊ *♠♠♠ * *
#   * ⊙⊙⊙  *
# *  ▣▣▣▣*  *
#  *▣▣▣▣▣ *
# *HappyBirthday*


# ∴　 +∴∵∴∵+
# 　 ∵ ㆀㆀ ∴ +
# +　+┏llll┓+
# 　 ┏★☆★┓∵
# ∴┏★★★★┓
#  ┏☆☆★☆☆┓+
# ┏*ⓗⓐⓟⓟⓨ*┓
# ⓑⓘⓡⓣⓗⓓⓐⓨ


help_handler = CommandHandler('help', help_command)
updater.dispatcher.add_handler(help_handler)

help_handler = CommandHandler('stop', stop_command)
updater.dispatcher.add_handler(help_handler)


echo_handler = MessageHandler(Filters.text, handler)
updater.dispatcher.add_handler(echo_handler)

photo_handler = MessageHandler(Filters.photo, get_photo)
updater.dispatcher.add_handler(photo_handler)

file_handler = MessageHandler(Filters.document, get_file)
updater.dispatcher.add_handler(file_handler)

# log all errors
updater.dispatcher.add_error_handler(error)

updater.start_polling(timeout=3, clean=True)
updater.idle()


