import os
import numpy as np
import pandas as pd
from datetime import datetime

# df = pd.read_excel('./info.xlsx', header=0)
df = pd.read_excel('./info.xlsx', sheet_name = 0, header=0)
dffamilys = pd.read_excel('./info.xlsx', sheet_name = 1, header=0)
dffriends = pd.read_excel('./info.xlsx', sheet_name = 2, header=0)
dfddmm = df['생년월일']
dffamddmm = dffamilys['생년월일']
dffriddmm = dffriends['생년월일']

# print(df.head()) 
# print() 
# print(xlsx.tail()) 
# print() 
# print(xlsx.shape)
# print(xlsx[:])
# print(df[:])
# print(xlsx['번호'])

dfddmm = df['생년월일']

dtddmm = datetime.today().strftime('%m%d')


def covertmmdd(DF):
    i = 0
    dfdm = DF
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(df['팀'][i], df['이름'][i], df['직급'][i], df['생년월일'][i].strftime('%Y-%m-%d'))
            print("능력있는 ♡ {} ♡ {}{}님 {}의 생일축하 드립니다".format(df['팀'][i], df['이름'][i], df['직급'][i], df['생년월일'][i]))            
            print('*=*=*=*=*=*=*=\nHAPPY BIRTHDAY\n  TO ♡YOU♡  \n*=*=*=*=*=*=*=\n')

        i = i+1

def covertmmddfamilys(DF):
    i = 0
    dfdm = DF
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(dffamilys['팀'][i], dffamilys['이름'][i], dffamilys['직급'][i], dffamilys['생년월일'][i].strftime('%Y-%m-%d'))
            print("사랑스런 ♥ {} ♥ {}님 {}의 생일축하 드립니다".format(df['팀'][i], df['이름'][i], df['생년월일'][i]))                
            print(' ＊ *♠♠♠ * * \n   * ⊙⊙⊙  *\n *  ▣▣▣▣*  *\n  *▣▣▣▣▣ *\n *HappyBirthday*\n')

        i = i+1

# ♥♡♤♠♧♣
def covertmmddfriends(DF):
    i = 0
    dfdm = DF
    for mmdd in dfdm:
        md = mmdd.strftime('%m%d')
        print(md, i)

        if md == dtddmm:
            print('Birthdays {0} = {1}', md, dtddmm)
            print(dffriends['팀'][i], dffriends['이름'][i], dffriends['직급'][i], dffriends['생년월일'][i].strftime('%Y-%m-%d'))
            print("멋진나의 친구 ♤ {} ♤이의 {}일 생일축하 드립니다".format(df['이름'][i], df['생년월일'][i]))  
            # update.message.reply_text(' ∴　 +∴∵∴∵+\n 　 ∵ ㆀㆀ ∴ +\n +　+┏llll┓+\n 　 ┏★☆★┓∵\n ∴┏★★★★┓\n  ┏☆☆★☆☆┓+\n ┏*ⓗⓐⓟⓟⓨ*┓\n ⓑⓘⓡⓣⓗⓓⓐⓨ\n')
            print(' ∴　 +∴∵∴∵+\n 　 ∵ ㆀㆀ ∴ +\n +　+┏llll┓+\n 　 ┏★☆★┓∵\n ∴┏★★★★┓\n  ┏☆☆★☆☆┓+\n ┏*ⓗⓐⓟⓟⓨ*┓\n ⓑⓘⓡⓣⓗⓓⓐⓨ\n')
            
        i = i+1

covertmmdd(dfddmm)
covertmmddfamilys(dffamddmm)
covertmmddfriends(dffriddmm)
