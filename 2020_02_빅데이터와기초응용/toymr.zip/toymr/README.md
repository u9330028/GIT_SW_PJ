사용법: `python3 toymr.py <구현한 모듈명> <입력 파일 경로> <결과 파일 경로>`
예: `python3 toymr.py wordcount my_doc my_doc_word_count`
서울공기질데이터: https://www.kaggle.com/bappekim/air-pollution-in-seoul
