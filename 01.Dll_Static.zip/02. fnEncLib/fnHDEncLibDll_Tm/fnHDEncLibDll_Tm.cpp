// fnHDEncLibDll_Tm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>

#define KEY_LEN				16
#define SSKEY_BLOCK_LEN			46
#define ENC_BLOCK_LEN			32

#define ERR_MST_KEY_INDEX		1	/* ������Ű Index�� 00 ~ 9 �̾�� �� */
#define ERR_SVR_HASH			2	/* Client �� Server Hash���� ����    */	
#define ERR_BLOCK_LEN			3	/* ��ȣȭ ���� ���� ����             */
#define ERR_ENC_DATA_KIND		4	/* ��ȣȭ ���� ���� ����             */
#define ERR_ETC_PROC			5	/* ��ȣȭ ����                       */

/**************** Function Prototype Declarations **************************************************************************************************/
// Encrpt Function
XDllExport int  CALLBACK fnHD_CKeyInit(BYTE *s1Key, int *s1Len, BYTE *s1Idx, BYTE *mk_table, BYTE *wKey, int wLen);
XDllExport int  CALLBACK fnHD_GetHashCode(BYTE *datetime, long amnt, BYTE *dData);
XDllExport int  CALLBACK fnHD_EncSeed(BYTE *wKey, BYTE *wIdx, BYTE *sData, int sLen, BYTE *dData, int *dLen);
XDllExport int  CALLBACK fnHD_DecSeed(BYTE *wKey, int wIdx, BYTE *mk_tabale, BYTE *sData, int sLen, BYTE *pwd, BYTE *acnt, BYTE *hData);
/**************************************************************************************************************************************************/

int	DataEncDecTest();

#ifdef _TEST_
	BYTE	printTemp[1024];
#endif
	
int main(int argc, char* argv[])
{
	int	rtn;
	rtn = DataEncDecTest();

	return rtn;

}




int	DataEncDecTest()
{
	int	rtn, sLen, dLen;
	long	amnt;
	BYTE	pwd[4+1], acnt[37+1], hData[20+1];
	BYTE	pwd1[4+1], acnt1[37+1], hData1[20+1];
	BYTE	datetime[10+1], sData[143+1], dData[143+1]; 
	BYTE	s1_Key[33], w1_Key[33], w2_Key[33];
	BYTE	w1_Idx[3], w2_Idx[3];
	BYTE	pbUKey[16], pbData[16];
	DWORD	pdwRKey[32];
	int	w1Len, s1Len, w2Len;
	int	kIdx;
//	BYTE	w1_Key[KEY_LEN*2+3]; /* Client�� Ű���� */

	BYTE MK_TABLE[] = "1A2B3C4D5E6F7F8B2B3C91A1FF09AA953C4D82B2E018BB064D5E73C3D127CCA75E6F64D4C236DDB86F7055E6B345EEC9708146F7A454F0DA81922708957309EC92A31819868218FD03B4092A7791272EFA2B3C485E6F7F81EB3C91A9FF09AA92DC4D82BAE018BB03CD5E73CBD127CCA4BE6F64DCC236DDB5AF7055EDB345EEC6908146FEA454F0D77192270F957309E862A31810868218F963B409217791272A";

	/* ATM �ʱⰪ Set */
	strcpy((char *)pwd,                   "8765");		/* ���� ��й�ȣ                         */
	strcpy((char *)acnt,                  "42968765");	/* ���¹�ȣ(�����ڵ�=�������� 8�ڸ�)     */
	amnt = 30000;						/* �ŷ��ݾ�(��ȸ���ŷ��� '0')            */
	strcpy((char *)datetime,              "0604132343");	/* �ŷ��Ͻ�(mmddhhmmss)                  */

	memset(s1_Key,                0x00,            sizeof(s1_Key));
	memset(w1_Key,                0x00,            sizeof(w1_Key));
	memset(w2_Key,                0x00,            sizeof(w2_Key));

	memcpy(s1_Key,                datetime,                    10);
	memcpy(s1_Key+6,              acnt,                         6);

	s1Len=strlen((char *)s1_Key);
	/*----------------------------------------------------------*/
	/* ����Ű�� �����´�                                        */
	/*----------------------------------------------------------*/
	fnHD_CKeyInit(w1_Key, &w1Len, w1_Idx, MK_TABLE, s1_Key, s1Len);

	/* Hash Code Create (���������Ͻ�(10)+�ŷ��ݾ�(12)==>HashCode(20) ) */
	memset(hData,                  0x00,             sizeof(hData));
	rtn = fnHD_GetHashCode(datetime, amnt, hData);

	/* ��ȣȭ ������� ����(32 Byte) */
	memset(sData,                  0x00,             sizeof(sData));
	sLen = 0;
	sData[sLen] = 0xAC; sLen += 1;			/* ������(1)    */
	memcpy(&sData[sLen], hData, 20); sLen += 20;	/* HashCode(20) */
	memcpy(&sData[sLen], pwd,    4); sLen +=  4;	/* Password(4)  */
	memcpy(&sData[sLen], acnt,   7); sLen +=  7;	/* ���¹�ȣ(7)  */
	
	/* Send Data Block Encrypt (in=32 Byte --> Out=48 Byte) */
	memset(dData,                  0x00,             sizeof(dData));
	rtn = fnHD_EncSeed(w1_Key, w1_Idx, sData, sLen, dData, &dLen);

	/* d1Data ���� (Client --> Server) �ӽñ��� */
	memset(sData,                  0x00,             sizeof(sData));
	memcpy(sData,                  dData,                     dLen);
	sLen = dLen;

	/* Recv Data Block Decrypt */
	memset(pwd1,                   0x00,              sizeof(pwd1));
	memset(acnt1,                  0x00,             sizeof(acnt1));
	memset(hData1,                 0x00,            sizeof(hData1));


#ifdef _TEST_
	printf("\n\n\n");
#endif
	/*-------------------------------------------------------------------------*/
	/* ���� WORKING Ű�� �����ϴ� ��ƾ                                         */
	/*-------------------------------------------------------------------------*/
	memset(w2_Idx,                 0x00,            sizeof(w2_Idx));

	memcpy(w2_Idx,                 sData+67,                     2);
	kIdx = atoi((char *)w2_Idx);

	/*-------------------------------------------------------------------------*/
	/* ���ŵ� ������ �ŷ�����(4), �ŷ��ð�(6), ���¹�ȣ(6)�ڸ��� Set �ؾ���    */
	/*-------------------------------------------------------------------------*/
	memcpy(pbData,                 datetime,                    10);
	memcpy(pbData+10,              acnt,                         6);

	rtn = fnHD_DecSeed(pbData, kIdx, MK_TABLE, sData, sLen, pwd1, acnt1, hData1);
	if(rtn != 0)
	{
//		fnHD_SetRspCode(rtn);
		return rtn;
	}
	/* Hash�� �� */
	if(memcmp(hData, hData1, 20))
	{
		rtn = ERR_SVR_HASH;
//		fnHD_SetRspCode(rtn);
		return rtn;
	}
	/* ��й�ȣ ��(����ó������ ����) */
	if(memcmp(pwd, pwd1, 4))
		rtn = 100;
	/* ���¹�ȣ ��(����ó������ ����) */
	if(memcmp(acnt, acnt1, 4))
		rtn = 100;

	while(1)
	{
		Sleep(100);
	}
	return rtn;
}