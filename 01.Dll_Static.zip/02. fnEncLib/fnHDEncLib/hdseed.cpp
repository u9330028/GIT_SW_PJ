/*----------------------------------------------------------------------------*/
/* ���ϸ� : hdseed.c                                                          */
/* ��  �� : �������ǿ� ��ȣȭ ���                                            */
/* �ۼ��� : Ű����ũ                                                          */
/* �ۼ��� : 2010�� 5�� 10��                                                   */
/*                                                                            */
/* ��������  ������  ���泻��                                                 */
/*                                                                            */
/*----------------------------------------------------------------------------*/
#include "stdafx.h"


#ifdef	_TEST_
	BYTE printTemp[1024];
#endif

/*----------------------------------------------------------------------------*/
/* Bin Hexa to String Hexa                                                    */
/*----------------------------------------------------------------------------*/
int	UnPack(BYTE *sData, int sLen, BYTE *dData)
{
	int	i, j = 0;
	BYTE	temp;

	for(i = 0; i < sLen; i++)
	{                         
		/* high nibble convert */
		temp = (sData[i] >> 4) & 0x0f;
		if(temp >= 0x0a && temp <= 0x0f)	/* Alpha Code */
			dData[j++] = temp + 0x37;
		else					/* Numeric Code */
			dData[j++] = temp + 0x30;
		
		/* low nibble convert */
        	temp = sData[i] & 0x0f;
		if(temp >= 0x0a && temp <= 0x0f)
			dData[j++] = temp + 0x37;
		else 
			dData[j++] = temp + 0x30;
    }
	return	j;
}
/*----------------------------------------------------------------------------*/
/* String Hexa to Bin Hexa                                                    */
/*----------------------------------------------------------------------------*/
int	Pack(BYTE *sData, int sLen, BYTE *dData)
{
	BYTE	temp1, temp2;

	int	i, j = 0;
	for(i = 0; i < sLen; i++)
	{
		/* source Convert */
		temp1 = sData[i];
		if(temp1 >= '0' && temp1 <= '9')
			temp2 = temp1 - 0x30;
		else if(temp1 >= 'a' && temp1 <= 'f')
			temp2 = temp1 - 0x57;
		else if(temp1 >= 'A' && temp1 <= 'F')
			temp2 = temp1 - 0x37;
		else 
			temp2 = 0x00;
		
		/* Make destData */
		if(i%2 == 0) /* Ȧ��Byte */
		{
			dData[j] = (temp2 << 4) & 0xf0;
		}
		else
		{
			dData[j] |= temp2 & 0x0f;
			j++;
		}
	}
	return	j;
}

void	HD_SetRspCode(int eCode)
{
	BYTE rsp_Code[3];

printf("eCode=%d\n", eCode);
	switch(eCode)
	{
		case ERR_SVR_HASH :	
			memcpy(rsp_Code, "K1", 2);	/* �ŷ����� ����(��ŷ���û) */
			break;
		case ERR_MST_KEY_INDEX :
			memcpy(rsp_Code, "K2", 2);	/* �ŷ����� ����(��ŷ���û) */
			break;
		default :
			memcpy(rsp_Code, "K3", 2);	/* ��ȣȭ ��Ÿ ����(������Ÿ ���� ����) */
			break;
	}
#ifdef _TEST_
	printf("\nERR_CODE = [%0d], RSP_CODE = [%.2s]", eCode, rsp_Code);
#endif
}

/*----------------------------------------------------------------------------*/
/* ����Ű ����                                                                */
/*----------------------------------------------------------------------------*/
int	HD_CKeyInit (
	BYTE	*s1Key, 	/* out: SessionKey1                           */
	int	*s1Len, 	/* out: SessionKey1�� Length                  */
	BYTE	*s1Idx,		/* out: ������Ű Index                        */
	BYTE	*mk_table,	/* in : ������Ű Table Block                  */
	BYTE	*wKey,		/* in : �ܸ����� ����� ����Ű ����(�ʱⰪ)   */
	int	wLen)		/* in : ����Ű Length                         */
{
	int     kIdx, rtn=0;
	BYTE    pbUKey[16], pbData[16];
	DWORD   pdwRKey[32];


	/*----------------------------------------------------------*/
	/* ������ Ű block�� index ���� �����Ѵ�                    */
	/*----------------------------------------------------------*/
	kIdx = rand()%10; 

#ifdef _TEST_
	kIdx = 8; 
#endif

	sprintf((char *)s1Idx,         "%02d",                    kIdx);
	memset(pbUKey,                 0x00,            sizeof(pbUKey));
	Pack(&mk_table[kIdx*KEY_LEN], KEY_LEN*2,               pbUKey);
	SeedRoundKey(pdwRKey, pbUKey); 

#ifdef _TEST_
	UnPack((BYTE *)pdwRKey, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("Master Key   = %s\n",printTemp);
#endif
	memcpy(pbData,                 wKey,                      wLen);

#ifdef _TEST_
	pbData[0]	=0x30;
	pbData[1]	=0x36;
	pbData[2]	=0x30;
	pbData[3]	=0x34;
	pbData[4]	=0x31;
	pbData[5]	=0x33;
	pbData[6]	=0x32;
	pbData[7]	=0x33;
	pbData[8]	=0x34;
	pbData[9]	=0x33;
	pbData[10]	=0x34;
	pbData[11]	=0x32;
	pbData[12]	=0x39;
	pbData[13]	=0x36;
	pbData[14]	=0x38;
	pbData[15]	=0x37;
#endif

#ifdef _TEST_
	UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("WorkingKey   = %s\n",printTemp);
#endif

	/* Encrypt S1*/
	/*----------------------------------------------------------*/
	/* ������Ű�� ����Ű�� ��ȣȭ �Ѵ�                          */
	/*----------------------------------------------------------*/
	SeedEncrypt(pbData, pdwRKey);

#ifdef _TEST_
	UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("SessionKey   = %s\n",printTemp);
#endif

	/* S1 Key Block Make */
/*
	j = 0;
	j += _UnPack(pbData, KEY_LEN, &s1Key[j]);
	j += sprintf((char *)&s1Key[j], "%02d", kIdx);
	*s1Len = j;
*/
	memcpy(s1Key,                  pbData,                      16);
	*s1Len = 16;

	return	rtn;
}
/*----------------------------------------------------------------------------*/
/* �ؽ����� �����Ѵ�                                                          */
/*----------------------------------------------------------------------------*/
int	HD_GetHashCode(
	BYTE	*datetime,	/* in : ���������Ͻ�(bitmap-7) */
	long	amnt,		/* in : �ŷ��ݾ�(��ȸ��=0) */
	BYTE	*dData)		/* out: Hash��(20 Byte) */
{
	int rtn = 0, tLen;
	BYTE		tData[30];
	HAS160_ALG_INFO	AlgInfo;

	tLen = sprintf((char *)tData, "%.10s%012ld", datetime, amnt);

	HAS160_Init(&AlgInfo);
	HAS160_Update(&AlgInfo, tData, tLen);
	HAS160_Final(&AlgInfo, dData);

#ifdef _TEST_
	UnPack(dData, 20, printTemp); printTemp[20*2] = 0;
	printf("\nHashCode     = %s)\n", printTemp);
#endif

	return	rtn;
}

int	HD_EncSeed(
	BYTE	*wKey,		/* in : ����Ű ����            */
	BYTE	*wIdx, 		/* in : ������Ű Index         */
	BYTE	*sData,		/* in : ��ȣȭ ��� ����       */
	int	sLen,		/* in : ��ȣȭ ������� Length */
	BYTE	*dData,		/* out: ��ȣȭ�� ����          */
	int	*dLen)		/* out: ��ȣȭ�� ���� Length   */
{
	int     i=0,j=0, rtn=0, mok;
	BYTE    pbUKey[16], pbData[16];
	DWORD   pdwRKey[32];

	/**** ��ȣȭ ó�� �� �������� Make ************************/
	i = 0;
	/* Total Length Set  */
	memcpy(&dData[i],              "096",                        3);
	i += 3;

	/* ��ȣȭ ó�� */
	memset(pbUKey,                 0x00,            sizeof(pbUKey));

#ifdef _TEST_
	UnPack(wKey, KEY_LEN, printTemp); printTemp[KEY_LEN*2] = 0;
	printf("\nInput Key    = %s\n", printTemp);
#endif

#ifdef _TEST_
	UnPack(sData, sLen, printTemp); printTemp[sLen*2] = 0;
	printf("\nInput Data   = %s\n", printTemp);
#endif

	memcpy(pbUKey,                 wKey,                   KEY_LEN);
	SeedRoundKey(pdwRKey, pbUKey); 

	mok    = sLen / 16;
	for(j = 0; j < mok; j++)  
	{
		memset(pbData,              0x00,       sizeof(pbData));
		memcpy(pbData,              &sData[16*j],           16);
		SeedEncrypt(pbData, pdwRKey);
		i += UnPack(pbData,        16,              &dData[i]);
	}

	/* Filler Set  */
	memcpy(dData+i,                 (char *)wIdx,               2);
	i = i + 2;
	memcpy(dData+i,                 "1AB23CDD456EF7",          14);
	i = i + 14;

	if(i<99)
		memset(&dData[i], 0x37, (99-i)); i += (99-i);

	dData[i] = 0x00;
	*dLen = i;

#ifdef _TEST_
	memcpy(printTemp,dData, i); printTemp[i] = 0;
	printf("\nEncrypt Data = %s\n", printTemp);
#endif

	return rtn;
}

int	HD_DecSeed(
	BYTE	*wKey,		/* in : ��ŷŰ ����            */
	int	wIdx,		/* in : ������Ű Index         */
	BYTE	*mk_table,	/* in : ������Ű Table Block   */
	BYTE	*sData,		/* in : ��ȣȭ ��� ����       */
	int	sLen,		/* in : ��ȣȭ ������� Length */
	BYTE	*pwd,		/* out: ��ȣȭ�� ��й�ȣ      */
	BYTE	*acnt,		/* out: ��ȣȭ�� ī���ȣ      */
	BYTE	*hData)		/* out: ��ȣȭ�� Hash��        */
{
		int     i, j, rtn=0, mok, tLen;

		BYTE    pbUKey[17], pbData[16];
		DWORD   pdwRKey[32];
		BYTE	tData[ENC_BLOCK_LEN*2 + 1];

	#ifdef _TEST_
		memcpy(printTemp, sData, sLen); printTemp[sLen] = 0;
		printf("\nEncrypt Data = %s\n",printTemp);
	#endif

		/**** �������� Error check *******************************/
		if(memcmp(&sData[0], "096", 3) || sLen < 96) {
			rtn = ERR_BLOCK_LEN;
			return(rtn);
		}

		/**** ��ȣȭ���� ��ȣȭ **********************************/
		/* ����Data Pack */
		i = ENC_BLOCK_LEN*2 + 16;
	tLen = Pack(&sData[3], i, tData);

	/* ��ȣȭ ó�� */
	memset(pbUKey,                 0x00,            sizeof(pbUKey));
	Pack(&mk_table[wIdx*KEY_LEN], KEY_LEN*2,               pbUKey);
	SeedRoundKey(pdwRKey, pbUKey);

#ifdef	_TEST_
	UnPack((BYTE *)pdwRKey, KEY_LEN*2, printTemp); printTemp[KEY_LEN*2] = 0;
	printf("\nMaster  Key  = %s\n",printTemp);
#endif

#ifdef	_TEST_
	UnPack(wKey, KEY_LEN*2, printTemp); printTemp[KEY_LEN*2] = 0;
	printf("Working Key  = %s\n",printTemp);
#endif

	memcpy(pbUKey,                 wKey,                        16);
	SeedEncrypt(pbUKey, pdwRKey);
#ifdef _TEST_
	UnPack((BYTE *)pbUKey, KEY_LEN*2, printTemp); printTemp[KEY_LEN*2] = 0;
	printf("Session Key  = %s\n",printTemp);
#endif

	SeedRoundKey(pdwRKey, pbUKey);

	mok    = tLen / 16;
	for(j = 0; j < mok; j++)  
	{
		memset(pbData,              0x00,       sizeof(pbData));
		memcpy(pbData,              &tData[16*j],           16);
		SeedDecrypt(pbData, pdwRKey);
		memcpy(&tData[16*j],        pbData,                 16);
	}

#ifdef	_TEST_
	UnPack(tData, tLen, printTemp); printTemp[tLen*2] = 0;
	printf("\nDecrypt Data = %s\n",printTemp);
#endif

	/**** Data���� Block Check *****************************/
	if(tData[0] != 0xAC) {
		rtn = ERR_ENC_DATA_KIND;
		return(rtn);
	}
	memcpy(hData,                  &tData[1],                   20);
	memcpy(pwd,                    &tData[21],                   4);
	memcpy(acnt,                   &tData[24],                   7);

	return	rtn;
}
