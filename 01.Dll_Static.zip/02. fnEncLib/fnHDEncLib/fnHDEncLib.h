/* **************************************************************************
//
// Nautilus Hyosung Inc. 2010 All Rights Reserved
//
// ���ϸ� : fnHDEncLib.cpp
// ��  �� : Dll ����
// ��  �� : 2010/05/25 �ű��ۼ�
//
// *************************************************************************/
#ifndef __fnDHEncLib_H__
#define __fnDHEncLib_H__

#ifndef XDllExport
	#ifdef __cplusplus
		#define XDllExport   extern "C" __declspec( dllexport )
	#else 
		#define XDllExport __declspec( dllexport )
	#endif
#endif

/********************** Include files *****************************/

#include <stdlib.h>
#include <string.h>

/**************** Function Prototype Declarations **************************************************************************************************/
// Encrpt Function
XDllExport int  CALLBACK fnHD_CKeyInit(BYTE *s1Key, int *s1Len, BYTE *s1Idx, BYTE *mk_table, BYTE *wKey, int wLen);
XDllExport int  CALLBACK fnHD_GetHashCode(BYTE *datetime, long amnt, BYTE *dData);
XDllExport int  CALLBACK fnHD_EncSeed(BYTE *wKey, BYTE *wIdx, BYTE *sData, int sLen, BYTE *dData, int *dLen);
XDllExport int  CALLBACK fnHD_DecSeed(BYTE *wKey, int wIdx, BYTE *mk_tabale, BYTE *sData, int sLen, BYTE *pwd, BYTE *acnt, BYTE *hData);
/**************************************************************************************************************************************************/
#endif