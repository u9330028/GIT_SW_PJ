/*--------------------------------------------------------------------*/
/*                                                                    */
/*--------------------------------------------------------------------*/

#ifndef _HDTYPE_H
#define _HDTYPE_H

/*
#define	BYTE	unsigned char
#define	WORD	unsigned short int
#define	DWORD	unsigned int
*/
//typedef	unsigned	int		DWORD;
//typedef	unsigned	short	WORD;
//typedef	unsigned	char	BYTE;

#endif
/*--------------------------------------------------------------------*/
