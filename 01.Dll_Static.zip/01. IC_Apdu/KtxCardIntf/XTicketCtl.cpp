/* **************************************************************************
//
// Nautilus Hyosung Inc. 2005 All Rights Reserved
//
// ���ϸ� : XTicketCtl.h
// ��  �� : XTicket ����
// ��  �� : 2005/07/06 �ű��ۼ�
//
// *************************************************************************/
#include "stdafx.h"
#include "XControl.h"
#include "XTicketCtl.h"

CXTicketCtl g_XTicketCtl;				// ���� CXTicketCtlŬ����

CXTicketCtl* GetXTicketCtl()
{
	return &g_XTicketCtl;
}

CXTicketCtl::CXTicketCtl() : CXControl()
{

}

CXTicketCtl::~CXTicketCtl()
{

}

void CXTicketCtl::Clear()
{
	m_nCount	= 0;
	ZeroMemory(m_byType, sizeof(m_byType));
	ZeroMemory(m_cCardId, sizeof(m_cCardId));

	CXControl::Clear();
}

int CXTicketCtl::Select(LPCTSTR lpszSubKeyName)
{
	CXControl::Reset();

	_tcscpy(m_szRegKeyName, lpszSubKeyName);

	// Select AID
	CopyMemory(m_bySendApdu, g_XT_bySel_AID, APDU_XC_SELECTAID_SIZE+1);
	
	int nResult = SendApdu(APDU_XC_SELECTAID_SIZE+1);

	if (nResult == 0 && m_byRecvApdu[0] == 0x6a && m_byRecvApdu[1] == 0x82) return XERR_NOTFOUND;
	else if (nResult < 0) return XERROR;

	m_nCount = m_byRecvApdu[14];						// �� Ƽ�� ����
	toHexString(m_byRecvApdu+4, 8, m_cCardId, 16);		// Card Id
		
	for (int i=0; i<m_nCount; i++) CopyMemory(m_byType[i], &m_byRecvApdu[16+3*i], 2);
	
	return XSUCCESS;
}

int CXTicketCtl::ReadTicket()
{
	int i = 0;
	int nResult;
	int nResponse;

	CopyMemory(m_bySendApdu, g_XT_byRead_TKT, sizeof(g_XT_byRead_TKT));
	RandomBytes(m_bySendApdu+5, 8);
	CopyMemory(m_bySendApdu+13, m_byType[i], 2);

	while (i<m_nCount){
		nResult = SendApdu(APDU_XT_READ_TKT_SIZE, nResponse);
		switch(nResult){
		case -1: return XERROR;
		case 0:
			if (m_byRecvApdu[nResponse-2] != 0x91 || m_byRecvApdu[nResponse-1] != 0x00) return XERROR;
			break;
		default:
			break;
		}

		SetReadTicketInfo(i);
		m_bySendApdu[2] = 0x00;
		i++;
	}

	i = (sizeof(stTicket_In_t)+1)*m_nCount-1;
	sprintf(m_szRegBuff, "%.2d", m_nCount);
	m_szRegBuff[2]   = g_chDeLimiter;
	m_szRegBuff[3+i] = 0x00;

	if (SetRegistryStr()) return XSUCCESS;	// �������͸��� ����.
	return XERR_REGDATA;
}

int	CXTicketCtl::XTicketIssue_Init()
{
	if (GetRegistryStr() != 16) return XERR_REGDATA;	// HRN
	
	CopyMemory(m_bySendApdu, g_XT_byIntn_AUTH, 5);
	toHex(m_szRegBuff, 16, m_bySendApdu+5, 8);
	
	if (SendApdu(APDU_XT_INTN_AUTH_SIZE) <= 0) return XERROR;

	CopyMemory(m_szRegBuff, m_cCardId, 16);
	m_szRegBuff[16] = g_chDeLimiter;					// Card Id
	toHexString(m_byRecvApdu, 4, m_szRegBuff+17, 8);	// MAC
	m_szRegBuff[25] = g_chDeLimiter;
	toHexString(m_byRecvApdu+4, 8, m_szRegBuff+26, 16);	// CRN
	m_szRegBuff[42] = 0x00;

	if (SetRegistryStr()) return XSUCCESS;	// �������͸��� ����.
	return XERR_REGDATA;
}

int	CXTicketCtl::XTicketIssue_Done()
{
	int nlen = GetRegistryStr();

#ifdef _XTICKET_220
	if (nlen != 229) return XERR_REGDATA;
	
	CopyMemory(m_bySendApdu, g_XT_byIssue_TKT, 4);
	m_bySendApdu[4] = 0x77;
	
	toHex(m_szRegBuff, 158, m_bySendApdu+5, 79);
	CopyMemory(m_bySendApdu+84, m_szRegBuff+158, 10);	// Name
	toHex(m_szRegBuff+168, 52, m_bySendApdu+94, 26);
	toHex(m_szRegBuff+221, 8, m_bySendApdu+120, 4);		// Mac
#else
	if (nlen != 239) return XERR_REGDATA;

	CopyMemory(m_bySendApdu, g_XT_byIssue_TKT, 4);
	m_bySendApdu[4] = 0x77;

	toHex(m_szRegBuff, 230, m_bySendApdu+5, 115);
	toHex(m_szRegBuff+231, 8, m_bySendApdu+120, 4);
#endif
	if (SendApdu(APDU_XT_ISSUE_SING_SIZE) <= 0) return XERROR;

	return XSUCCESS;
}

int	CXTicketCtl::XTicketCancel_Init()
{
	if (GetRegistryStr() != 34) return XERR_REGDATA;			// HRN|Ticket Type|Ticket Id
	BYTE byRead[5] = {0x90, 0x8C, 0x03, 0x00, 0x10};

	CopyMemory(m_bySendApdu, byRead, 5);
	toHex(m_szRegBuff,16 , m_bySendApdu+5, 8);					// HRN
	toHex(m_szRegBuff+17, 4, m_bySendApdu+13, 2);				// Ticket Type
	toHex(m_szRegBuff+22, 12, m_bySendApdu+15, 6);				// Ticket Id

	int nlen = 0;
	int nRes = 0;
	if ((nlen = SendApdu(APDU_XT_READ_TKT_SET_SIZE, nRes)) < 0) return XERROR;
	if (nlen == 0){
		if (nRes >= 2){
			if (m_byRecvApdu[nRes-2] != 0x91 || m_byRecvApdu[nRes-1] != 0x00) return XERROR;
		}else 
			return XERROR;
	}

#ifdef _XTICKET_220	
	toHexString(m_byRecvApdu, 79, m_szRegBuff, 158);
	CopyMemory(m_szRegBuff+158, m_byRecvApdu+79, 10);
	toHexString(m_byRecvApdu+89, 26, m_szRegBuff+168, 52);

	m_szRegBuff[220] = g_chDeLimiter;

	toHexString(m_byRecvApdu+115, 8, m_szRegBuff+221, 16);	// CRN
	m_szRegBuff[237] = g_chDeLimiter;

	toHexString(m_byRecvApdu+123, 4, m_szRegBuff+238, 8);	// MAC
	m_szRegBuff[246] = 0x00;
#else
	toHexString(m_byRecvApdu, 115, m_szRegBuff, 230);
	m_szRegBuff[230] = g_chDeLimiter;

	toHexString(m_byRecvApdu+115, 8, m_szRegBuff+231, 16);	// CRN
	m_szRegBuff[247] = g_chDeLimiter;

	toHexString(m_byRecvApdu+123, 4, m_szRegBuff+248, 8);	// MAC
	m_szRegBuff[256] = 0x00;
#endif

	if (SetRegistryStr()) return XSUCCESS;	// �������͸��� ����.
	return XERR_REGDATA;
}

int	CXTicketCtl::XTicketCancel_Done()
{
	if (GetRegistryStr() != 27) return XERR_REGDATA;			// Log|MAC
	CopyMemory(m_bySendApdu, g_XT_bySet_TKT, 5);
	toHex(m_szRegBuff, 18,  m_bySendApdu+5, 9);
	toHex(m_szRegBuff+19, 8, m_bySendApdu+14, 4);

	if (SendApdu(APDU_XT_SET_STATUS_SIZE) <= 0) return XERROR;

	toHexString(m_byRecvApdu, 4, m_szRegBuff, 8);				// MAC
	m_szRegBuff[8] = 0x00;

	if (SetRegistryStr()) return XSUCCESS;	// �������͸��� ����.
	return XERR_REGDATA;
}

void CXTicketCtl::SetReadTicketInfo(int nOffset)
{
#ifdef _XTICKET_220
	TCHAR* pDest	= m_szRegBuff+3+nOffset*(sizeof(stTicket_In_t)+1);
	stTicket_In_t* pTicket = (stTicket_In_t *)(m_byRecvApdu + 1);

	toHexString((LPBYTE)pTicket, 79, pDest, 158);
	CopyMemory(pDest+158, pTicket->chName, sizeof(pTicket->chName));
	toHexString((LPBYTE)pTicket+89, 26, pDest+168, 52);

	pDest[220] = g_chDeLimiter;
#else
	TCHAR* pDest	= m_szRegBuff+3+nOffset*(sizeof(stTicket_In_t)+1);
	stTicket_In_t* pTicket = (stTicket_In_t *)(m_byRecvApdu + 1);

	toHexString((LPBYTE)pTicket, 115, pDest, 230);
	pDest[230] = g_chDeLimiter;
#endif
}