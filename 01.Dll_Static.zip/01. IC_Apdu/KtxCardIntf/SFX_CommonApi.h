/****************************************************************************
* File Name		: SFX_CommonApi.cpp
* 
* Description	: ���� ���̺귯�� ���
*
* Department	: ��ƿ����ȿ��(��)
* 
* Version		: 1.0.0 (������)
*
* Rivision	:
*		1. v 1.0.0 : 2004/04/13 - ���� ����
*		   �躴�� (hds-similrae@hyosung.com, yappang@bcline.com)
*
*										Copyright (c) 2004, Nautilus Hyosung
* ***************************************************************************
*/
#ifndef _SFXCOMMONAPI_H_
#define	_SFXCOMMONAPI_H_


////////////////////////////////////////////////////////////////////////////
//		�޸� ����, �Ҹ� ����
////////////////////////////////////////////////////////////////////////////
// �޸� ���� [ x : �޸� ������ ]
//#define xmalloc(x) MemAlloc( __FILE__, __LINE__, (x) )
// �޸� ���� [ x : �޸� ����Ÿ ����Ʈ ]
//#define xfree(x)   MemFree ( __FILE__, __LINE__, (x) )

void SfxGetModulePath(LPTSTR a_lpszModulePath, LPDWORD a_lpcbSize );

//void* MemAlloc(LPCTSTR a_lpszFileName, int a_nLine, size_t a_size);
//void  MemFree(LPCTSTR a_lpszFileName, int a_nLine, void *a_memblock);

//void htoa(LPCBYTE pbSource, int cbSource, LPTSTR pbStr, int* pcbStr, BOOL inspace=FALSE);
//BOOL atoh(LPTSTR pszSource, int cbSource, LPBYTE pbHexa, int* pcbHexa);
//void htoa_16_str(
//		IN	int     nSpaceCount,
//		IN  LPCBYTE pbSource,	IN  int  cbSource,
//		OUT LPTSTR  pszDest ,	OUT int* pcbDest);
//void htoa_dump(
//		IN  LPCBYTE a_pbSource,	IN  int a_cbSource,
//		OUT LPTSTR  a_pszDest,	OUT int* a_pcbDest,
//		IN  int     a_nUnit,	IN  int a_nMaxColumn);

//void toHexDumpString(LPBYTE pbSource, int cbSource, LPTSTR pszDest, int* pcbDest, int nUnit);


////////////////////////////////////////////////////////////////////////////

//CString GetCommaLeftStr(LPTSTR a_lpszSource);

////////////////////////////////////////////////////////////////////////////

void RandomBytes(LPBYTE pbBlock, int cbBlock);
void XorBytes(LPBYTE a, LPBYTE b, LPBYTE c, int length);
void BytesToInts(LPBYTE in, int* out, int length);
void IntsToBytes(int* in, BYTE* out, int length);
void BytesToShorts (BYTE* in, int* out, int length);
void ShortsToBytes (int* in, BYTE* out, int length);
int  StrHexToInteger(LPCTSTR strHex);

BOOL toHexString(BYTE* pbHex, int cbHex, TCHAR* strDest, int strDestLen, BOOL isSpace = FALSE);
BOOL toHex(LPCTSTR str, int strLen, BYTE* pbHex, int cbHex);

BOOL toBcdString(BYTE* pbBcd, int cbBcd, TCHAR* strDest, int strDestLen);
BOOL toBcd(LPCTSTR str, int strLen, BYTE* pbBcd, int cbBcd);

#define	PADFLAG_8000		0
#define	PADFLAG_INVERSE		1
#define	PADFLAG_ZERO		2
BOOL toPadding(BYTE* pbHex, int cbHex, BYTE* pbPad, int* pcbPad, int calcUnit, int nFlag = PADFLAG_8000);
void toInverse(BYTE* src, BYTE* dest, int size);

#define	FB_RIGHT			0
#define	FB_LEFT				1
void FillBytes(LPBYTE source, int srclen, BYTE chr, LPBYTE dest, int destlen, int nFlag = 0);

// �߰� (2005.04.07)
void SFXTRACE(LPCTSTR lpszFormat, ...);
void GetJulianDate(BYTE* pbSrc);
void SetJulianDate(BYTE* pbSrc, TCHAR* pResult);

#endif


