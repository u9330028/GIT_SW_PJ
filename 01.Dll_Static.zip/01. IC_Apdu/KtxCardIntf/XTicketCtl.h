/* **************************************************************************
//
// Nautilus Hyosung Inc. 2005 All Rights Reserved
//
// ���ϸ� : XTicketCtl.h
// ��  �� : XTicket ����
// ��  �� : 2005/07/06 �ű��ۼ�
//
// *************************************************************************/
#ifndef __XTICKETCTL_H__
#define __XTICKETCTL_H__

class CXTicketCtl : public CXControl
{
public:
	CXTicketCtl();
	virtual ~CXTicketCtl();

// Attributes
private:
	int				m_nCount;									// Ticket ����
	BYTE			m_byType[18][2];							// Ticket type
	TCHAR			m_cCardId[16];								// Card Id	
	
// Operations
public:
	virtual void	Clear();

	int				Select(LPCTSTR lpszSubKeyName);				// Select
	int				ReadTicket();								// Ticket �б�
	int				XTicketIssue_Init();						// �߱� ����
	int				XTicketIssue_Done();						// �߱� ��
	int				XTicketCancel_Init();						// ��� ����
	int				XTicketCancel_Done();						// ��� ��

protected:
	void			SetReadTicketInfo(int nOffset);
				
};

CXTicketCtl* GetXTicketCtl();

#endif