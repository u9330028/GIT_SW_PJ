/****************************************************************************
* File Name		: SFX_CommonApi.cpp
* 
* Description	: ���� ���̺귯�� ���
*
* Department	: ��ƿ����ȿ��(��)
* 
* Version		: 1.0.0 (������)
*
* Rivision	:
*		1. v 1.0.0 : 2004/04/13 - ���� ����
*		   �躴�� (hds-similrae@hyosung.com, yappang@bcline.com)
*
*										Copyright (c) 2004, Nautilus Hyosung
* ***************************************************************************
*/
#include "stdafx.h"
#include <assert.h>
#include <time.h>
#include <math.h>
#include "SFX_CommonApi.h"

//
// Function		: SfxGetModulePath
// Description	: 
//		
//
// Parameter	: 
// Result		: 
//
// Remark		:
// Rivision 	: 
//		2004/04/13 - ���� �ۼ� (BSKIM)
//
void SfxGetModulePath(LPTSTR a_lpszModulePath, LPDWORD a_lpcbSize )
{
	LPTSTR	lpDest = NULL;
    TCHAR	szFilePath[_MAX_PATH] = { 0 };

    // ���� �۾� ���丮 ���
	GetCurrentDirectory(sizeof(szFilePath), szFilePath);
	
	DWORD dwCopyLen = strlen(szFilePath);
	if ( dwCopyLen >= (*a_lpcbSize) - 1 )
	{
		*a_lpcbSize = dwCopyLen + 1;
		return;
	}

	strcpy( a_lpszModulePath, szFilePath );
	*a_lpcbSize = dwCopyLen;
}

////////////////////////////////////////////////////////////////////////////
//		�޸� �Ҵ�� ���� �Լ�
////////////////////////////////////////////////////////////////////////////

//
// �� �� �� : �޸� ����
// ��    �� : ���� �޸𸮸� �����Ѵ�.
// �� �� �� : MemAlloc
// �Ķ���� : a_lpszFile - �Լ��� ����� ���ϸ� [IN] 
//            a_nLine    - ���ϳ� ������ġ [IN] 
//            a_size     - �޸� ������ [IN] 
// �� �� �� : ����
// ���ǻ��� : xmalloc��ũ�ο��� ���������� ȣ��
//
//void* MemAlloc( LPCTSTR a_lpszFileName, int a_nLine, size_t a_size )
//{
//    void* pAddr = NULL;
//    pAddr = malloc(a_size);
//    memset(pAddr, 0x00, a_size);
    
//#ifdef MEM_CHECK
//	TRACE( "*** Allo : File = %s, Line = %d, ADDR = 0x%.8x, SIZE = %d\n",
//		   a_lpszFileName, a_nLine, pAddr, a_size );
//#endif
//	return pAddr;
//}

//
// �� �� �� : �޸� ����
// ��    �� : ���� ������ �޸𸮸� �����Ѵ�.
// �� �� �� : MemFree
// �Ķ���� : a_lpszFileName - �Լ��� ����� ���ϸ� [IN] 
//            a_nLine        - ���ϳ� ������ġ [IN] 
//            a_memblock     - �޸� ������ [IN] 
// �� �� �� : ����
// ���ǻ��� : xfree��ũ�ο��� ���������� ȣ��
//
//void MemFree(LPCTSTR a_lpszFileName, int a_nLine, void *a_memblock)
//{
//#ifdef MEM_CHECK
//	TRACE( "*** Free : File = %s, Line = %d, ADDR = 0x%.8x\n",
//		   a_lpszFileName, a_nLine, a_memblock );
//#endif
//    free( a_memblock );

//    a_memblock = NULL;
//}


//
// Function		: htoa
// Description	: 
//
// Parameter	: 
// Result		: 
//
// Remark		:
// Rivision 	: 
//		2004/04/09 - ���� �ۼ� (BSKIM)
//
//void htoa(LPCBYTE pbSource, int cbSource, LPTSTR pbStr, int* pcbStr, BOOL inspace /*=FALSE*/)
//{
	// size check
//	int cbReq = cbSource * (2 + ((inspace) ? 1 : 0));
//	if (*pcbStr < cbReq) {
//		*pcbStr = cbReq;
//		return;
//	}

//	if (pbStr == NULL)
//		return;

//	BYTE hi, lo;
//	int  pos = 0;
//	for(int i=0; i < cbSource; i++)
//	{
//		hi = (pbSource[i] & 0xf0) >> 4;
//		lo = (pbSource[i] & 0x0f);

//		pbStr[pos++] = hi + ((hi <= 0x09) ? 0x30 : 0x37);
//		pbStr[pos++] = lo + ((lo <= 0x09) ? 0x30 : 0x37);
//		if (inspace)
//			pbStr[pos++] = 0x20;
//	}

//	*pcbStr = pos;
//}

//
// �� �� �� : Numeric�� ���ڿ��� HEX����Ÿ ������ ��ȯ
// ��    �� : Numeric�� ���ڿ��� HEX����Ÿ ������ ��ȯ�Ѵ�.
// �� �� �� : StringToHex
// �Ķ���� : lpData      - ������ ���ڿ� ����Ÿ [IN] 
//            dwDataSize  - ���ڿ� ����Ÿ�� ������ [IN] 
//            lpBcd       - BCD����Ÿ [OUT] 
//            dwBcdSize   - BCD����Ÿ�� ������ [OUT] 
// �� �� �� : TRUE  - ����
//            FALSE - ����
// ���ǻ��� : "903F" 0x39 0x30 0x33 0x3F -> 0x90 0x3F ��
//            0x09 0x00 0x03 0x0F -> 0x90 0x3F �� ��ȯ
//            ��������� ������ ����Ǹ� 
//            �Էµ���Ÿ�� ����� Ȧ���ϰ�� �ǵ��� ����Ÿ�� �ҽ�.
//
//BOOL atoh(LPTSTR pszSource, int cbSource, LPBYTE pbHexa, int* pcbHexa)
//{
//    int     nPos      = 0;                              // ����Ÿ �¾� ��ġ
//    BYTE    byHiData  = 0;                              // ���� ����Ʈ
//    BYTE    byLowData = 0;                              // ���� ����Ʈ
        
    // ������� ������ üũ �� 2�� ������� Ȯ��
//	int cbReq = cbSource / 2;
//    if ( cbReq > *pcbHexa )  {
//		*pcbHexa = cbReq;
//        return FALSE;
//	}

	// Source ������ üũ
//	if ( cbSource % 2 != 0 )	return FALSE;

//	int nRemain = cbSource;
//	int	srcOffset = 0, destOffset = 0;

//    while(nRemain)
//    {
//        byHiData  = pszSource[srcOffset++];
//        byLowData = pszSource[srcOffset++];

        // �Էµ���Ÿ üũ( '0'~'9' , 'a'~'f', 'A'~'F' )
//        if( !isalnum((int)byHiData) || !isalnum((int)byLowData) )
//            return FALSE;
        
        // ��������Ʈ������ ��ȯ
//        if( byHiData >= 0x30 && byHiData <= 0x39 )
//            byHiData  = ( byHiData & 0x0F ) * 0x10;
//        else
//            byHiData  = ( ( byHiData & 0x0F ) + 0x09 ) * 0x10;

        // ��������Ʈ������ ��ȯ
//        if( byLowData >= 0x30 && byLowData <= 0x39 )
//            byLowData = byLowData & 0x0F;
//        else
//            byLowData  = ( byLowData & 0x0F ) + 0x09;
        
//        pbHexa[destOffset++] = byHiData + byLowData;         
//    }
//	*pcbHexa = destOffset;

//    return TRUE;
//}



//
// Function		: htoa_16_str
// Description	: 
//
// Parameter	: 
// Result		: 
//
// Remark		:
// Rivision 	: 
//		2004/04/09 - ���� �ۼ� (BSKIM)
//
//void htoa_16_str(
//	IN	int     nSpaceCount,
//	IN  LPCBYTE pbSource,	IN  int  cbSource,
//	OUT	LPTSTR  pszDest ,	OUT int* pcbDest)
//{

	// �ʿ��� ������ ũ�⸦ ���Ѵ�.
//	int cbTarget = nSpaceCount + 16 * 3 + 1 + 16;
//	if (*pcbDest < cbTarget || cbSource > 16) {
//		*pcbDest = cbTarget;
//		return;
//	}

	// �� ���� ä���
//	int pos = 0;
//	memset(pszDest, 0x20, nSpaceCount);
//	pos += nSpaceCount;	

	// AA BB CC ...
//	int cbSrc = min(cbSource, 16);
//	cbTarget = *pcbDest - pos;
//	htoa(pbSource, cbSrc, &pszDest[pos], &cbTarget, TRUE);
//	pos += cbTarget;

	// ���� �ڸ� �� ��ŭ ���� ä�� �ֱ�
//	for(int i=0; i < 16-cbSrc; i++) {
//		strcpy(&pszDest[pos], _T("   "));
//		pos += 3;
//	}

//	pszDest[pos++] = ' ';

//	for(i=0; i < cbSrc; i++)
//		pszDest[pos++] = IsChar(pbSource[i]) ? pbSource[i] : '.';

//	*pcbDest = pos;
//}

//
// Function		: htoa_dump
// Description	: 
//
// Parameter	: 
// Result		: 
//
// Remark		:
// Rivision 	: 
//		2004/04/09 - ���� �ۼ� (BSKIM)
//
//void htoa_dump(
//	IN  LPCBYTE a_pbSource,	IN  int a_cbSource,
//	OUT LPTSTR  a_pszDest,	OUT int* a_pcbDest,
//	IN  int     a_nUnit,	IN  int a_nMaxColumn)
//{
//	int nColumn = a_cbSource / a_nUnit + 1;
//	int nRow    = nColumn / a_nMaxColumn + 1;

	// size check
//	int nReqBytes = a_cbSource * 2 + nColumn * 2 + nRow * 2 + 1;
//	if (*a_pcbDest < nReqBytes) {
//		*a_pcbDest = nReqBytes;
//		return;
//	}

	// hexa to string
//	int    cbHexaStr = a_cbSource * 2;
//	LPTSTR pHexaStr = new char[cbHexaStr];
//	memset(pHexaStr, 0, cbHexaStr);

//	htoa(a_pbSource, a_cbSource, pHexaStr, &cbHexaStr, FALSE);

	// �÷� ������ ��ȯ
//	int dest_off = 0, hexa_off = 0;
//	int copyBytes, remainBytes = cbHexaStr;

//	for(int i=1; i <= nColumn; i++)
//	{
//		if (remainBytes == 0)
//			break;
//		copyBytes = min(a_nUnit*2, remainBytes);
//		strncpy(&a_pszDest[dest_off], &pHexaStr[hexa_off], copyBytes);
//		dest_off += copyBytes;	hexa_off += copyBytes;
//
//		if ((i % a_nMaxColumn) == 0) {
//			a_pszDest[dest_off++] = '\r';
//			a_pszDest[dest_off++] = '\n';
//		} else {
//			a_pszDest[dest_off++] = ' ';
//			a_pszDest[dest_off++] = ' ';
//		}
//		remainBytes -= copyBytes;
//	}
//	delete pHexaStr;
//	*a_pcbDest = dest_off;
//}

//
// Function		: toHexDumpString
// Description	: 
//
// Parameter	: 
// Result		: 
//
// Remark		:
// Rivision 	: 
//		2004/06/04 - ���� �ۼ� (BSKIM)
//
//void toHexDumpString(LPBYTE pbSource, int cbSource, LPTSTR pszDest, int* pcbDest, int nUnit)
//{
//	int lines = cbSource / nUnit + 1;
//	int reqBuffersize = cbSource * 3 + lines * 2;

//	int srcOffset	= 0;
//	int destOffset	= 0;
//	int convBytes	= 0;
//	int remainBytes = cbSource;

//	if (*pcbDest >= reqBuffersize)
//	{
//		while(remainBytes)
//		{
//			convBytes = __min(remainBytes, nUnit);

//			toHexString(&pbSource[srcOffset], convBytes, &pszDest[destOffset], convBytes*3, TRUE);
//			srcOffset  += convBytes;
//			destOffset += convBytes * 3;

//			pszDest[destOffset++] = '\r';
//			pszDest[destOffset++] = '\n';

//			remainBytes -= convBytes;
//		}
//	}

//	*pcbDest = reqBuffersize;
//}


//CString GetCommaLeftStr(LPTSTR a_lpszSource)
//{
//	LPTSTR	pdest;
//	int		nLength;
//	CString sResult = a_lpszSource;

//	if (pdest = _tcschr(a_lpszSource, ','))
//	{
//		nLength = pdest - a_lpszSource;
//		sResult = CString(a_lpszSource, nLength);
//	}
//	return sResult;
//}


void RandomBytes(LPBYTE pbBlock, int cbBlock)
{
	srand( (unsigned)time( NULL ) );

	for (int i = 0; i < cbBlock; ++ i)
		pbBlock[i]=(BYTE)(rand() % 256);
}


void XorBytes(LPBYTE a, LPBYTE b, LPBYTE c, int length)
{
	for ( int i = 0; i < length; ++i )
		c[i] = (BYTE)( a[i] ^ b[i] );
}


void BytesToInts(LPBYTE in, int* out, int length)
{
	for (int i=0; i < length; ++i) 
	{
		out[i] =
#ifndef	SFX_BIGENDIAN
		( ( in[4 * i    ] & 0xFF )       ) |
		( ( in[4 * i + 1] & 0xFF ) << 8  ) |
		( ( in[4 * i + 2] & 0xFF ) << 16 ) |
		( ( in[4 * i + 3] & 0xFF ) << 24 );
#else
		( ( in[4 * i    ] & 0xFF ) << 24 ) |
		( ( in[4 * i + 1] & 0xFF ) << 16 ) |
		( ( in[4 * i + 2] & 0xFF ) << 8  ) |
		  ( in[4 * i + 3] & 0xFF );
#endif
	}
}


void IntsToBytes(int* in, BYTE* out, int length)
{
	for ( int i=0; i < length; ++i)
	{
#ifndef	SFX_BIGENDIAN
		out[i * 4    ] = (BYTE) (in[i]);
		out[i * 4 + 1] = (BYTE) (in[i] >> 8 );
		out[i * 4 + 2] = (BYTE) (in[i] >> 16);
		out[i * 4 + 3] = (BYTE) (in[i] >> 24);
#else
		out[i * 4    ] = (BYTE) (in[i] >> 24);
		out[i * 4 + 1] = (BYTE) (in[i] >> 16);
		out[i * 4 + 2] = (BYTE) (in[i] >> 8 );
		out[i * 4 + 3] = (BYTE) (in[i]);
#endif
	}
}


void BytesToShorts (BYTE* in, int* out, int length)
{
	for ( int i=0; i < length; ++i)
	{
		out[i] =
#ifndef	SFX_BIGENDIAN
		(   in[i * 2    ] & 0xff ) |
		( ( in[i * 2 + 1] & 0xff ) << 8);
#else
		( ( in[i * 2    ] & 0xff ) << 8) |
		  ( in[i * 2 + 1] & 0xff );
#endif
	}
}


void ShortsToBytes (int* in, BYTE* out, int length)
{
	for ( int i=0; i < length; ++i)
	{
#ifndef	SFX_BIGENDIAN
		out[i * 2    ] = (BYTE) in[i];
		out[i * 2 + 1] = (BYTE) (in[i] >> 8);
#else
		out[i * 2    ] = (BYTE) (in[i] >> 8);
		out[i * 2 + 1] = (BYTE) in[i];
#endif
	}
}

int  StrHexToInteger(LPCTSTR strHex)
{
	int str_len = _tcslen(strHex);

	if ( str_len > (sizeof(int)*2) )
		return -1;

	BYTE hex[4] = {0};
	toHex(strHex, str_len, hex, sizeof(hex));

	int ints = 0;
	BytesToInts(hex, &ints, 1);

	return ints;
}


BOOL toHexString(BYTE* pbHex, int cbHex, TCHAR* strDest, int strDestLen, BOOL isSpace)
{
	int offset = 0;
	TCHAR* hex = _T("0123456789ABCDEF");

	if (strDestLen < cbHex*2) return FALSE;

	int i = 0;
	for ( int count = 0; count < cbHex; count++)
	{
		strDest[i++] = hex[ (pbHex[offset] >> 4) & 0x0F ];
		strDest[i++] = hex[ pbHex[offset++] & 0x0F ];
		if (isSpace) strDest[i++] = ' ';
	}

	return TRUE;
}

BOOL toHex(LPCTSTR str, int strLen, BYTE* pbHex, int cbHex)
{
	int offset = 0;

	if ( (strLen % 2) != 0 || (strLen / 2) > cbHex)
		return FALSE;

	int hi, lo;
	for(int i = 0; offset < strLen; i++)
	{
        hi = str[offset++];
        lo = str[offset++];

        // �Էµ���Ÿ üũ( '0'~'9' , 'a'~'f', 'A'~'F' )
        if( !isalnum(hi) || !isalnum(lo) )
            return FALSE;

        // ��������Ʈ������ ��ȯ
		hi = (hi >= '0' && hi <='9') ? ((hi & 0x0F) * 16) : (((hi & 0x0F) + 9) * 16);
		// ��������Ʈ������ ��ȯ
		lo = (lo >= '0' && lo <='9') ? (lo & 0x0F) : ((lo & 0x0F) + 9);
       
        pbHex[i] = (BYTE)(hi + lo);
	}

	return TRUE;
}

BOOL toBcdString(BYTE* pbBcd, int cbBcd, TCHAR* strDest, int strDestLen)
{
	int offset = 0;
	TCHAR* strBcd = _T("0123456789......");

	if (strDestLen < cbBcd*2) return FALSE;

	int i = 0, hi, lo;
	for ( int count = 0; count < cbBcd; count++)
	{
		hi = (pbBcd[offset] >> 4) & 0x0F;
		lo = pbBcd[offset++] & 0x0F;

		if (hi >= 10 && lo >= 10)
			return FALSE;

		strDest[i++] = strBcd[ hi ];
		strDest[i++] = strBcd[ lo ];
	}

	return TRUE;
}


BOOL toBcd(LPCTSTR str, int strLen, BYTE* pbBcd, int cbBcd)
{
	int offset = 0;

	int hi, lo;
	for(int i = 0; str[offset] != '\0'; i++)
	{
        hi = str[offset++] - '0';
        lo = str[offset++] - '0';

		if (hi > 10 || lo > 10 || i >= cbBcd)
			return FALSE;
      
		pbBcd[i] = (BYTE)((hi << 4) | lo);
	}

	return TRUE;
}


BOOL toPadding(BYTE* pbHex, int cbHex, BYTE* pbPad, int* pcbPad, int calcUnit, int nFlag)
{
	// �е��� ������ ������ ���
	int mod = cbHex % calcUnit;
	int padSize = mod ? calcUnit-mod : mod;

	if (*pcbPad < (cbHex+padSize)) {
		*pcbPad = cbHex+padSize;
		return FALSE;
	}

	int i;
	int offset = 0;

	memcpy(pbPad, pbHex, cbHex);
	offset += cbHex;

	switch(nFlag)
	{
	case PADFLAG_8000	 :
		if (padSize) {
			pbPad[offset++] = 0x80;
			memset(&pbPad[offset], 0x00, padSize-1);
		}
	break;

	case PADFLAG_INVERSE :
		for(i = 0; i < padSize; i++)
			pbPad[offset++] = ~pbHex[i];
	break;

	case PADFLAG_ZERO	 :
		if (padSize)
			memset(&pbPad[offset], 0x00, padSize);
	break;
	}

	*pcbPad = cbHex + padSize;

	return TRUE;
}


void toInverse(BYTE* src, BYTE* dest, int size)
{
	for(int i = 0; i < size; i++)
	{
		dest[i] = src[i] ^ 0xFF;
	}
}


void FillBytes(LPBYTE source, int srclen, BYTE chr, LPBYTE dest, int destlen, int nFlag)
{
	assert( destlen >= srclen );
	LPBYTE pbBuffer = new BYTE[destlen];
	memset(pbBuffer, chr, destlen);

	int offset = (nFlag == 0) ? 0 : (destlen - srclen);
	memcpy(&pbBuffer[offset], source, srclen);
	memcpy(dest, pbBuffer, destlen);

	delete pbBuffer;
}

void SFXTRACE(LPCTSTR lpszFormat, ...)
{
#ifdef _DEBUG

	TCHAR	szMsg[1024];
	int		nResult;
	va_list	argList;

	ZeroMemory( szMsg, sizeof(szMsg) );
	
	va_start( argList, lpszFormat );
	nResult = vsprintf( szMsg, lpszFormat, argList );
	va_end( argList );

	::OutputDebugString( szMsg );

#endif
}

void GetJulianDate(BYTE* pbSrc)
{
	struct tm basetime;
	time_t now, base;
	long ltime;
	BYTE byJulDate[4];

	time( &now );

	basetime.tm_year = 95;
	basetime.tm_mon = 0;
	basetime.tm_mday = 1;
	basetime.tm_hour = 0;
	basetime.tm_min = 0;
	basetime.tm_sec =0;
	base = mktime( &basetime );

	ltime = now - base;

	long ltemp1, ltemp2;

	ltemp1 = ltime;
	ltemp2 = ltemp1 - (long)(256.0*(floor(ltemp1/256.0)));
	byJulDate[0] = (BYTE)ltemp2;

	ltemp1 = (long)((ltemp1 - ltemp2)/256.0);
	ltemp2 = ltemp1 - (long)(256.0*(floor(ltemp1/256.0)));
	byJulDate[1] = (BYTE)ltemp2;

	ltemp1 = (long)((ltemp1 - ltemp2)/256.0);
	ltemp2 = ltemp1 - (long)(256.0*(floor(ltemp1/256.0)));
	byJulDate[2] = (BYTE)ltemp2;

	ltemp1 = (long)((ltemp1 - ltemp2)/256.0);
	ltemp2 = ltemp1 - (long)(256.0*(floor(ltemp1/256.0)));
	byJulDate[3] = (BYTE)ltemp2;

	pbSrc[0] = byJulDate[3];
	pbSrc[1] = byJulDate[2];
	pbSrc[2] = byJulDate[1];
	pbSrc[3] = byJulDate[0];
}

void SetJulianDate(BYTE* pbSrc, TCHAR* pResult)
{
	BYTE byDate[4];
	struct tm vcbt = { 0, 0, 0, 1, 0, 95 };
	long value, temp;
	time_t vtime = mktime( &vcbt );

	byDate[0] = pbSrc[3];
	byDate[1] = pbSrc[2];
	byDate[2] = pbSrc[1];
	byDate[3] = pbSrc[0];
	value	  = 0;

	for (int i=0; i<4; i++){
		temp = (long)byDate[i];
		if (temp<0) temp += 256;

		value += (temp << (i*8));
	}

	temp = vtime+value;

	struct tm* t = gmtime(&temp);

	_stprintf(pResult, "%.4d%.2d%.2d", t->tm_year+1900, t->tm_mon+1, t->tm_mday);
}