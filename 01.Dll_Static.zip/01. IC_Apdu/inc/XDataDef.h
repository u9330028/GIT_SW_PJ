/* **************************************************************************
//
// Nautilus Hyosung Inc. 2005 All Rights Reserved
//
// ���ϸ� : XDataDef.h
// ��  �� : ������ ���� 
// ��  �� : 2005/04/19 �ű��ۼ�
//
// *************************************************************************/
#ifndef __XDATADEF_H__
#define __XDATADEF_H__

/////////////////////////////////////////////////////////////////////////////
// ����
#define	APDU_SIZE				256

#ifndef XSUCCESS
	#define	XSUCCESS		1		// ����
#endif
#ifndef XERROR
	#define XERROR			-1		// ����
#endif
#ifndef XERR_REGDATA
	#define XERR_REGDATA	-2		// �������͸� ������ �б�/����/���� ����
#endif
#ifndef XERR_NOTFOUND
	#define XERR_NOTFOUND	-3		// ī�忡 ���ø� ����
#endif
#ifndef XCREDIT
	#define XCREDIT			1		// ����
#endif
#ifndef XRESTORE
	#define XRESTORE		0		// ����
#endif
/////////////////////////////////////////////////////////////////////////////
// ���� ���� �ڵ�
#define	MSG_SUCCESS				"00"		// ����
#define	MSG_RES_MUST_CLEAR		"01"		// ���� �� TS bit Clear

/////////////////////////////////////////////////////////////////////////////
// Merchant
#define	MERCHANT_NAME			"HS_ATM"	// Merchant Name
#define MERCHANT_SIZE			6			// Merchant Size

/////////////////////////////////////////////////////////////////////////////
// Transaction Type
#define TRANS_CREDIT_TYPE		0x11		// ���� �ŷ� Ÿ��

/////////////////////////////////////////////////////////////////////////////
// APDU Command Flag
#define	APDU_SELECT_AID			0x01													
#define APDU_READ_BIN_1			0x02
#define	APDU_READ_BIN_2			0x03
#define APDU_GET_CSN			0x04
#define APDU_READ_BAL			0x05
#define APDU_CHK_TSBIT			0x06
#define APDU_ENC_DATA			0x07
#define APDU_INIT_CREDIT		0x08
#define APDU_COMPLETE_CRD		0x09

#define APDU_INIT_RESTORE		0x11
#define APDU_COMPLETE_RESTORE	0x12

#define APDU_INIT_TRANSIT		0x21
#define APDU_TRN_DEBIT			0x22

#define APDU_COMPLETE_TRN		0x30

/////////////////////////////////////////////////////////////////////////////
// APDU Command SIZE
#define	APDU_XC_SELECTAID_SIZE		14														// Select AID
#define APDU_XC_READBIN_SIZE		5														// Read Binary
#define APDU_XC_GETCSN_SIZE			5														// Get CSN
#define APDU_XC_READBAL_SIZE		10														// Read Balance
#define APDU_XC_CHKTSBIT_SIZE		5														// Check TS bit
#define APDU_XC_ENCDATA_SIZE		15														// Encrypt Data
#define APDU_XC_INITCRD_SIZE		30														// Init Credit
#define APDU_XC_COMCRD_SIZE			28														// Complete Credit
#define APDU_XC_INITREST_SIZE		5														// Init Restore
#define APDU_XC_COMREST_SIZE		27														// Complete Restore
#define APDU_XC_INITTRN_SIZE		5														// Init for Transit Transaction
#define APDU_XC_COMDEBIT_SIZE		37														// Transit Debit
#define APDU_XC_COMTRN_SIZE			5														// Complete Transaction

#define APDU_XT_READ_TKT_SIZE		15														// Read XTicket Info.
#define APDU_XT_INTERNAL_AUTH_SIZE	13														// Internal Auth
#define APDU_XT_ISSUE_SING_SIZE		124														// Single Ticket Issue			
#define APDU_XT_READ_TKT_SET_SIZE	21														// Read Ticket
#define APDU_XT_INTN_AUTH_SIZE		13														// Internal Auth
#define APDU_XT_SET_STATUS_SIZE		18														// Set Status

/////////////////////////////////////////////////////////////////////////////
// ��� ����
const char g_chDeLimiter			= '|';
// APDU Command 
const BYTE g_XC_bySel_AID[14]	= {0x00, 0xA4, 0x04, 0x00, 0x09, 0xA0, 0x00, 0x00, 0x00,	// Select AID
								   0x03, 0x60, 0x60, 0x41, 0x00};
const BYTE g_XC_byRead_BIN1[5]	= {0x00, 0xB0, 0x81, 0x00, 0x18};							// Read Binary 1
const BYTE g_XC_byRead_BIN2[5]	= {0x00, 0xB0, 0x84, 0x00, 0x04};							// Read Binary 2
const BYTE g_XC_byGet_CSN[5]	= {0x00, 0xC0, 0x02, 0xA1, 0x08};							// Get CSN
const BYTE g_XC_byRead_BAL[10]	= {0x80, 0x32, 0x00, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00,	// Read Balance
								   0x06};	
const BYTE g_XC_byChk_TSBIT[5]	= {0x80, 0x74, 0x00, 0x00, 0x00};							// Check TS bit
const BYTE g_XC_byEnc_DATA[5]	= {0x80, 0x7A, 0x00, 0x00, 0x0A};							// Encrypt Data
const BYTE g_XC_byInit_CRD[7]	= {0x80, 0x52, 0x04, 0x26, 0x19, 0x00, 0x03};				// Init Credit
const BYTE g_XC_byCom_CRD[6]	= {0x80, 0x36, 0x00, 0x00, 0x17, 0x00};						// Complete Credit

const BYTE g_XC_byIint_REST[5]	= {0x80, 0x58, 0x00, 0x00, 0x1C};							// Init Restore
const BYTE g_XC_byCom_REST[5]	= {0x80, 0x70, 0x00, 0x00, 0x16};							// Complete Restore

const BYTE g_XC_byInit_TRANS[5]	= {0x80, 0x02, 0x01, 0x01, 0x17};							// Init for Transit Transaction
const BYTE g_XC_byTrn_DEBIT[5]	= {0x80, 0x04, 0x00, 0x01, 0x1F};							// Transit Debit 

const BYTE g_XC_byCom_TRN[5]	= {0x80, 0x72, 0x00, 0x00, 0x00};							// Complete Transaction

////////////////X-Ticket/////////////////////
const BYTE g_XT_bySel_AID[15]	= {0x00, 0xA4, 0x04, 0x00, 0x0A, 0x4B, 0x54, 0x58, 0x2E,	// Select AID
								   0x4d, 0x45, 0x4d, 0x42, 0x45, 0x52};						
const BYTE g_XT_byRead_TKT[5]	= {0x90, 0x8C, 0x02, 0x00, 0x0A};							// Read Ticket
const BYTE g_XT_byIntn_AUTH[5]	= {0x90, 0x88, 0x00, 0x00, 0x08};							// Internal Auth
const BYTE g_XT_byIssue_TKT[4]	= {0x94, 0x86, 0x00, 0x00};									// Issue Ticket 
const BYTE g_XT_bySet_TKT[5]	= {0x94, 0x8E, 0x69, 0xFF, 0x0D};							// Set Ticket

/////////////////////////////////////////////////////////////////////////////
// ����ü ����
typedef struct _stMsg0200_In_t
{
	TCHAR	chCSN			[16];			// Card Serial Number
	TCHAR	chCAN			[16];			// Card Number
	TCHAR	chCTC			[ 6];			// Card Counter
	TCHAR	chRND_1			[16];			// ����1
	TCHAR	chRND_2			[16];			// ����2
	TCHAR	chCrypto		[ 8];			// ��ȣ��
	TCHAR	chEncPin		[16];			// ��ȣȭ�� Pin
	TCHAR	chCurBal		[12];			// �� ī���ܾ�
	TCHAR	chRs_TrnxType	[ 2];			// ����: 11
	TCHAR	chRs_Amount		[ 6];			// ����: Last C/R Log file
	TCHAR	chRs_Balance	[ 6];			// ����: Last C/R Log file
	TCHAR	chRs_DateTime	[ 8];			// ����: Julian Date
	TCHAR	chRs_CTC		[ 6];			// ����
	TCHAR	chRs_TID		[16];			// ����
}stMsg0200_In_t;

#ifdef _XTICKET_220
	typedef struct _stTicket_In_t
	{
		TCHAR	chTicketType	[ 4];			// Ticket Type
		TCHAR	chSignOffset	[ 2];			// Sign Offset
		TCHAR	chTID			[12];			// TID
		TCHAR	chRNO			[16];			// RND
		TCHAR	chMID			[10];			// MID
		TCHAR	chDeptCode		[ 4];			// Departure_Code
		TCHAR	chDeptTime		[12];			// Departure_Time
		TCHAR	chTrainType		[ 2];			// Train_Type
		TCHAR	chTrainNum		[ 6];			// Train_Number
		TCHAR	chArrCode		[ 4];			// Arrival_Code
		TCHAR	chArrTime		[ 4];			// Arrival_Time
		TCHAR	chSeatGradeNo	[ 6];			// Seat Grade & Seat No
		TCHAR	chTransType		[ 2];			// Transfer Type
		TCHAR	chTrnasNum		[ 6];			// Transfer Number
		TCHAR	chTransArrCode	[ 4];			// Transfer_Arr_Code
		TCHAR	chTransArrTime  [ 4];			// Transfer_Arr_time
		TCHAR	chTransfer		[ 4];			// Transfer
		TCHAR	chTransTime		[ 4];			// Transfer Time
		TCHAR	chTransGradeNo	[ 6];			// Transfer Seat Grade & Transfer Seat No
		TCHAR	chDiscount		[ 2];			// Discount
		TCHAR	chPrice			[ 8];			// Price
		TCHAR	chPayDate		[12];			// Pay Date
		TCHAR	chCrdCardNum	[16];			// Credit Card Number
		TCHAR	chArrivalNo		[ 8];			// Approval No
		TCHAR	chName			[10];			// Name
		TCHAR	chIDNo			[14];			// Id No.
		TCHAR	chPayType		[ 2];			// Pay Type
		TCHAR	chRFU1			[ 8];			// RFU1
		TCHAR	chSign			[ 8];			// SIGN
		TCHAR	chInTime		[ 4];			// In Time
		TCHAR	chOutTime		[ 4];			// Out Time
		TCHAR	chPrintCnt		[ 2];			// Print CNT
		TCHAR	chRFU2			[ 8];			// RFU2
		TCHAR	chTktStatus		[ 2];			// Ticket Status
	}stTicket_In_t;
#else
	typedef struct _stTicket_In_t
	{
		TCHAR	chTicketType	[ 4];			// Ticket Type
		TCHAR	chSignOffset	[ 2];			// Sign Offset
		TCHAR	chTID			[12];			// TID
		TCHAR	chRNO			[16];			// RND
		TCHAR	chMID			[10];			// MID
		TCHAR	chDeptCode		[ 4];			// Departure_Code
		TCHAR	chDeptTime		[12];			// Departure_Time
		TCHAR	chTrainType		[ 2];			// Train_Type
		TCHAR	chTrainNum		[ 6];			// Train_Number
		TCHAR	chArrCode		[ 4];			// Arrival_Code
		TCHAR	chArrTime		[ 4];			// Arrival_Time
		TCHAR	chSeatGradeNo	[ 6];			// Seat Grade & Seat No
		TCHAR	chTransType		[ 2];			// Transfer Type
		TCHAR	chTrnasNum		[ 6];			// Transfer Number
		TCHAR	chTransArrCode	[ 4];			// Transfer_Arr_Code
		TCHAR	chTransArrTime  [ 4];			// Transfer_Arr_time
		TCHAR	chTransfer		[ 4];			// Transfer
		TCHAR	chTransTime		[ 4];			// Transfer Time
		TCHAR	chTransGradeNo	[ 6];			// Transfer Seat Grade & Transfer Seat No
		TCHAR	chDiscount		[ 2];			// Discount
		TCHAR	chPrice			[ 8];			// Price
		TCHAR	chPayDate		[12];			// Pay Date
		TCHAR	chCrdCardNum	[16];			// Credit Card Number
		TCHAR	chArrivalNo		[ 8];			// Approval No
		TCHAR	chName			[20];			// Name
		TCHAR	chIDNo			[14];			// Id No.
		TCHAR	chPayType		[ 2];			// Pay Type
		TCHAR	chRFU1			[ 8];			// RFU1
		TCHAR	chSign			[ 8];			// SIGN
		TCHAR	chInTime		[ 4];			// In Time
		TCHAR	chOutTime		[ 4];			// Out Time
		TCHAR	chPrintCnt		[ 2];			// Print CNT
		TCHAR	chRFU2			[ 8];			// RFU2
		TCHAR	chTktStatus		[ 2];			// Ticket Status
	}stTicket_In_t;
#endif

#endif