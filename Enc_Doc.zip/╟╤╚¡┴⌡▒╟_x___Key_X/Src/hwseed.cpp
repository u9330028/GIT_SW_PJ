/*******************************************************************************
* 
* FILE:         hwseed.c
* VER :         09.06.24
* DESCRIPTION: Core routines for the enhanced hwseed
* 
*******************************************************************************/
#include <time.h>
#include <sys/timeb.h>
#include "seedx.h"
#include "has160.h"
#include "hwseed.h"

#ifdef LOG_MODE
	BYTE printTemp[1024];
#endif

/******************* Bin Hexa to String Hexa *******************/
int _UnPack(BYTE *sData, int sLen, BYTE *dData)
{
    int i, j = 0;
	BYTE temp;

    for(i = 0; i < sLen; i++)
    {                         
        /* high nibble convert */
		temp = (sData[i] >> 4) & 0x0f;
		if(temp >= 0x0a && temp <= 0x0f)	/* Alpha Code */
			dData[j++] = temp + 0x37;
		else								/* Numeric Code */
			dData[j++] = temp + 0x30;
		
		/* low nibble convert */
        temp = sData[i] & 0x0f;
		if(temp >= 0x0a && temp <= 0x0f)
			dData[j++] = temp + 0x37;
		else 
			dData[j++] = temp + 0x30;
    }
	return j;
}

/******************* String Hexa to Bin Hexa *******************/
int _Pack(BYTE *sData, int sLen, BYTE *dData)
{
	BYTE temp1, temp2;

	int i, j = 0;
	for(i = 0; i < sLen; i++)
	{
		/* source Convert */
		temp1 = sData[i];
		if(temp1 >= '0' && temp1 <= '9')
			temp2 = temp1 - 0x30;
		else if(temp1 >= 'a' && temp1 <= 'f')
			temp2 = temp1 - 0x57;
		else if(temp1 >= 'A' && temp1 <= 'F')
			temp2 = temp1 - 0x37;
		else 
			temp2 = 0x00;
		
		/* Make destData */
		if(i%2 == 0) /* Ȧ��Byte */
		{
			dData[j] = (temp2 << 4) & 0xf0;
		}
		else
		{
			dData[j] |= temp2 & 0x0f;
			j++;
		}
	}
	return j;
}

extern "C" _declspec(dllexport) int HW_CKeyInit (
	BYTE *s1Key, 	/* out: SessionKey1(�ܸ��Ⱑ HOST�� ������ ��) */
	int *s1Len, 	/* out: SessionKey1�� Length */
	BYTE *mk_table,	/* in : ������Ű Table Block */
	BYTE *wKey,		/* out: �ܸ����� ����� ����Ű ����(�ʱⰪ) */
	int *wLen)		/* out: ����Ű Length */
{
	int     i,j, kIdx, rtn=0;
	BYTE    pbUKey[47], pbData[47];
	DWORD   pdwRKey[32];

    time_t timer;
    struct tm *t;

	/* Make SessionKey Version */
    timer = time(NULL);
    t = localtime(&timer);
	j = sprintf((char *)s1Key, "%02d%02d%02d%02d%02d%02d",
		t->tm_sec,
		t->tm_min,
		t->tm_hour,
		t->tm_mday,
		t->tm_mon+1,
		t->tm_year-100);

#ifdef TEST_MODE
	memcpy(s1Key, "582415080609", j);
#endif

	memcpy(wKey,s1Key, j);

	/* Get S1 MasterKey Index */
	kIdx = rand()%10; 

#ifdef TEST_MODE
	kIdx = 8; 
#endif

	/* Get S1 MasterKey */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&mk_table[kIdx], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	/* Set S1 Key */
	memset(pbData, 0x00, sizeof(pbData));
	for(i=0; i<KEY_LEN; i++){ pbData[i] = rand()%0xff; }

#ifdef TEST_MODE
	pbData[0]	=0x6b;
	pbData[1]	=0xd6;
	pbData[2]	=0xeb;
	pbData[3]	=0x2c;
	pbData[4]	=0xa9;
	pbData[5]	=0x03;
	pbData[6]	=0x21;
	pbData[7]	=0xbb;
	pbData[8]	=0xef;
	pbData[9]	=0x5f;
	pbData[10]	=0x5f;
	pbData[11]	=0x4c;
	pbData[12]	=0xfc;
	pbData[13]	=0x10;
	pbData[14]	=0xec;
	pbData[15]	=0xbe;
#endif

	*wLen = KEY_VER_LEN;
	*wLen += _UnPack(pbData, KEY_LEN/2, &wKey[*wLen]);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey1 C0=%s",printTemp);
#endif

	/* Encrypt S1*/
	SeedEncrypt(pbData, pdwRKey);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey1 C1=%s",printTemp);
#endif

	/* S1 Key Block Make */
	j += _UnPack(pbData, KEY_LEN, &s1Key[j]);
	j += sprintf((char *)&s1Key[j], "%02d", kIdx);
	*s1Len = j;

	return rtn;
}

extern "C" _declspec(dllexport) int HW_SKeyFinal(
	BYTE *s2Key, 	/* in : SessionKey1, out:SessionKey2 (�ܸ����ۿ�) */
	int *s2Len, 	/* out: SessionKey2 Length */
	BYTE *mk_table,	/* in : ������Ű Table Block */
	BYTE *wKey,		/* out: Host���� ����� ����Ű ���� */
	int *wLen)		/* out: ����Ű Length */

{
	int     i,j, kIdx, rtn=0;
	BYTE    pbUKey[47], pbData[47];
	DWORD   pdwRKey[32];

	/* Set Session Key Version */
	memcpy(wKey, s2Key, KEY_VER_LEN);
	*wLen = KEY_VER_LEN;

	/* Get S1 MasterKey Index */
	kIdx = s2Key[SSKEY_BLOCK_LEN-1];
	if(kIdx < '0' && kIdx > '9')
	{
		rtn = ERR_CLI_KEY_INDEX; /* Session Key Block Error */
		return rtn;
	}
	kIdx -= 0x30;

	/* Get S1 MasterKey */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&mk_table[kIdx], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	/* Decrypt S1 */
	memset(pbData, 0x00, sizeof(pbData));
	i = _Pack(&s2Key[KEY_VER_LEN], KEY_LEN*2, pbData);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey1 S0=%s",printTemp);
#endif

	SeedDecrypt(pbData, pdwRKey);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey1 S0=%s",printTemp);
#endif

	/* W1 First Block Set */
	*wLen += _UnPack(pbData, KEY_LEN/2, &wKey[KEY_VER_LEN]);

	/* Get S2 MasterKey Index */
	kIdx = rand()%10; 

#ifdef TEST_MODE
	kIdx = 3;
#endif

	/* Get S2 MasterKey */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&mk_table[kIdx], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	/* Set S2 Key */
	memset(pbData, 0x00, sizeof(pbData));
	for(i=0; i<KEY_LEN; i++){ pbData[i] = rand()%0xff; }

#ifdef TEST_MODE
	pbData[0x0]	= 0xed;
	pbData[0x1]	= 0x51;
	pbData[0x2]	= 0x06;
	pbData[0x3]	= 0x45;
	pbData[0x4]	= 0x4d;
	pbData[0x5]	= 0x99;
	pbData[0x6]	= 0x25;
	pbData[0x7]	= 0x8e;
	pbData[0x8]	= 0x51;
	pbData[0x9]	= 0x65;
	pbData[0xa]	= 0x53;
	pbData[0xb]	= 0x05;
	pbData[0xc]	= 0x5c;
	pbData[0xd]	= 0x33;
	pbData[0xe]	= 0xec;
	pbData[0xf]	= 0x3f;
#endif

	/* W1 Last Block Set */
	*wLen += _UnPack(&pbData[8], KEY_LEN/2, &wKey[*wLen]);
	*wLen += sprintf((char *)&wKey[*wLen], "01");
	
#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey2 S0=%s",printTemp);
#endif

	/* Encrypt S2 */
	SeedEncrypt(pbData, pdwRKey);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey2 S1=%s",printTemp);
#endif

	/* make data */
	memcpy(s2Key, wKey, KEY_VER_LEN);
	j = KEY_VER_LEN;
	j += _UnPack(pbData, KEY_LEN, &s2Key[j]);
	j += sprintf((char *)&s2Key[j], "%02d", kIdx);
	*s2Len = j;

#ifdef LOG_MODE
	printf("\nSessionKey  S =%.46s",wKey);
#endif

	return rtn;
}

extern "C" _declspec(dllexport) int HW_CKeyFinal(
	BYTE *s2Key, 	/* in : SessionKey2 (HOST���� ���Ź��� ��)  */
	BYTE *mk_table,	/* in : ������Ű Table Block */
	BYTE *wKey,		/* out: �ܸ��⿡�� ����� ����Ű ���� */
	int *wLen)		/* out: ����Ű Length */
{
	int     i, kIdx, rtn=0;
	BYTE    pbUKey[47], pbData[47];
	DWORD   pdwRKey[32];

	/* Check S2 MasterKey Index */
	kIdx = s2Key[SSKEY_BLOCK_LEN-1];
	if(kIdx < '0' && kIdx > '9')
	{
		rtn = ERR_SVR_KEY_INDEX; /* Session Key Block Error */
		return rtn;
	}
	kIdx -= 0x30;

	/* session key version check */
	if(memcmp(&s2Key[0], wKey, KEY_VER_LEN) != 0)
	{
		rtn = ERR_SVR_KEY_VER; /* Recv Key version Error */
		return rtn;
	}

	/* Get S2 MasterKey */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&mk_table[kIdx], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	/* Decrypt S2 */
	memset(pbData, 0x00, sizeof(pbData));
	i = _Pack(&s2Key[KEY_VER_LEN], KEY_LEN*2, pbData);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey2 C1=%s",printTemp);
#endif

	SeedDecrypt(pbData, pdwRKey);

#ifdef LOG_MODE
	_UnPack(pbData, KEY_LEN, printTemp); printTemp[32] = 0;
	printf("\nSessionKey2 C0=%s",printTemp);
#endif

	/* W1 Last Block Set */
	*wLen = KEY_VER_LEN + KEY_LEN;
	*wLen += _UnPack(&pbData[8], KEY_LEN/2, &wKey[*wLen]);
	*wLen += sprintf((char *)&wKey[*wLen], "01");

#ifdef LOG_MODE
	printf("\nSessionKey  C =%.46s",wKey);
#endif

	return rtn;
}

extern "C" _declspec(dllexport) int HW_GetHashCode(
	BYTE *datetime,	/* in : ���������Ͻ�(bitmap-7) */
	long amnt,		/* in : �ŷ��ݾ�(��ȸ��=0) */
	BYTE *dData)	/* out: Hash��(20 Byte) */
{
	int rtn = 0, tLen;
	BYTE			tData[30];
	HAS160_ALG_INFO	AlgInfo;

	tLen = sprintf((char *)tData, "%.10s%012ld", datetime, amnt);
	HAS160_Init(&AlgInfo);
	HAS160_Update(&AlgInfo, tData, tLen);
	HAS160_Final(&AlgInfo, dData);

#ifdef LOG_MODE
	_UnPack(dData, 20, printTemp); printTemp[20*2] = 0;
	printf("\n\nHashCode =%s",printTemp);
#endif

	return rtn;
}

extern "C" _declspec(dllexport) int HW_EncSeed(
	BYTE *wKey,		/* in : ����Ű ���� */
	BYTE *sData,	/* in : ��ȣȭ ��� ���� */
	int sLen,		/* in : ��ȣȭ ������� Length */
	BYTE *dData,	/* out: ��ȣȭ�� ���� */
	int *dLen)		/* out: ��ȣȭ�� ���� Length */
{
	int     i=0,j=0, rtn=0, mok;
	BYTE    pbUKey[20], pbData[20];
	DWORD   pdwRKey[32];

#ifdef LOG_MODE
	_UnPack(sData, sLen, printTemp); printTemp[sLen*2] = 0;
	printf("\n\nDataSeed C0 =%s",printTemp);
#endif
	
	/**** ��ȣȭ ó�� �� �������� Make ************************/
	i = 0;
	/* Total Length Set  */
	memcpy(&dData[i], "140", 3); i += 3;	

	/* Ű���� Set */
	memcpy(&dData[i], wKey, KEY_VER_LEN); 
	i += KEY_VER_LEN;

	/* ��ȣȭ ó�� */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&wKey[KEY_VER_LEN], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	mok    = sLen / 16;
	for(j = 0; j < mok; j++)  
	{
		memset(pbData, 0x00, sizeof(pbData));
		memcpy(pbData, &sData[16*j], 16);
		SeedEncrypt(pbData, pdwRKey);
		i += _UnPack(pbData, 16, &dData[i]);
	}

	/* Filler Set  */
	if(i<143)
		memset(&dData[i], 0x20, (143-i)); i += (143-i);	

	dData[i] = 0x00;
	*dLen = i;

#ifdef LOG_MODE
	memcpy(printTemp,dData, i); printTemp[i] = 0;
	printf("\nDataSeed C1 =%s",printTemp);
#endif

	return rtn;
}

extern "C" _declspec(dllexport) int HW_DecSeed(
	BYTE *wKey,		/* in : ����Ű ���� */
	BYTE *sData,	/* in : ��ȣȭ ��� ���� */
	int sLen,		/* in : ��ȣȭ ������� Length */
	BYTE *pwd,		/* out: ��ȣȭ�� ��й�ȣ */
	BYTE *acnt,		/* out: ��ȣȭ�� ī���ȣ */
	BYTE *hData)	/* out: ��ȣȭ�� Hash�� */
{
	int     i, j, rtn=0, mok, tLen;

	BYTE	tData[ENC_BLOCK_LEN*2 + 1];
	BYTE    pbUKey[20], pbData[20];
	DWORD   pdwRKey[32];

#ifdef LOG_MODE
	memcpy(printTemp, sData, sLen); printTemp[sLen] = 0;
	printf("\nDataSeed S1 =%s",printTemp);
#endif

	/**** �������� Error check *******************************/
	if(memcmp(&sData[0], "140", 3) || sLen < 143) {
		rtn = ERR_CLI_BLOCK_LEN;
		return(rtn);
	}
	if(memcmp(&sData[3], wKey, KEY_VER_LEN)) {
		rtn = ERR_CLI_KEY_VER;
		/* DB�� ������ Session Key & Version�� Clear �ʿ� */
		/* Client���� Ű��ȯ ��û(�����ڵ�) ������ �� */
		return(rtn);
	}

	/**** ��ȣȭ���� ��ȣȭ **********************************/
	/* ����Data Pack */
	i = ENC_BLOCK_LEN*2;
	tLen = _Pack(&sData[15], i, tData);

	/* ��ȣȭ ó�� */
	memset(pbUKey, 0x00, sizeof(pbUKey));
	_Pack(&wKey[KEY_VER_LEN], KEY_LEN*2, pbUKey);
	SeedEncRoundKey(pdwRKey, pbUKey); 

	mok    = tLen / 16;
	for(j = 0; j < mok; j++)  
	{
		memset(pbData, 0x00, sizeof(pbData));
		memcpy(pbData, &tData[16*j], 16);
		SeedDecrypt(pbData, pdwRKey);
		memcpy(&tData[16*j], pbData, 16);
	}

#ifdef LOG_MODE
	_UnPack(tData, tLen, printTemp); printTemp[tLen*2] = 0;
	printf("\nDataSeed S0 =%s",printTemp);
#endif



	/**** Data���� Block Check *****************************/
	if(tData[0] != 0x31) {
		rtn = ERR_CLI_ENC_DATA_KIND;
		return(rtn);
	}
	memcpy(hData, &tData[1], 20);
	memcpy(pwd, &tData[21], 4);
	memcpy(acnt, &tData[27], 37);

	return rtn;
}

