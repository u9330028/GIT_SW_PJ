/*******************************************************************************
*
* FILE:         has160.h
* VER :         09.06.10
* DESCRIPTION:  header file for has160.c
*
*******************************************************************************/

#ifndef _HAS160_H
#define _HAS160_H


/********************** Include files *****************************/

#include <stdlib.h>
#include <string.h>


/******************** Endian Definitions **************************/

/* #define BIG_ENDIAN */		/* Motorora,ibm370,Sparc,risc based */
#define LITTLE_ENDIAN	/* Intel,Dec,Alpha */


/********************* Type Definitions **********************/

typedef unsigned __int32	DWORD;	/* 32 bit Type */
typedef unsigned __int16	WORD;	/* 16 bit Type */
typedef unsigned char		BYTE;	/*  8 bit Type */

/******************* Constant Definitions *************************/

#define HAS160_DIGEST_BLOCKLEN	64
#define HAS160_DIGEST_VALUELEN	20

	
/********************** Common Macros *****************************/

#if defined(_MSC_VER)
	#define ROTL_DWORD(x, n) _lrotl((x), (n))
	#define ROTR_DWORD(x, n) _lrotr((x), (n))
#else
	#define ROTL_DWORD(x, n) ( (DWORD)((x) << (n)) | (DWORD)((x) >> (32-(n))) )
	#define ROTR_DWORD(x, n) ( (DWORD)((x) >> (n)) | (DWORD)((x) << (32-(n))) )
#endif

/*	reverse the byte order of DWORD(DWORD:4-bytes integer) and WORD. */
#define ENDIAN_REVERSE_DWORD(dwS)	( (ROTL_DWORD((dwS),  8) & 0x00ff00ff)	\
									 | (ROTL_DWORD((dwS), 24) & 0xff00ff00) )

/*	move DWORD type to BYTE type and BYTE type to DWORD type */
#if defined(BIG_ENDIAN)		/*	Big-Endian machine */
	#define BIG_B2D(B, D)		D = *(DWORD *)(B)
	#define BIG_D2B(D, B)		*(DWORD *)(B) = (DWORD)(D)
	#define LITTLE_B2D(B, D)	D = ENDIAN_REVERSE_DWORD(*(DWORD *)(B))
	#define LITTLE_D2B(D, B)	*(DWORD *)(B) = ENDIAN_REVERSE_DWORD(D)
#elif defined(LITTLE_ENDIAN)	/*	Little-Endian machine */
	#define BIG_B2D(B, D)		D = ENDIAN_REVERSE_DWORD(*(DWORD *)(B))
	#define BIG_D2B(D, B)		*(DWORD *)(B) = ENDIAN_REVERSE_DWORD(D)
	#define LITTLE_B2D(B, D)	D = *(DWORD *)(B)
	#define LITTLE_D2B(D, B)	*(DWORD *)(B) = (DWORD)(D)
#else
	#error ERROR : Invalid DataChangeType
#endif



/*	HAS160.. */
typedef struct{
	DWORD		ChainVar[HAS160_DIGEST_VALUELEN/4];	/*	Chaining Variable ���� */
	DWORD		Count[4];							
	BYTE		Buffer[HAS160_DIGEST_BLOCKLEN];		/*	Buffer for unfilled block */
} HAS160_ALG_INFO;


/**************** Function Prototype Declarations *****************/

void	HAS160_Init(HAS160_ALG_INFO	*AlgInfo);
void	HAS160_Update(HAS160_ALG_INFO *AlgInfo, BYTE *Message, DWORD MessageLen);
void	HAS160_Final(HAS160_ALG_INFO *AlgInfo, BYTE *Digest);


/******************************************************************/
#endif
