#include <sqlhdr.h>
#include <sqliapi.h>
#line 1 "atominit.ec"
/*============================================================================*/
/* Program Name: atominit.ec                                                  */
/* Execute File: atominit                                                     */
/* Function    : load(unload) MoniManager processes                           */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2010.02.25    SHLEE            First Ver                    */
/*============================================================================*/
/* 
 * EXEC SQL INCLUDE "maincom.h";
 */
#line 12 "atominit.ec"

#line 12 "atominit.ec"
#line 1 "/data/atmadm/fsprepare/inc/maincom.h"
/*============================================================================*/
/* Program Name: maincom.h                                                    */
/* Execute File:                                                              */
/* Function    : ATOM Process Header file                                     */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.02.01    SHLEE            First Ver                    */
/*----------------------------------------------------------------------------*/
#ifndef	 _ATMSCOM_H
#define	 _ATMSCOM_H

/*-----------------------------------------------------------------------*/
/* Declare include file                                                  */
/*-----------------------------------------------------------------------*/
#include "defcom.h"
#include "string.h"
#include "shm.h"
#include "msg.h"

/*-----------------------------------------------------------------------*/
/* Define Common Variable                                                */
/*-----------------------------------------------------------------------*/
#define RUNCHECK_WAIT_TIME	5
#define MIN_QSIZE           65535

/*-----------------------------------------------------------------------*/
/* ATOM PROCESS CONTROL SHARED MEMORY STRUCTURE                          */
/*-----------------------------------------------------------------------*/
typedef struct
{
#if (!defined(WIN32) && !defined(_WIN32))
    char    pidname [10];           /* process name               */
#else
    char    pidname [10 + 4];       /* process name               */
#endif
    char    pstat   [ 1];           /* "R"(running) / "D"(down)   */
    char    startdt [14];           /* process start date         */
    char    downdt  [14];           /* process down date          */
    char    desc    [20];           /* process description        */
    char    reserved[20];           /* reserved area              */
} s_daemoninfo;

/*-----------------------------------------------------------------------*/
/* Declare Database Variable                                             */
/*-----------------------------------------------------------------------*/
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 49 "/data/atmadm/fsprepare/inc/maincom.h"
#line 50 "/data/atmadm/fsprepare/inc/maincom.h"
  char g_SERVERGB[2];
  char g_PROCNAME[9];
  char g_DBSID[21];
  char g_USERID[11];
  char g_PASSWD[11];
int g_DBCONNECTGB;
int g_CONNECTCNT;
/*
 * EXEC SQL END   DECLARE SECTION;
 */
#line 57 "/data/atmadm/fsprepare/inc/maincom.h"


FILE *logfp;
s_daemoninfo  pDmonInfo;

/*-----------------------------------------------------------------------*/
/* Declare Function Prototype                                            */
/*-----------------------------------------------------------------------*/
extern void sig_init    ();
extern void proc_end    ();
extern void clean_zombie();

#endif  /* _ATMSCOM_H */
#line 69 "/data/atmadm/fsprepare/inc/maincom.h"
/* 
 * EXEC SQL INCLUDE "dbdef.h";
 */
#line 13 "atominit.ec"

#line 13 "atominit.ec"
#line 1 "/data/atmadm/fsprepare/inc/dbdef.h"
/*============================================================================*/
/* Program Name: dbdef.h                                                      */
/* Execute File:                                                              */
/* Function    : DataBase Interface Include File                              */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.07.21    SHLEE            First Ver                    */
/*============================================================================*/
#ifndef	 _DBDEF_H
#define	 _DBDEF_H

/* 
 * EXEC SQL INCLUDE SQLCA;
 */
#line 15 "/data/atmadm/fsprepare/inc/dbdef.h"

#line 15 "/data/atmadm/fsprepare/inc/dbdef.h"
#line 1 "/informix/incl/dmi/sqlca.h"
/****************************************************************************
 *
 * Licensed Material - Property Of IBM
 *
 * "Restricted Materials of IBM"
 *
 * IBM Informix Client SDK
 * Copyright IBM Corporation 1997, 2008. All rights reserved.
 *
 *  Title:       sqlca.h
 *  Description: SQL Control Area
 *
 ***************************************************************************
 */

#ifndef SQLCA_INCL
#define SQLCA_INCL

#include "ifxtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sqlca_s
    {
    int4 sqlcode;
#ifdef DB2CLI
    char sqlerrm[600]; /* error message parameters */
#else /* DB2CLI */
    char sqlerrm[72]; /* error message parameters */
#endif /* DB2CLI */
    char sqlerrp[8];
    int4 sqlerrd[6];
		    /* 0 - estimated number of rows returned */
		    /* 1 - serial value after insert or  ISAM error code */
		    /* 2 - number of rows processed */
		    /* 3 - estimated cost */
		    /* 4 - offset of the error into the SQL statement */
		    /* 5 - rowid after insert  */
#ifdef _FGL_
    char sqlawarn[8];
#else
    struct sqlcaw_s
	{
	char sqlwarn0; /* = W if any of sqlwarn[1-7] = W */
	char sqlwarn1; /* = W if any truncation occurred or
				database has transactions or
			        no privileges revoked */
	char sqlwarn2; /* = W if a null value returned or
				ANSI database */
	char sqlwarn3; /* = W if no. in select list != no. in into list or
				turbo backend or no privileges granted */
	char sqlwarn4; /* = W if no where clause on prepared update, delete or
				incompatible float format */
	char sqlwarn5; /* = W if non-ANSI statement */
	char sqlwarn6; /* = W if server is in data replication secondary mode */
	char sqlwarn7; /* = W if database locale is different from proc_locale
                          = W if backend XPS and if explain avoid_execute is set
                              (for select, insert, delete and update only)
			*/
	} sqlwarn;
#endif
    } ifx_sqlca_t;

/* NOTE: 4gl assumes that the sqlwarn structure can be defined as
 *	sqlawarn -- an 8 character string, because single-char
 *	variables are not recognized in 4gl.
 *
 * If this structure should change, the code generated by 4gl compiler
 *	must also change
 */

#define SQLNOTFOUND 100

#ifndef IFX_THREAD
#ifdef DB2CLI
#define sqlca ifmxsqlca
extern struct sqlca_s sqlca;
#else /* DB2CLI */
extern struct sqlca_s sqlca;
#endif /* DB2CLI */

#ifndef DRDAHELP
extern int4 SQLCODE;
#endif

extern char SQLSTATE[];
#else /* IFX_THREAD */
extern int4 * ifx_sqlcode(void);
extern struct sqlca_s * ifx_sqlca(void);
/* ifx_sqlstate() declared in sqlhdr.h */
#define SQLCODE (*(ifx_sqlcode()))
#define SQLSTATE ((char *)(ifx_sqlstate()))
#define sqlca (*(ifx_sqlca()))
#endif /* IFX_THREAD */

#ifdef __cplusplus
}
#endif

#endif /* SQLCA_INCL */

#line 103 "/informix/incl/dmi/sqlca.h"
#line 16 "/data/atmadm/fsprepare/inc/dbdef.h"

/*----------------------------------------------------------------------------*/
/* SQL DEFINE                                                                 */
/*----------------------------------------------------------------------------*/
#ifdef ORACLE
/* definition for oracle */
#ifndef     SQLCODE
#define     SQLCODE             sqlca.sqlcode
#endif
#ifndef     SQLCOUNT
#define     SQLCOUNT            sqlca.sqlerrd[2]
#endif
#ifndef     SQLMSG
#define     SQLMSG              sqlca.sqlerrm.sqlerrmc
#endif
#ifndef     SQLNOTFOUND
#define     SQLNOTFOUND         1403
#endif
#ifndef     SQLDUPLICATE
#define     SQLDUPLICATE        -1
#endif
#ifndef     SQLOK
#define     SQLOK               0
#endif
#ifndef     SQLNOTCONNECT
#define     SQLNOTCONNECT       -3114
#endif
#ifndef     SQLNOWAIT
#define     SQLNOWAIT           54
#endif
#ifndef     SQL_NOTFOUND
#define     SQL_NOTFOUND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_FETCHEND
#define     SQL_FETCHEND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT != 0))
#endif
#ifndef     SQL_UPNOTFOUND
#define     SQL_UPNOTFOUND      ((SQLCODE == SQLOK) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_DUPLICATE
#define     SQL_DUPLICATE       (SQLCODE == SQLDUPLICATE)
#endif
#ifndef     SQL_NOTCONNECT
#define     SQL_NOTCONNECT      (SQLCODE == SQLNOTCONNECT)
#endif
#ifndef     SQL_ERROR
#define     SQL_ERROR           (SQLCODE != SQLOK)
#endif
#ifndef     SQL_NOWAIT
#define     SQL_NOWAIT          (SQLCODE == SQLNOWAIT)
#endif

#else

/* definition for informix */
#ifndef     SQLCODE
#define     SQLCODE             sqlca.sqlcode
#endif
#ifndef     SQLCOUNT
#define     SQLCOUNT            sqlca.sqlerrd[2]
#endif
#ifndef     SQLMSG
/* ������� 2009.12.15 HDOH
#define     SQLMSG              sqlca.sqlerrm
#define     SQLMSG              SQLSTATE
*/
#define     SQLMSG              f_get_errMsg(SQLCODE)
#endif
#ifndef     SQLNOTFOUND
#define     SQLNOTFOUND         100
#endif
#ifndef     SQLDUPLICATE100
#define     SQLDUPLICATE100     -100
#endif
#ifndef     SQLDUPLICATE239
#define     SQLDUPLICATE239     -239
#endif
#ifndef     SQLDUPLICATE268
#define     SQLDUPLICATE268     -268
#endif
#ifndef     SQLDUPLICATE371
#define     SQLDUPLICATE371     -371
#endif
#ifndef     SQLOK
#define     SQLOK               0
#endif
#ifndef     SQLNOTCONNECT
#define     SQLNOTCONNECT       -3114
#endif
#ifndef     SQLNOWAIT
#define     SQLNOWAIT           54
#endif
#ifndef     SQLLOCK243
#define     SQLLOCK243          -243
#endif
#ifndef     SQLLOCK244
#define     SQLLOCK244          -244
#endif
#ifndef     SQL_NOTFOUND
#define     SQL_NOTFOUND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_FETCHEND
#define     SQL_FETCHEND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT != 0))
#endif
#ifndef     SQL_UPNOTFOUND
#define     SQL_UPNOTFOUND      ((SQLCODE == SQLOK) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_DUPLICATE
#define     SQL_DUPLICATE       ((SQLCODE == SQLDUPLICATE100) || (SQLCODE == SQLDUPLICATE239) || (SQLCODE == SQLDUPLICATE268) || (SQLCODE == SQLDUPLICATE371))
#endif
#ifndef     SQL_NOTCONNECT
#define     SQL_NOTCONNECT      (SQLCODE == SQLNOTCONNECT)
#endif
#ifndef     SQL_ERROR
#define     SQL_ERROR           (SQLCODE != SQLOK)
#endif
#ifndef     SQL_NOWAIT
#define     SQL_NOWAIT          (SQLCODE == SQLNOWAIT)
#endif
#ifndef     SQL_LOCK
#define     SQL_LOCK            ((SQLCODE == SQLLOCK243) || (SQLCODE == SQLLOCK244))
#endif
#endif
/*----------------------------------------------------------------------------*/
/* vairable DEFINE                                                            */
/*----------------------------------------------------------------------------*/
#ifndef     NORMAL
#define     NORMAL              1
#endif
#ifndef     ABNORMAL
#define     ABNORMAL           -1
#endif

#ifndef     NOTFOUND
#define     NOTFOUND            2
#endif

#ifndef     NOWAIT
#define     NOWAIT              3
#endif

/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 157 "/data/atmadm/fsprepare/inc/dbdef.h"
#line 158 "/data/atmadm/fsprepare/inc/dbdef.h"
#ifdef INFORMIX
typedef struct _sql_context
  {
      char conn_name[11];
  }  sql_context;
#endif
typedef struct ParamArgs
  {
    sql_context ctx;
      char connName[11];
      char dbName[10];
    int conngb;
    int pid;
    int thid;
  }  t_params;
/*
 * EXEC SQL END  DECLARE SECTION;
 */
#line 174 "/data/atmadm/fsprepare/inc/dbdef.h"


t_params *g_Msg_Pool;
t_params *g_Img_Pool;
t_params *g_Main_Pool;

int DBConnect        ();
int DBCommit         ();
int DBRollback       ();
int DBDisconnect     ();
int DBBeginWork      ();
int DBLockSet        ();
int DBLockClear      ();
int downSvrProcess   ();
int updateSvrProcess ();
int getErrMsg        ();
int jnlDBCommit      ();
int jnlDBRollback    ();
int jnlDBBeginWork   ();
int createContext    ();
int assignContext    ();
int freeContext      ();
int f_getserialno    ();
int f_getnodename    ();
int f_getprotocoltype();
int f_getprovidercode();
char *f_get_errMsg   ();
int f_dormantConnection();
int f_getServerProcess();
int f_assignConnection();
int f_updateSvrProcess();

#endif		/*  _DBDEF_H  */

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
#line 210 "/data/atmadm/fsprepare/inc/dbdef.h"
/* 
 * EXEC SQL INCLUDE "var_svr_process.h";    ** server process table   **
 */
#line 14 "atominit.ec"

#line 14 "atominit.ec"
#line 1 "/data/atmadm/fsprepare/inc/var_svr_process.h"
/*----------------------------------------------------------------------------*/
/*  Server Process Structure                                                  */
/*----------------------------------------------------------------------------*/
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 4 "/data/atmadm/fsprepare/inc/var_svr_process.h"
#line 5 "/data/atmadm/fsprepare/inc/var_svr_process.h"
typedef struct tagV_SVR_PROCESS
  {
      char server_type[2];
      char proc_type[2];
      char proc_name[9];
      char proc_seq[3];
      char run_target[2];
      char run_flag[2];
      char proc_id[11];
    int max_proc_cnt;
    int run_proc_cnt;
    int msg_db_cnt;
    int img_db_cnt;
      char send_queue_key[11];
      char send_queue_id[11];
    int send_queue_size;
      char recv_queue_key[11];
      char recv_queue_id[11];
    int recv_queue_size;
    int queue_type;
      char con_server_ip[16];
    int server_port;
    int client_port;
      char sub_proc_name[9];
    int delay_time;
      char proc_start_date[9];
      char proc_start_time[7];
      char proc_down_date[9];
      char proc_down_time[7];
      char shm_flag[2];
      char shm_key[11];
    int shm_size;
      char auto_run_flag[2];
  }  T_SVR_PROCESS;
T_SVR_PROCESS V_SVR_PROCESS;
/*
 * EXEC SQL END   DECLARE SECTION;
 */
#line 42 "/data/atmadm/fsprepare/inc/var_svr_process.h"

#line 42 "/data/atmadm/fsprepare/inc/var_svr_process.h"
/* 
 * EXEC SQL INCLUDE "var_net_process.h";    ** protocal process table **
 */
#line 15 "atominit.ec"

#line 15 "atominit.ec"
#line 1 "/data/atmadm/fsprepare/inc/var_net_process.h"
/*----------------------------------------------------------------------------*/
/*  protocal process structure                                                */
/*----------------------------------------------------------------------------*/
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 4 "/data/atmadm/fsprepare/inc/var_net_process.h"
#line 5 "/data/atmadm/fsprepare/inc/var_net_process.h"
typedef struct tagV_NET_PROCESS
  {
      char server_type[2];
      char provider_type[2];
      char provider_cd[3];
      char proc_type[2];
      char protocal_type[2];
      char proc_name[9];
      char run_target[2];
      char run_flag[2];
      char proc_id[11];
      char net_conn_flag[2];
      char connection_type[2];
      char net_status[2];
      char con_server_ip[16];
    int server_port;
    int client_port;
    int delay_time;
      char proc_start_date[9];
      char proc_start_time[7];
      char proc_down_date[9];
      char proc_down_time[7];
      char auto_run_flag[2];
  }  T_NET_PROCESS;
T_NET_PROCESS V_NET_PROCESS;
/*
 * EXEC SQL END   DECLARE SECTION;
 */
#line 31 "/data/atmadm/fsprepare/inc/var_net_process.h"

#line 31 "/data/atmadm/fsprepare/inc/var_net_process.h"
#line 16 "atominit.ec"

#define  LOAD_PROCESS     'R'
#define  UNLOAD_PROCESS   'D'

/*----------------------------------------------------------------------------*/
/* FUNCTION : setSvrProcess                                                   */
/* SYNTAX   : int setSvrProcess(char *tranKind)                               */
/* ARGUMENT : tranKind : 0-down, 1-running                                    */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : update a process status of T_ServerProcess                      */
/*----------------------------------------------------------------------------*/
int setSvrProcess(char *tranKind)
{
    int  pid = 0;

    if (tranKind[0] == '1')  /* running */
    {
        V_SVR_PROCESS.run_target   [0] = '1';
        V_SVR_PROCESS.auto_run_flag[0] = '0';
        V_SVR_PROCESS.run_flag     [0] = '0';
        pid = getpid();
    }
    else  /* down */
    {
        V_SVR_PROCESS.run_target   [0] = '0';
        V_SVR_PROCESS.auto_run_flag[0] = '1';
    }
    sprintf(V_SVR_PROCESS.proc_id, "%d", pid);

/*
 *     EXEC SQL UPDATE T_ServerProcess
 *                 SET RUN_TARGET    = :V_SVR_PROCESS.run_target,
 *                     RUN_FLAG      = :V_SVR_PROCESS.run_flag
 *               WHERE SERVER_TYPE   = :V_SVR_PROCESS.server_type
 *                 AND PROC_TYPE     = :V_SVR_PROCESS.proc_type
 *                 AND PROC_NAME     = :V_SVR_PROCESS.proc_name
 *                 AND PROC_SEQ      = :V_SVR_PROCESS.proc_seq;
 */
#line 45 "atominit.ec"
  {
#line 51 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 51 "atominit.ec"
    {
#line 51 "atominit.ec"
    "UPDATE T_ServerProcess SET RUN_TARGET = ? , RUN_FLAG = ? WHERE SERVER_TYPE = ? AND PROC_TYPE = ? AND PROC_NAME = ? AND PROC_SEQ = ?",
    0
    };
#line 51 "atominit.ec"
  static ifx_statement_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 51 "atominit.ec"
    };
#line 51 "atominit.ec"
#line 51 "atominit.ec"
  _sqibind[0].sqldata = V_SVR_PROCESS.run_target;
#line 51 "atominit.ec"
  _sqibind[1].sqldata = V_SVR_PROCESS.run_flag;
#line 51 "atominit.ec"
  _sqibind[2].sqldata = V_SVR_PROCESS.server_type;
#line 51 "atominit.ec"
  _sqibind[3].sqldata = V_SVR_PROCESS.proc_type;
#line 51 "atominit.ec"
  _sqibind[4].sqldata = V_SVR_PROCESS.proc_name;
#line 51 "atominit.ec"
  _sqibind[5].sqldata = V_SVR_PROCESS.proc_seq;
  sqli_stmt(ESQLINTVERSION, &_SQ0, sqlcmdtxt, 6, _sqibind, (struct value *)0, (ifx_literal_t *)0, (ifx_namelist_t *)0, (ifx_cursor_t *)0, 4, 0, 0);
#line 51 "atominit.ec"
  }

    if (SQL_ERROR)
    {
        logging(logfp, ERROR, "T_ServerProcess UPDATE ERROR: [%d:%s]",
                       SQLCODE, SQLMSG);
        DBRollback();
        return ABNORMAL;
    }
    DBCommit();

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : loadSvrProcess                                                  */
/* SYNTAX   : int loadSvrProcess()                                            */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : run the server process of T_ServerProcess                       */
/*----------------------------------------------------------------------------*/
int loadSvrProcess()
{
    int totalCount = 0;

    while(1)
    {
        memset(&V_SVR_PROCESS, 0x00, sizeof(V_SVR_PROCESS));
/*
 *         EXEC SQL SELECT first 1 *
 *                    INTO :V_SVR_PROCESS
 *                    FROM T_ServerProcess
 *                   WHERE SERVER_TYPE   = :g_SERVERGB
 *                     AND RUN_TARGET    = '0'
 *                     AND AUTO_RUN_FLAG = '1';
 */
#line 79 "atominit.ec"
  {
#line 84 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 84 "atominit.ec"
    {
#line 84 "atominit.ec"
    "SELECT first 1 * FROM T_ServerProcess WHERE SERVER_TYPE = ? AND RUN_TARGET = '0' AND AUTO_RUN_FLAG = '1'",
    0
    };
#line 84 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 84 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).max_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).run_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).msg_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).img_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).send_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).recv_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).queue_type), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).shm_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 84 "atominit.ec"
    };
#line 84 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 84 "atominit.ec"
  _sqobind[0].sqldata = (V_SVR_PROCESS).server_type;
#line 84 "atominit.ec"
  _sqobind[1].sqldata = (V_SVR_PROCESS).proc_type;
#line 84 "atominit.ec"
  _sqobind[2].sqldata = (V_SVR_PROCESS).proc_name;
#line 84 "atominit.ec"
  _sqobind[3].sqldata = (V_SVR_PROCESS).proc_seq;
#line 84 "atominit.ec"
  _sqobind[4].sqldata = (V_SVR_PROCESS).run_target;
#line 84 "atominit.ec"
  _sqobind[5].sqldata = (V_SVR_PROCESS).run_flag;
#line 84 "atominit.ec"
  _sqobind[6].sqldata = (V_SVR_PROCESS).proc_id;
#line 84 "atominit.ec"
  _sqobind[7].sqldata = (char *) &(V_SVR_PROCESS).max_proc_cnt;
#line 84 "atominit.ec"
  _sqobind[8].sqldata = (char *) &(V_SVR_PROCESS).run_proc_cnt;
#line 84 "atominit.ec"
  _sqobind[9].sqldata = (char *) &(V_SVR_PROCESS).msg_db_cnt;
#line 84 "atominit.ec"
  _sqobind[10].sqldata = (char *) &(V_SVR_PROCESS).img_db_cnt;
#line 84 "atominit.ec"
  _sqobind[11].sqldata = (V_SVR_PROCESS).send_queue_key;
#line 84 "atominit.ec"
  _sqobind[12].sqldata = (V_SVR_PROCESS).send_queue_id;
#line 84 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_SVR_PROCESS).send_queue_size;
#line 84 "atominit.ec"
  _sqobind[14].sqldata = (V_SVR_PROCESS).recv_queue_key;
#line 84 "atominit.ec"
  _sqobind[15].sqldata = (V_SVR_PROCESS).recv_queue_id;
#line 84 "atominit.ec"
  _sqobind[16].sqldata = (char *) &(V_SVR_PROCESS).recv_queue_size;
#line 84 "atominit.ec"
  _sqobind[17].sqldata = (char *) &(V_SVR_PROCESS).queue_type;
#line 84 "atominit.ec"
  _sqobind[18].sqldata = (V_SVR_PROCESS).con_server_ip;
#line 84 "atominit.ec"
  _sqobind[19].sqldata = (char *) &(V_SVR_PROCESS).server_port;
#line 84 "atominit.ec"
  _sqobind[20].sqldata = (char *) &(V_SVR_PROCESS).client_port;
#line 84 "atominit.ec"
  _sqobind[21].sqldata = (V_SVR_PROCESS).sub_proc_name;
#line 84 "atominit.ec"
  _sqobind[22].sqldata = (char *) &(V_SVR_PROCESS).delay_time;
#line 84 "atominit.ec"
  _sqobind[23].sqldata = (V_SVR_PROCESS).proc_start_date;
#line 84 "atominit.ec"
  _sqobind[24].sqldata = (V_SVR_PROCESS).proc_start_time;
#line 84 "atominit.ec"
  _sqobind[25].sqldata = (V_SVR_PROCESS).proc_down_date;
#line 84 "atominit.ec"
  _sqobind[26].sqldata = (V_SVR_PROCESS).proc_down_time;
#line 84 "atominit.ec"
  _sqobind[27].sqldata = (V_SVR_PROCESS).shm_flag;
#line 84 "atominit.ec"
  _sqobind[28].sqldata = (V_SVR_PROCESS).shm_key;
#line 84 "atominit.ec"
  _sqobind[29].sqldata = (char *) &(V_SVR_PROCESS).shm_size;
#line 84 "atominit.ec"
  _sqobind[30].sqldata = (V_SVR_PROCESS).auto_run_flag;
#line 84 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,31,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 84 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ServerProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        logging(logfp, TRACE, "running process = [%s][%s]"
                     , V_SVR_PROCESS.server_type, V_SVR_PROCESS.proc_name);

        if (setSvrProcess("1") == ABNORMAL)
        {
            logging(logfp, ERROR, "[s] => setSvrProcess() Call ERROR!!",
                           V_SVR_PROCESS.proc_name);
            usleep(100000);
            continue;
        }
        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " START SERVER PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    if (totalCount > 0) sleep(3);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : unloadSvrProcess                                                */
/* SYNTAX   : int unloadSvrProcess()                                          */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : down the server process of T_ServerProcess                      */
/*----------------------------------------------------------------------------*/
int unloadSvrProcess()
{
    int totalCount = 0;

    while(1)
    {
        memset(&V_SVR_PROCESS, 0x00, sizeof(V_SVR_PROCESS));
/*
 *         EXEC SQL SELECT first 1 *
 *                    INTO :V_SVR_PROCESS
 *                    FROM T_ServerProcess
 *                   WHERE SERVER_TYPE = :g_SERVERGB
 *                     AND RUN_TARGET  = '1'
 *                     AND RUN_FLAG    = '1';
 */
#line 129 "atominit.ec"
  {
#line 134 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 134 "atominit.ec"
    {
#line 134 "atominit.ec"
    "SELECT first 1 * FROM T_ServerProcess WHERE SERVER_TYPE = ? AND RUN_TARGET = '1' AND RUN_FLAG = '1'",
    0
    };
#line 134 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 134 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).max_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).run_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).msg_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).img_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).send_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).recv_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).queue_type), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).shm_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 134 "atominit.ec"
    };
#line 134 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 134 "atominit.ec"
  _sqobind[0].sqldata = (V_SVR_PROCESS).server_type;
#line 134 "atominit.ec"
  _sqobind[1].sqldata = (V_SVR_PROCESS).proc_type;
#line 134 "atominit.ec"
  _sqobind[2].sqldata = (V_SVR_PROCESS).proc_name;
#line 134 "atominit.ec"
  _sqobind[3].sqldata = (V_SVR_PROCESS).proc_seq;
#line 134 "atominit.ec"
  _sqobind[4].sqldata = (V_SVR_PROCESS).run_target;
#line 134 "atominit.ec"
  _sqobind[5].sqldata = (V_SVR_PROCESS).run_flag;
#line 134 "atominit.ec"
  _sqobind[6].sqldata = (V_SVR_PROCESS).proc_id;
#line 134 "atominit.ec"
  _sqobind[7].sqldata = (char *) &(V_SVR_PROCESS).max_proc_cnt;
#line 134 "atominit.ec"
  _sqobind[8].sqldata = (char *) &(V_SVR_PROCESS).run_proc_cnt;
#line 134 "atominit.ec"
  _sqobind[9].sqldata = (char *) &(V_SVR_PROCESS).msg_db_cnt;
#line 134 "atominit.ec"
  _sqobind[10].sqldata = (char *) &(V_SVR_PROCESS).img_db_cnt;
#line 134 "atominit.ec"
  _sqobind[11].sqldata = (V_SVR_PROCESS).send_queue_key;
#line 134 "atominit.ec"
  _sqobind[12].sqldata = (V_SVR_PROCESS).send_queue_id;
#line 134 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_SVR_PROCESS).send_queue_size;
#line 134 "atominit.ec"
  _sqobind[14].sqldata = (V_SVR_PROCESS).recv_queue_key;
#line 134 "atominit.ec"
  _sqobind[15].sqldata = (V_SVR_PROCESS).recv_queue_id;
#line 134 "atominit.ec"
  _sqobind[16].sqldata = (char *) &(V_SVR_PROCESS).recv_queue_size;
#line 134 "atominit.ec"
  _sqobind[17].sqldata = (char *) &(V_SVR_PROCESS).queue_type;
#line 134 "atominit.ec"
  _sqobind[18].sqldata = (V_SVR_PROCESS).con_server_ip;
#line 134 "atominit.ec"
  _sqobind[19].sqldata = (char *) &(V_SVR_PROCESS).server_port;
#line 134 "atominit.ec"
  _sqobind[20].sqldata = (char *) &(V_SVR_PROCESS).client_port;
#line 134 "atominit.ec"
  _sqobind[21].sqldata = (V_SVR_PROCESS).sub_proc_name;
#line 134 "atominit.ec"
  _sqobind[22].sqldata = (char *) &(V_SVR_PROCESS).delay_time;
#line 134 "atominit.ec"
  _sqobind[23].sqldata = (V_SVR_PROCESS).proc_start_date;
#line 134 "atominit.ec"
  _sqobind[24].sqldata = (V_SVR_PROCESS).proc_start_time;
#line 134 "atominit.ec"
  _sqobind[25].sqldata = (V_SVR_PROCESS).proc_down_date;
#line 134 "atominit.ec"
  _sqobind[26].sqldata = (V_SVR_PROCESS).proc_down_time;
#line 134 "atominit.ec"
  _sqobind[27].sqldata = (V_SVR_PROCESS).shm_flag;
#line 134 "atominit.ec"
  _sqobind[28].sqldata = (V_SVR_PROCESS).shm_key;
#line 134 "atominit.ec"
  _sqobind[29].sqldata = (char *) &(V_SVR_PROCESS).shm_size;
#line 134 "atominit.ec"
  _sqobind[30].sqldata = (V_SVR_PROCESS).auto_run_flag;
#line 134 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,31,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 134 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ServerProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        /*---------------------------------------------------------------*/
        /* update a process info of T_ServerProcess(finished)            */
        /*---------------------------------------------------------------*/
        if (setSvrProcess("0") == ABNORMAL)
        {
            logging(logfp, ERROR, "[%s] => setSvrProcess() Call ERROR!!",
                           V_SVR_PROCESS.proc_name);
            usleep(100000);
            continue;
        }
        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " DOWN SERVER PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    if (totalCount > 0) sleep(10);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : killSvrProcess                                                  */
/* SYNTAX   : int killSvrProcess()                                            */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : strongly kill process that not killed (T_ServerProcess)         */
/*----------------------------------------------------------------------------*/
int killSvrProcess()
{
    int  downpid = 0;
    int  totalCount = 0;

    while(1)
    {
        memset(&V_SVR_PROCESS, 0x00, sizeof(V_SVR_PROCESS));
/*
 *         EXEC SQL SELECT *
 *                    INTO :V_SVR_PROCESS
 *                    FROM T_ServerProcess
 *                   WHERE SERVER_TYPE = :g_SERVERGB
 *                     AND RUN_FLAG    = '1'
 *                     AND PROC_ID     > '0';
 */
#line 180 "atominit.ec"
  {
#line 185 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 185 "atominit.ec"
    {
#line 185 "atominit.ec"
    "SELECT * FROM T_ServerProcess WHERE SERVER_TYPE = ? AND RUN_FLAG = '1' AND PROC_ID > '0'",
    0
    };
#line 185 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 185 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).max_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).run_proc_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).msg_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).img_db_cnt), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).send_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).recv_queue_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).queue_type), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_SVR_PROCESS).shm_size), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 185 "atominit.ec"
    };
#line 185 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 185 "atominit.ec"
  _sqobind[0].sqldata = (V_SVR_PROCESS).server_type;
#line 185 "atominit.ec"
  _sqobind[1].sqldata = (V_SVR_PROCESS).proc_type;
#line 185 "atominit.ec"
  _sqobind[2].sqldata = (V_SVR_PROCESS).proc_name;
#line 185 "atominit.ec"
  _sqobind[3].sqldata = (V_SVR_PROCESS).proc_seq;
#line 185 "atominit.ec"
  _sqobind[4].sqldata = (V_SVR_PROCESS).run_target;
#line 185 "atominit.ec"
  _sqobind[5].sqldata = (V_SVR_PROCESS).run_flag;
#line 185 "atominit.ec"
  _sqobind[6].sqldata = (V_SVR_PROCESS).proc_id;
#line 185 "atominit.ec"
  _sqobind[7].sqldata = (char *) &(V_SVR_PROCESS).max_proc_cnt;
#line 185 "atominit.ec"
  _sqobind[8].sqldata = (char *) &(V_SVR_PROCESS).run_proc_cnt;
#line 185 "atominit.ec"
  _sqobind[9].sqldata = (char *) &(V_SVR_PROCESS).msg_db_cnt;
#line 185 "atominit.ec"
  _sqobind[10].sqldata = (char *) &(V_SVR_PROCESS).img_db_cnt;
#line 185 "atominit.ec"
  _sqobind[11].sqldata = (V_SVR_PROCESS).send_queue_key;
#line 185 "atominit.ec"
  _sqobind[12].sqldata = (V_SVR_PROCESS).send_queue_id;
#line 185 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_SVR_PROCESS).send_queue_size;
#line 185 "atominit.ec"
  _sqobind[14].sqldata = (V_SVR_PROCESS).recv_queue_key;
#line 185 "atominit.ec"
  _sqobind[15].sqldata = (V_SVR_PROCESS).recv_queue_id;
#line 185 "atominit.ec"
  _sqobind[16].sqldata = (char *) &(V_SVR_PROCESS).recv_queue_size;
#line 185 "atominit.ec"
  _sqobind[17].sqldata = (char *) &(V_SVR_PROCESS).queue_type;
#line 185 "atominit.ec"
  _sqobind[18].sqldata = (V_SVR_PROCESS).con_server_ip;
#line 185 "atominit.ec"
  _sqobind[19].sqldata = (char *) &(V_SVR_PROCESS).server_port;
#line 185 "atominit.ec"
  _sqobind[20].sqldata = (char *) &(V_SVR_PROCESS).client_port;
#line 185 "atominit.ec"
  _sqobind[21].sqldata = (V_SVR_PROCESS).sub_proc_name;
#line 185 "atominit.ec"
  _sqobind[22].sqldata = (char *) &(V_SVR_PROCESS).delay_time;
#line 185 "atominit.ec"
  _sqobind[23].sqldata = (V_SVR_PROCESS).proc_start_date;
#line 185 "atominit.ec"
  _sqobind[24].sqldata = (V_SVR_PROCESS).proc_start_time;
#line 185 "atominit.ec"
  _sqobind[25].sqldata = (V_SVR_PROCESS).proc_down_date;
#line 185 "atominit.ec"
  _sqobind[26].sqldata = (V_SVR_PROCESS).proc_down_time;
#line 185 "atominit.ec"
  _sqobind[27].sqldata = (V_SVR_PROCESS).shm_flag;
#line 185 "atominit.ec"
  _sqobind[28].sqldata = (V_SVR_PROCESS).shm_key;
#line 185 "atominit.ec"
  _sqobind[29].sqldata = (char *) &(V_SVR_PROCESS).shm_size;
#line 185 "atominit.ec"
  _sqobind[30].sqldata = (V_SVR_PROCESS).auto_run_flag;
#line 185 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,31,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 185 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ServerProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        logging(logfp, TRACE, "kill [%s:%s] PID[%s]", V_SVR_PROCESS.server_type
                     , V_SVR_PROCESS.proc_name, V_SVR_PROCESS.proc_id);

        downpid = atoi(V_SVR_PROCESS.proc_id);

        /*---------------------------------------------------------------*/
        /* strongly kill process that not killed                         */
        /*---------------------------------------------------------------*/
        if (kill((pid_t)downpid, SIGUSR1) == -1)
        {
            logging(logfp, ERROR, "PROC KILL ERROR![%d:%s]",
                           downpid, UNIX_ERRMSG);

/*
 *             EXEC SQL UPDATE T_ServerProcess
 *                         SET RUN_FLAG    = '0',
 *                             PROC_ID     = '0'
 *                       WHERE SERVER_TYPE = :V_SVR_PROCESS.server_type
 *                         AND PROC_TYPE   = :V_SVR_PROCESS.proc_type
 *                         AND PROC_NAME   = :V_SVR_PROCESS.proc_name
 *                         AND PROC_SEQ    = :V_SVR_PROCESS.proc_seq;
 */
#line 208 "atominit.ec"
  {
#line 214 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 214 "atominit.ec"
    {
#line 214 "atominit.ec"
    "UPDATE T_ServerProcess SET RUN_FLAG = '0' , PROC_ID = '0' WHERE SERVER_TYPE = ? AND PROC_TYPE = ? AND PROC_NAME = ? AND PROC_SEQ = ?",
    0
    };
#line 214 "atominit.ec"
  static ifx_statement_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 214 "atominit.ec"
    };
#line 214 "atominit.ec"
#line 214 "atominit.ec"
  _sqibind[0].sqldata = V_SVR_PROCESS.server_type;
#line 214 "atominit.ec"
  _sqibind[1].sqldata = V_SVR_PROCESS.proc_type;
#line 214 "atominit.ec"
  _sqibind[2].sqldata = V_SVR_PROCESS.proc_name;
#line 214 "atominit.ec"
  _sqibind[3].sqldata = V_SVR_PROCESS.proc_seq;
  sqli_stmt(ESQLINTVERSION, &_SQ0, sqlcmdtxt, 4, _sqibind, (struct value *)0, (ifx_literal_t *)0, (ifx_namelist_t *)0, (ifx_cursor_t *)0, 4, 0, 0);
#line 214 "atominit.ec"
  }

            if (SQL_ERROR)
            {
                DBRollback();
                continue;
            }
            DBCommit();
        }
        else
        {
            logging(logfp, TRACE, "PROCESS KILL PID=[%d] ", downpid);
        }

        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " KILL SERVER PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : setNetProcess                                                   */
/* SYNTAX   : int setNetProcess(char *tranKind)                               */
/* ARGUMENT : tranKind : 0-down, 1-running                                    */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : update a process status of T_ProtocolProcess                    */
/*----------------------------------------------------------------------------*/
int setNetProcess(char *tranKind)
{
    int  pid = 0;

    if (tranKind[0] == '1')  /* running */
    {
        V_NET_PROCESS.run_target   [0] = '1';
        V_NET_PROCESS.auto_run_flag[0] = '0';
        V_NET_PROCESS.run_flag     [0] = '0';
        pid = getpid();
    }
    else  /* down */
    {
        V_NET_PROCESS.run_target   [0] = '0';
        V_NET_PROCESS.auto_run_flag[0] = '1';
    }
    sprintf(V_NET_PROCESS.proc_id, "%d", pid);

/*
 *     EXEC SQL UPDATE T_ProtocolProcess
 *                 SET RUN_TARGET    = :V_NET_PROCESS.run_target,
 *                     RUN_FLAG      = :V_NET_PROCESS.run_flag
 *               WHERE SERVER_TYPE   = :V_NET_PROCESS.server_type
 *                 AND PROVIDER_TYPE = :V_NET_PROCESS.provider_type
 *                 AND PROVIDER_CD   = :V_NET_PROCESS.provider_cd
 *                 AND PROC_TYPE     = :V_NET_PROCESS.proc_type
 *                 AND PROTOCAL_TYPE = :V_NET_PROCESS.protocal_type
 *                 AND PROC_NAME     = :V_NET_PROCESS.proc_name;
 */
#line 263 "atominit.ec"
  {
#line 271 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 271 "atominit.ec"
    {
#line 271 "atominit.ec"
    "UPDATE T_ProtocolProcess SET RUN_TARGET = ? , RUN_FLAG = ? WHERE SERVER_TYPE = ? AND PROVIDER_TYPE = ? AND PROVIDER_CD = ? AND PROC_TYPE = ? AND PROTOCAL_TYPE = ? AND PROC_NAME = ?",
    0
    };
#line 271 "atominit.ec"
  static ifx_statement_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 271 "atominit.ec"
    };
#line 271 "atominit.ec"
#line 271 "atominit.ec"
  _sqibind[0].sqldata = V_NET_PROCESS.run_target;
#line 271 "atominit.ec"
  _sqibind[1].sqldata = V_NET_PROCESS.run_flag;
#line 271 "atominit.ec"
  _sqibind[2].sqldata = V_NET_PROCESS.server_type;
#line 271 "atominit.ec"
  _sqibind[3].sqldata = V_NET_PROCESS.provider_type;
#line 271 "atominit.ec"
  _sqibind[4].sqldata = V_NET_PROCESS.provider_cd;
#line 271 "atominit.ec"
  _sqibind[5].sqldata = V_NET_PROCESS.proc_type;
#line 271 "atominit.ec"
  _sqibind[6].sqldata = V_NET_PROCESS.protocal_type;
#line 271 "atominit.ec"
  _sqibind[7].sqldata = V_NET_PROCESS.proc_name;
  sqli_stmt(ESQLINTVERSION, &_SQ0, sqlcmdtxt, 8, _sqibind, (struct value *)0, (ifx_literal_t *)0, (ifx_namelist_t *)0, (ifx_cursor_t *)0, 4, 0, 0);
#line 271 "atominit.ec"
  }

    if (SQL_ERROR)
    {
        logging(logfp, ERROR, "T_ProtocolProcess UPDATE ERROR: [%s:%s:%d:%s]",
                       V_NET_PROCESS.server_type, V_NET_PROCESS.proc_name,
                       SQLCODE, SQLMSG);
        DBRollback();
        return ABNORMAL;
    }
    DBCommit();

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : loadNetProcess                                                  */
/* SYNTAX   : int loadNetProcess()                                            */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : run the server process of T_ServerProcess                       */
/*----------------------------------------------------------------------------*/
int loadNetProcess()
{
    int totalCount = 0;

    while(1)
    {
        memset(&V_NET_PROCESS, 0x00, sizeof(V_NET_PROCESS));
/*
 *         EXEC SQL SELECT first 1 *
 *                    INTO :V_NET_PROCESS
 *                    FROM T_ProtocolProcess
 *                   WHERE SERVER_TYPE   = :g_SERVERGB
 *                     AND RUN_TARGET    = '0'
 *                     AND AUTO_RUN_FLAG = '1';
 */
#line 300 "atominit.ec"
  {
#line 305 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 305 "atominit.ec"
    {
#line 305 "atominit.ec"
    "SELECT first 1 * FROM T_ProtocolProcess WHERE SERVER_TYPE = ? AND RUN_TARGET = '0' AND AUTO_RUN_FLAG = '1'",
    0
    };
#line 305 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 305 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 305 "atominit.ec"
    };
#line 305 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 305 "atominit.ec"
  _sqobind[0].sqldata = (V_NET_PROCESS).server_type;
#line 305 "atominit.ec"
  _sqobind[1].sqldata = (V_NET_PROCESS).provider_type;
#line 305 "atominit.ec"
  _sqobind[2].sqldata = (V_NET_PROCESS).provider_cd;
#line 305 "atominit.ec"
  _sqobind[3].sqldata = (V_NET_PROCESS).proc_type;
#line 305 "atominit.ec"
  _sqobind[4].sqldata = (V_NET_PROCESS).protocal_type;
#line 305 "atominit.ec"
  _sqobind[5].sqldata = (V_NET_PROCESS).proc_name;
#line 305 "atominit.ec"
  _sqobind[6].sqldata = (V_NET_PROCESS).run_target;
#line 305 "atominit.ec"
  _sqobind[7].sqldata = (V_NET_PROCESS).run_flag;
#line 305 "atominit.ec"
  _sqobind[8].sqldata = (V_NET_PROCESS).proc_id;
#line 305 "atominit.ec"
  _sqobind[9].sqldata = (V_NET_PROCESS).net_conn_flag;
#line 305 "atominit.ec"
  _sqobind[10].sqldata = (V_NET_PROCESS).connection_type;
#line 305 "atominit.ec"
  _sqobind[11].sqldata = (V_NET_PROCESS).net_status;
#line 305 "atominit.ec"
  _sqobind[12].sqldata = (V_NET_PROCESS).con_server_ip;
#line 305 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_NET_PROCESS).server_port;
#line 305 "atominit.ec"
  _sqobind[14].sqldata = (char *) &(V_NET_PROCESS).client_port;
#line 305 "atominit.ec"
  _sqobind[15].sqldata = (char *) &(V_NET_PROCESS).delay_time;
#line 305 "atominit.ec"
  _sqobind[16].sqldata = (V_NET_PROCESS).proc_start_date;
#line 305 "atominit.ec"
  _sqobind[17].sqldata = (V_NET_PROCESS).proc_start_time;
#line 305 "atominit.ec"
  _sqobind[18].sqldata = (V_NET_PROCESS).proc_down_date;
#line 305 "atominit.ec"
  _sqobind[19].sqldata = (V_NET_PROCESS).proc_down_time;
#line 305 "atominit.ec"
  _sqobind[20].sqldata = (V_NET_PROCESS).auto_run_flag;
#line 305 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,21,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 305 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ProtocolProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        logging(logfp, TRACE, "running process = [%s][%s]"
                     , V_NET_PROCESS.server_type, V_NET_PROCESS.proc_name);

        if (setNetProcess("1") == ABNORMAL)
        {
            logging(logfp, ERROR, "[%s] => setProtocalProcess() Call ERROR!!",
                           V_NET_PROCESS.proc_name);
            usleep(100000);
            continue;
        }
        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " START PROTOCOL PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    if (totalCount > 0) sleep(3);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : unloadNetProcess                                                */
/* SYNTAX   : int unloadNetProcess()                                          */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : down the server process of T_ProtocolProcess                    */
/*----------------------------------------------------------------------------*/
int unloadNetProcess()
{
    int totalCount = 0;

    while(1)
    {
        memset(&V_NET_PROCESS, 0x00, sizeof(V_NET_PROCESS));
/*
 *         EXEC SQL SELECT first 1 *
 *                    INTO :V_NET_PROCESS
 *                    FROM T_ProtocolProcess
 *                   WHERE SERVER_TYPE = :g_SERVERGB
 *                     AND RUN_TARGET  = '1'
 *                     AND RUN_FLAG    = '1';
 */
#line 350 "atominit.ec"
  {
#line 355 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 355 "atominit.ec"
    {
#line 355 "atominit.ec"
    "SELECT first 1 * FROM T_ProtocolProcess WHERE SERVER_TYPE = ? AND RUN_TARGET = '1' AND RUN_FLAG = '1'",
    0
    };
#line 355 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 355 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 355 "atominit.ec"
    };
#line 355 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 355 "atominit.ec"
  _sqobind[0].sqldata = (V_NET_PROCESS).server_type;
#line 355 "atominit.ec"
  _sqobind[1].sqldata = (V_NET_PROCESS).provider_type;
#line 355 "atominit.ec"
  _sqobind[2].sqldata = (V_NET_PROCESS).provider_cd;
#line 355 "atominit.ec"
  _sqobind[3].sqldata = (V_NET_PROCESS).proc_type;
#line 355 "atominit.ec"
  _sqobind[4].sqldata = (V_NET_PROCESS).protocal_type;
#line 355 "atominit.ec"
  _sqobind[5].sqldata = (V_NET_PROCESS).proc_name;
#line 355 "atominit.ec"
  _sqobind[6].sqldata = (V_NET_PROCESS).run_target;
#line 355 "atominit.ec"
  _sqobind[7].sqldata = (V_NET_PROCESS).run_flag;
#line 355 "atominit.ec"
  _sqobind[8].sqldata = (V_NET_PROCESS).proc_id;
#line 355 "atominit.ec"
  _sqobind[9].sqldata = (V_NET_PROCESS).net_conn_flag;
#line 355 "atominit.ec"
  _sqobind[10].sqldata = (V_NET_PROCESS).connection_type;
#line 355 "atominit.ec"
  _sqobind[11].sqldata = (V_NET_PROCESS).net_status;
#line 355 "atominit.ec"
  _sqobind[12].sqldata = (V_NET_PROCESS).con_server_ip;
#line 355 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_NET_PROCESS).server_port;
#line 355 "atominit.ec"
  _sqobind[14].sqldata = (char *) &(V_NET_PROCESS).client_port;
#line 355 "atominit.ec"
  _sqobind[15].sqldata = (char *) &(V_NET_PROCESS).delay_time;
#line 355 "atominit.ec"
  _sqobind[16].sqldata = (V_NET_PROCESS).proc_start_date;
#line 355 "atominit.ec"
  _sqobind[17].sqldata = (V_NET_PROCESS).proc_start_time;
#line 355 "atominit.ec"
  _sqobind[18].sqldata = (V_NET_PROCESS).proc_down_date;
#line 355 "atominit.ec"
  _sqobind[19].sqldata = (V_NET_PROCESS).proc_down_time;
#line 355 "atominit.ec"
  _sqobind[20].sqldata = (V_NET_PROCESS).auto_run_flag;
#line 355 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,21,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 355 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ProtocolProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        /*---------------------------------------------------------------*/
        /* update a process info of T_ServerProcess(finished)            */
        /*---------------------------------------------------------------*/
        if (setNetProcess("0") == ABNORMAL)
        {
            logging(logfp, ERROR, "[%s] => setProtocalProcess() Call ERROR!!",
                           V_NET_PROCESS.proc_name);
            usleep(100000);
            continue;
        }
        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " DOWN PROTOCOL PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    if (totalCount > 0) sleep(10);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : killNetProcess                                                  */
/* SYNTAX   : int killNetProcess()                                            */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : strongly kill process that not killed (T_ProtocolProcess)       */
/*----------------------------------------------------------------------------*/
int killNetProcess()
{
    int  downpid = 0;
    int  totalCount = 0;

    while(1)
    {
        memset(&V_NET_PROCESS, 0x00, sizeof(V_NET_PROCESS));
/*
 *         EXEC SQL SELECT first 1 *
 *                    INTO :V_NET_PROCESS
 *                    FROM T_ProtocolProcess
 *                   WHERE SERVER_TYPE = :g_SERVERGB
 *                     AND RUN_FLAG    = '1'
 *                     AND PROC_ID     > '0';
 */
#line 401 "atominit.ec"
  {
#line 406 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 406 "atominit.ec"
    {
#line 406 "atominit.ec"
    "SELECT first 1 * FROM T_ProtocolProcess WHERE SERVER_TYPE = ? AND RUN_FLAG = '1' AND PROC_ID > '0'",
    0
    };
#line 406 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 406 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).server_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).client_port), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 102, sizeof((V_NET_PROCESS).delay_time), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 406 "atominit.ec"
    };
#line 406 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 406 "atominit.ec"
  _sqobind[0].sqldata = (V_NET_PROCESS).server_type;
#line 406 "atominit.ec"
  _sqobind[1].sqldata = (V_NET_PROCESS).provider_type;
#line 406 "atominit.ec"
  _sqobind[2].sqldata = (V_NET_PROCESS).provider_cd;
#line 406 "atominit.ec"
  _sqobind[3].sqldata = (V_NET_PROCESS).proc_type;
#line 406 "atominit.ec"
  _sqobind[4].sqldata = (V_NET_PROCESS).protocal_type;
#line 406 "atominit.ec"
  _sqobind[5].sqldata = (V_NET_PROCESS).proc_name;
#line 406 "atominit.ec"
  _sqobind[6].sqldata = (V_NET_PROCESS).run_target;
#line 406 "atominit.ec"
  _sqobind[7].sqldata = (V_NET_PROCESS).run_flag;
#line 406 "atominit.ec"
  _sqobind[8].sqldata = (V_NET_PROCESS).proc_id;
#line 406 "atominit.ec"
  _sqobind[9].sqldata = (V_NET_PROCESS).net_conn_flag;
#line 406 "atominit.ec"
  _sqobind[10].sqldata = (V_NET_PROCESS).connection_type;
#line 406 "atominit.ec"
  _sqobind[11].sqldata = (V_NET_PROCESS).net_status;
#line 406 "atominit.ec"
  _sqobind[12].sqldata = (V_NET_PROCESS).con_server_ip;
#line 406 "atominit.ec"
  _sqobind[13].sqldata = (char *) &(V_NET_PROCESS).server_port;
#line 406 "atominit.ec"
  _sqobind[14].sqldata = (char *) &(V_NET_PROCESS).client_port;
#line 406 "atominit.ec"
  _sqobind[15].sqldata = (char *) &(V_NET_PROCESS).delay_time;
#line 406 "atominit.ec"
  _sqobind[16].sqldata = (V_NET_PROCESS).proc_start_date;
#line 406 "atominit.ec"
  _sqobind[17].sqldata = (V_NET_PROCESS).proc_start_time;
#line 406 "atominit.ec"
  _sqobind[18].sqldata = (V_NET_PROCESS).proc_down_date;
#line 406 "atominit.ec"
  _sqobind[19].sqldata = (V_NET_PROCESS).proc_down_time;
#line 406 "atominit.ec"
  _sqobind[20].sqldata = (V_NET_PROCESS).auto_run_flag;
#line 406 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,21,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 406 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            if (SQL_NOTFOUND) break;
            logging(logfp, ERROR, "SELECT T_ServerProcess ERROR[%d:%s]",
                           SQLCODE, SQLMSG);
            return ABNORMAL;
        }

        logging(logfp, TRACE, "kill [%s:%s] PID[%s]", V_NET_PROCESS.server_type
                     , V_NET_PROCESS.proc_name, V_NET_PROCESS.proc_id);

        downpid = atoi(V_NET_PROCESS.proc_id);

        /*---------------------------------------------------------------*/
        /* strongly kill process that not killed                         */
        /*---------------------------------------------------------------*/
        if (kill((pid_t)downpid, SIGUSR1) == -1)
        {
            logging(logfp, ERROR, "PROC KILL ERROR![%d:%s]",
                           downpid, UNIX_ERRMSG);

/*
 *             EXEC SQL UPDATE T_ProtocolProcess
 *                         SET RUN_FLAG      = '0',
 *                             PROC_ID       = '0'
 *                       WHERE SERVER_TYPE   = :V_NET_PROCESS.server_type
 *                         AND PROVIDER_TYPE = :V_NET_PROCESS.provider_type
 *                         AND PROVIDER_CD   = :V_NET_PROCESS.provider_cd
 *                         AND PROC_TYPE     = :V_NET_PROCESS.proc_type
 *                         AND PROTOCAL_TYPE = :V_NET_PROCESS.protocal_type
 *                         AND PROC_NAME     = :V_NET_PROCESS.proc_name;
 */
#line 429 "atominit.ec"
  {
#line 437 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 437 "atominit.ec"
    {
#line 437 "atominit.ec"
    "UPDATE T_ProtocolProcess SET RUN_FLAG = '0' , PROC_ID = '0' WHERE SERVER_TYPE = ? AND PROVIDER_TYPE = ? AND PROVIDER_CD = ? AND PROC_TYPE = ? AND PROTOCAL_TYPE = ? AND PROC_NAME = ?",
    0
    };
#line 437 "atominit.ec"
  static ifx_statement_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
      { 114, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 437 "atominit.ec"
    };
#line 437 "atominit.ec"
#line 437 "atominit.ec"
  _sqibind[0].sqldata = V_NET_PROCESS.server_type;
#line 437 "atominit.ec"
  _sqibind[1].sqldata = V_NET_PROCESS.provider_type;
#line 437 "atominit.ec"
  _sqibind[2].sqldata = V_NET_PROCESS.provider_cd;
#line 437 "atominit.ec"
  _sqibind[3].sqldata = V_NET_PROCESS.proc_type;
#line 437 "atominit.ec"
  _sqibind[4].sqldata = V_NET_PROCESS.protocal_type;
#line 437 "atominit.ec"
  _sqibind[5].sqldata = V_NET_PROCESS.proc_name;
  sqli_stmt(ESQLINTVERSION, &_SQ0, sqlcmdtxt, 6, _sqibind, (struct value *)0, (ifx_literal_t *)0, (ifx_namelist_t *)0, (ifx_cursor_t *)0, 4, 0, 0);
#line 437 "atominit.ec"
  }

            if (SQL_ERROR)
            {
                DBRollback();
                continue;
            }
            DBCommit();
        }
        else
        {
            logging(logfp, TRACE, "PROCESS KILL PID=[%d] ", downpid);
        }

        totalCount++;
        usleep(100000);
    }
    logging(logfp, TRACE, "#####################################");
    logging(logfp, TRACE, " KILL PROTOCOL PROCESS COUNT = [%d]", totalCount);
    logging(logfp, TRACE, "#####################################");

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : initializeQueue                                                 */
/* SYNTAX   : int initializeQueue()                                           */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : initialize queue id                                             */
/*----------------------------------------------------------------------------*/
int initializeQueue()
{

/*
 *     EXEC SQL UPDATE T_ServerProcess
 *                 SET SEND_QUEUE_ID = ' '
 *                   , RECV_QUEUE_ID = ' '
 *               WHERE SERVER_TYPE   = :g_SERVERGB ;
 */
#line 471 "atominit.ec"
  {
#line 474 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 474 "atominit.ec"
    {
#line 474 "atominit.ec"
    "UPDATE T_ServerProcess SET SEND_QUEUE_ID = ' ' , RECV_QUEUE_ID = ' ' WHERE SERVER_TYPE = ?",
    0
    };
#line 474 "atominit.ec"
  static ifx_statement_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 474 "atominit.ec"
    };
#line 474 "atominit.ec"
#line 474 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
  sqli_stmt(ESQLINTVERSION, &_SQ0, sqlcmdtxt, 1, _sqibind, (struct value *)0, (ifx_literal_t *)0, (ifx_namelist_t *)0, (ifx_cursor_t *)0, 4, 0, 0);
#line 474 "atominit.ec"
  }

    if (SQL_ERROR && !SQL_NOTFOUND)
    {
        logging(logfp, ERROR, "INITIALIZATION QUEUE ERROR [%d:%s]",
                       SQLCODE, SQLMSG);
        DBRollback();
        return ABNORMAL;
    }

    DBCommit();

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : main                                                            */
/* SYNTAX   : int main(int argc, char **argv)                                 */
/* ARGUMENT : argc : argument count                                           */
/*            argv : argument                                                 */
/* RETURN   :                                                                 */
/* PURPOSE  : process main function                                           */
/*----------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 499 "atominit.ec"
#line 500 "atominit.ec"
  char proc_id[11] = {0x00, };
/*
 * EXEC SQL END DECLARE SECTION;
 */
#line 501 "atominit.ec"

    char run_type [ 1+1] = {0x00, };
    char host_name[20+1] = {0x00, };
    char ap1_name [20+1] = {0x00, };
    char ap2_name [20+1] = {0x00, };
    char command  [64+1] = {0x00, };
    char args0    [10+1] = {0x00, };
    int  errflag = 0;
    int  downpid = 0;
    pid_t pid = 0;
#if (defined(WIN32) || defined(_WIN32))
    char progargs[100+1] = {0x00,};
    char cmdargs [100+1] = {0x00,};
#endif

    /*-------------------------------------------------------------------*/
    /* check argument count                                              */
    /*-------------------------------------------------------------------*/
    if (argc < 3)
    {
        fprintf(stderr, "<< Usage >> %s [A/B] [R/D] &\n", argv[0]);
        fflush(stderr);
        exit (1);
    }

    memset (g_PROCNAME, 0x00    , sizeof(g_PROCNAME));
    sprintf(g_PROCNAME, "%.8s"  , argv[0]);

    /*-------------------------------------------------------------------*/
    /* initialize process                                                */
    /*-------------------------------------------------------------------*/
    if (initProc(argc, argv) == ABNORMAL)
    {
        if (logfp) logging(logfp, ERROR, "Fail to initialize process");
        proc_end();
    }

    run_type[0] = toupper(argv[2][0]);
logging(logfp, TRACE, "atominit run_type = [%s]", run_type);

    /*-------------------------------------------------------------------*/
    /* �⵿(����) ��� ���� ��Ȯ��                                       */
    /*-------------------------------------------------------------------*/
    if (f_getConfigVaule("AP1_HOST_NAME", ap1_name) == ABNORMAL)
    {
        logging(logfp, ERROR, "[AP1_HOST_NAME]getConfigVaule ERROR");
        proc_end();
    }

    if (f_getConfigVaule("AP2_HOST_NAME", ap2_name) == ABNORMAL)
    {
        logging(logfp, ERROR, "[AP2_HOST_NAME]getConfigVaule ERROR");
        proc_end();
    }

    if (gethostname(host_name, sizeof(host_name)-1) < 0)
    {
        logging(logfp, ERROR, "gethostname error! [%d:%s]", errno, UNIX_ERRMSG);
        proc_end();
    }

    if (memcmp(host_name, ap1_name, strlen(host_name)) == 0)
    { /* A���� */
        g_SERVERGB[0] = 'A';
    }
    else if (memcmp(host_name, ap2_name, strlen(host_name)) == 0)
    { /* B���� */
        g_SERVERGB[0] = 'B';
    }
    else
    { /* �������� ���� */
        logging(logfp, ERROR, "SERVER TYPE ERROR!");
        logging(logfp, ERROR, "HOST_NAME = [%s]", host_name);
        logging(logfp, ERROR, "AP1_NAME  = [%s]", ap1_name);
        logging(logfp, ERROR, "AP2_NAME  = [%s]", ap2_name);
        proc_end();
    }

    logging(logfp, TRACE, "HOST_NAME   = [%s]", host_name);
    logging(logfp, TRACE, "AP1_NAME    = [%s]", ap1_name);
    logging(logfp, TRACE, "AP2_NAME    = [%s]", ap2_name);
    logging(logfp, TRACE, "SERVER_TYPE = [%s]", g_SERVERGB);

    switch (run_type[0])
    {
        case LOAD_PROCESS: /* load all process */
            /*-----------------------------------------------------------*/
            /* 1. load server process (start)                            */
            /*-----------------------------------------------------------*/
            if (loadSvrProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "downProcess ERROR !!!");
            }

            /*-----------------------------------------------------------*/
            /* 2. load protocol process (start)                          */
            /*-----------------------------------------------------------*/
            if (loadNetProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "downProcess ERROR !!!");
            }
        break;
        case UNLOAD_PROCESS: /* unload all process */
            /*-----------------------------------------------------------*/
            /* 1. unload server process (down)                           */
            /*-----------------------------------------------------------*/
            if (unloadSvrProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "unloadSvrProcess ERROR !!!");
            }

            /*-----------------------------------------------------------*/
            /* 2. unload protocol process (down)                         */
            /*-----------------------------------------------------------*/
            if (unloadNetProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "unloadNetProcess ERROR !!!");
            }

            /*-----------------------------------------------------------*/
            /* 3. kill server process (down)                             */
            /*-----------------------------------------------------------*/
            if (killSvrProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "killSvrProcess ERROR !!!");
            }

            /*-----------------------------------------------------------*/
            /* 4. kill protocol process (down)                           */
            /*-----------------------------------------------------------*/
            if (killNetProcess() == ABNORMAL)
            {
                logging(logfp, ERROR, "killNetProcess ERROR !!!");
            }

            /*-----------------------------------------------------------*/
            /* 5. initialize a queue status with space                   */
            /*-----------------------------------------------------------*/
            if (initializeQueue() == ABNORMAL)
            {
                logging(logfp, ERROR, "initializeQueue ERROR !!!");
            }
        break;
        default: /* run type mismatch */
            printf("\n<< USAGE >> atominit [A/B] [R/D] &\n");
            logging(logfp, ERROR, "<< USAGE >> atominit [A/B] [R/D] &\n");
            errflag = 1;
        break;
    }

    if (!errflag && run_type[0] == UNLOAD_PROCESS)
    { /* ���������� ���μ��� ����ó�� �Ϸ� �� atommain ���� */
        strcpy(command, "pk atommain > NULL");

/*
 *         EXEC SQL SELECT PROC_ID
 *                    INTO :proc_id
 *                    FROM T_MONPROCESS
 *                   WHERE SERVER_TYPE = :g_SERVERGB
 *                     AND PROC_NAME   = 'atommain'
 *                     AND PROC_SEQ    = '01';
 */
#line 655 "atominit.ec"
  {
#line 660 "atominit.ec"
  static const char *sqlcmdtxt[] =
#line 660 "atominit.ec"
    {
#line 660 "atominit.ec"
    "SELECT PROC_ID FROM T_MONPROCESS WHERE SERVER_TYPE = ? AND PROC_NAME = 'atommain' AND PROC_SEQ = '01'",
    0
    };
#line 660 "atominit.ec"
static ifx_cursor_t _SQ0 = {0};
  static ifx_sqlvar_t _sqibind[] = 
    {
      { 100, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 660 "atominit.ec"
    };
  static ifx_sqlvar_t _sqobind[] = 
    {
      { 100, 11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
#line 660 "atominit.ec"
    };
#line 660 "atominit.ec"
  _sqibind[0].sqldata = g_SERVERGB;
#line 660 "atominit.ec"
  _sqobind[0].sqldata = proc_id;
#line 660 "atominit.ec"
  sqli_slct(ESQLINTVERSION, &_SQ0,sqlcmdtxt,1,_sqibind,1,_sqobind,0,(ifx_literal_t *)0,(ifx_namelist_t *)0,0);
#line 660 "atominit.ec"
  }

        if (SQL_ERROR)
        {
            logging(logfp, ERROR, "T_MONPROCESS SELECT ERROR [%s][%d:%s]",
                           g_SERVERGB, SQLCODE, SQLMSG);
            logging(logfp, TRACE, "pk atommain > NULL executing...");
            /* �ý��� �������� ���μ��� ���� */
            system(command);
        }
        else
        {
            downpid = atoi(proc_id);

            /*---------------------------------------------------------------*/
            /* strongly kill process that not killed                         */
            /*---------------------------------------------------------------*/
            if (kill((pid_t)downpid, SIGUSR1) == -1)
            {
                logging(logfp, ERROR, "PROC KILL ERROR![%d:%s]",
                               downpid, UNIX_ERRMSG);
                logging(logfp, TRACE, "pk atommain > NULL executing...");
                /* �ý��� �������� ���μ��� ���� */
                system(command);
            }
            else
            {
                logging(logfp, TRACE, "ATOMMAIN KILLED PID=[%d] ", downpid);
            }
        }
    }
    else if (!errflag && run_type[0] == LOAD_PROCESS)
    { /* ���������� ���μ��� �⵿ó�� �Ϸ� �� atommain �⵿ */

        strcpy(command, "atommain %s > NULL", g_SERVERGB);

        snprintf(args0, sizeof(args0), "%.8s", "atommain");

#if (!defined(WIN32) && !defined(_WIN32))
        if (!(pid = fork()))      /* Child process */
        {
            logging(logfp, TRACE, "[%s:%s] fork().OK!", args0, g_SERVERGB);
#if 0
            if (logfp) fclose(logfp);
#endif
            setsid();

            if (execlp(args0,         /* process name    */
                       args0,         /* running process */
                       g_SERVERGB,    /* server type     */
                      (char*)0) < 0)
            {
                logging(logfp, ERROR, "[%s] PROCESS RUN ERROR!",args0);
                exit(4);
            }
        }
#else
        logging(logfp, TRACE, "%s winforkexec", args0);

        sprintf(progargs, "%s.exe", args0);
        sprintf(cmdargs , "%s %s %d", args0
                                    , g_SERVERGB
                                    , getpid()
               );
        pid = winforkexec(progargs, cmdargs);
#endif

        if (pid < 0)
        {
            logging(logfp, ERROR, "ATOMMAIN PROCESS START ERROR [%s][%d:%s]",
                           g_SERVERGB, errno, UNIX_ERRMSG);
            logging(logfp, TRACE, "atommain %s > NULL executing...", g_SERVERGB);
            /* �ý��� �������� ���μ��� �⵿ */
            system(command);
        }
        else
        {
            logging(logfp, TRACE, "ATOMMAIN %s STARTED", g_SERVERGB);
        }
    }
    sleep(2);
    proc_end();
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/

#line 746 "atominit.ec"
