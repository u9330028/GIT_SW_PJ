#include <sqlhdr.h>
#include <sqliapi.h>
#line 1 "atom_initproc.ec"
/*============================================================================*/
/* Program Name: atom_initproc.ec                                             */
/* Execute File: atommain                                                     */
/* Function    : MoniManager main process common function                     */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2009.12.08    SHLEE            First Ver                    */
/*============================================================================*/
/* 
 * EXEC SQL INCLUDE "maincom.h";
 */
#line 12 "atom_initproc.ec"

#line 12 "atom_initproc.ec"
#line 1 "/data/atmadm/fsprepare/inc/maincom.h"
/*============================================================================*/
/* Program Name: maincom.h                                                    */
/* Execute File:                                                              */
/* Function    : ATOM Process Header file                                     */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.02.01    SHLEE            First Ver                    */
/*----------------------------------------------------------------------------*/
#ifndef	 _ATMSCOM_H
#define	 _ATMSCOM_H

/*-----------------------------------------------------------------------*/
/* Declare include file                                                  */
/*-----------------------------------------------------------------------*/
#include "defcom.h"
#include "string.h"
#include "shm.h"
#include "msg.h"

/*-----------------------------------------------------------------------*/
/* Define Common Variable                                                */
/*-----------------------------------------------------------------------*/
#define RUNCHECK_WAIT_TIME	5
#define MIN_QSIZE           65535

/*-----------------------------------------------------------------------*/
/* ATOM PROCESS CONTROL SHARED MEMORY STRUCTURE                          */
/*-----------------------------------------------------------------------*/
typedef struct
{
#if (!defined(WIN32) && !defined(_WIN32))
    char    pidname [10];           /* process name               */
#else
    char    pidname [10 + 4];       /* process name               */
#endif
    char    pstat   [ 1];           /* "R"(running) / "D"(down)   */
    char    startdt [14];           /* process start date         */
    char    downdt  [14];           /* process down date          */
    char    desc    [20];           /* process description        */
    char    reserved[20];           /* reserved area              */
} s_daemoninfo;

/*-----------------------------------------------------------------------*/
/* Declare Database Variable                                             */
/*-----------------------------------------------------------------------*/
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 49 "/data/atmadm/fsprepare/inc/maincom.h"
#line 50 "/data/atmadm/fsprepare/inc/maincom.h"
  char g_SERVERGB[2];
  char g_PROCNAME[9];
  char g_DBSID[21];
  char g_USERID[11];
  char g_PASSWD[11];
int g_DBCONNECTGB;
int g_CONNECTCNT;
/*
 * EXEC SQL END   DECLARE SECTION;
 */
#line 57 "/data/atmadm/fsprepare/inc/maincom.h"


FILE *logfp;
s_daemoninfo  pDmonInfo;

/*-----------------------------------------------------------------------*/
/* Declare Function Prototype                                            */
/*-----------------------------------------------------------------------*/
extern void sig_init    ();
extern void proc_end    ();
extern void clean_zombie();

#endif  /* _ATMSCOM_H */
#line 69 "/data/atmadm/fsprepare/inc/maincom.h"
/* 
 * EXEC SQL INCLUDE "dbdef.h";
 */
#line 13 "atom_initproc.ec"

#line 13 "atom_initproc.ec"
#line 1 "/data/atmadm/fsprepare/inc/dbdef.h"
/*============================================================================*/
/* Program Name: dbdef.h                                                      */
/* Execute File:                                                              */
/* Function    : DataBase Interface Include File                              */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.07.21    SHLEE            First Ver                    */
/*============================================================================*/
#ifndef	 _DBDEF_H
#define	 _DBDEF_H

/* 
 * EXEC SQL INCLUDE SQLCA;
 */
#line 15 "/data/atmadm/fsprepare/inc/dbdef.h"

#line 15 "/data/atmadm/fsprepare/inc/dbdef.h"
#line 1 "/informix/incl/dmi/sqlca.h"
/****************************************************************************
 *
 * Licensed Material - Property Of IBM
 *
 * "Restricted Materials of IBM"
 *
 * IBM Informix Client SDK
 * Copyright IBM Corporation 1997, 2008. All rights reserved.
 *
 *  Title:       sqlca.h
 *  Description: SQL Control Area
 *
 ***************************************************************************
 */

#ifndef SQLCA_INCL
#define SQLCA_INCL

#include "ifxtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sqlca_s
    {
    int4 sqlcode;
#ifdef DB2CLI
    char sqlerrm[600]; /* error message parameters */
#else /* DB2CLI */
    char sqlerrm[72]; /* error message parameters */
#endif /* DB2CLI */
    char sqlerrp[8];
    int4 sqlerrd[6];
		    /* 0 - estimated number of rows returned */
		    /* 1 - serial value after insert or  ISAM error code */
		    /* 2 - number of rows processed */
		    /* 3 - estimated cost */
		    /* 4 - offset of the error into the SQL statement */
		    /* 5 - rowid after insert  */
#ifdef _FGL_
    char sqlawarn[8];
#else
    struct sqlcaw_s
	{
	char sqlwarn0; /* = W if any of sqlwarn[1-7] = W */
	char sqlwarn1; /* = W if any truncation occurred or
				database has transactions or
			        no privileges revoked */
	char sqlwarn2; /* = W if a null value returned or
				ANSI database */
	char sqlwarn3; /* = W if no. in select list != no. in into list or
				turbo backend or no privileges granted */
	char sqlwarn4; /* = W if no where clause on prepared update, delete or
				incompatible float format */
	char sqlwarn5; /* = W if non-ANSI statement */
	char sqlwarn6; /* = W if server is in data replication secondary mode */
	char sqlwarn7; /* = W if database locale is different from proc_locale
                          = W if backend XPS and if explain avoid_execute is set
                              (for select, insert, delete and update only)
			*/
	} sqlwarn;
#endif
    } ifx_sqlca_t;

/* NOTE: 4gl assumes that the sqlwarn structure can be defined as
 *	sqlawarn -- an 8 character string, because single-char
 *	variables are not recognized in 4gl.
 *
 * If this structure should change, the code generated by 4gl compiler
 *	must also change
 */

#define SQLNOTFOUND 100

#ifndef IFX_THREAD
#ifdef DB2CLI
#define sqlca ifmxsqlca
extern struct sqlca_s sqlca;
#else /* DB2CLI */
extern struct sqlca_s sqlca;
#endif /* DB2CLI */

#ifndef DRDAHELP
extern int4 SQLCODE;
#endif

extern char SQLSTATE[];
#else /* IFX_THREAD */
extern int4 * ifx_sqlcode(void);
extern struct sqlca_s * ifx_sqlca(void);
/* ifx_sqlstate() declared in sqlhdr.h */
#define SQLCODE (*(ifx_sqlcode()))
#define SQLSTATE ((char *)(ifx_sqlstate()))
#define sqlca (*(ifx_sqlca()))
#endif /* IFX_THREAD */

#ifdef __cplusplus
}
#endif

#endif /* SQLCA_INCL */

#line 103 "/informix/incl/dmi/sqlca.h"
#line 16 "/data/atmadm/fsprepare/inc/dbdef.h"

/*----------------------------------------------------------------------------*/
/* SQL DEFINE                                                                 */
/*----------------------------------------------------------------------------*/
#ifdef ORACLE
/* definition for oracle */
#ifndef     SQLCODE
#define     SQLCODE             sqlca.sqlcode
#endif
#ifndef     SQLCOUNT
#define     SQLCOUNT            sqlca.sqlerrd[2]
#endif
#ifndef     SQLMSG
#define     SQLMSG              sqlca.sqlerrm.sqlerrmc
#endif
#ifndef     SQLNOTFOUND
#define     SQLNOTFOUND         1403
#endif
#ifndef     SQLDUPLICATE
#define     SQLDUPLICATE        -1
#endif
#ifndef     SQLOK
#define     SQLOK               0
#endif
#ifndef     SQLNOTCONNECT
#define     SQLNOTCONNECT       -3114
#endif
#ifndef     SQLNOWAIT
#define     SQLNOWAIT           54
#endif
#ifndef     SQL_NOTFOUND
#define     SQL_NOTFOUND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_FETCHEND
#define     SQL_FETCHEND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT != 0))
#endif
#ifndef     SQL_UPNOTFOUND
#define     SQL_UPNOTFOUND      ((SQLCODE == SQLOK) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_DUPLICATE
#define     SQL_DUPLICATE       (SQLCODE == SQLDUPLICATE)
#endif
#ifndef     SQL_NOTCONNECT
#define     SQL_NOTCONNECT      (SQLCODE == SQLNOTCONNECT)
#endif
#ifndef     SQL_ERROR
#define     SQL_ERROR           (SQLCODE != SQLOK)
#endif
#ifndef     SQL_NOWAIT
#define     SQL_NOWAIT          (SQLCODE == SQLNOWAIT)
#endif

#else

/* definition for informix */
#ifndef     SQLCODE
#define     SQLCODE             sqlca.sqlcode
#endif
#ifndef     SQLCOUNT
#define     SQLCOUNT            sqlca.sqlerrd[2]
#endif
#ifndef     SQLMSG
/* ������� 2009.12.15 HDOH
#define     SQLMSG              sqlca.sqlerrm
#define     SQLMSG              SQLSTATE
*/
#define     SQLMSG              f_get_errMsg(SQLCODE)
#endif
#ifndef     SQLNOTFOUND
#define     SQLNOTFOUND         100
#endif
#ifndef     SQLDUPLICATE100
#define     SQLDUPLICATE100     -100
#endif
#ifndef     SQLDUPLICATE239
#define     SQLDUPLICATE239     -239
#endif
#ifndef     SQLDUPLICATE268
#define     SQLDUPLICATE268     -268
#endif
#ifndef     SQLDUPLICATE371
#define     SQLDUPLICATE371     -371
#endif
#ifndef     SQLOK
#define     SQLOK               0
#endif
#ifndef     SQLNOTCONNECT
#define     SQLNOTCONNECT       -3114
#endif
#ifndef     SQLNOWAIT
#define     SQLNOWAIT           54
#endif
#ifndef     SQLLOCK243
#define     SQLLOCK243          -243
#endif
#ifndef     SQLLOCK244
#define     SQLLOCK244          -244
#endif
#ifndef     SQL_NOTFOUND
#define     SQL_NOTFOUND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_FETCHEND
#define     SQL_FETCHEND        ((SQLCODE == SQLNOTFOUND) && (SQLCOUNT != 0))
#endif
#ifndef     SQL_UPNOTFOUND
#define     SQL_UPNOTFOUND      ((SQLCODE == SQLOK) && (SQLCOUNT == 0))
#endif
#ifndef     SQL_DUPLICATE
#define     SQL_DUPLICATE       ((SQLCODE == SQLDUPLICATE100) || (SQLCODE == SQLDUPLICATE239) || (SQLCODE == SQLDUPLICATE268) || (SQLCODE == SQLDUPLICATE371))
#endif
#ifndef     SQL_NOTCONNECT
#define     SQL_NOTCONNECT      (SQLCODE == SQLNOTCONNECT)
#endif
#ifndef     SQL_ERROR
#define     SQL_ERROR           (SQLCODE != SQLOK)
#endif
#ifndef     SQL_NOWAIT
#define     SQL_NOWAIT          (SQLCODE == SQLNOWAIT)
#endif
#ifndef     SQL_LOCK
#define     SQL_LOCK            ((SQLCODE == SQLLOCK243) || (SQLCODE == SQLLOCK244))
#endif
#endif
/*----------------------------------------------------------------------------*/
/* vairable DEFINE                                                            */
/*----------------------------------------------------------------------------*/
#ifndef     NORMAL
#define     NORMAL              1
#endif
#ifndef     ABNORMAL
#define     ABNORMAL           -1
#endif

#ifndef     NOTFOUND
#define     NOTFOUND            2
#endif

#ifndef     NOWAIT
#define     NOWAIT              3
#endif

/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 157 "/data/atmadm/fsprepare/inc/dbdef.h"
#line 158 "/data/atmadm/fsprepare/inc/dbdef.h"
#ifdef INFORMIX
typedef struct _sql_context
  {
      char conn_name[11];
  }  sql_context;
#endif
typedef struct ParamArgs
  {
    sql_context ctx;
      char connName[11];
      char dbName[10];
    int conngb;
    int pid;
    int thid;
  }  t_params;
/*
 * EXEC SQL END  DECLARE SECTION;
 */
#line 174 "/data/atmadm/fsprepare/inc/dbdef.h"


t_params *g_Msg_Pool;
t_params *g_Img_Pool;
t_params *g_Main_Pool;

int DBConnect        ();
int DBCommit         ();
int DBRollback       ();
int DBDisconnect     ();
int DBBeginWork      ();
int DBLockSet        ();
int DBLockClear      ();
int downSvrProcess   ();
int updateSvrProcess ();
int getErrMsg        ();
int jnlDBCommit      ();
int jnlDBRollback    ();
int jnlDBBeginWork   ();
int createContext    ();
int assignContext    ();
int freeContext      ();
int f_getserialno    ();
int f_getnodename    ();
int f_getprotocoltype();
int f_getprovidercode();
char *f_get_errMsg   ();
int f_dormantConnection();
int f_getServerProcess();
int f_assignConnection();
int f_updateSvrProcess();

#endif		/*  _DBDEF_H  */

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
#line 210 "/data/atmadm/fsprepare/inc/dbdef.h"
/* 
 * EXEC SQL INCLUDE "var_svr_process.h";     ** server process table **
 */
#line 14 "atom_initproc.ec"

#line 14 "atom_initproc.ec"
#line 1 "/data/atmadm/fsprepare/inc/var_svr_process.h"
/*----------------------------------------------------------------------------*/
/*  Server Process Structure                                                  */
/*----------------------------------------------------------------------------*/
/*
 * EXEC SQL BEGIN DECLARE SECTION;
 */
#line 4 "/data/atmadm/fsprepare/inc/var_svr_process.h"
#line 5 "/data/atmadm/fsprepare/inc/var_svr_process.h"
typedef struct tagV_SVR_PROCESS
  {
      char server_type[2];
      char proc_type[2];
      char proc_name[9];
      char proc_seq[3];
      char run_target[2];
      char run_flag[2];
      char proc_id[11];
    int max_proc_cnt;
    int run_proc_cnt;
    int msg_db_cnt;
    int img_db_cnt;
      char send_queue_key[11];
      char send_queue_id[11];
    int send_queue_size;
      char recv_queue_key[11];
      char recv_queue_id[11];
    int recv_queue_size;
    int queue_type;
      char con_server_ip[16];
    int server_port;
    int client_port;
      char sub_proc_name[9];
    int delay_time;
      char proc_start_date[9];
      char proc_start_time[7];
      char proc_down_date[9];
      char proc_down_time[7];
      char shm_flag[2];
      char shm_key[11];
    int shm_size;
      char auto_run_flag[2];
  }  T_SVR_PROCESS;
T_SVR_PROCESS V_SVR_PROCESS;
/*
 * EXEC SQL END   DECLARE SECTION;
 */
#line 42 "/data/atmadm/fsprepare/inc/var_svr_process.h"

#line 42 "/data/atmadm/fsprepare/inc/var_svr_process.h"
#line 15 "atom_initproc.ec"

/*-----------------------------------------------------------------------*/
/* function prototype                                                    */
/*-----------------------------------------------------------------------*/
void proc_end1();
void proc_end2();
void proc_end3();
void proc_end4();
void proc_end5();
void proc_end6();
void proc_end7();
void proc_end8();
void proc_end9();
void proc_enda();
void proc_endb();
void proc_endc();

/*----------------------------------------------------------------------------*/
/* FUNCTION : checkProcess                                                    */
/* SYNTAX   : int checkProcess(char *process_id)                              */
/* ARGUMENT : process_id : process id (I)                                     */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : check a running status of atommain                              */
/*----------------------------------------------------------------------------*/
int checkProcess(char *process_id)
{
    int pid = 0;
    int kill_count = 2;
    int kill_result = 0;
    int alive_flag = 0;

    pid = atoi(process_id);

    if (pid > 0)
    {
        kill_count = 2;
        while (kill_count > 0)
        {
            --kill_count;

            errno = 0;
            kill_result = -1;
            alive_flag = 0;
            /* check kill signal */
            kill_result = kill((pid_t)pid,0);

#if !(defined(WIN32) || defined(_WIN32))
            if ((kill_result == 0) || (errno != ESRCH))
#else
            if (kill_result == 0)
#endif
            { /* running */
                alive_flag = 1;
                break;
            }
            else
            {
                printf("\nPID=[%ld] send check singal", pid);
                sleep(1);
            }
        }
    }

    if (!alive_flag) return ABNORMAL;
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : setMainRun                                                      */
/* SYNTAX   : int setMainRun(char *pidname)                                   */
/* ARGUMENT : pidname: process name (I)                                       */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : start ATOMMAIN process and set shared memory of running         */
/*----------------------------------------------------------------------------*/
int setMainRun(char *pidname)
{
    int  shmid = 0;
    char tdate[21] = {0x00, };
    s_daemoninfo *shmaddr = NULL;
printf("\n atommain_setMainRun starting...\n");
    if ((shmid = accessShm(SHMKEY_DAEMON)) < 0)
    {
        shmid = createShm(SHMKEY_DAEMON, sizeof(s_daemoninfo));
        if (shmid == ABNORMAL) return ABNORMAL;
    }
printf("\n atommain_setMainRun 1...\n");

    shmaddr = (s_daemoninfo *)attachShm(shmid, 0);
    if (shmaddr == (s_daemoninfo *)NULL) return ABNORMAL;

    memset(&pDmonInfo, 0x20, sizeof(pDmonInfo));
    if ( (!memcmp(shmaddr->pidname, pidname, sizeof(shmaddr->pidname))) &&
         (!memcmp(shmaddr->pstat, "R", 1)) )
    {
        if (checkProcess(shmaddr->reserved) == ABNORMAL)
        {
            printf("\natommain[%s] abnormal downed.. restart\n",
                           shmaddr->reserved);
        }
        else
        {
            memcpy(&pDmonInfo, shmaddr, sizeof(pDmonInfo));
            printf("\nProcess[%s] is Alreay Running....", pidname);
            detachShm(shmaddr);
            return ABNORMAL;
        }
    }
printf("\n atommain_setMainRun 2...\n");
    memcpy (pDmonInfo.pidname , pidname, sizeof(pDmonInfo.pidname));
    memcpy (pDmonInfo.pstat   , "R"    , sizeof(pDmonInfo.pstat)  );
    getDate(tdate);
    memcpy (pDmonInfo.startdt , tdate  , sizeof(pDmonInfo.startdt));
    memset (pDmonInfo.downdt  , 0x20   , sizeof(pDmonInfo.downdt) );
    memcpy (pDmonInfo.desc    , "ATOM SERVER PROCESS ", sizeof(pDmonInfo.desc));
    sprintf(pDmonInfo.reserved, "%d"   , getpid());
    memcpy(shmaddr          , &pDmonInfo, sizeof(pDmonInfo));

    detachShm(shmaddr);

    printf("atommain pid = [%s]\n", pDmonInfo.reserved);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : setMainDown                                                     */
/* SYNTAX   : int setMainDown()                                               */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : down ATOMMAIN process and set shared memory of stopping         */
/*----------------------------------------------------------------------------*/
int setMainDown()
{
    int  shmid = 0;
    char tdate[21] = {0x00, };
    s_daemoninfo *shmaddr = NULL;

    if ((shmid = accessShm(SHMKEY_DAEMON)) < 0)
    {
        shmid = createShm(SHMKEY_DAEMON, sizeof(s_daemoninfo));
        if (shmid == ABNORMAL) return ABNORMAL;
    }

    shmaddr = (s_daemoninfo *)attachShm(shmid, 0);
    if (shmaddr == (s_daemoninfo *)NULL) return ABNORMAL;

    memset(&pDmonInfo, 0x20, sizeof(pDmonInfo));
    memcpy(pDmonInfo.pidname, shmaddr->pidname, sizeof(pDmonInfo.pidname));
    memcpy(pDmonInfo.pstat  , "D"             , sizeof(pDmonInfo.pstat)  );
    memcpy(pDmonInfo.startdt, shmaddr->startdt, sizeof(pDmonInfo.startdt));
    memset(tdate, 0x00, sizeof(tdate));
    getDate(tdate);
    memcpy(pDmonInfo.downdt , tdate           , sizeof(pDmonInfo.downdt) );
    memcpy(pDmonInfo.desc   , "ATOM SERVER PROCESS ", sizeof(pDmonInfo.desc));
    memcpy(shmaddr          , &pDmonInfo, sizeof(pDmonInfo));

    detachShm(shmaddr);

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : initProc                                                        */
/* SYNTAX   : int initProc(int argc, char **argv)                             */
/* ARGUMENT : argc : argument count                                           */
/*            argv : argument                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : initialize process                                              */
/*----------------------------------------------------------------------------*/
int initProc(int argc, char **argv)
{
    char logfile[64+1] = {0x00, };
	char userid [10+1] = {0x00, };
	char passwd [10+1] = {0x00, };
	char sid    [20+1] = {0x00, };
	char errmsg [64+1] = {0x00, };
    int  ix = 0;

    /*-------------------------------------------------------------------*/
    /* initialize signal                                                 */
    /*-------------------------------------------------------------------*/
    sig_init();

    /*-------------------------------------------------------------------*/
    /* initialize variable                                               */
    /*-------------------------------------------------------------------*/
    memset(g_SERVERGB, 0x00, sizeof(g_SERVERGB));
    g_SERVERGB[0] = toupper(argv[1][0]);
    if ((g_SERVERGB[0] != 'A') && (g_SERVERGB[0] != 'B'))
    {
        fprintf(stderr, "<< Usage >> %s [A/B] &\n", argv[0]);
        fflush(stderr);
        exit (1);
    }

    /*-------------------------------------------------------------------*/
    /* Connect Database                                                  */
    /*-------------------------------------------------------------------*/
    if (DBConnect(userid, passwd, sid, errmsg) == ABNORMAL)
    {
        g_DBCONNECTGB = FALSE;
        fprintf(stderr, "DataBase connect ERROR  = [%d]\n", SQLCODE);
        fprintf(stderr, "DataBase connect ERROR  = [%s]\n", SQLMSG);
        fprintf(stderr, "DataBase connect userid = [%s]\n", userid);
        fprintf(stderr, "DataBase connect passwd = [%s]\n", passwd);
        fprintf(stderr, "DataBase connect sid    = [%s]\n", sid);
        fprintf(stderr, "DataBase connect errmsg = [%s]\n", errmsg);
        return ABNORMAL;
    }
    g_DBCONNECTGB = TRUE;

    /*-------------------------------------------------------------------*/
    /* Create Log File                                                   */
    /*-------------------------------------------------------------------*/
    snprintf(logfile, sizeof(logfile), "%s", g_PROCNAME);
    logfp = (FILE *)initLogFile(logfile, "a+");
    if (logfp == (FILE *)NULL)
    {
        if (UNIX_ERROR)
        {
            fprintf(stderr, "%s file open ERROR: %s\n", logfile);
            fflush(stderr);
            exit(1);
        }
    }

    logging(logfp, TRACE, "*************************************");
    logging(logfp, TRACE, "[%s] PROCESS START ...........OK!", g_PROCNAME);
    logging(logfp, TRACE, "*************************************");

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : initMsgQueue                                                    */
/* SYNTAX   : int initMsgQueue()                                              */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : Initialize Message Queue                                        */
/*----------------------------------------------------------------------------*/
int initMsgQueue()
{
    int qkey, qid, qsize = 0;

    /*-------------------------------------------------------------------*/
    /* Initialize Send Queue                                             */
    /*-------------------------------------------------------------------*/
    if (atoi(V_SVR_PROCESS.send_queue_key) > 0)
    {
        qkey  = atoi(V_SVR_PROCESS.send_queue_key);
        qsize = V_SVR_PROCESS.send_queue_size;
        if (qsize < MIN_QSIZE) qsize = MIN_QSIZE;
        qid   = setMsg(qkey, qsize);
        if (qid == ABNORMAL)  V_SVR_PROCESS.send_queue_id[0] = '0';
        else sprintf(V_SVR_PROCESS.send_queue_id, "%d", qid);
    }

    /*-------------------------------------------------------------------*/
    /* Initialize Receive Queue                                          */
    /*-------------------------------------------------------------------*/
    if (atoi(V_SVR_PROCESS.recv_queue_key) > 0)
    {
        qkey  = atoi(V_SVR_PROCESS.recv_queue_key);
        qsize = V_SVR_PROCESS.recv_queue_size;
        if (qsize < MIN_QSIZE) qsize = MIN_QSIZE;
        qid   = setMsg(qkey, qsize);
        if (qid == ABNORMAL) V_SVR_PROCESS.recv_queue_id[0] = '0';
        else sprintf(V_SVR_PROCESS.recv_queue_id, "%d", qid);
    }

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : sig_init                                                        */
/* SYNTAX   : void sig_init()                                                 */
/* ARGUMENT :                                                                 */
/* RETURN   :                                                                 */
/* PURPOSE  : initialize signal                                               */
/*----------------------------------------------------------------------------*/
void sig_init()
{
    signal(SIGHUP,    SIG_IGN    ); /* Hangup (01)                            */
    signal(SIGINT,    SIG_IGN    ); /* Interrupt (02)                         */
    signal(SIGTRAP,   SIG_IGN    ); /* Trace trap (05)                        */
    signal(SIGEMT ,   SIG_IGN    ); /* EMT instruction (07)                   */
    signal(SIGFPE ,   SIG_IGN    ); /* Floating point exception (08)          */
    signal(SIGALRM,   SIG_IGN    ); /* Alarm Clock (14)                       */
    signal(SIGCHLD,   SIG_IGN    ); /* Child proc. terminated or stopped(18)  */
    signal(SIGTSTP,   SIG_IGN    ); /* Interactive stop signal (25)           */
    signal(SIGCONT,   SIG_IGN    ); /* Continue if stopped (26)               */
    signal(SIGTTIN,   SIG_IGN    ); /* Read from control terminal (27)        */
    signal(SIGTTOU,   SIG_IGN    ); /* Write to control terminal (28)         */
    signal(SIGURG ,   SIG_IGN    ); /* urgent condition on IO channel (29)    */
    signal(SIGQUIT,   proc_end1  ); /* Quit (03)                              */
    signal(SIGILL ,   proc_end2  ); /* Illegal instruction (04)               */
    signal(SIGABRT,   proc_end3  ); /* Process abort (06)                     */
    signal(SIGBUS ,   proc_end4  ); /* Bus error (10)                         */
    signal(SIGSEGV,   proc_end5  ); /* Segmentation Violation (11)            */
    signal(SIGSYS ,   proc_end6  ); /* Bad argument to system call (12)       */
    signal(SIGPIPE,   proc_end7  ); /* Pipe error (13) Closing Socket Write   */
    signal(SIGTERM,   proc_end8  ); /* SW termination signal from kill (15)   */
    signal(SIGIO  ,   proc_end9  ); /* asynchronous I/O (22)                  */
    signal(SIGSTOP,   proc_enda  ); /* Stop signal (24)                       */
    signal(SIGKILL,   proc_endb  ); /* Process Closing Signal                 */
    signal(SIGCHLD,   clean_zombie);/* Child proc. terminated or stopped(18)  */
    signal(SIGUSR1,   proc_endc  ); /* User Signal 1 (16) : Process down      */
    signal(SIGUSR2,   SIG_IGN    ); /* User Signal 2 (17) : reserved          */
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : clean_zombie                                                    */
/* SYNTAX   : void clean_zombie(int signo)                                    */
/* ARGUMENT : signo : signal no                                               */
/* RETURN   :                                                                 */
/* PURPOSE  : Clear zombie process                                            */
/*----------------------------------------------------------------------------*/
void clean_zombie(int signo)
{
    int status = 0;

    waitpid(-1, &status, WNOHANG);
    signal(SIGCHLD, clean_zombie);
    sighold(SIGCHLD);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : proc_end                                                        */
/* SYNTAX   : void proc_end()                                                 */
/* ARGUMENT :                                                                 */
/* RETURN   : NORMAL : OK   ABNORMAL : NOK                                    */
/* PURPOSE  : Processing down process                                         */
/*----------------------------------------------------------------------------*/
void proc_end()
{

    /*-------------------------------------------------------------------*/
    /* set down flag of atommain process                                 */
    /*-------------------------------------------------------------------*/
    if (!memcmp(g_PROCNAME, "atommain", sizeof(g_PROCNAME)-1))
    {
        logging(logfp, TRACE, "proc_end()..1");

        if (setMainDown() == ABNORMAL)
        {
            if (logfp) logging(logfp, ERROR, "setMainDown() : ERROR");
            else
            {
                fprintf(stderr, "setMainDown() : ERROR");
                fflush(stderr);
            }
        }
        logging(logfp, TRACE, "proc_end()..2");
    }

    if (g_DBCONNECTGB) DBDisconnect();
        logging(logfp, TRACE, "proc_end()..3");

    if (logfp)
    {
        logging(logfp, TRACE, "*************************************");
        logging(logfp, TRACE, "[%s] PROCESS END ...........OK!", g_PROCNAME);
        logging(logfp, TRACE, "*************************************");
        fclose(logfp);
    }

    exit(0);
}

void proc_end1()
{
    logging(logfp, ERROR, "proc_end1");
    logging(logfp, ERROR, "proc_end1:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end2()
{
    logging(logfp, ERROR, "proc_end2");
    logging(logfp, ERROR, "proc_end2:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end3()
{
    logging(logfp, ERROR, "proc_end3");
    logging(logfp, ERROR, "proc_end3:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end4()
{
    logging(logfp, ERROR, "proc_end4");
    logging(logfp, ERROR, "proc_end4:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end5()
{
    logging(logfp, ERROR, "proc_end5");
    logging(logfp, ERROR, "proc_end5:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end6()
{
    logging(logfp, ERROR, "proc_end6");
    logging(logfp, ERROR, "proc_end6:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end7()
{
    logging(logfp, ERROR, "proc_end7");
    logging(logfp, ERROR, "proc_end7:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end8()
{
    logging(logfp, ERROR, "proc_end8");
    logging(logfp, ERROR, "proc_end8:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_end9()
{
    logging(logfp, ERROR, "proc_end9");
    logging(logfp, ERROR, "proc_end9:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_enda()
{
    logging(logfp, ERROR, "proc_enda");
    logging(logfp, ERROR, "proc_enda:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_endb()
{
    logging(logfp, ERROR, "proc_endb");
    logging(logfp, ERROR, "proc_endb:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

void proc_endc()
{
    logging(logfp, ERROR, "proc_endc");
    logging(logfp, ERROR, "proc_endc:[%d][%s]", errno, UNIX_ERRMSG);
    proc_end();
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/

#line 469 "atom_initproc.ec"
