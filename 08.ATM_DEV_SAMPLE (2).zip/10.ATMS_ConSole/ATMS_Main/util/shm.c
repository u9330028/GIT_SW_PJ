/*============================================================================*/
/* Program Name: shm.c                                                        */
/* Execute File: libutil.a                                                    */
/* Function    : Shared Memory Interface Library                              */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.01.21    SHLEE            First Ver                    */
/*============================================================================*/
#include "defcom.h"
#include "shm.h"

/*----------------------------------------------------------------------------*/
/* FUNCTION : accessShm                                                       */
/* SYNTAX   : int accessShm(key_t shmkey)                                     */
/* ARGUMENT : shmkey : shared memory key                                      */
/* RETURN   : NORMAL : SHM ID  ABNORMAL : NOK                                 */
/* PURPOSE  : Get shared memory id                                            */
/*----------------------------------------------------------------------------*/
int accessShm(key_t shmkey)
{
    int shmid = 0;

#if (!defined(WIN32) && !defined(_WIN32))
    shmid = shmget(shmkey,0,SHMPERM|IPC_EXCL);

    if (shmid < 0) return ABNORMAL;
#else
	HANDLE HFileMapping;
	char s_shmkey[128]={0,};
	int size=1024000;

	memset(s_shmkey,0,sizeof(s_shmkey));
	sprintf(s_shmkey,"SHM%d",shmkey);


	HFileMapping = OpenFileMapping( 
		FILE_MAP_ALL_ACCESS,
		0, s_shmkey); 

	if(HFileMapping != NULL)
	{
		if(GetLastError() == ERROR_ALREADY_EXISTS)
		{
			printf("SHARE MEMORY ALREADY CREATED : %s\n", s_shmkey);
			//CloseHandle(HFileMapping);
			//return 1;
		}
	}
	else
	{
		printf("OpenFileMapping : error, %s\n", strerror(GetLastError()));
		return -1;
	}

	//ptr = (char *) MapViewOfFile(HFileMapping,FILE_MAP_WRITE,0,0,0);

	shmid = shmkey;
#endif
    return shmid; 
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : createShm                                                       */
/* SYNTAX   : int createShm(key_t shmkey, int shmsize)                        */
/* ARGUMENT : shmkey : shared memory key                                      */
/*          : shmsize: shared memory size                                     */
/* RETURN   : NORMAL : SHM ID   ABNORMAL : NOK                                */
/* PURPOSE  : Create shared memory                                            */
/*----------------------------------------------------------------------------*/
int createShm(key_t shmkey, int shmsize)
{
    int              shmid;
    char            *shmaddr;


#if (!defined(WIN32) && !defined(_WIN32))
    struct shmid_ds  shmid_ds;

    /*-------------------------------------------------------------------*/
    /* If exist, return shared memory id                                 */
    /*-------------------------------------------------------------------*/
    if ((shmid = accessShm(shmkey)) > 0) return shmid;

    /*-------------------------------------------------------------------*/
    /* Check shared memory size                                          */
    /*-------------------------------------------------------------------*/
    if (shmsize <= 0) return ABNORMAL;

    /*-------------------------------------------------------------------*/
    /* Create shared memory                                              */
    /*-------------------------------------------------------------------*/
    if ((shmid = shmget(shmkey, shmsize, SHMPERM | IPC_CREAT)) < 0) 
        return ABNORMAL;

    /*-------------------------------------------------------------------*/
    /* Attach shared memory                                              */
    /*-------------------------------------------------------------------*/
    shmaddr = attachShm(shmid,0);
    if (shmaddr == (char *)NULL) return ABNORMAL;

    /*-------------------------------------------------------------------*/
    /* Initialize shared memory                                          */ 
    /*-------------------------------------------------------------------*/
    memset(shmaddr, 0x20, shmsize);

    /*-------------------------------------------------------------------*/
    /* Detach shared memory                                              */ 
    /*-------------------------------------------------------------------*/
    if (detachShm(shmaddr) == ABNORMAL) return ABNORMAL;

    return shmid;
#else
	HANDLE HFileMapping;
	char s_shmkey[128]={0,};

	int size=1024000;
	void *ptr;

	memset(s_shmkey,0,sizeof(s_shmkey));
	sprintf(s_shmkey,"SHM%d",shmkey);

	HFileMapping = CreateFileMapping
	((HANDLE) 0xFFFFFFFF,
	(LPSECURITY_ATTRIBUTES) NULL,
	PAGE_READWRITE,
	0, size, s_shmkey);

	if(HFileMapping != NULL)
	{
		if(GetLastError() == ERROR_ALREADY_EXISTS)
		{
			printf("SHARE MEMORY ALREADY CREATED : %s\n", s_shmkey);
			//CloseHandle(HFileMapping);
			//return 1;
		}
	}

	//ptr = (char *) MapViewOfFile(HFileMapping,FILE_MAP_WRITE,0,0,0);

	return shmkey;
#endif
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : attachShm                                                       */
/* SYNTAX   : char *attachShm(int shmid, int shmmode)                         */
/* ARGUMENT : shmid  : shm id                                                 */
/*          : shmmode: attach mode                                            */
/* RETURN   : NORMAL : �����޸��� �ּ�,   ���� : (char *)ABNORMALL          */
/* PURPOSE  : Attach shared memory                                            */
/*----------------------------------------------------------------------------*/
char *attachShm(int shmid, int shmmode)
{
    void            *ptr      ;

#if (!defined(WIN32) && !defined(_WIN32))

    struct shmid_ds  shmid_ds;

    /*-------------------------------------------------------------------*/
    /* Check shared memroy id                                            */
    /*-------------------------------------------------------------------*/
	if (shmctl(shmid,IPC_STAT,&shmid_ds) < 0) return ((char *)NULL);

    if (shmmode == SHM_RDONLY) ptr = shmat(shmid,(void *)NULL,shmmode);
    else                       ptr = shmat(shmid,(void *)NULL,0);

#else
	HANDLE HFileMapping;
	char s_shmkey[128]={0,};

	key_t shmkey;
	shmkey=shmid;

	memset(s_shmkey,0,sizeof(s_shmkey));
	sprintf(s_shmkey,"SHM%d",shmkey);

	HFileMapping = OpenFileMapping( 
		FILE_MAP_ALL_ACCESS,
		0, s_shmkey); 
	if(HFileMapping == NULL)
	{
		return (char *)NULL;
	}

	printf("attachShm : call MapViewOfFile\n");
	ptr = (char *) MapViewOfFile(HFileMapping,FILE_MAP_WRITE,0,0,0);
	printf("attachShm : after MapViewOfFile\n");
#endif

    if (ptr == (void *)-1) return ((char *)NULL);
    return ((char *)ptr);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : detachShm                                                       */
/* SYNTAX   : int detachShm(char *ptr)                                        */
/* ARGUMENT : ptr : shared memory address                                     */
/* RETURN   : NORMAL / ABNORMALL                                              */
/* PURPOSE  : Detach shared memory                                            */
/*----------------------------------------------------------------------------*/
int detachShm(char *ptr)
{
#if (!defined(WIN32) && !defined(_WIN32))
    if (shmdt(ptr) < 0) return ABNORMAL;
#endif

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : delShm                                                          */
/* SYNTAX   : int delShm(key_t shmkey)                                        */
/* ARGUMENT : shmkey : shm key                                                */
/* RETURN   : NORMAL / ABNORMALL                                              */
/* PURPOSE  : Remove shared memory                                            */
/*----------------------------------------------------------------------------*/
int delShm(key_t shmkey)
{
    int shmid;
#if (!defined(WIN32) && !defined(_WIN32))
    if ((shmid = accessShm(shmkey)) < 0) return ABNORMAL;

    if (shmctl(shmid,IPC_RMID,0) < 0) return ABNORMAL;
#endif
    return NORMAL;
} 

/*----------------------------------------------------------------------------*/
/* FUNCTION : statShm                                                         */
/* SYNTAX   : int statShm(int shmid, struct shmid_ds *shminfo)                */
/* ARGUMENT : shmid  : shm id  (I)                                            */
/*            shminfo: shm info(O)                                            */
/* RETURN   : NORMAL : shm addr,   ABNORMAL : NOK                             */
/* PURPOSE  : Get current status of shared memory                             */
/*----------------------------------------------------------------------------*/
int statShm(int shmid, struct shmid_ds *shminfo)
{
#if (!defined(WIN32) && !defined(_WIN32))
    if (shmctl(shmid,IPC_STAT,shminfo) < 0) return ABNORMAL;
#endif
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
