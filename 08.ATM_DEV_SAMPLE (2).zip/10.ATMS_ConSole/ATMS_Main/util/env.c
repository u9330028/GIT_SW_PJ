/*============================================================================*/
/* Program Name: env.c                                                        */
/* Execute File: libutil.a                                                    */
/* Function    : Environ Variable Loading Library                             */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.01.21    SHLEE            First Ver                    */
/*============================================================================*/
#include "defcom.h"
#include "env.h"

/*----------------------------------------------------------------------------*/
/* FUNCTION : loadEnvInt                                                      */
/* SYNTAX   : int loadEnvInt(char *fppath, char *envkey, int  *envval)        */
/* ARGUMENT : fppath : File Path  (I)                                         */
/*          : envkey : File Key   (I)                                         */
/*          : envval : Key Value  (O)                                         */
/* RETURN   : NORMAL : OK  ABNORMAL : NOK                                     */
/* PURPOSE  : Environment variables loading to process type of integer        */
/*----------------------------------------------------------------------------*/
int loadEnvInt(char *fppath, char *envkey, int  *envval)
{
    FILE *envfp = NULL;
    char buf[128], tmp[128];
    int  ix;

    if ((envfp = fopen(fppath, "r")) == (FILE *)NULL) return ABNORMAL;

    memset(buf, 0x00, sizeof(buf));
    while (fgets(buf, sizeof(buf), envfp) != NULL)
    {
        /* Skip COMMENT */
        if (buf[0] == '#') continue;

        /* Remove space */
        if ((trimString(buf)) <= 0) continue;
        if (buf[0] == '[') continue;

        for (ix = 0; buf[ix] != 0; ix++)
        {
            if( buf[ix] == '=' )
            {
                if (!memcmp(buf, envkey, ix))
                {
                    sprintf(tmp, "%s", &buf[ix+1]);
                    tmp[strlen(tmp)] = 0x00;
                    *envval = atoi(tmp);
                    fclose(envfp);
                    return NORMAL;
                }
            }
        }
    }
    fclose(envfp);
    return ABNORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : loadEnvStr                                                      */
/* SYNTAX   : int loadEnvStr(char *fppath, char *envkey, char  *envval)       */
/* ARGUMENT : fppath : File Path  (I)                                         */
/*          : envkey : File Key   (I)                                         */
/*          : envval : Key Value  (O)                                         */
/* RETURN   : NORMAL : OK  ABNORMAL : NOK                                     */
/* PURPOSE  : Environment variables loading to process type of string         */
/*----------------------------------------------------------------------------*/
int loadEnvStr(char *fppath, char *envkey, char  *envval)
{
    FILE *envfp = NULL;
    char buf[128] = {0x00, };
    int  ix;

    if ((envfp = fopen(fppath, "r")) == (FILE *)NULL) return ABNORMAL;

    while (fgets(buf, sizeof(buf), envfp) != NULL)
    {
        /* Skip COMMENT */
        if (buf[0] == '#') continue;

        /* Remove space */
        if ((trimString(buf)) <= 0) continue;
        if (buf[0] == '[') continue;

        for (ix = 0; buf[ix] != 0; ix++)
        {
            if( buf[ix] == '=' )
            {
                if (!memcmp(buf, envkey, ix))
                {
                    sprintf(envval, "%s", &buf[ix+1]);
                    envval[strlen(envval)] = 0x00;
                    fclose(envfp);
                    return NORMAL;
                }
            }
        }
    }
    fclose(envfp);
    return ABNORMAL;
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
