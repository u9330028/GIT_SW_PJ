/*============================================================================*/
/* Program Name: string.c                                                     */
/* Execute File: libutil.a                                                    */
/* Function    : String Interface Library                                     */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.06.21    SHLEE            First Ver                    */
/*============================================================================*/
#include "defcom.h"


/*----------------------------------------------------------------------------*/
/* FUNCTION : getDate                                                         */
/* SYNTAX   : int getDate(char *tdate)                                        */
/* ARGUMENT : tdate  : date                                                   */
/* RETURN   : NORMAL : OK  ABNORMAL : NOK                                     */
/* PURPOSE  : Get date(YYYYMMDDHHMMSS)                                        */
/*----------------------------------------------------------------------------*/
int getDate(char *tdate)
{
    time_t t_clock;
    struct tm *t;

    t_clock = time(0);
    t = (struct tm *)localtime(&t_clock);
    sprintf(tdate, "%4d%02d%02d%02d%02d%02d", t->tm_year+1900, t->tm_mon + 1,
                   t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : trimString                                                      */
/* SYNTAX   : int trimString(char *instr)                                     */
/* ARGUMENT : instr : conversion string in/out                                */
/* RETURN   : NORMAL : string length / ABNORMAL                               */
/* PURPOSE  : Remove space                                                    */
/*----------------------------------------------------------------------------*/
int trimString(char *instr)
{
    int len, i, j;

    len = strlen(instr);
    j = 0;
    for(i=0; i<len; i++)
    {
        switch(instr[i])
        {
            case ' ' :
            case '\t':
            case '\r':
            case '\n':
            case '\b':
                 continue;
            default  :
                 instr[j] = instr[i];
                 j++;
        }
    }
    instr[j] = 0x00;

    return (strlen(instr));
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : ltrimString                                                     */
/* SYNTAX   : int ltrimString(char *instr)                                    */
/* ARGUMENT : instr : conversion string in/out                                */
/* RETURN   : NORMAL : string length / ABNORMAL                               */
/* PURPOSE  : Remove left space                                               */
/*----------------------------------------------------------------------------*/
int ltrimString(char *instr)
{
    int len, i, j;

    len = strlen(instr);
    for(i = 0; i < len; i++)
    {
        if(instr[i] != ' ') break;
    }

    for(j = i; j < len; j++)
    {
        instr[j-i] = instr[j];
    }
    instr[j-i] = 0x00;

    return (strlen(instr));
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : rtrimString                                                     */
/* SYNTAX   : int rtrimString(char *instr)                                    */
/* ARGUMENT : instr : conversion string in/out                                */
/* RETURN   : NORMAL : string length / ABNORMAL                               */
/* PURPOSE  : Remove right space                                              */
/*----------------------------------------------------------------------------*/
int rtrimString(char *instr)
{
    int   len, i;

    len = strlen(instr);
    for(i = len-1; i >= 0; i--)
    {
        if(instr[i] != ' ') break;
    }
    instr[i+1] = 0x00;

    return (strlen(instr));
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : str2int                                                         */
/* SYNTAX   : int str2int(char *strVal, int strLeng)                          */
/* ARGUMENT : strVal : conversion string                                      */
/*          : strLeng: conversion length                                      */
/* RETURN   : NORMAL : conversion int / ABNORMAL                              */
/* PURPOSE  : Convert string to integer                                       */
/*----------------------------------------------------------------------------*/
int str2int(char *strVal, int strLeng)
{
    char temp[10] = {0x00, };
    int  convNum  = 0;
    int  i;

    for ( i = 0; i < strLeng; i++ ){
        if ( !isdigit( strVal[i] ) && strVal[i] != '-' && strVal[i] != ' ' )
            return ABNORMAL;
    }

    sprintf(temp, "%.*s", strLeng, strVal);

    convNum = atoi(temp);

    return (convNum);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : str2double                                                      */
/* SYNTAX   : int str2double(char *strVal, int strLeng)                       */
/* ARGUMENT : strVal : conversion string                                      */
/*          : strLeng: conversion length                                      */
/* RETURN   : NORMAL : conversion double / ABNORMAL                           */
/* PURPOSE  : Convert string to double Number                                 */
/*----------------------------------------------------------------------------*/
double str2double(char *strVal, int strLeng)
{
    char   temp[20] = {0x00, };
    double convNum  = 0;
    int  i;

    for ( i = 0; i < strLeng; i++ ){
        if ( !isdigit( strVal[i] ) && strVal[i] != '-' && strVal[i] != ' ' )
            return ABNORMAL;
    }

    sprintf(temp, "%.*s", strLeng, strVal);

    convNum = atof(temp);

    return (convNum);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : getFileSize                                                     */
/* SYNTAX   : long getFileSize(FILE *filefp)                                  */
/* ARGUMENT : filefp  : file fd                                               */
/* RETURN   : NORMAL  : file length                                           */
/* PURPOSE  : Get file size                                                   */
/*----------------------------------------------------------------------------*/
long getFileSize(FILE *filefp)
{
    long length = 0L;

    ftell(filefp);
    fseek(filefp, 0L, SEEK_END);
    length = ftell(filefp);
    fseek(filefp, 0L, SEEK_SET);

    return length;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : ip2long                                                         */
/* SYNTAX   : int ip2long(char *instr)                                        */
/* ARGUMENT : instr : conversion string in/out (ip address -> long)           */
/* RETURN   : ���� : string length                                            */
/* PURPOSE  : ip address -> long                                              */
/*----------------------------------------------------------------------------*/
int ip2long(char *instr)
{
    int     len, i, j;
    int     nip = 0;
    char    cip[ 4] = {0x00, };
    char    tmp[16] = {0x00, };

    len = strlen(instr);
    strcpy(tmp, instr);
    memset(instr, 0x00, sizeof(tmp)-1);
    
    j = 0;
    for (i=0; i<len; i++)
    {
        switch(tmp[i])
        {
            case '\t':
            case '\r':
            case '\n':
            case '\b':
            case '.':
                 j = 0;
                 nip = atoi(cip);
                 sprintf(cip, "%03d", nip);
                 strcat(instr, cip);
                 memset(cip, 0x00, sizeof(cip));
                 continue;
            case ' ' :
                break;
            default  :
                 cip[j] = tmp[i];
                 j++;
        }
    }
    sprintf(tmp, "%03d", nip = atoi(cip));
    strcat(instr, tmp);
    instr[strlen(instr)+1] = 0x00;

    return (strlen(instr));
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : createNewFile                                                   */
/* SYNTAX   : createNewFile(char *fpath, char *mode)                          */
/* ARGUMENT : fpath  : file path (I)                                          */
/*            mode   : file mode (I)                                          */
/* RETURN   : NORMAL : file pointer ABNORMAL : NOK                            */
/* PURPOSE  : Create file including upper directory                           */
/*----------------------------------------------------------------------------*/
FILE *createNewFile(char *fpath, char *mode)
{
    FILE *newfp     = NULL;
    char instr[128] = {0x00, };
    int  nLoop      = 0;

    for (nLoop=1; nLoop < strlen(fpath); nLoop++)
    {
// modify by Yong : 2008-11-27 ���� 1:22:41
#if !(defined(WIN32)||defined(_WIN32))
        if (fpath[nLoop] == '/')
#else
		if (fpath[nLoop] == '/' ||fpath[nLoop] == '\\')
#endif
        {
            sprintf(instr, "%.*s", nLoop, fpath);
#if (!defined(WIN32) && !defined(_WIN32))
            errno = 0;
#endif
            /*-----------------------------------------------------------*/
            /* Make directory                                            */
            /*-----------------------------------------------------------*/
            if (mkdir(instr, 0750))
            {
                if (errno != 0 && errno != EEXIST) /* exist?? */
                { 
                    return (FILE *)NULL;
                }   
            }
        }
    }

    /*-------------------------------------------------------------------*/
    /* Open file                                                         */
    /*-------------------------------------------------------------------*/
    if ((newfp = fopen(fpath, mode)) == NULL)
    {
        newfp = (FILE *)NULL;
    }

    return newfp;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : getStrValue                                                     */
/* SYNTAX   : getStrValue(char *path, char *str)                              */
/* ARGUMENT : path   : file path        (I)                                   */
/*            str    : search string    (I)                                   */
/* RETURN   : NORMAL : string ABNORMAL : NULL                                 */
/* PURPOSE  : str ������ �ش��ϴ� ���ڿ� ��                                   */
/*----------------------------------------------------------------------------*/
int getStrValue(char *path, char *str, char *strval)
{
    FILE *fp = NULL;
    char buff[64+1] = {0x00, };
    int idx = 0;
    int ix = 0;

    if ((fp = fopen(path, "r")) == (FILE *)NULL)
    {
        printf("err=[%s]\n", UNIX_ERRMSG);
        return ABNORMAL;
    }

    while (fgets(buff, sizeof(buff), fp) != NULL)
    {
        if (buff[0] == '#') continue;

        if (!memcmp(&buff[0], str, strlen(str)))
        {
            buff[strlen(buff)-1] = 0x00;
            idx = strlen(str);
            while (buff[idx++] != 0x00)
            {
                if (buff[idx] == '=') continue;

                strval[ix] = buff[idx];
                ix++;
            }
            break;
        }
    }

    fclose(fp);
    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : checkTimeFormat                                                 */
/* SYNTAX   : int checkTimeFormat(char *stime)                                */
/* ARGUMENT : stime  : time (HHMMSS)                                          */
/* RETURN   : NORMAL : OK  ABNORMAL : NOK                                     */
/* PURPOSE  : Check time format (HHMMSS)                                      */
/*----------------------------------------------------------------------------*/
int checkTimeFormat(char *stime)
{
    /* 6�ڸ��̰� 240000���� ũ�ų� ������ 235959�� ��ȯ */
    if (strlen(stime) >= 6 && memcmp(stime, "240000", 6) >= 0)
        memcpy(stime, "235959", 6);

    /* �ð� 23���� ũ�� 23���� ��ȯ */
    if (strlen(stime) >= 2)
        if (memcmp(stime, "23", 2) > 0)
            memcpy(stime, "23", 2);

    /* ���� 59���� ũ�� 59�� ��ȯ */
    if (strlen(stime) >= 4)
        if (memcmp(stime+2, "59", 2) > 0)
            memcpy(stime+2, "59", 2);

    /* �ʰ� 59���� ũ�� 59�� ��ȯ */
    if (strlen(stime) >= 6)
        if (memcmp(stime+4, "59", 2) > 0)
            memcpy(stime+4, "59", 2);

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : f_GetElapsetime                                                 */
/* SYNTAX   : int f_GetElapsetime(csdate, stime, edate, etime)                */
/* ARGUMENT : sdate  : �������� (YYYYMMDD)                                    */
/*            stime  : ���۽ð� (HHMMSS)                                      */
/*            edate  : �������� (YYYYMMDD)                                    */
/*            etime  : ����ð� (HHMMSS)                                      */
/* RETURN   : NORMAL : OK  ABNORMAL : NOK                                     */
/* PURPOSE  : �����Ͻÿ� �����Ͻ��� �ð� ���� ���(��)                        */
/*----------------------------------------------------------------------------*/
double f_GetElapsetime(char *sdate, char *stime, char *edate, char *etime)
{
    struct tm tm_check;
    time_t tm_start;
    time_t tm_end;
    char tmp[4+1] = {0x00, };
    double diff_time = 0;


    sprintf(tmp, "%.4s", &sdate[0]);
    tm_check.tm_year   = atoi(tmp) - 1900;   /* start year 1900 */
    sprintf(tmp, "%.2s", &sdate[4]);
    tm_check.tm_mon    = atoi(tmp) - 1;      /* start month 0 */
    sprintf(tmp, "%.2s", &sdate[6]);
    tm_check.tm_mday   = atoi(tmp);
    sprintf(tmp, "%.2s", &stime[0]);
    tm_check.tm_hour   = atoi(tmp);
    sprintf(tmp, "%.2s", &stime[2]);
    tm_check.tm_min    = atoi(tmp);
    sprintf(tmp, "%.2s", &stime[4]);
    tm_check.tm_sec    = atoi(tmp);
    tm_check.tm_isdst  = 0;                  /* summer time not used */
    /* ���۽ð� ��� */
    tm_start = mktime(&tm_check);

    memset(&tm_check, 0x00, sizeof(tm_check));
    sprintf(tmp, "%.4s", &edate[0]);
    tm_check.tm_year   = atoi(tmp) - 1900;   /* start year 1900 */
    sprintf(tmp, "%.2s", &edate[4]);
    tm_check.tm_mon    = atoi(tmp) - 1;      /* start month 0 */
    sprintf(tmp, "%.2s", &edate[6]);
    tm_check.tm_mday   = atoi(tmp);
    sprintf(tmp, "%.2s", &etime[0]);
    tm_check.tm_hour   = atoi(tmp);
    sprintf(tmp, "%.2s", &etime[2]);
    tm_check.tm_min    = atoi(tmp);
    sprintf(tmp, "%.2s", &etime[4]);
    tm_check.tm_sec    = atoi(tmp);
    tm_check.tm_isdst  = 0;                  /* summer time not used */
    /* ����ð� ��� */
    tm_end = mktime(&tm_check);

    diff_time = difftime(tm_end, tm_start);

    return diff_time;
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
