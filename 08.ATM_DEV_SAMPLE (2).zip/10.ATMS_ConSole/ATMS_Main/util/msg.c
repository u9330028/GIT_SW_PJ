/*============================================================================*/
/* Program Name: msg.c                                                        */
/* Execute File: libutil.a                                                    */
/* Function    : Message Queue Interface Library                              */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.01.21    SHLEE            First Ver                    */
/*============================================================================*/
#include "defcom.h"
#include "msg.h"

/*----------------------------------------------------------------------------*/
/* FUNCTION : clsMsg                                                          */
/* SYNTAX   : int clsMsg(int qid)                                             */
/* ARGUMENT : qid    : Message Queue Id.                                      */
/* RETURN   : NORMAL : OK (Length of clear data)  ABNORMAL : NOK              */
/* PURPOSE  : Initialize Message Queue                                        */
/*----------------------------------------------------------------------------*/
int clsMsg(int qid)
{
    int               stat;
    int               cls_size = 0;
    msgf              msgf_rd;
    struct msqid_ds   msqid_ds;

    if (msgctl (qid, IPC_STAT, (struct msqid_ds *) &msqid_ds) != 0)
    {
        return ABNORMAL;
    }

    do
    {
        msgf_rd.msg_type = 0;
        stat = msgrcv (qid,&msgf_rd,MAXMSGDATA,msgf_rd.msg_type,IPC_NOWAIT);
        if (stat < 0) stat = 0;
        cls_size += stat;
    } while (stat);

    return (cls_size);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : setMsg                                                          */
/* SYNTAX   : int setMsg(int qkey, int qsize)                                 */
/* ARGUMENT : qkey : queue key(queue number (ket_t))                          */
/*            qsize: queue size(queue size)                                   */
/* RETURN   : NORMAL : Queue id,  ABNORMAL : NOK                              */
/* PURPOSE  : Create Message Queue (If exist, return Queue ID)                */
/*----------------------------------------------------------------------------*/
int setMsg (int qkey, int qsize)
{
    int    qid, ctl_rt;
    struct msqid_ds msqid_ds;

    /*-------------------------------------------------------------------*/
    /* if exist, return queue id else create message queue               */
    /*-------------------------------------------------------------------*/
    if ((qid = msgget(qkey, IPC_ALLOC | PERM)) == -1)
    {
        if ((qid = msgget(qkey, PERM | IPC_CREAT | IPC_EXCL)) < 0)
            return ABNORMAL;
    } 
    else
    {
        return (qid);
    }

    /*-------------------------------------------------------------------*/
    /* Get Message Queue status                                          */
    /*-------------------------------------------------------------------*/
    ctl_rt = msgctl (qid, IPC_STAT, (struct msqid_ds *) &msqid_ds);
    if (ctl_rt != 0) return ABNORMAL;

    if ((msqid_ds.msg_qbytes > qsize) && (qsize > 0))
    {
        msqid_ds.msg_qbytes = qsize;

        ctl_rt = msgctl (qid, IPC_SET, (struct msqid_ds *) &msqid_ds);
        if (ctl_rt != 0) return ABNORMAL;
    }

    return (qid);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : delMsg                                                          */
/* SYNTAX   : int delMsg(int qid, int qkey)                                   */
/* ARGUMENT : qid  : queue id  value                                          */
/*            qkey : queue key value                                          */
/* RETURN   : NORMAL : Queue id,  ABNORMAL : NOK                              */
/* PURPOSE  : Remove Message Queue by queue id and queue key                  */
/*----------------------------------------------------------------------------*/
int delMsg (int qid, int qkey)
{
    if ((qid == 0) && (qkey > 0))
    {
        if ((qid = msgget (qkey, PERM)) < 0)
        {
            return ABNORMAL;
        }
    }

    if (msgctl (qid, IPC_RMID, (struct msqid_ds *) 0) != 0) return ABNORMAL;

    return (qid);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : putMsg                                                          */
/* SYNTAX   : int putMsg(int qid, long owner, char *buff, int w_size)         */
/* ARGUMENT : qid    : Message Queue Id.                                      */
/*          : owner  : Message Type                                           */
/*          : buff   : Transaction Message buffer                             */
/*          : w_size : Queue Size                                             */
/* RETURN   : NORMAL : Length of sending Data,  ABNORMAL : NOK                */
/* PURPOSE  : Send Data in message queue by nowait mode                       */
/*----------------------------------------------------------------------------*/
int  putMsg(int qid, long owner, char *buff, int w_size)
{
    int    w_ret;
    msgf   msgf_wr;
    struct msqid_ds msqid_ds;

    msgf_wr.msg_type = owner;
    memset(msgf_wr.msg_data, 0x00, sizeof(msgf_wr.msg_data));
    memcpy(msgf_wr.msg_data, buff, w_size                  );

    /*-------------------------------------------------------------------*/
    /* Get current status of message queue                               */
    /*-------------------------------------------------------------------*/
    if (msgctl(qid, IPC_STAT, (struct msqid_ds *) &msqid_ds) != 0)
    {
        return ABNORMAL;
    }

    /*-------------------------------------------------------------------*/
    /* Check a Queue of full status                                      */
    /*-------------------------------------------------------------------*/
    if ((msqid_ds.msg_qbytes - msqid_ds.msg_cbytes) < w_size)
    {
        return ABNORMAL;
    }

    /*-------------------------------------------------------------------*/
    /* Send data in message queue                                        */
    /*-------------------------------------------------------------------*/
// modify by Yong : 2008-12-01 ���� 10:23:30
#if !(defined(WIN32)||defined(_WIN32))
	    w_ret = msgsnd(qid, &msgf_wr, w_size, IPC_NOWAIT);	
#else
	    w_ret = msgsnd(qid, &msgf_wr, w_size+4, IPC_NOWAIT);		
#endif
    if (w_ret != 0)
    {
        return ABNORMAL;
    }

    return (w_size);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : putMsg_wait                                                     */
/* SYNTAX   : int putMsg_wait(int qid, long owner, char *buff, int w_size,    */
/*          :                 int trytm)                                      */
/* ARGUMENT : qid    : Message Queue Id.                                      */
/*          : owner  : Message Type                                           */
/*          : buff   : Transaction Message buffer                             */
/*          : w_size : Queue Size                                             */
/*          : trytm  : Delay retry time(sec)                                  */
/* RETURN   : NORMAL : Length of sending Data  ,  ABNORMAL : NOK              */
/* PURPOSE  : Send Data in message queue by nowait mode                       */
/*          : if queue is full, retry per 0.2 seconds by trytm count          */
/*----------------------------------------------------------------------------*/
int  putMsg_wait(int qid, long owner, char *buff, int w_size, int trytm)
{
    int    w_ret = 0;
    int    cnt   = 0;
    int    ix, iy;
    msgf   msgf_wr;
    struct msqid_ds msqid_ds;

    msgf_wr.msg_type = owner;
    memset(msgf_wr.msg_data, 0x00, sizeof(msgf_wr.msg_data));
    memcpy(msgf_wr.msg_data, buff, w_size                  );

    cnt = trytm;
    for (ix = 0, iy = -1; ix < cnt; ix++)
    {
        /*---------------------------------------------------------------*/
        /* Get current status of message queue                           */
        /*---------------------------------------------------------------*/
        if (msgctl(qid, IPC_STAT, (struct msqid_ds *) &msqid_ds) != 0)
        {
            continue;
            /*return ABNORMAL;*/
        }

        /*---------------------------------------------------------------*/
        /* Check a Queue of full status                                  */
        /*---------------------------------------------------------------*/
        if ((msqid_ds.msg_qbytes - msqid_ds.msg_cbytes) < w_size)
        {
            usleep(200000);
            continue;
        }

        /*---------------------------------------------------------------*/
        /* Send data in message queue                                    */
        /*---------------------------------------------------------------*/
        w_ret = msgsnd(qid, &msgf_wr, w_size, IPC_NOWAIT);

        if (w_ret != 0)
        {
            if (errno == 11)
            {
                usleep(200000);
                continue;
            }
            usleep(200000);
            continue;
        }

        iy = ix;
        break;
    }

    if (iy == -1) return ABNORMAL;

    return (w_size);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : statMsg                                                         */
/* SYNTAX   : int statMsg(int qid)                                            */
/* ARGUMENT : qid  : queue id  value                                          */
/* RETURN   : NORMAL / ABNORMAL                                               */
/* PURPOSE  : Check message queue status                                      */
/*----------------------------------------------------------------------------*/
int statMsg(int qid)
{
    struct msqid_ds msqid_ds;

    if (msgctl (qid, IPC_STAT, (struct msqid_ds *) &msqid_ds) != 0)
        return ABNORMAL;

    /*-------------------------------------------------------------------*/
    /* Check queue status                                                */
    /*-------------------------------------------------------------------*/
    if ((msqid_ds.msg_qbytes - msqid_ds.msg_cbytes) <= 0) return ABNORMAL;

    return NORMAL;
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : getMsg                                                          */
/* SYNTAX   : int getMsg(int qid, long owner, char *buff, int mode)           */
/* ARGUMENT : qid    : Message Queue Id.                                      */
/*          : owner  : Message Type                                           */
/*          : buff   : Transaction Message buffer                             */
/*          : mode   : read mode                                              */
/* RETURN   : NORMAL : Length of reading Data  ,  ABNORMAL : NOK              */
/* PURPOSE  : Read Data of message queue                                      */
/*----------------------------------------------------------------------------*/
int  getMsg(int qid, long owner, char *buff, int mode)
{
    int    ret;
    msgf   msgf_rd;
    struct msqid_ds msqid_ds;
// modify by Yong : 2008-12-01 ���� 10:10:54
#if (defined(WIN32)||defined(_WIN32))
	memset(&msgf_rd,0,sizeof(msgf_rd));
#endif

    if (msgctl (qid, IPC_STAT, (struct msqid_ds *) &msqid_ds) != 0)
        return ABNORMAL;

    msgf_rd.msg_type = owner;
    if (mode == IPC_NOWAIT)
        ret = msgrcv (qid,&msgf_rd, MAXMSGDATA, msgf_rd.msg_type,mode);
    else
        ret = msgrcv (qid,&msgf_rd, MAXMSGDATA, msgf_rd.msg_type,0);

    if (ret < 0)
    {
        return (ret);
    }

    memcpy (buff, msgf_rd.msg_data, ret);

    return (ret);
}

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
