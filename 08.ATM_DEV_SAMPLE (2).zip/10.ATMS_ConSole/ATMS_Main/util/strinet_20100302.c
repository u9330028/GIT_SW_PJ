/*============================================================================*/
/* Program Name: strinet.c                                                    */
/* Execute File: libsock.a                                                    */
/* Function    : net domain Stream socket Interface Libarary                  */
/* Programmer  : LEE SANG HOON                                                */
/* Description : Copyright (C) 2008 NAUTILUS HYOSUNG. Ltd                     */
/*               All rights Reserved                                          */
/*----------------------------------------------------------------------------*/
/*   VERSION      DATE          NAME             COMMENT                      */
/*   VER 1.00     2008.07.21    SHLEE            First Ver                    */
/*============================================================================*/
#include "defcom.h"
#include "strinet.h"

#if (defined(WIN32) || defined(_WIN32))
/*----------------------------------------------------------------------------*/
/* FUNCTION : int selectSleep()                                               */
/* SYNTAX   : int selectSleep(int sockfd, int delay)                          */
/* ARGUMENT : sockfd : socket fd                                              */
/*            delay  : delay cycle(count)                                     */
/* RETURN   : NORMAL : socket fd   ABNORMAL : NOK                             */
/* PURPOSE  : data recv�� 0.1�� delay. ��ü Frame BUFFER �� ��⵵�� �Ѵ�     */
/*----------------------------------------------------------------------------*/
int selectSleep(int sockfd, int delay)
{
    struct timeval tval={0};
    fd_set    rset;
    int       iRet=0;
    int       loop=0;

    tval.tv_sec = 1;

    while (1)
    {
        FD_ZERO(&rset);
        FD_SET(sockfd, &rset);

        iRet=select(sockfd+1,&rset,(fd_set *)NULL,(fd_set *)NULL,&tval);

        if (iRet == 0) //timeout
        {
            loop++;
            if (loop >= delay)
            continue;
        }
        else if(iRet > 0)
        {
            Sleep(100);
            return 0;
        }
        else
        {
            break;
        }
    }
    return -1;
}
#endif
/*----------------------------------------------------------------------------*/
/* FUNCTION : initServerSocket                                                */
/* SYNTAX   : int initServerSocket(int port, int initno, int maxsize)         */
/* ARGUMENT : port   : connect port                                           */
/*            initno : max client count                                       */
/*            maxsize: buffer size                                            */
/* RETURN   : NORMAL : socket fd   ABNORMAL : NOK                             */
/* PURPOSE  : Create tcp/ip server socket                                     */
/*----------------------------------------------------------------------------*/
int initServerSocket(int port, int initno, int maxsize)
{
    int    optval, sockfd;
    struct sockaddr_in serv_addr;
    int    bufflen, oplen;

    sockfd = -1;
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        return ABNORMAL;
    }

    optval = 1;
    setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(int));
    bzero((char*) &serv_addr, sizeof(serv_addr) );
    serv_addr.sin_family      = AF_INET          ;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port        = htons(port) ;

    bufflen = maxsize * 1000;
    oplen   = sizeof(bufflen);

    setsockopt(sockfd,SOL_SOCKET,SO_SNDBUF, &bufflen, oplen);
    setsockopt(sockfd,SOL_SOCKET,SO_RCVBUF, &bufflen, oplen);
    setsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE, (char *)&optval, sizeof(optval));

    if (bind(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) != 0)
    {
        closesocket(sockfd);
        return ABNORMAL;
    }

    if (listen(sockfd, initno) != 0)
    {
        closesocket(sockfd);
        return ABNORMAL;
    }

    return (sockfd);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : initClientSocket                                                */
/* SYNTAX   : int initClientSocket(int hport, char *haddr, int trycnt)        */
/* ARGUMENT : port   : connect port                                           */
/*            haddr  : connect ip address                                     */
/*            trycnt : connect retry count                                    */
/* RETURN   : NORMAL : socket fd   ABNORMAL : NOK                             */
/* PURPOSE  : Create tcp/ip client socket                                     */
/*----------------------------------------------------------------------------*/
int initClientSocket(int hport, char *haddr, int trycnt)
{
    int    sockfd, curcnt = 0;
    struct sockaddr_in cli_addr;

    if (trycnt <= 0) return ABNORMAL;

    while(1)
    {
        sockfd  = -1;

        /*--------------------------------------------------------*/
        /* Initialize the socket address structure                */
        /*--------------------------------------------------------*/
        memset(&cli_addr, 0x00, sizeof(cli_addr));
        cli_addr.sin_family      = AF_INET;
        cli_addr.sin_port        = htons(hport);
        cli_addr.sin_addr.s_addr = inet_addr(haddr);

        /*--------------------------------------------------------*/
        /* Create an AF_INET stream socket                        */
        /*--------------------------------------------------------*/
        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) return ABNORMAL;

        /*--------------------------------------------------------*/
        /* Connect to the server                                  */
        /*--------------------------------------------------------*/
        if(connect(sockfd,(struct sockaddr *)&cli_addr,sizeof(cli_addr)) < 0)
        {
            closesocket(sockfd);
            if (++curcnt < trycnt) continue;
            else                   return ABNORMAL;
        }

        return (sockfd);
    }
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : writeSocket                                                     */
/* SYNTAX   : int writeSocket(int sockfd, char *senddata, int sendlen)        */
/* ARGUMENT : sockfd   : socket fd                                            */
/*            senddata : send data                                            */
/*            sendlen  : send data length                                     */
/* RETURN   : write length                                                    */
/* PURPOSE  : Write data to socket                                            */
/*----------------------------------------------------------------------------*/
int writeSocket(int sockfd, char *senddata, int sendlen)
{
    register int nleft, nwritten;

    nleft = sendlen;
    while (nleft > 0)
    {
        nwritten = send(sockfd, senddata, nleft, 0);
        if (nwritten < 0)
        {
#if !(defined(WIN32) || defined(_WIN32))
            if (errno == EINTR) continue;
#else
            if (WSAGetLastError() == 10035)
            {
                selectSleep(sockfd,2);
                continue;
            }
            if (WSAGetLastError() == WSAEINTR) continue;
#endif
            return (nwritten);
        }
        else if (nwritten == 0) break;

        nleft -= nwritten;
        senddata += nwritten;
    }

    return (sendlen - nleft);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : writeSocket_wait                                                */
/* SYNTAX   : int writeSocket_wait(int sockfd, char *senddata, int sendlen)   */
/* ARGUMENT : sockfd   : socket fd                                            */
/*            senddata : send data                                            */
/*            sendlen  : send data length                                     */
/* RETURN   : write length                                                    */
/* PURPOSE  : Write data to socket (consider alarm signal)                    */
/*----------------------------------------------------------------------------*/
int writeSocket_wait(int sockfd, char *senddata, int sendlen)
{
    register int nleft, nwritten;

    nleft = sendlen;
    while (nleft > 0)
    {
        nwritten = send(sockfd, senddata, nleft, 0);
        if (nwritten < 0)
        {
#if !(defined(WIN32) || defined(_WIN32))
            if (errno == EINTR) return(0);
#else
            if(WSAGetLastError()==WSAEINTR) return(0);
#endif
            return (nwritten);
        }
        else if (nwritten == 0) break;

        nleft -= nwritten;
        senddata += nwritten;
    }

    return (sendlen - nleft);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : readSocket                                                      */
/* SYNTAX   : int readSocket(int sockfd, char *recvdata, int recvlen)         */
/* ARGUMENT : sockfd   : socket fd                                            */
/*            recvdata : recv data                                            */
/*            recvlen  : recv data length                                     */
/* RETURN   : read length                                                     */
/* PURPOSE  : Read data from socket                                           */
/*----------------------------------------------------------------------------*/
int readSocket(int sockfd, char *recvdata, int recvlen, int timeout)
{
    register int nleft, nreadden;
    char *temp = NULL;
    int nErr=0;
    time_t stime = 0;
    time_t etime = 0;

    temp = (char *)malloc(recvlen+1);
    if (temp == NULL)
    { /* check memory allocate */
        return 0;
    }

    nleft = recvlen;

    stime = time(0); /* start time */

    while (nleft > 0)
    {
        memset(temp, 0x00, recvlen+1);
        nreadden = recv(sockfd, temp, nleft, 0);   /* Blocking Mode */
        if (nreadden <  0)
        {
#if !(defined(WIN32) || defined(_WIN32))
            if (errno == EINTR) continue;
#else
            nErr=WSAGetLastError();
            if(nErr==10035)
            {
                selectSleep(sockfd,2);
                continue;
            }
            if(nErr==WSAEINTR) continue;
#endif
            free(temp); temp = NULL;
            return (nreadden);
        }
        else if (nreadden == 0)
        {
            free(temp); temp = NULL;
            return (nreadden);
        }

        nleft -= nreadden;
        memcpy(recvdata, temp, nreadden);
        recvdata += nreadden;

        etime = time(0); /* finished time */

        if ((int)(etime - stime) > (int)timeout)
        {/* TimeOut */
            free(temp); temp = NULL;
            return 0; /* Timeout */
        }
    }

    if (temp != NULL)
    {
        free(temp); temp = NULL;
    }
    return (recvlen - nleft);
}

/*----------------------------------------------------------------------------*/
/* FUNCTION : readSocket_wait                                                 */
/* SYNTAX   : int readSocket_wait(int sockfd, char *recvdata, int recvlen)    */
/* ARGUMENT : sockfd   : socket fd                                            */
/*            recvdata : recv data                                            */
/*            recvlen  : recv data length                                     */
/* RETURN   : read length                                                     */
/* PURPOSE  : Read data from socket(Consider alarm signal)                    */
/*----------------------------------------------------------------------------*/
int readSocket_wait(int sockfd, char *recvdata, int recvlen)
{
    register int nleft, nreadden;
    char *temp = NULL;

    temp = (char *)malloc(recvlen+1);
    if (temp == NULL)
    { /* check memory allocate */
        return 0;
    }
    nleft = recvlen;
    while (nleft > 0)
    {
        memset(temp, 0x00, recvlen+1);
        nreadden = recv(sockfd, temp, nleft, 0);   /* Blocking Mode */
        if (nreadden <  0)
        {
            free(temp); temp = NULL;
            if (errno == EINTR) return (nreadden);
            return (nreadden);
        }
        else if (nreadden == 0)
        {
            free(temp); temp = NULL;
            return (nreadden);
        }

        nleft -= nreadden;
        memcpy(recvdata, temp, nreadden);
        recvdata += nreadden;
    }

    if (temp != NULL)
    {
        free(temp); temp = NULL;
    }
    return (recvlen - nleft);
}

#if (!defined(WIN32) && !defined(_WIN32))
/*----------------------------------------------------------------------------*/
/* FUNCTION : closesocket                                                     */
/* SYNTAX   : int closesocket(int sockfd)                                     */
/* ARGUMENT : sockfd  : socket fd                                             */
/* RETURN   : NORMAL  : OK                                                    */
/* PURPOSE  : close socket                                                    */
/*----------------------------------------------------------------------------*/
int closesocket(int sockfd)
{

    shutdown(sockfd, SHUT_RDWR);
    close(sockfd);

    return NORMAL;
}
#endif

/*----------------------------------------------------------------------------*/
/*                        E N D   O F   F I L E                               */
/*----------------------------------------------------------------------------*/
