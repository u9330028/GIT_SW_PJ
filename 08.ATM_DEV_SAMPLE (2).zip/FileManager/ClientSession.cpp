#include "stdafx.h"
#include "Critical.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "EventSelect.h"
#include "PacketSession.h"
#include "ClientSession.h"


CClientSession::CClientSession(HWND hParentWnd)
{
	m_hParentWnd = hParentWnd;

	memset(m_szNumberCD, 0x00, sizeof(m_szNumberCD));
	memset(m_szVersion, 0x00, sizeof(m_szVersion));

	ResetFileList();
}

CClientSession::~CClientSession(void)
{
}

BOOL CClientSession::Begin(LPSTR remoteAddress, USHORT remotePort)
{
	if (!remoteAddress || remotePort <= 0)
		return FALSE;

	if (!mSession.Begin())
	{
		End();

		return FALSE;
	}

	if (!mSession.TcpBind())
	{
		End();

		return FALSE;
	}

	if (!CEventSelect::Begin(mSession.GetSocket()))
	{
		End();

		return FALSE;
	}

	if (!mSession.Connect(remoteAddress, remotePort))
	{
		End();

		return FALSE;
	}

	return TRUE;
}


BOOL CClientSession::End(void)
{
	mSession.End();

	CEventSelect::End();

	return TRUE;
}

BOOL CClientSession::GetLocalIP(WCHAR* pIP)
{
    return mSession.GetLocalIP(pIP);
}

BOOL CClientSession::GetLocalIP(TCHAR* pIP)
{
    return mSession.GetLocalIP(pIP);
}

USHORT CClientSession::GetLocalPort(void)
{
	return mSession.GetLocalPort();
}

BOOL CClientSession::ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength)
{
	void *Object = NULL;

	return mReadPacketQueue.Pop(&Object, protocol, packet, packetLength);
}

BOOL CClientSession::WritePacket(const BYTE *pData, DWORD dwDataLength)
{
	if (!mSession.WritePacket(pData, dwDataLength))
		return FALSE;
	
	if (!mSession.WriteComplete())
		return FALSE;
	
	return TRUE;
}

void CClientSession::OnIoRead(void)
{
	BYTE	btPacket[MAX_BUFFER_LENGTH]	= {0,};
	DWORD	dwPacketLength				= 0;

	DWORD	dwProtocol					= 0;

	if (mSession.ReadPacketForEventSelect())
	{
		while (mSession.GetPacket(btPacket, dwPacketLength) == PACKET_EXIST)
		{
			mReadPacketQueue.Push(this, dwProtocol, btPacket, dwPacketLength);
			ProcessPacket();
			//SendMessageToParent(UM_SESSION_RECEIVE, 0, 0);
		}
	}
}

// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
void CClientSession::OnIoConnected(DWORD dwError)
{
	SendMessageToParent(UM_SESSION_CONNECTED, 0, dwError);
}

// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
void CClientSession::OnIoDisconnected(void)
{
	TRACE(_T("OnIoDisconnected\n"));
	SendMessageToParent(UM_SESSION_DISCONNECTED, 0, 0);
}

void CClientSession::OnIoError(DWORD dwError)
{
	TRACE(_T("OnIoError(%d)\n"), dwError);

	switch(dwError)
	{
	case WSAETIMEDOUT:	// ����ð� �ʰ�
		break;

	default:
		break;
	}

	SendMessageToParent(UM_SESSION_DISCONNECTED, 0, 0);
}

void CClientSession::SetParentWnd(HWND hParentWnd)
{
	m_hParentWnd  = hParentWnd;
}

void CClientSession::SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(m_hParentWnd == NULL || !IsWindow(m_hParentWnd))
		return;
	
	::PostMessage(m_hParentWnd, uMsg, wParam, lParam);
}

void CClientSession::ProcessPacket()
{
	LPVOID pObject = NULL;
	DWORD dwPacketLength = 0;
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	BYTE btData[MAX_BUFFER_LENGTH] = {0x00, };
	BYTE btCommand[128] = {0x00, };
	TCHAR szNumberCD[10] = {0x00,};
	TCHAR szDataCount[128] = {0x00, };
	int nTokenLength = 0;
	int nDataCount = 33;
	int nDataLength = 0;
	int nDataPosition = 0;
	BOOL bResult = FALSE;
	CString strMessage = _T("");


	memset(btPacket, 0x00, sizeof(btPacket));
	if(mReadPacketQueue.Pop(&pObject, btPacket, dwPacketLength))
	{
		// ���� ���� ������� Ÿ�Ӿƿ� ����
		ClearReceiveTimeOut();

		CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("[CClientSession::ProcessPacket] ���� ��Ŷ(%ld) ó�� ����"), dwPacketLength);
//		theTrace.TraceHex(btPacket, dwPacketLength);

		////////////////////////////////////////////////////////////////////////
		// ���� ���� üũ
		////////////////////////////////////////////////////////////////////////
		if (btPacket[0] != STX)
		{
			CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("[ERROR] Receive Data Format (STX) Error"));
//			SendFormatErrorPacket();
			return;
		}

		if (btPacket[dwPacketLength - 1] != ETX) 
		{
			CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("[ERROR] Receive Data Format (ETX) Error"));
//			SendFormatErrorPacket();

//			strMessage.Format(_T("[NRMS] DATA FORMAT ERROR ����"));
//			SendMessageToParent(UM_START_PROGRAM, FALSE, MAX_PROGRESS_STEP);
			return;
		}

		ProcessPacket(btPacket, dwPacketLength);
	}
}

void CClientSession::SetReceiveTimeOut(DWORD dwTimeOut)
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::SetTimer(m_hParentWnd, TIMER_FILE_RECEIVE_TIMEOUT, dwTimeOut, NULL);
	}
}

void CClientSession::ClearReceiveTimeOut()
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::KillTimer(m_hParentWnd, TIMER_FILE_RECEIVE_TIMEOUT);
	}
}


void CClientSession::ProcessPacket(const BYTE *pPacket, DWORD dwPacketLength)
{
	PACKET_HEADER header;
	PACKET_INFO info;
	int nResult = 0;
	BYTE btSendPacket[MAX_PACKET_LENGTH] = {0x00,};
	DWORD dwSendLength = 0;
	
	memset(&header, 0x00, sizeof(header));
	memset(&info, 0x00, sizeof(info));
	
	// PACKET FORMAT CHECK
	if(IsValidPacket(pPacket, dwPacketLength, header, info) == FALSE)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Msg Format error");

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, MSG_FORMAT_ERROR);
		if(!WritePacket(btSendPacket, dwSendLength))
			End();
		
		return;
	}

	// file list
	if(memcmp(header.type, REP_FILE_LIST, LENGTH_MSG_TYPE) == 0)
	{
		CProcessLog::GetInstance()->Dump(FS_LOG, "FILE_LIST ��Ŷ ����", (BYTE*) pPacket, dwPacketLength);

		ParseFileList(pPacket, dwPacketLength);
		wsprintf(info.filepath, "%s", m_arFileList[m_nFileIndex].szFilePath);
		info.nFilePathLength = strlen(info.filepath);

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileSizeRequestPacket(btSendPacket, info);
		if(!WritePacket(btSendPacket, dwSendLength))
			End();

		CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_SIZE ��û��Ŷ ����");
	}
	// request file size
	else if(memcmp(header.type, REP_FILE_SIZE, LENGTH_MSG_TYPE) == 0)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_SIZE ��Ŷ ����");

		ParseFileSize(pPacket, dwPacketLength);

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileDataRequestPacket(btSendPacket, info);
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "FIRST FILE_DATA ��û��Ŷ ����");

		if(!WritePacket(btSendPacket, dwSendLength))
			End();

		CProcessLog::GetInstance()->WriteLog(FS_LOG, "FIRST FILE_DATA ��û��Ŷ ����");
	}
	// request file data 
	else if(memcmp(header.type, REP_FILE_DATA, LENGTH_MSG_TYPE) ==0)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "%s FILE_DATA %ld ����Ʈ ����", info.filepath, info.nDataLength);

		nResult = WriteToFile(info);
		if(nResult > 0)
		{
			memset(btSendPacket, 0x00, sizeof(btSendPacket));
			dwSendLength = MakeFileDataRequestPacket(btSendPacket, info);
			CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_DATA ��û��Ŷ ����");

			Sleep(1);
			if(!WritePacket(btSendPacket, dwSendLength))
				End();

			CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_DATA ��û��Ŷ ����");
		}
		else
		{
			memset(btSendPacket, 0x00, sizeof(btSendPacket));
			if(nResult == -1)
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_WRITE_ERROR);
			else if(nResult == -2)
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_CREATE_ERROR);
			else
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_ETC_ERROR);

			if(!WritePacket(btSendPacket, dwSendLength))
				End();

			CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_ERROR ��Ŷ ����");
		}
	}
	else if(memcmp(header.type, REP_FILE_END, LENGTH_MSG_TYPE) ==0)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "%s FILE_END %ld ����Ʈ ����", info.filepath, info.nDataLength);

		nResult = WriteToFile(info);
		if(nResult > 0)
		{
			char szTempFilePath[LENGTH_MAX_BUFFER] = {0x00,};
			memset(szTempFilePath, 0x00, sizeof(szTempFilePath));
			wsprintf(szTempFilePath, FILEFORMAT_TEMP, info.filepath);

			if(m_arFileList[m_nFileIndex].lFileSize != GetFileSize(szTempFilePath))
			{
				memset(btSendPacket, 0x00, sizeof(btSendPacket));
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_SAVE_ERROR);
				if(!WritePacket(btSendPacket, dwSendLength))
					End();

				CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_SAVE_ERROR ��Ŷ ����");
			}
			else
			{
				if(m_nFileIndex < m_nFileCount - 1)	
				{
					m_nFileIndex++ ; // next file
					memset(btSendPacket, 0x00, sizeof(btSendPacket));
					dwSendLength = MakeFileSizeRequestPacket(btSendPacket, info);
					if(!WritePacket(btSendPacket, dwSendLength))
						End();

					CProcessLog::GetInstance()->WriteLog(FS_LOG, "NEXT FILE_SIZE ��Ŷ ����");
				}				
				else
				{
					CProcessLog::GetInstance()->WriteLog(FS_LOG, "ȭ�� ���� �Ϸ�!");
					
					// Temp file -> org file
					if(MoveTempFile() == 0)
					{
						// failure
						dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, UPDATE_ERROR);
						CProcessLog::GetInstance()->WriteLog(FS_LOG, "UPDATE_ERROR ��Ŷ ����");
						
						WritePacket(btSendPacket, dwSendLength);

						CProcessLog::GetInstance()->WriteLog(FS_LOG, "UPDATE_ERROR ��Ŷ ����");
					}
					else
					{
						dwSendLength = MakeFileEndRequestPacket(btSendPacket, info);
						CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_END_��Ŷ ����(%s)", info.filepath);

						WritePacket(btSendPacket, dwSendLength);
						
						CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_END ��Ŷ ����");
					}

					// ���� ������ ��� �Ϸ�Ǿ����Ƿ� ������ �����Ѵ�.
					End();
				}
			}
		}
		else
		{
			memset(btSendPacket, 0x00, sizeof(btSendPacket));
			if(nResult == -1)
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_WRITE_ERROR);
			else if(nResult == -2)
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_CREATE_ERROR);
			else
				dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, FILE_ETC_ERROR);

			if(!WritePacket(btSendPacket, dwSendLength))
				End();

			CProcessLog::GetInstance()->WriteLog(FS_LOG, "FILE_ERROR ��Ŷ ����");
		}
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Msg Format error");

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeErrorPacket(btSendPacket, REQ_ERROR, MSG_FORMAT_ERROR);
		if(!WritePacket(btSendPacket, dwSendLength))
			End();
	}
}

BOOL CClientSession::IsValidPacket(const BYTE *pPacket,
									DWORD dwPacketLength,
									PACKET_HEADER &header,
									PACKET_INFO &info)
{
	int nLength = 0;
	int nIndex = 0;
	int nFilePathLength = 0;
	int nDataLength = 0;
	TCHAR szLength[10] = {0x00,};
	TCHAR szFilePath[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR szData[LENGTH_MAX_BUFFER] = {0x00,}; 
	
	if(dwPacketLength <= sizeof(header))
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CClientSession::IsValidPacket] [ERROR] Packet Format error[Length <= Header size]");
		return FALSE;
	}
	
	memset(&header, 0x00, sizeof(header));
	memcpy(&header, pPacket, sizeof(header));
	
	// STX ERROR
	if(header.stx[0] != STX)	 
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CClientSession::IsValidPacket] [ERROR] Packet Format error[STX]");
		return FALSE;
	}
	
	// LENGTH DATA ERROR
	if(!IsNumber(header.length, sizeof(header.length)))
	{
		// length error
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CClientSession::IsValidPacket] [ERROR] Packet Format error[Length field error]");
		return FALSE;
	}
	
	memset(szLength, 0x00, sizeof(szLength));
	memcpy(szLength, header.length, sizeof(header.length));
	nLength = atoi(szLength);
	
	// PACKET LENGTH ERROR
	if(nLength != dwPacketLength)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CClientSession::IsValidPacket] [ERROR] Packet Format error[not same length]");
		return FALSE;
	}
	
	// ETX ERROR
	if(pPacket[dwPacketLength - 1] != ETX)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CClientSession::IsValidPacket] [ERROR] Packet Format error[ETX]");
		return FALSE;
	}
	
	memset(&info, 0x00, sizeof(info));
	memset(szFilePath, 0x00, sizeof(szFilePath));
	memset(szData, 0x00, sizeof(szData));
	
	// GET FILEPATH
	nFilePathLength = GetFirstToken(szFilePath, &pPacket[sizeof(header)], dwPacketLength - sizeof(header), FS);
	nIndex = sizeof(header) + LENGTH_FS + nFilePathLength;
	
	// GET DATA
	//nDataLength = GetFirstToken(szData, &pPacket[nIndex], dwPacketLength - nIndex, ETX);
	nDataLength = dwPacketLength - nIndex - 1; // -1 //ETX
	if(nDataLength > 0)
	{
		memcpy(szData, &pPacket[nIndex], nDataLength);
	}
	
	
	memcpy(info.cdname, header.cdname, sizeof(header.cdname));
	memcpy(info.size, header.size, sizeof(header.size));
	memcpy(info.filepath, szFilePath, nFilePathLength);
	memcpy(info.data, szData, nDataLength);
	info.nFilePathLength = nFilePathLength;
	info.nDataLength = nDataLength;
	
	return TRUE;
}

DWORD CClientSession::MakeVersionRequestPacket(BYTE *pPacketBuffer)
{
	PACKET_INFO packet;
	char szData[LENGTH_MAX_BUFFER] = {0x00,};

	memset(&packet, 0x00, sizeof(packet));
	memcpy(packet.type, REQ_VERSION, LENGTH_MSG_TYPE);
	memcpy(packet.cdname, GetNumberCD(), LENGTH_CDNUM);
	memcpy(packet.data, GetVersion(), LENGTH_VERSION);
	wsprintf(packet.size, "%04d", LENGTH_FILE_BUFFER);
	packet.nDataLength = LENGTH_VERSION;


	CProcessLog::GetInstance()->WriteLog(FS_LOG, "MakeVersionRequestPacket VERSION:%s", packet.data);

	return MakePacket(pPacketBuffer, packet);
}

DWORD CClientSession::MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode)
{
	PACKET_INFO info;
	memset(&info, 0x00, sizeof(info));
	
	info.nFilePathLength = 0;
	memcpy(info.type, lpszType, LENGTH_MSG_TYPE);
	memcpy(info.data, lpszErrorCode, LENGTH_ERROR_CODE);
	memcpy(info.cdname, GetNumberCD(), LENGTH_CDNUM);
	wsprintf(info.size, "%04d", LENGTH_FILE_BUFFER);
	
	info.nDataLength = LENGTH_ERROR_CODE;

	CProcessLog::GetInstance()->WriteLog(FS_LOG, "MakeErrorPacket ERROR TYPE:%s CODE:%s", lpszType, lpszErrorCode);
	
	return MakePacket(pPacketBuffer, info);
}

DWORD CClientSession::MakeFileSizeRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;
	
	memcpy(&packet, &info, sizeof(info));
	memcpy(packet.type, REQ_FILE_SIZE, LENGTH_MSG_TYPE);
	memcpy(packet.cdname, GetNumberCD(), LENGTH_CDNUM);
	wsprintf(packet.size, "%04d", LENGTH_FILE_BUFFER);

	memset(packet.data, 0x00, sizeof(packet.data));
	packet.nDataLength = 0;

	wsprintf(packet.filepath, "%s", m_arFileList[m_nFileIndex].szFilePath);
	packet.nFilePathLength = strlen(packet.filepath);

	CProcessLog::GetInstance()->WriteLog(FS_LOG, "MakeFileSizeRequestPacket FILE:%s", packet.filepath);

	return MakePacket(pPacketBuffer, packet);
}

DWORD CClientSession::MakeFileDataRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;
	char szTempFilePath[MAX_PATH] = {0x00,};

	memcpy(&packet, &info, sizeof(info));
	memcpy(packet.type, REQ_FILE_DATA, LENGTH_MSG_TYPE);
	memcpy(packet.cdname, GetNumberCD(), LENGTH_CDNUM);
	wsprintf(packet.size, "%04d", LENGTH_FILE_BUFFER);

	wsprintf(szTempFilePath, FILEFORMAT_TEMP, info.filepath);
	wsprintf(packet.data, "%ld", GetFileSize(szTempFilePath));
	packet.nDataLength = strlen(packet.data);

	wsprintf(packet.filepath, "%s", m_arFileList[m_nFileIndex].szFilePath);
	packet.nFilePathLength = strlen(packet.filepath);

	CProcessLog::GetInstance()->WriteLog(FS_LOG, "MakeFileDataRequestPacket FILE:%s POSITION:%s", packet.filepath, packet.data);

	return MakePacket(pPacketBuffer, packet);
}

DWORD CClientSession::MakeFileEndRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;
//	char szTempFilePath[MAX_PATH] = {0x00,};

	memset(&packet, 0x00, sizeof(packet));

	memcpy(&packet, &info, sizeof(info));
	memcpy(packet.type, REQ_FILE_END, LENGTH_MSG_TYPE);
	memcpy(packet.cdname, GetNumberCD(), LENGTH_CDNUM);
	wsprintf(packet.size, "%04d", LENGTH_FILE_BUFFER);
	
//	wsprintf(szTempFilePath, FILEFORMAT_TEMP, info.filepath);
	memset(packet.data, 0x00, sizeof(packet.data));
	packet.nDataLength = 0;
	

	// 2010.10.14 ghk@kci.co.kr filepath ����
	wsprintf(packet.filepath, "%s", m_arFileList[m_nFileIndex].szFilePath);
	packet.nFilePathLength = strlen(packet.filepath);	

	CProcessLog::GetInstance()->WriteLog(FS_LOG, "MakeFileEndRequestPacket FILE:[%s]", packet.filepath);
	
	DWORD dwLength = MakePacket(pPacketBuffer, packet);
	CProcessLog::GetInstance()->Dump(FS_LOG, "FILE_END", pPacketBuffer, dwLength);

	return dwLength;
}

DWORD CClientSession::MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	int nIndex = 0;
	DWORD dwPacketLength = 0;
	TCHAR szLength[5] = {0x00,};
	PACKET_HEADER header;
	
	dwPacketLength = sizeof(header) + info.nFilePathLength + LENGTH_FS + info.nDataLength + LENGTH_ETX;
	
	memset(szLength, 0x00, sizeof(szLength));
	wsprintf(szLength, "%04d", dwPacketLength);
	
	memset(&header, 0x00, sizeof(PACKET_HEADER));	
	memcpy(header.length, szLength, sizeof(header.length));
	memset(header.stx, STX, LENGTH_STX);
	memcpy(header.type, info.type, LENGTH_MSG_TYPE);
	memcpy(header.cdname, info.cdname, sizeof(header.cdname));
	memcpy(header.size, info.size, sizeof(header.size));
	
	memcpy(pPacketBuffer, &header, sizeof(header));
	nIndex += sizeof(header);
	
	memcpy(pPacketBuffer + nIndex, info.filepath, info.nFilePathLength);
	nIndex += info.nFilePathLength;
	
	memset(pPacketBuffer + nIndex, FS, LENGTH_FS);
	nIndex += LENGTH_FS;
	
	memcpy(pPacketBuffer + nIndex, info.data, info.nDataLength);
	nIndex += info.nDataLength;
	
	memset(pPacketBuffer + nIndex, ETX, LENGTH_ETX);
	
	// retrun packet length 
	return dwPacketLength;
}

int CClientSession::GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int iLen = strlen((char*)sMsg);
	for(int i=0; i < iLen; i++)
	{
		if(sMsg[i] == fs)
		{
			return i; // length of token
		}
		else
		{
			sToken[i] = sMsg[i];
		}
	}
	
	// GetToken failure
	return 0;
}

int CClientSession::GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int i,j;
	int iLen = strlen((char*)sMsg);
	i= iLen; j=0;
	
	for(i; i >= 0 ; i--)
	{
		if(sMsg[i] == fs) {
			wsprintf(sToken,"%s",&sMsg[i+1]);
			return i;
		}
	}
	
	// GetToken failure
	return -1;
}

BOOL CClientSession::IsNumber(char *pszData, int nLength)
{
	if(pszData == NULL)
		return FALSE;
	
	for(int i=0; i<nLength; i++)
	{
		if(!isdigit(pszData[i]))
			return FALSE;
	}
	
	return TRUE;
}

LPCTSTR CClientSession::GetNumberCD()
{
	TCHAR szValue[20] = {0x00,};
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("Local", "CDnumber", "", szValue, sizeof(szValue), ATOM_INFO_INI);

	if(strlen(szValue) == LENGTH_CDNUM) 
	{
		memset(m_szNumberCD, 0x00, sizeof(m_szNumberCD));
		memcpy(m_szNumberCD, szValue, strlen(szValue));
	}
	else 
	{
		memset(m_szNumberCD, 0x20, sizeof(m_szNumberCD));
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "[Failure] Fail to get cdnumber");
	}
	
	return m_szNumberCD;
}

LPCTSTR CClientSession::GetVersion()
{
	TCHAR szValue[20] = {0x00,};

	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("VERSION", "VER", "", szValue, sizeof(szValue), ATOM_VERSION_INI);
	
	if(strlen(szValue) == LENGTH_VERSION) 
	{
		memcpy(m_szVersion, szValue, strlen(szValue));
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "CD VERSION : %s", m_szVersion);						
	}
	else 
	{
		memset(m_szVersion, 0x20, LENGTH_VERSION);
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "[Failure] Fail to get version");
	}

	return m_szVersion;
}

int CClientSession::WriteToFile(PACKET_INFO &info)
{
	TCHAR szTempFilePath[LENGTH_MAX_BUFFER] = {0x00,};

	if(memcmp(info.filepath, m_arFileList[m_nFileIndex].szFilePath, info.nFilePathLength) != 0)
	{
		// error.. ��û�� ȭ�ϰ� �ٸ� ȭ�� �̸�.
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "Different file name(org:%s , now:%s)",
			m_arFileList[m_nFileIndex].szFilePath, info.filepath);
		return 0;
	}

	memset(szTempFilePath, 0x00, sizeof(szTempFilePath));
	wsprintf(szTempFilePath, FILEFORMAT_TEMP, info.filepath);
	

	return WriteToFile(szTempFilePath, info.data, info.nDataLength);
}

int CClientSession::WriteToFile(LPCTSTR lpszFilePath, char *pszData, int nDataLength)
{
	HANDLE hFile = INVALID_HANDLE_VALUE;
	DWORD dwWritten = 0;
	int nResult = 0;
	
	if(nDataLength <= 0)
		return 0;
	
    if ((hFile = CreateFile(lpszFilePath,
							GENERIC_READ | GENERIC_WRITE,
							FILE_SHARE_READ | FILE_SHARE_WRITE,  // exclusive access
							NULL,                 // no security attrs
							OPEN_ALWAYS,
							FILE_ATTRIBUTE_ARCHIVE,
							NULL)) == INVALID_HANDLE_VALUE)
						{
							return -2;
						}
	
    SetFilePointer(hFile, 0, NULL, FILE_END);
	
    if(WriteFile(hFile, pszData, nDataLength, &dwWritten, NULL))
		nResult = dwWritten;
	else
		nResult = -1;
	
	CloseHandle(hFile);
	
	return nResult;
}

int CClientSession::SendVersionRequestPacket()
{
	BYTE btSendPacket[MAX_PACKET_LENGTH] = {0x00,};
	DWORD dwSendLength = 0;

	memset(btSendPacket, 0x00, sizeof(btSendPacket));
	dwSendLength = MakeVersionRequestPacket(btSendPacket);

	return WritePacket(btSendPacket, dwSendLength);
}

int CClientSession::ParseFileList(const BYTE *pPacket, DWORD dwPacketLength)
{
	int nCount = 0;
	int nIndex = 0;
	int nFileCount = 0;
	TCHAR szValue[10] = {0x00,};
	TCHAR szFilePath[MAX_FILE_NAME] = {0x00,};
	TCHAR szTempFilePath[MAX_FILE_NAME] = {0x00,};
	BYTE *pBuffer = new BYTE[dwPacketLength +1];

	memset(pBuffer, 0x00, dwPacketLength + 1);
	memcpy(pBuffer, pPacket, dwPacketLength);

	// ���ϸ���Ʈ �ʱ�ȭ
	ResetFileList();

	// STX[1] + LENGTH[4] + CMD[2] + FS[1] + FILECOUNT[2] + { FILEPATH[N] + FS[1] } + ETX[1]
	if(dwPacketLength <= 8)
		return 0;

	// ���� ����
	memset(szValue, 0x00, sizeof(szValue));
	memcpy(szValue, &pBuffer[9], LENGTH_FILE_COUNT);
	nFileCount = atoi(szValue);

	// ���ϸ��
	nCount = 0;
	nIndex = 10;
	while(pBuffer[nIndex] != ETX && nIndex < dwPacketLength)
	{
		memset(szFilePath, 0x00, sizeof(szFilePath));
		GetFirstToken(szFilePath, &pBuffer[nIndex], dwPacketLength - nIndex, FS);
		strcpy(m_arFileList[nCount++].szFilePath, szFilePath);
		nIndex = nIndex + strlen(szFilePath) + 1;

		// �ӽ����� ����
		memset(szTempFilePath, 0x00, sizeof(szTempFilePath));
		wsprintf(szTempFilePath, FILEFORMAT_TEMP, szFilePath);
		if(PathFileExists(szTempFilePath))
			_unlink(szTempFilePath);
	}

	delete []pBuffer;
	pBuffer = NULL;

	if(nCount != nFileCount)
		return -1;

	m_nFileCount = nFileCount;
	return nCount;
}

ULONG CClientSession::ParseFileSize(const BYTE *pPacket, DWORD dwPacketLength)
{
	int nIndex = 0;
	int nDataLength = 0;
	ULONG lFileSize = 0;
	TCHAR szData[LENGTH_MAX_BUFFER] = {0x00, };
	BYTE *pBuffer = new BYTE[dwPacketLength +1];
	
	memset(pBuffer, 0x00, dwPacketLength + 1);
	memcpy(pBuffer, pPacket, dwPacketLength);

	nIndex = sizeof(PACKET_HEADER) + strlen(m_arFileList[m_nFileIndex].szFilePath) + LENGTH_FS;

	// get data
	nDataLength = dwPacketLength - nIndex - LENGTH_ETX; // Header + ETX
	memset(szData, 0x00, sizeof(szData));
	memcpy(szData, &pBuffer[nIndex], nDataLength);

	lFileSize = _atoi64(szData);
	m_arFileList[m_nFileIndex].lFileSize = lFileSize;

	delete []pBuffer;
	pBuffer = NULL;

	return lFileSize;
}

void CClientSession::ResetFileList()
{
	m_nFileCount = 0;
	m_nFileIndex = 0;

	// ���ϸ���Ʈ �ʱ�ȭ
	for(int i=0; i<MAX_FILE_COUNT; i++) 
	{
		memset(&m_arFileList[i], 0x00, sizeof(m_arFileList[i]));
	}
}

ULONG CClientSession::GetFileSize(LPCTSTR lpszFilePath)
{
	if(lpszFilePath == NULL || !PathFileExists(lpszFilePath))
		return 0;
	
	CFileStatus fs;
	
	if(CFile::GetStatus(lpszFilePath, fs))
	{
		return fs.m_size;
	}
	else
	{
		return 0;
	}
}

int CClientSession::MoveTempFile()
{
	char szTempFilePath[LENGTH_MAX_BUFFER] = {0x00,};
	char szFilePath[LENGTH_MAX_BUFFER] = {0x00,};

	for(int i=0; i<m_nFileCount; i++)
	{
		memset(szFilePath, 0x00, sizeof(szFilePath));
		memset(szTempFilePath, 0x00, sizeof(szTempFilePath));
		
		wsprintf(szFilePath, "%s", m_arFileList[i].szFilePath);
		wsprintf(szTempFilePath, FILEFORMAT_TEMP, szFilePath);
		
		_unlink(szFilePath);
		if(rename(szTempFilePath, szFilePath) != 0)
		{
			// failure
			CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Failure] Rename (%s , %s)", szTempFilePath, szFilePath);
			return 0;
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Success] Rename (%s , %s)", szTempFilePath, szFilePath);
		}
	}
	
	return 1;
}