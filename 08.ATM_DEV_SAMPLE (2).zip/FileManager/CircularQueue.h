#pragma once

typedef struct tagQUEUE_DATA
{
	void	*Object;
	BYTE	Data[MAX_BUFFER_LENGTH];
	DWORD	DataLength;

	CHAR	RemoteAddress[32];
	USHORT	RemotePort;

	DWORD	Protocol;
} QUEUE_DATA;

class CCircularQueue : public CMultiThreadSync<CCircularQueue>
{
public:
	CCircularQueue(void);
	~CCircularQueue(void);

private:
	QUEUE_DATA	mQueue[MAX_QUEUE_LENGTH];
	DWORD		mQueueHead;
	DWORD		mQueueTail;

public:
	BOOL		Begin(void);
	BOOL		End(void);

	BYTE*		Push(void *object, BYTE *data, DWORD dataLength);
	BYTE*		Push(void *object, BYTE *data, DWORD dataLength, LPCSTR remoteAddress, USHORT remotePort);
	BYTE*		Push(void *object, DWORD protocol, BYTE *data, DWORD dataLength);
	BYTE*		Push(void *object, DWORD protocol, BYTE *data, DWORD dataLength, LPCSTR remoteAddress, USHORT remotePort);

	BOOL		Pop(void **object, BYTE *data, DWORD &dataLength);
	BOOL		Pop(void **object, BYTE *data, DWORD &dataLength, LPSTR remoteAddress, USHORT &remotePort);
	BOOL		Pop(void **object, DWORD &protocol, BYTE *data, DWORD &dataLength);
	BOOL		Pop(void **object, DWORD &protocol, BYTE *data, DWORD &dataLength, LPSTR remoteAddress, USHORT &remotePort);
	BOOL		Pop(void);

	BOOL		IsEmpty(void);
};