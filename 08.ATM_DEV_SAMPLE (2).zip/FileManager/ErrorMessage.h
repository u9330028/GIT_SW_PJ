// ErrorMessage.h: interface for the CError class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ERRORMESSAGE_H__84028D8A_C115_4401_A4D4_6CE91108A425__INCLUDED_)
#define AFX_ERRORMESSAGE_H__84028D8A_C115_4401_A4D4_6CE91108A425__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#import <msxml3.dll>
using namespace MSXML2;


class CErrorMessage : public CObject  
{
public:
	CErrorMessage();
	virtual ~CErrorMessage();

public:
	static CString GetErrorMessage(DWORD dwError);
	static CString GetErrorMessage(CException *pException);
	static CString GetErrorMessage(IXMLDOMParseErrorPtr pErrorPtr);
	static CString GetErrorMessage(_com_error e);
};

#endif // !defined(AFX_ERRORMESSAGE_H__84028D8A_C115_4401_A4D4_6CE91108A425__INCLUDED_)
