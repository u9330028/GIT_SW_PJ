#pragma once

class CIocp
{
public:
	CIocp(VOID);
	virtual ~CIocp(VOID);

private:
	HANDLE				m_hIocpHandle;
	DWORD				m_dwWorkerThreadCount;

	std::vector<HANDLE>	m_vWorkerThread;

	HANDLE				m_hStartupEventHandle;

protected:
	virtual VOID		OnIoRead(VOID *object, DWORD dataLength)	= 0;
	virtual VOID		OnIoWrote(VOID *object, DWORD dataLength)	= 0;
	virtual VOID		OnIoConnected(VOID *object)					= 0;
	virtual VOID		OnIoDisconnected(VOID *object)				= 0;

public:
	BOOL				Begin(VOID);
	BOOL				End(VOID);
	
	BOOL				RegisterSocketToIocp(SOCKET socket, ULONG_PTR completionKey);

	VOID				WorkerThreadCallback(VOID);
};

