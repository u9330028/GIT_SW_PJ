#pragma once

class CEventSelect
{
public:
	CEventSelect(void);
	virtual ~CEventSelect(void);

private:
	HANDLE			m_hSelectEventHandle;
	HANDLE			m_hStartupEventHandle;
	HANDLE			m_hDestroyEventHandle;
	
	HANDLE			m_hSelectThreadHandle;

	SOCKET			m_hSocket;

protected:
	virtual void	OnIoRead(void)					= 0;
	//virtual void	OnIoWrote(void)					= 0;
	virtual void	OnIoConnected(DWORD dwError)	= 0;
	virtual void	OnIoDisconnected(void)			= 0;
	virtual void	OnIoError(DWORD dwError)		= 0;

public:
	BOOL			Begin(SOCKET socket);
	BOOL			End(void);

	void			SelectThreadCallback(void);
};
