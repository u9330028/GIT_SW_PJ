#pragma once

#include "PacketSession.h"

class CClientSession : public CEventSelect
{
public:
//	CClientSession(void);
	CClientSession(HWND hParentWnd);
	virtual ~CClientSession(void);

private:
	CPacketSession	mSession;
	CCircularQueue	mReadPacketQueue;

public:
	BOOL			Begin(LPSTR remoteAddress, USHORT remotePort);
	BOOL			End(void);

	BOOL			GetLocalIP(WCHAR* pIP);
	BOOL			GetLocalIP(TCHAR* pIP);
	USHORT			GetLocalPort(void);

	BOOL			ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength);
	BOOL			WritePacket(const BYTE *pData, DWORD dwDataLength);

	void			ProcessPacket();

public:
	int				SendVersionRequestPacket();
	void			ClearReceiveTimeOut();
	void			SetParentWnd(HWND hParentWnd);

protected:
	void			OnIoRead(void);
	void			OnIoConnected(DWORD dwError);	// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoDisconnected(void);			// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoError(DWORD dwError);		// ���� �߻��� ȣ��Ǵ� �����Լ�

protected:
	void			ResetFileList();
	int				ParseFileList(const BYTE *pPacket, DWORD dwPacketLength);
	ULONG			ParseFileSize(const BYTE *pPacket, DWORD dwPacketLength);
	int				WriteToFile(LPCTSTR lpszFilePath, char *pszData, int nDataLength);
	int				WriteToFile(PACKET_INFO &info);

	DWORD			MakeVersionRequestPacket(BYTE *pPacketBuffer);
	DWORD			MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode);
	DWORD			MakeFileSizeRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD			MakeFileDataRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD			MakeFileEndRequestPacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD			MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	BOOL			IsValidPacket(const BYTE *pPacket, DWORD dwPacketLength, PACKET_HEADER &header, PACKET_INFO &info);
	void			ProcessPacket(const BYTE *pPacket, DWORD dwPacketLength);

	int				GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	int				GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	BOOL			IsNumber(char *pszData, int nLength);
	LPCTSTR			GetNumberCD();
	LPCTSTR			GetVersion();
	ULONG			GetFileSize(LPCTSTR lpszFilePath);
	int				MoveTempFile();

	void			SetReceiveTimeOut(DWORD dwTimeOut);
	void			SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	HWND			m_hParentWnd;
	TCHAR			m_szNumberCD[20];
	TCHAR			m_szVersion[20];

	int				m_nFileIndex;
	int				m_nFileCount;
	FILEINFO		m_arFileList[MAX_FILE_COUNT];
};
