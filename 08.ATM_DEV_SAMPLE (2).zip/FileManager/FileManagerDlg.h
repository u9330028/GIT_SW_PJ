// FileManagerDlg.h : header file
//

#if !defined(AFX_FILEMANAGERDLG_H__A63C070E_52F8_41B9_B58B_56167B1DB81F__INCLUDED_)
#define AFX_FILEMANAGERDLG_H__A63C070E_52F8_41B9_B58B_56167B1DB81F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "FileSendServer.h"
#include "FileReceiveServer.h"

/////////////////////////////////////////////////////////////////////////////
// CFileManagerDlg dialog

class CFileManagerDlg : public CDialog
{
// Construction
public:
	void SetFileServerInfo(CString strIP, int nPort);
	CFileManagerDlg(CWnd* pParent = NULL);	// standard constructor
	~CFileManagerDlg();

// Dialog Data
	//{{AFX_DATA(CFileManagerDlg)
	enum { IDD = IDD_FILEMANAGER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileManagerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int ConnectToFileServer();
	void DeleteSession();

	BOOL StartupServer();
	BOOL StartupNetwork();
	BOOL StartManager();

	HICON m_hIcon;

	BOOL				m_bNetworkStartup;
	CFileSendServer		m_oFileSendServer;
	CFileReceiveServer	m_oFileReceiveServer;
	CClientSession		*m_pFileClient;

	CString				m_strFileServerIP;
	int					m_nFileServerPort;

	// Generated message map functions
	//{{AFX_MSG(CFileManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnFileServerConnect(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnFileServerConnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnFileServerDisConnected(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEMANAGERDLG_H__A63C070E_52F8_41B9_B58B_56167B1DB81F__INCLUDED_)
