// Processor.cpp: implementation of the CProcessor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Process.h"
#include "Tlhelp32.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcess::CProcess()
{

}

CProcess::~CProcess()
{

}


int CProcess::Execute(CString strProcessPath, CString strCommandParam, BOOL bWaitUntilExit, DWORD *pExitCode)
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
	CString strCommandLine = "";

    ZeroMemory( &si, sizeof(si) );
    ZeroMemory( &pi, sizeof(pi) );
	si.cb = sizeof(si);

	try
	{
		strCommandLine.Format("\"%s\" %s", strProcessPath, strCommandParam);
		if(::CreateProcess(NULL,
						   (LPTSTR)(LPCTSTR)strCommandLine,
						   NULL,
						   NULL,
						   FALSE,
						   0,
						   NULL,
						   NULL,
						   &si,
						   &pi) == 0)
		{
			// ���� ����
			return FALSE;
		}
		
		WaitForInputIdle(pi.hProcess, 3000);
		
		if(bWaitUntilExit == TRUE)
		{
			// Wait until child process exits.
			WaitForSingleObject(pi.hProcess, INFINITE);
			if(pExitCode != NULL)
			{
				GetExitCodeProcess(pi.hProcess, pExitCode);
			}

			// Close process and thread handles. 
			CloseHandle( pi.hProcess );
			CloseHandle( pi.hThread );
		}
	}
	catch(...)
	{
		return FALSE;
	}


	return TRUE;
}


BOOL CProcess::CreateProcess(DWORD pFlag, WORD pShow, LPCTSTR szCommand, LPCTSTR pDir, DWORD dwTimeOut, BOOL bWait)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory(&si,		sizeof si);
	si.dwFlags = pFlag;
	si.wShowWindow = pShow ;

	if (!::CreateProcess(NULL,
					   (char *)szCommand,
					   NULL,
					   NULL,
					   FALSE,
					   NORMAL_PRIORITY_CLASS,
					   NULL,
					   NULL,
					   &si,
					   &pi))
	{
		return FALSE;
	}

	// ���α׷��� ����Ǵ� ���� Ȯ���Ѵ�.
	// �� �������α׷��̸� �ٷ� ���ϵȴ�.
	WaitForInputIdle(pi.hProcess, dwTimeOut);
	
	if (bWait)
	{
		MSG msg;
		DWORD dwStart = GetTickCount();
		DWORD dwWaitResult = 0;

		while(GetTickCount() < dwStart + dwTimeOut)
		{
			
			if(GetExitCodeProcess(pi.hProcess, &dwWaitResult))
			{
				if(dwWaitResult != STILL_ACTIVE)
					break;
			}

			if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
			Sleep(1);
		}
	}

	CloseHandle( pi.hProcess );
	CloseHandle( pi.hThread );


	return TRUE;
}

BOOL CProcess::KillProcess(CString strFileName, BOOL bAll)
{
	BOOL bReturn		= FALSE;
    HANDLE hProcessSnap	= NULL; 
	PROCESSENTRY32 pe32	= {0};

	strFileName.TrimLeft();
	strFileName.TrimRight();
	strFileName.MakeLower();

    hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0); 

    if (hProcessSnap == INVALID_HANDLE_VALUE) 
        return FALSE; 
 
    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (Process32First(hProcessSnap, &pe32))
    {
		BOOL bFound = FALSE;
		DWORD dwExitCode = 0;
        DWORD dwPriorityClass; 
       
        do 
        {
            HANDLE	hProcess; 
			

            // Get the actual priority class. 
            hProcess = OpenProcess (PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID); 
            dwPriorityClass = GetPriorityClass (hProcess); 
             
			CString strProcessName = pe32.szExeFile;

			strProcessName.TrimLeft();
			strProcessName.TrimRight();
			strProcessName.MakeLower();

			bFound = FALSE;
			if(strProcessName.CompareNoCase(strFileName) == 0)
			{
				if (pe32.th32ProcessID != GetCurrentProcessId())
				{
					bFound = TRUE;
					if(TerminateProcess(hProcess, 0))
					{
						bReturn = TRUE;
						GetExitCodeProcess(hProcess, &dwExitCode);
					}
					else
					{
						bReturn = FALSE;
						CProcessLog::GetInstance()->WriteLog(FM_LOG,
							"KillProcess(%s) ERROR:%d", strFileName, GetLastError());
						break;
					}
				}
			}

			CloseHandle (hProcess);

			// ��� ���μ����� �����Ű��
			if (!bAll && bFound)
				break;
        } while (Process32Next(hProcessSnap, &pe32));

		if(!bFound)
			bReturn = TRUE;
    } 
    else
	{
        bReturn = FALSE;    // could not walk the list of processes 
		CProcessLog::GetInstance()->WriteLog(FM_LOG, 
			"KillProcess(%s) Process32First ERROR:%d", strFileName, GetLastError());
	}
 
    // Do not forget to clean up the snapshot object. 
    CloseHandle (hProcessSnap);

	return bReturn;	
}