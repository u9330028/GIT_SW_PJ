#include "stdafx.h"
#include "logging.h"
#include "aes.h"
#include "Define.h"

CFileLog::CFileLog()
{
    m_hLogFile = (HANDLE) -1;
	m_strFileName = _T("");

	m_bEncrypt = TRUE;
}



CFileLog::~CFileLog()
{
    CloseHandle(m_hLogFile);
    m_hLogFile = (HANDLE) -1;
}



CString CFileLog::ConvertFileName(LPCTSTR FullFileName)
{
	CString		szReturn;

	char		PathName[100] = {0x00,};
	char		FileName[50] = {0x00,};
	char		NewFileName[150] = {0x00,};
	short		i, length;
	CTime		t;

	length = lstrlen(FullFileName);

	memset(PathName, 0x00, sizeof(PathName));
	memset(FileName, 0x00, sizeof(FileName));
	memset(NewFileName, 0x00, sizeof(NewFileName));

	for (i=length;i>0;i--)
	{
		if (FullFileName[i] == 0x5c)		// ox5c is '\'
			break;
	}
	if (i > 0)
	{
		memcpy(PathName, FullFileName, i);
		lstrcpy(FileName, &(FullFileName[i+1]));

		t = CTime::GetCurrentTime();

		wsprintf(NewFileName, "%s\\%04d%02d%02d%s", PathName, t.GetYear(), t.GetMonth(), t.GetDay(), FileName);
	}
	else
	{
		lstrcpy(NewFileName, FullFileName);
	}

	szReturn = NewFileName;


	// 2010.06.14 ghk@kci.co.kr
	// �α� ��ȣȭ
	TCHAR szValue[24] = {0x00,};
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString(_T("ENCRYPT"), _T("IS_LOCAL"), _T("FALSE"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(lstrcmp(szValue, _T("TRUE")) == 0 || lstrcmp(szValue, _T("true")) == 0)
		m_bEncrypt = FALSE;
	else
		m_bEncrypt = TRUE;

	return(szReturn);
}



BOOL CFileLog::SetFileName(LPCTSTR FullFileName)
{
	short		i;
	CString		FileName;
    DWORD		dwWrite;

	FileName = ConvertFileName(FullFileName);

    if ((m_hLogFile = CreateFile(FileName.GetBuffer(0),
                            GENERIC_READ | GENERIC_WRITE,
                            0,                    // exclusive access
                            NULL,                 // no security attrs
                            OPEN_ALWAYS,
                            FILE_ATTRIBUTE_ARCHIVE,
                            NULL )) == (HANDLE) -1 )
    {
        return (FALSE);
    }

	m_strFileName = FullFileName;
    SetFilePointer(m_hLogFile, 0, NULL, FILE_END);

    WriteFile( m_hLogFile, "\xd\xa", 2, &dwWrite, NULL );
    for (i=0; i<69; i++)
	{
        WriteFile( m_hLogFile, "-", 1, &dwWrite, NULL );
	}
	CloseFile();

	return (TRUE);
}


BOOL CFileLog::OpenFile()
{
	CString		FileName;

	FileName = ConvertFileName((LPCTSTR) m_strFileName);

	if ((m_hLogFile = CreateFile(FileName.GetBuffer(0),
								 GENERIC_READ | GENERIC_WRITE,
								 0,                    // exclusive access
								 NULL,                 // no security attrs
								 OPEN_ALWAYS,
								 FILE_ATTRIBUTE_ARCHIVE,
								 NULL )) == (HANDLE) -1 )
	{
		return (FALSE);
	}

	SetFilePointer(m_hLogFile, 0, NULL, FILE_END);

	return (TRUE);
}



BOOL CFileLog::CloseFile()
{
    if (m_hLogFile == (HANDLE) -1)
        return (FALSE);

    CloseHandle(m_hLogFile);
    m_hLogFile = (HANDLE) -1;
    return (TRUE);
}


void CFileLog::Logging(char *szData, BOOL startLine)
{
    char							tmpbuf[256] = {0x00,};
    DWORD							dwWrite, dwWritten;
    BY_HANDLE_FILE_INFORMATION		FileInformation;
	SYSTEMTIME						tm;

	GetLocalTime(&tm);

	if (OpenFile() == FALSE)
		return;

    if (startLine)
	{
        GetFileInformationByHandle(m_hLogFile, &FileInformation);
        dwWrite = FileInformation.nFileSizeHigh;
        dwWrite = dwWrite << 16;
        dwWrite += FileInformation.nFileSizeLow;

/*
        if (dwWrite > MAXFILESIZE)
			NextLogFileOpen();
*/


		WriteFile( m_hLogFile, "\xd\xa", 2, &dwWritten, NULL );

		wsprintf(tmpbuf, "[%02d/%02d/%02d %02d:%02d:%02d.%03d] ", tm.wMonth, tm.wDay, tm.wYear%100, tm.wHour, tm.wMinute, tm.wSecond, tm.wMilliseconds);
		dwWrite = lstrlen((LPCTSTR) tmpbuf);
		WriteFile( m_hLogFile, tmpbuf, dwWrite, &dwWritten, NULL );
    }

	dwWrite = lstrlen((LPCTSTR) szData);
   	if(m_bEncrypt && dwWrite > 0)
	{
		int nBufferLength = (dwWrite * 2) + 256;
		TCHAR *pEncrypt = new TCHAR[nBufferLength];
		TCHAR szKey[54] = {0x00,};

		if(pEncrypt)
		{
			memset(szKey, 0x00, sizeof(szKey));
			wsprintf(szKey, _T("%04d%02d%02d"), tm.wYear, tm.wMonth, tm.wDay);

			memset(pEncrypt, 0x00, nBufferLength);
			long lResult = enc(szData, pEncrypt, nBufferLength, szKey);
			if(lResult > 0)
			{
				WriteFile( m_hLogFile, pEncrypt, lResult, &dwWritten, NULL );
			}

			delete pEncrypt;
			pEncrypt = NULL;
		}
	}
	else
	{
		WriteFile( m_hLogFile, szData, dwWrite, &dwWritten, NULL );
	}

	CloseFile();
}




void CFileLog::PrintBytes(BYTE *szData, short length, BOOL bEncrypt)
{
    DWORD	dwWritten = 0;

	if (OpenFile() == FALSE)
		return;

	if(m_bEncrypt && length > 0)
	{
		int nBufferLength = (length * 2) + 256;
		TCHAR *pEncrypt = new TCHAR[nBufferLength];
		TCHAR *pPlain = new TCHAR[length + 2];
		TCHAR szKey[54] = {0x00,};
		
		if(pEncrypt && pPlain)
		{
			SYSTEMTIME tm;
			GetLocalTime(&tm);

			memset(szKey, 0x00, sizeof(szKey));
			wsprintf(szKey, _T("%04d%02d%02d"), tm.wYear, tm.wMonth, tm.wDay);
		
			memset(pPlain, 0x00, length + 2);
			memcpy(pPlain, szData, length);

			memset(pEncrypt, 0x00, nBufferLength);
			long lResult = enc(pPlain, pEncrypt, nBufferLength, szKey);
			if(lResult > 0)
			{
				WriteFile( m_hLogFile, pEncrypt, lResult, &dwWritten, NULL );
			}
			
			delete pEncrypt;
			pEncrypt = NULL;

			delete pPlain;
			pPlain = NULL;
		}
	}
	else
	{
		WriteFile(m_hLogFile, szData, length, &dwWritten, NULL);
	}

	CloseFile();
}



void CFileLog::NextLogFileOpen(void)
{
    int         i;
	CString		FileName, NewName, strTmp;
    HANDLE      hFile;

    FileName = ConvertFileName((LPCTSTR) m_strFileName);
    NewName = FileName;

    for (i=0;i<MAXFILECOUNT;i++)
	{
		strTmp = FileName.Left (FileName.GetLength() - 3);
		FileName.Format ("%s%03d", strTmp.GetBuffer(0), i);
        if ((hFile = CreateFile(FileName.GetBuffer(0),
								GENERIC_READ,
								0,
								NULL,
                                OPEN_EXISTING,
								FILE_ATTRIBUTE_ARCHIVE, NULL)) == (HANDLE) -1 )
        {
            break;
        }

        CloseHandle(hFile);
        hFile = (HANDLE) -1;
    }
    if (i == MAXFILECOUNT)
	{
        remove(FileName.GetBuffer(0));  // Delete 99th File
        i--;							// Point 99
    }

    i--;								// Point Last File
    for (;i>=0;i--)
	{
		strTmp = FileName.Left (FileName.GetLength() - 3);
		FileName.Format ("%s%03d", strTmp.GetBuffer(0), i);
		strTmp = FileName.Left (FileName.GetLength() - 3);
		NewName.Format ("%s%03d", strTmp.GetBuffer(0), i+1);

        rename(FileName.GetBuffer(0), NewName.GetBuffer(0));
    }

    CloseHandle(m_hLogFile);
    m_hLogFile = (HANDLE) -1;

	strTmp = ConvertFileName((LPCTSTR) m_strFileName);
    rename(strTmp.GetBuffer(0), FileName.GetBuffer(0));

    m_hLogFile = CreateFile(strTmp.GetBuffer(0), GENERIC_READ | GENERIC_WRITE, 0, NULL,
                           OPEN_ALWAYS, FILE_ATTRIBUTE_ARCHIVE, NULL);
}




void CFileLog::Printf(BOOL startLine, const char *format, ...)
{
	va_list		args;
	char		buffer[4096] = {0x00,};

	va_start(args, format);

	vsprintf(buffer, format, args);

	va_end(args);

	Logging(buffer, startLine);
}

void CFileLog::Printh(BOOL startLine, void *szData, int length)
{
	
	// startLine�� TRUE/FALSE(����/������ ���)
	BYTE   bufLine[128];
	BYTE   bufTemp[8];
	BYTE * pData;
	
	int	   nBaseOffset, nBaseHexa, nBaseChar;
	int    nLength;
	int    j, i=0;
	
	//	if(m_bWrite == FALSE) return;
	
	if(length < 1) return;
	
	
	
	nLength = length;
	pData = new BYTE[nLength + 2];
	
	memset(pData, 0x00, nLength);
	memcpy(pData, szData, nLength);
	
	if (startLine == FALSE)
	{
		DWORD						dwWrite;
		CString strHexMsg;
		int i;
		
		if (OpenFile() == FALSE)
		{
			delete pData;
			return;
		}
		
		for(i=0; i < nLength; ++i)
		{
			strHexMsg.Format(" %02X", pData[i]);
			WriteFile( m_hLogFile, (BYTE *)(LPCTSTR)strHexMsg, 3, &dwWrite, NULL );
		}
		
		CloseFile();
		
	}
	else if(startLine == TRUE)
	{   //1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
		//[01234]  12 34 56 78 90 12 34 56 12 34 56 78 90 12 34 56    [1234567890123456]\r\n
		
		// HEADER�� ��´�. 
		memset(bufLine, 0x00, sizeof(bufLine));
		
		PrintBytes((BYTE *)"\r\n", 2, FALSE);
		memset(bufLine, 0x00, sizeof(bufLine));
		wsprintf((CHAR *)bufLine,"                 POS   [01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16]   [123456789ABCDEF0]");
		PrintBytes(bufLine, 90);
		
		PrintBytes((BYTE *)"\r\n", 2, FALSE);
		memset(bufLine, 0x00, sizeof(bufLine));
		wsprintf((CHAR *)bufLine,"               ==============================================================================");
		PrintBytes(bufLine, 90);
		
		
		nBaseOffset = 0;
		nBaseHexa   = 9 +15;
		nBaseChar   = 61 +15;
		while(i<nLength)
		{
			memset(bufTemp, 0x00, sizeof(bufTemp));
			memset(bufLine, 0x00, sizeof(bufLine));
			wsprintf((CHAR *)bufLine, "%s", \
				"               [     ]                                                     [                ]");
			
			// Offset�� �����Ѵ�. 
			wsprintf((CHAR *)bufTemp, "%05d", nBaseOffset);
			memcpy(bufLine+1 + 15, bufTemp, 5);
			
			for(j = 0; j<16 && i < nLength; ++j, ++i)
			{
				// hexa code�� �����Ѵ�.
				memset(bufTemp, 0x00, sizeof(bufTemp));
				wsprintf((CHAR *)bufTemp, "%02X", pData[i]);
				memcpy(bufLine + nBaseHexa + (j*3), bufTemp, 2);
				
				// char code�� �����Ѵ�. 
				bufLine[nBaseChar + j]   = (BYTE)pData[i];
			}
			
			PrintBytes((BYTE *)"\r\n\r\n", 2, FALSE);
			PrintBytes(bufLine, 90 + 15);
			nBaseOffset += 16 + 15;
		}
		
		PrintBytes((BYTE *)"\r\n\r\n", 2, FALSE);	
	}
	
	delete pData;
}