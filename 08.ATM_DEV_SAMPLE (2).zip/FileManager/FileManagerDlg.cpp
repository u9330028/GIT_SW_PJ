// FileManagerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FileManager.h"
#include "FileManagerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileManagerDlg dialog

CFileManagerDlg::CFileManagerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFileManagerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFileManagerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_bNetworkStartup = FALSE;
	
	m_pFileClient = NULL;
	m_strFileServerIP = "";
	m_nFileServerPort = FILESERVER_PORT;
}

CFileManagerDlg::~CFileManagerDlg()
{
	if(m_bNetworkStartup)
	{
		m_oFileSendServer.End();
		CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::~CFileManagerDlg] FILE_SEND ���� ����"));

		m_oFileReceiveServer.End();
		CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::~CFileManagerDlg] FILE_RECEIVE ���� ����"));
	
		WSACleanup();
		CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::~CFileManagerDlg] WSACleanup �Ϸ�"));
	}
}


void CFileManagerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileManagerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFileManagerDlg, CDialog)
	//{{AFX_MSG_MAP(CFileManagerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(UM_FILESERVER_CONNECT, OnFileServerConnect)
	ON_MESSAGE(UM_SESSION_CONNECTED, OnFileServerConnected)
	ON_MESSAGE(UM_SESSION_DISCONNECTED, OnFileServerDisConnected)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileManagerDlg message handlers

BOOL CFileManagerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	SetWindowText(TITLE_AFM);

	// ������ �����
	MoveWindow(0,0,0,0);

	StartManager();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFileManagerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		// ALT + F4 ����
		if(nID == SC_CLOSE)
			return;

		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFileManagerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFileManagerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

LRESULT CFileManagerDlg::OnFileServerConnect(WPARAM wParam, LPARAM lParam)
{
	ConnectToFileServer();

	return 1L;
}

LRESULT CFileManagerDlg::OnFileServerConnected(WPARAM wParam, LPARAM lParam)
{
	if(lParam != ERROR_SUCCESS)
	{
		DeleteSession();
		CProcessLog::GetInstance()->WriteLog(FS_LOG, 
											 _T("FILE SERVER(IP:%s PORT:%d) ���� ����"),
											 m_strFileServerIP,
											 m_nFileServerPort);
		return 0L;
	}

	CProcessLog::GetInstance()->WriteLog(FS_LOG, 
										 _T("FILE SERVER(IP:%s PORT:%d) ���� �Ϸ�"),
										 m_strFileServerIP,
										 m_nFileServerPort);

	if(!m_pFileClient->SendVersionRequestPacket())
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("������û ��Ŷ ���� ����"));
		DeleteSession();
	}

	return 1L;
/*
	CString strMessage = _T("");
	TCHAR szServerIP[20] = {0x00,};
	TCHAR szPort[20] = {0x00,};
	
	m_wndServerIP.GetWindowText(szServerIP, sizeof(szServerIP));
	m_wndPort.GetWindowText(szPort, sizeof(szPort));
	
	if(lParam != ERROR_SUCCESS)
	{
		EnableControl(FALSE);
		EnableServerInfo(TRUE);
		
		strMessage.Format(_T("SERVER IP:%s PORT:%s ���� ����(%d)"), szServerIP, szPort, lParam);
		theTrace.TraceLog(_T("[CManagerTPDlg::OnConnected] %s"), strMessage);
		SetStatusText(strMessage, TRUE);
		
		DeleteSession();
		
		//SetTimer(TIMER_NRMS_RECONNECT, ELAPSE_NRMS_RECONNECT, NULL);
		return 0L;
	}
	
	strMessage.Format(_T("SERVER IP:%s PORT:%s ���� �Ϸ�"), szServerIP, szPort);
	theTrace.TraceLog(_T("[CManagerTPDlg::OnConnected] %s"), strMessage);
	SetStatusText(strMessage, TRUE);
	
	EnableControl(TRUE);
	EnableControl(IDC_BUTTON_CONNECT, FALSE);
	
	return 1L;
*/
}

LRESULT CFileManagerDlg::OnFileServerDisConnected(WPARAM wParam, LPARAM lParam)
{
	DeleteSession();
	
	CProcessLog::GetInstance()->WriteLog(FS_LOG, 
										_T("FILE SERVER(IP:%s PORT:%d)���� ������ �����Ǿ����ϴ�."),
										m_strFileServerIP,
										m_nFileServerPort);
	
	return 1L;
}

BOOL CFileManagerDlg::StartManager()
{
	if(!StartupNetwork())
		return FALSE;
	
	// 2010.05.21 ghk@kci.co.kr
	// ���������� ���Ұ��� �ϴ��� �ٸ� ����� �����Ѵ�.
	StartupServer();

	return TRUE;
}

BOOL CFileManagerDlg::StartupNetwork()
{
	WSADATA WsaData;
	
	int nStartup = WSAStartup(MAKEWORD(2, 2), &WsaData);
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::StartupNetwork] WSAStartup %s"), (nStartup == 0 ? _T("����"): _T("����")));
	
	if(nStartup != 0)
	{
		return FALSE;
	}
		
	m_bNetworkStartup = TRUE;
	
	return TRUE;
}

BOOL CFileManagerDlg::StartupServer()
{
	BOOL bResult = TRUE;
	TCHAR szValue[20] = {0x00,};
	int nPort = SVR_PORT_LOG;

	// �α׼��� ���� ����
	nPort = SVR_PORT_LOG;
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("FileManager", "port", "", szValue, sizeof(szValue), ATOM_FILEMANAGER_INI);
	if(strlen(szValue) > 0)
		nPort = atoi(szValue);
	
	if(!m_oFileSendServer.Begin(nPort))
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::StartupServer] FILESEND���� ���� ����"));
		bResult = FALSE;
	}
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileManagerDlg::StartupServer] FILESEND(PORT:%d)���� ����"), nPort);


	// ���ϼ��� ���� ����
	nPort = SVR_PORT_SAVE;
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("FileSave", "port", "", szValue, sizeof(szValue), ATOM_FILEMANAGER_INI);
	if(strlen(szValue)>0)
		nPort = atoi(szValue);
	
	if(!m_oFileReceiveServer.Begin(nPort))
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("[CFileManagerDlg::StartupServer] FILERECEIVE ���� ���� ����"));
		bResult = FALSE;
	}
	
	CProcessLog::GetInstance()->WriteLog(FS_LOG, _T(" "));
	CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("========================================================================="));
	CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("[CFileManagerDlg::StartupServer] FILERECEIVE(PORT:%d) ���� ����"), nPort);
	

	return bResult;
}

BOOL CFileManagerDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_F4))
	{
		// ESCAPE, ENTER KeyDown ����
		return TRUE;
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CFileManagerDlg::SetFileServerInfo(CString strIP, int nPort)
{
	m_strFileServerIP = strIP;
	m_nFileServerPort = nPort;
}

void CFileManagerDlg::DeleteSession()
{
	if(m_pFileClient)
	{
		m_pFileClient->End();
		delete m_pFileClient;
		m_pFileClient = NULL;
	}
}

int CFileManagerDlg::ConnectToFileServer()
{
	m_pFileClient = new CClientSession(GetSafeHwnd());
	
	CProcessLog::GetInstance()->WriteLog(FS_LOG, 
										_T("FILE SERVER(IP:%s PORT:%d) ���� ����"),
										m_strFileServerIP,
										m_nFileServerPort);

	return m_pFileClient->Begin((LPTSTR)(LPCTSTR) m_strFileServerIP, m_nFileServerPort);
}
