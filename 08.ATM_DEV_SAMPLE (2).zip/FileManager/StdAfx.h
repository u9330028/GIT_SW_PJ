// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__B243F0A2_FF3A_4872_BED6_1FD8DEFB6943__INCLUDED_)
#define AFX_STDAFX_H__B243F0A2_FF3A_4872_BED6_1FD8DEFB6943__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <vector>
#include "winsock2.h"
#include "mswsock.h"

#include "Define.h"
#include "Directory.h"
#include "ProcessLog.h"

#include "Critical.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "PacketSession.h"
#include "Iocp.h"


#include "ConnectedSession.h"
#include "SessionManager.h"

#include "EventSelect.h"
#include "ClientSession.h"

#include "ZipFile.h"
#include "UnzipFile.h"
#include "shlwapi.h"

#include "ErrorMessage.h"


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__B243F0A2_FF3A_4872_BED6_1FD8DEFB6943__INCLUDED_)
