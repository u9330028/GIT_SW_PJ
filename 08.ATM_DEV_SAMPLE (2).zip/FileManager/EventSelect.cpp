#include "stdafx.h"
#include "EventSelect.h"

DWORD WINAPI SelectThreadCallback(LPVOID parameter)
{
	CEventSelect *pOwner = (CEventSelect*) parameter;
	pOwner->SelectThreadCallback();

	return 0;
}

void CEventSelect::SelectThreadCallback(void)
{
	WSANETWORKEVENTS	NetworkEvents;
	DWORD				dwEventID = 0;
	DWORD				dwResult	= 0;
	HANDLE				hThreadEvents[2] = {m_hDestroyEventHandle, m_hSelectEventHandle};

	while (TRUE)
	{
		SetEvent(m_hStartupEventHandle);

		dwEventID = ::WaitForMultipleObjects(2, hThreadEvents, FALSE, INFINITE);
		switch (dwEventID)
		{
		case WAIT_OBJECT_0:
			return;

		case WAIT_OBJECT_0 + 1:
			dwResult = WSAEnumNetworkEvents(m_hSocket, m_hSelectEventHandle, &NetworkEvents);

			if (dwResult == SOCKET_ERROR)
			{
				OnIoError(WSAGetLastError());
				return;
			}
			else
			{
				if (NetworkEvents.lNetworkEvents & FD_CONNECT)
				{
					if (NetworkEvents.iErrorCode[FD_CONNECT_BIT])
					{
						OnIoConnected(NetworkEvents.iErrorCode[FD_CONNECT_BIT]);
						return;
					}

					OnIoConnected(0);
				}
				else if (NetworkEvents.lNetworkEvents & FD_WRITE)
				{
					//OnIoWrote();
				}
				else if (NetworkEvents.lNetworkEvents & FD_READ)
				{
					OnIoRead();
				}
				else if (NetworkEvents.lNetworkEvents & FD_CLOSE)
				{
					OnIoDisconnected();

					return;
				}
			}
			break;

		default:
			return;
		}
	}

	return;
}

CEventSelect::CEventSelect(void)
{
	m_hSelectEventHandle	= NULL;
	m_hDestroyEventHandle	= NULL;
	m_hSelectThreadHandle	= NULL;
	m_hStartupEventHandle	= NULL;

	m_hSocket				= NULL;
}

CEventSelect::~CEventSelect(void)
{
}

BOOL CEventSelect::Begin(SOCKET socket)
{
	if (!socket)
		return FALSE;

	if (m_hSocket)
		return FALSE;

	m_hSocket = socket;

	m_hSelectEventHandle = WSACreateEvent();
	if (m_hSelectEventHandle == WSA_INVALID_EVENT)
	{
		End();

		return FALSE;
	}

	m_hDestroyEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	if (m_hDestroyEventHandle == NULL)
	{
		End();

		return FALSE;
	}

	m_hStartupEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	if (m_hStartupEventHandle == NULL)
	{
		End();

		return FALSE;
	}

	DWORD dwResult = WSAEventSelect(socket, m_hSelectEventHandle, FD_CONNECT | FD_READ | FD_WRITE | FD_CLOSE);
	if (dwResult == SOCKET_ERROR)
	{
		End();

		return FALSE;
	}

	DWORD SelectThreadID	= 0;
	m_hSelectThreadHandle	= CreateThread(NULL, 0, ::SelectThreadCallback, this, 0, &SelectThreadID);

	if (!m_hSelectThreadHandle)
	{
		End();

		return FALSE;
	}

	// Thread�� Wait�ɶ����� �ð��� �����ش�.
	WaitForSingleObject(m_hStartupEventHandle, INFINITE);

	return TRUE;
}

BOOL CEventSelect::End(void)
{
	if (!m_hSocket)
		return FALSE;

	if(m_hSelectThreadHandle)
	{
		SetEvent(m_hDestroyEventHandle);

		WaitForSingleObject(m_hSelectThreadHandle, INFINITE);

		CloseHandle(m_hSelectThreadHandle);
		m_hSelectThreadHandle = NULL;
	}

	if(m_hSelectEventHandle)
	{
		CloseHandle(m_hSelectEventHandle);
		m_hSelectEventHandle = NULL;
	}

	if(m_hDestroyEventHandle)
	{
		CloseHandle(m_hDestroyEventHandle);
		m_hDestroyEventHandle = NULL;
	}

	if(m_hStartupEventHandle)
	{
		CloseHandle(m_hStartupEventHandle);
		m_hStartupEventHandle = NULL;
	}

	return TRUE;
}
