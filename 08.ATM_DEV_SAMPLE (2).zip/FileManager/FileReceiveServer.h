// FileReceiveServer.h: interface for the CFileReceiveServer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILERECEIVESERVER_H__52C62C05_475D_4108_AE85_CBC82142165B__INCLUDED_)
#define AFX_FILERECEIVESERVER_H__52C62C05_475D_4108_AE85_CBC82142165B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ServerIocp.h"

class CFileReceiveServer : public CServerIocp  
{
public:
	CFileReceiveServer();
	virtual ~CFileReceiveServer();

private:
	TCHAR m_szNumberCD[20];
	BOOL m_bZipFile;
	
public:
	ULONG GetFileSize(LPCTSTR lpszFilePath);
	BOOL IsNumber(char *pszData, int nLength);
	LPCTSTR GetNumberCD();
	
	DWORD MakeFileSizePacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD MakeFileDataPacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode);
	
protected:
	// ��Ŷ ó���� �� �Լ�
	void ProcessPacket(CConnectedSession *pConnectedSession, BYTE *pPacket, DWORD dwPacketLength);
	
	BOOL IsValidPacket(const BYTE *pPacket, DWORD dwPacketLength, PACKET_HEADER &header, PACKET_INFO &info);
	
	int GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	int GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	int GetZipFileName(LPCTSTR szFilePath, TCHAR *szZipFileName);
	int MakeZipFile(char* szFullFilePath);
	int ReadFile(CFile *pFile, LONGLONG lFilePtr, int nBytesToRead, char *szReadBuffer);
	int	WriteToFile(LPCTSTR lpszFilePath, char *pszData, int nDataLength);

	int ConnectToFileServer(BYTE *pPacket, DWORD dwPacketLength);
	int ConnectToFileServer(LPCTSTR lpszAddress, int nPort);
};

#endif // !defined(AFX_FILERECEIVESERVER_H__52C62C05_475D_4108_AE85_CBC82142165B__INCLUDED_)
