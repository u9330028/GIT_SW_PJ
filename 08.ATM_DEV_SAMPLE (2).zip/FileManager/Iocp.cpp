#include "stdafx.h"
#include "Iocp.h"

DWORD WINAPI WorkerThreadCallback(LPVOID parameter)
{
	CIocp *pOwner = (CIocp*) parameter;
	if(pOwner)
	{
		pOwner->WorkerThreadCallback();
	}
	
	return 0;
}

CIocp::CIocp(VOID)
{
	m_hIocpHandle			= NULL;
	m_dwWorkerThreadCount	= 0;

	m_hStartupEventHandle	= NULL;
}

CIocp::~CIocp(VOID)
{
}

BOOL CIocp::Begin(VOID)
{
	m_hIocpHandle		= NULL;

	SYSTEM_INFO SystemInfo;
	GetSystemInfo(&SystemInfo);

	m_dwWorkerThreadCount	= SystemInfo.dwNumberOfProcessors * 2;
	m_hIocpHandle			= CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);

	if (!m_hIocpHandle)
		return FALSE;

	m_hStartupEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	if (m_hStartupEventHandle == NULL)
	{
		End();

		return FALSE;
	}

	for (DWORD i=0; i<m_dwWorkerThreadCount; i++)
	{
		HANDLE hWorkerThread = CreateThread(NULL, 0, ::WorkerThreadCallback, this, 0, NULL);
		m_vWorkerThread.push_back(hWorkerThread);

		WaitForSingleObject(m_hStartupEventHandle, INFINITE);
	}

	return TRUE;
}

BOOL CIocp::End(VOID)
{
	DWORD i = 0;
	for (i=0;i<m_vWorkerThread.size();i++)
		PostQueuedCompletionStatus(m_hIocpHandle, 0, 0, NULL);

	for (i=0;i<m_vWorkerThread.size();i++)
	{
		WaitForSingleObject(m_vWorkerThread[i], INFINITE);

		CloseHandle(m_vWorkerThread[i]);

		// 2010.07.28 ghk@kci.co.kr
		// ����� ������ �ڵ� �ʱ�ȭ
		m_vWorkerThread[i] = NULL;
	}

	if (m_hIocpHandle)
	{
		CloseHandle(m_hIocpHandle);

		// 2010.07.28 ghk@kci.co.kr
		// ����� �ڵ� �ʱ�ȭ
		m_hIocpHandle = NULL;
	}

	m_vWorkerThread.clear();

	if (m_hStartupEventHandle)
	{
		CloseHandle(m_hStartupEventHandle);
		// 2010.07.28 ghk@kci.co.kr
		// ����� �ڵ� �ʱ�ȭ
		m_hStartupEventHandle = NULL;
	}

	return TRUE;
}

BOOL CIocp::RegisterSocketToIocp(SOCKET hSocket, ULONG_PTR completionKey)
{
	if (!hSocket || !completionKey)
		return FALSE;

	m_hIocpHandle = CreateIoCompletionPort((HANDLE) hSocket, m_hIocpHandle, completionKey, 0);

	if (!m_hIocpHandle)
		return FALSE;

	return TRUE;
}

VOID CIocp::WorkerThreadCallback(VOID)
{
	BOOL			bSuccessed					= FALSE;
	DWORD			dwNumberOfByteTransfered	= 0;
	VOID			*CompletionKey				= NULL;
	OVERLAPPED		*Overlapped					= NULL;
	OVERLAPPEDEX	*OverlappedEx				= NULL;
	VOID			*Object						= NULL;

	while (TRUE)
	{
		SetEvent(m_hStartupEventHandle);

		bSuccessed = GetQueuedCompletionStatus(m_hIocpHandle,
											   &dwNumberOfByteTransfered,
											   (LPDWORD) &CompletionKey,
											   &Overlapped,
											   INFINITE);

		if (!CompletionKey)
			return;

		OverlappedEx	= (OVERLAPPEDEX*) Overlapped;
		Object			= OverlappedEx->Object;

		if (!bSuccessed || (bSuccessed && !dwNumberOfByteTransfered))
		{
			if (OverlappedEx->IoType == IO_ACCEPT)
				OnIoConnected(Object);
			else
				OnIoDisconnected(Object);

			continue;
		}

		switch (OverlappedEx->IoType)
		{
		case IO_READ:
			OnIoRead(Object, dwNumberOfByteTransfered);
			break;

		case IO_WRITE:
			OnIoWrote(Object, dwNumberOfByteTransfered);
			break;
		}
	}
}