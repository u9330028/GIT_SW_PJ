// Directory.cpp: implementation of the CDirectory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Directory.h"
#include <stdio.h>
#include <windows.h>



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDirectory::CDirectory()
{

}

CDirectory::~CDirectory()
{

}

CString CDirectory::GetDirectory(CString strFilePath)
{
	CString strDirectoryPath = _T("");
	CString strFile = strFilePath;
	
	if(strFile.GetLength() <= 0)
		return strDirectoryPath;
	
	strDirectoryPath = strFile;
	if(strFile.Find(_T(".")) == -1)
		return strDirectoryPath;

	strFile.Replace('\\', '/');
	int nIndex = strFile.ReverseFind('/');
	strDirectoryPath = strFile.Left(nIndex);
	if(strDirectoryPath.GetLength() > 1 && strDirectoryPath.Right(1) == '/')
		strDirectoryPath = strDirectoryPath.Left(nIndex - 1);
	
	return strDirectoryPath;
}

BOOL CDirectory::GetDirectory(CString strFilePath, CString &strDirectoryPath)
{
	strDirectoryPath = _T("");
	CString strFile = strFilePath;

	if(strFile.GetLength() <= 0)
		return FALSE;

	strDirectoryPath = strFile;
	if(strFile.Find(_T(".")) != -1)
	{
		strFile.Replace('\\', '/');
		int nIndex = strFile.ReverseFind('/');
		strDirectoryPath = strFile.Left(nIndex);
	}

	return TRUE;
}


BOOL CDirectory::MakeDirectory(const CString strPath)
{
	CString strDirectory = strPath;
	strDirectory.Replace('\\', '/');

	if(strDirectory.IsEmpty())
		return FALSE;

	// remove ending / if exists
	if(strDirectory.Right(1) == "/")
		strDirectory = strDirectory.Left(strDirectory.GetLength() - 1); 

	// base case . . .if directory exists
	DWORD dwFileAttribute = GetFileAttributes(strDirectory);
	if(dwFileAttribute != -1)
	{
		if(dwFileAttribute & FILE_ATTRIBUTE_DIRECTORY)
			return TRUE;
	}

	// recursive call, one less directory
	int nFound = strDirectory.ReverseFind('/');
	if(nFound != -1)
	{
		MakeDirectory(strDirectory.Left(nFound));
	}

	// actual work
	if (!CreateDirectory(strDirectory, NULL)) 
		return FALSE;

	return TRUE;
}

BOOL CDirectory::GetFileName(CString strFilePath, CString &strFileName)
{
	CString strFile = strFilePath;
	int nLength = strFile.GetLength();
	if(nLength <= 0)
		return FALSE;

	strFile.Replace('\\', '/');
	int nIndex = strFile.ReverseFind('/') + 1;
	int nCount = nLength - nIndex;
	if(nCount > 0)
		strFileName = strFile.Mid(nIndex, nCount);
	else
		return FALSE;

	return TRUE;
}

BOOL CDirectory::DeleteDirectory(CString strPath, BOOL bRemoveDirectory)
{
	DWORD dwAttr = GetFileAttributes(strPath);
	if (dwAttr != 0xffffffff) 
	{
		if (!(dwAttr & FILE_ATTRIBUTE_DIRECTORY))
		{
			DeleteFile(strPath);
			return TRUE;
		}
	}


	CFileFind ff;
	CString strPathName = GetDirectory(strPath) + _T("/*.*");
	
	BOOL bRes = ff.FindFile(strPathName);
	while(bRes)
	{
		bRes = ff.FindNextFile();
		if (ff.IsDots())
			continue;
		
		if (ff.IsDirectory())
		{
			strPathName = ff.GetFilePath();
			DeleteDirectory(strPathName);
		}
		else
		{
			DeleteDirectory(ff.GetFilePath());
		}
	}
	ff.Close();

	if(bRemoveDirectory)
	{
		RemoveDirectory(strPath);
	}
	

	return TRUE;
}