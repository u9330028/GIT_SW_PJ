//////////////////////////////////////////////////////////////////////
// ExecVersion.cpp: implementation of the CExecVersion class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ExecVersion.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

typedef struct tagLANGANDCODEPAGE 
{
	WORD wLanguage;
	WORD wCodePage;
} LANGANDCODEPAGE, *LPLANGANDCODEPAGE;

LPLANGANDCODEPAGE lpTranslate;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CExecVersion::CExecVersion()
{
	m_dwSize = 0;
	m_lpBuffer = NULL;
	m_lpData = NULL;
	m_lpszImageName = "";

	InitVer();
}

CExecVersion::CExecVersion(LPTSTR lpszImageName)
{
	m_dwSize = 0;
	m_lpBuffer = NULL;
	m_lpszImageName = lpszImageName;

	InitVer();
}

CExecVersion::~CExecVersion()
{
	if(m_lpBuffer != NULL)
	{
		free(m_lpBuffer);
		m_lpBuffer = NULL;
	}
}

CString CExecVersion::GetProductName()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\ProductName"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetProductVersion()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\ProductVersion"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetCompanyName()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\CompanyName"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetCopyright()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\LegalCopyright"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetComments()
{
	CString	strComments = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};

	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);

		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\Comments"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);

			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}

		if(m_uiDataSize == 0)
			strComments = "";
		else
			strComments.Format("%s", m_lpData);
	}

	return strComments;
}

CString CExecVersion::GetFileDescription()
{
	CString	strFileDescr = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};

	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);

		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\FileDescription"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);

			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}

		if(m_uiDataSize == 0)
			strFileDescr = "";
		else
			strFileDescr.Format("%s", m_lpData);
	}

	return strFileDescr;
}


CString CExecVersion::GetFileVersion()
{
	CString	strFileVer = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};

	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);

		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\FileVersion"),	lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);

			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}

		if(m_uiDataSize == 0)
			strFileVer = "";
		else
			strFileVer.Format("%s", m_lpData);
	}

	return strFileVer;
}

CString CExecVersion::GetInternalName()
{
	CString	strInternalName = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\InternalName"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strInternalName = "";
		else
			strInternalName.Format("%s", m_lpData);
	}
	
	return strInternalName;
}

CString CExecVersion::GetLegalTrademarks()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\LegalTrademarks"),	lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetPrivateBuild()
{
	CString	strVersion = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\PrivateBuild"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strVersion = "";
		else
			strVersion.Format("%s", m_lpData);
	}
	
	return strVersion;
}

CString CExecVersion::GetSpecialBuild()
{
	CString	strSpecBuild = "";
	CString strTemp = "";
	LPSTR SubBlock = {0x00,};
	
	if(m_lpBuffer != NULL)
	{
		// Read the list of languages and code pages.
		VerQueryValue(m_lpBuffer, TEXT("\\VarFileInfo\\Translation"), (LPVOID*)&lpTranslate, &m_uiDataSize);
		
		// Read the file description for each language and code page.
		int nEnd = (m_uiDataSize / sizeof(LANGANDCODEPAGE));
		for (int i=0; i < nEnd; i++)
		{
			strTemp.Format(("\\StringFileInfo\\%04x%04x\\SpecialBuild"), lpTranslate[i].wLanguage, lpTranslate[i].wCodePage);
			SubBlock = strTemp.GetBuffer(0);
			
			// Retrieve file description for language and code page "i". 
			VerQueryValue(m_lpBuffer, SubBlock, &m_lpData, &m_uiDataSize); 
		}
		
		if(m_uiDataSize == 0)
			strSpecBuild = "";
		else
			strSpecBuild.Format("%s", m_lpData);
	}

	return strSpecBuild;
}

void CExecVersion::InitVer()
{
	m_dwHandle = 0;
	m_uiDataSize = 0;


//	m_lpData = malloc(m_uiDataSize);
	// Get the version information block size, then use it to allocate a storage buffer.
	m_dwSize = ::GetFileVersionInfoSize(m_lpszImageName, &m_dwHandle);
	if(m_dwSize > 0)
	{
		m_lpBuffer = malloc(m_dwSize);
		
		// Get the versioninformation block
		::GetFileVersionInfo(m_lpszImageName, 0, m_dwSize, m_lpBuffer);
	}
}
