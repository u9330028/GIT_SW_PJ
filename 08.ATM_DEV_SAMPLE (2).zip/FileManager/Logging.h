#ifndef _FILE_LOG
#define _FILE_LOG

#define MAXFILESIZE    1000000
#define MAXFILECOUNT	10

class CFileLog
{
public:
	CFileLog();
	~CFileLog();

private:
    HANDLE      m_hLogFile;          // Handle for log file
	CString		m_strFileName;
	BOOL		m_bEncrypt;

private:
	CString		ConvertFileName(LPCTSTR FullFileName);
    BOOL		OpenFile();
    BOOL		CloseFile();
    void		NextLogFileOpen(void);
    void		Logging(char *szData, BOOL startLine);

public:
	BOOL		SetThisFile(char *FullFileName);
	BOOL		SetFileName(LPCTSTR FullFileName);
    void		PrintBytes(BYTE *szData, short length, BOOL bEncrypt = TRUE);
	void		Printf(BOOL startLine, const char *format, ...);
	void		Printh(BOOL startLine, void *szData, int length);
};

#endif
