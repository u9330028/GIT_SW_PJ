#include "stdafx.h"
#include "Critical.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "PacketSession.h"

CPacketSession::CPacketSession(VOID)
{
	m_nRemainLength = 0;
	memset(m_btPacketBuffer, 0, sizeof(m_btPacketBuffer));
}

CPacketSession::~CPacketSession(VOID)
{
}

BOOL CPacketSession::Begin(VOID)
{
	CThreadSync Sync;

	m_nRemainLength = 0;
	memset(m_btPacketBuffer, 0, sizeof(m_btPacketBuffer));

	if (!m_oWriteQueue.Begin())
		return FALSE;

	return CNetworkSession::Begin();
}

BOOL CPacketSession::End(VOID)
{
	CThreadSync Sync;

	if (!m_oWriteQueue.End())
		return FALSE;

	return CNetworkSession::End();
}

UINT CPacketSession::GetPacket(BYTE *packet, DWORD &packetLength)
{
	CThreadSync Sync;

	if (!packet)
		return PACKET_INVALID_PACKET_LENGTH;

	UINT nRemainSize = sizeof(DWORD);
	if (m_nRemainLength < nRemainSize)
		return PACKET_INVALID_PACKET_LENGTH;

	TCHAR szPacketLength[10] = {0x00, };
	INT nPacketLength = 0;

	// STX(1) + LENGTH(4)
	memset(szPacketLength, 0x00, sizeof(szPacketLength));
	memcpy(szPacketLength, &m_btPacketBuffer[1], 4);
	nPacketLength = atoi(szPacketLength);

	if (nPacketLength > MAX_BUFFER_LENGTH || nPacketLength <= 0) // Invalid Packet
	{
		m_nRemainLength = 0;
		return PACKET_INVALID_PACKET_LENGTH;
	}

	if (nPacketLength <= m_nRemainLength)
	{
		packetLength = nPacketLength;
		memcpy(packet, m_btPacketBuffer, packetLength);

		if(m_nRemainLength - nPacketLength > 0)
		{
			memmove(m_btPacketBuffer, m_btPacketBuffer + nPacketLength, m_nRemainLength - nPacketLength);
		}

		m_nRemainLength -= nPacketLength;
		if (m_nRemainLength <= 0)
		{
			m_nRemainLength = 0;
			memset(m_btPacketBuffer, 0, sizeof(m_btPacketBuffer));
		}

		return PACKET_EXIST;
	}

	return PACKET_INVALID_PACKET_LENGTH;
}

// ReadPacketForIocp�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadPacketForIocp(DWORD readLength)
{
	CThreadSync Sync;

	if (!CNetworkSession::ReadForIocp(m_btPacketBuffer + m_nRemainLength, readLength))
		return FALSE;

	m_nRemainLength	+= readLength;

	//return getPacket(protocol, packet, packetLength);
	return TRUE;
}

// ReadPacketForEventSelect�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadPacketForEventSelect(VOID)
{
	CThreadSync Sync;

	DWORD ReadLength = 0;

	if (!CNetworkSession::ReadForEventSelect(m_btPacketBuffer + m_nRemainLength, ReadLength))
		return FALSE;

	m_nRemainLength	+= ReadLength;

	//return getPacket(protocol, packet, packetLength);
	return TRUE;
}


BOOL CPacketSession::WritePacket(const BYTE *pPacket, DWORD dwPacketLength)
{
	CThreadSync Sync;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(btPacket, 0x00, sizeof(btPacket));
	memcpy(btPacket, pPacket, dwPacketLength);
	
	
	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = m_oWriteQueue.Push(this, btPacket, dwPacketLength);
	
//	theTrace.TraceHex(btPacket, dwPacketLength);
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;
	
	if (!lpCommand)
		return FALSE;
	
	// STX(1) + LENGTH(4) + CMD(2) + FS(1) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 9 + dwDataLength;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));
	
	sprintf(szLength, "%04d", dwPacketLength);
	
	btPacket[0] = STX;
	memcpy(&btPacket[1], szLength, 4);	// ��Ŷ���� 4�ڸ�
	memcpy(&btPacket[5], lpCommand, 2);	// ���ɾ� 2�ڸ�
	btPacket[7] = FS;
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[8], pData, dwDataLength);	// ���ɾ� 2�ڸ�
	}
	btPacket[8 + dwDataLength] = ETX;
	
	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = m_oWriteQueue.Push(this, btPacket, dwPacketLength);
	
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;
	
	if (!lpCommand || !lpNumberCD)
		return FALSE;
	
	// STX(1) + LENGTH(4) + CMD(2) + FS(1) + CDNUMBER(4) + FS(1) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 14 + dwDataLength;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));
	
	wsprintf(szLength, "%04d", dwPacketLength);
	
	btPacket[0] = STX;
	memcpy(&btPacket[1], szLength, 4);	// ��Ŷ���� 4�ڸ�
	memcpy(&btPacket[5], lpCommand, 2);	// ���ɾ� 2�ڸ�
	btPacket[7] = FS;
	memcpy(&btPacket[8], lpNumberCD, 4);	// ���ɾ� 2�ڸ�
	btPacket[12] = FS;
	
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[13], pData, dwDataLength);	// ���ɾ� 2�ڸ�
	}
	btPacket[13 + dwDataLength] = ETX;

	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = m_oWriteQueue.Push(this, btPacket, dwPacketLength);
	
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WriteComplete(VOID)
{
	CThreadSync Sync;

	// WriteQueue���� Pop�� �� �ָ� �ȴ�.
	return m_oWriteQueue.Pop();
}
