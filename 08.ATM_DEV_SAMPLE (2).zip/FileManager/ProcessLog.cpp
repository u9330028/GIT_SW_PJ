// ProcessLog.cpp: implementation of the CProcessLog class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ProcessLog.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProcessLog logger;
//CCriticalSection m_cs;

CProcessLog::CProcessLog()
{
// 	// IS_LOCAL == FALSE �̸� ��ȣȭ
// 	CProcessIniRead IniRead(PATH_IBP_CONFIG);
// 	bLogEncryption = IniRead.ReadBoolean("ENCRYPT","IS_LOCAL",FALSE);
	::InitializeCriticalSection(&m_cs);	
}

CProcessLog::~CProcessLog()
{
	::DeleteCriticalSection(&m_cs);
}

CProcessLog* CProcessLog::GetInstance()
{
	return &logger;
}

/***********************************************************
* Function : �α� ���� ���� �޼ҵ�
* Parameter : strFileName	: ��¥�� ������ �α����� Full Path
			strAlias	: �α������� ����(Map�� ���� ���ϸ� lookup �� ��� key) -> �������� log ���� ó���� ����
			isEncrypt	: TRUE = ��ȣȭ, FALSE = ���ȣȭ
* ReturnType : 
*
* 20100823 kimjiyoung 
* - 
***********************************************************/
void CProcessLog::SetFileName(CString strFileName, CString strAlias, BOOL isEncrypt)
{
	//m_strFileName = strFileName;
	m_mapFileName.SetAt(strAlias, strFileName);
	m_bLogEncryption = isEncrypt;
}

/***********************************************************
* Function : �α� �ۼ��� ���� �ܺο��� ȣ��Ǵ� �޼ҵ�
* Parameter : �α׷� ������ ������
* ReturnType : 
*
* 20100107 kimjiyoung 
* - ���ο��� ���Ͽ� Write�ϴ� �޼ҵ� ȣ��
***********************************************************/
void CProcessLog::WriteLog(CString strAlias, char* szLogFmt, ...)
{
	//m_cs.Lock();
	::EnterCriticalSection( &m_cs );

	va_list ap;
	char chLogStr[BUFSIZE + 1];

	va_start(ap, szLogFmt);
	memset(chLogStr, 0x00, (BUFSIZE + 1));
	vsprintf(chLogStr, szLogFmt, ap);

	m_strAlias = strAlias;
	WriteMsgLog(chLogStr);

	//m_cs.Unlock();
	::LeaveCriticalSection(&m_cs);
}

// void CProcessLog::WriteBizLog(char* szLogFmt, ...)
// {
// 	//m_cs.Lock();
// 	::EnterCriticalSection( &m_cs );
// 	
// 	va_list ap;
// 	char chLogStr[BUFSIZE + 1];
// 	
// 	va_start(ap, szLogFmt);
// 	memset(chLogStr, 0x00, (BUFSIZE + 1));
// 	vsprintf(chLogStr, szLogFmt, ap);
// 	
// 	WriteMsgLog(chLogStr,TRUE);
// 	
// 	//m_cs.Unlock();
// 	::LeaveCriticalSection(&m_cs);
// }

/***********************************************************
* Function : Map���� �α� ���ϸ� �˻��ϴ� �޼ҵ�
* Parameter : 
* ReturnType : 
*
* 20100823 kimjiyoung 
* - 
***********************************************************/
void CProcessLog::GetFileName()
{
	CString strFileName;
	m_mapFileName.Lookup(m_strAlias, strFileName);

	SYSTEMTIME t;
	::GetLocalTime(&t);
	CString today;
	today.Format("%04d%02d%02d", t.wYear, t.wMonth, t.wDay);

	char chTemp = 0x5C;
	int nFind = strFileName.ReverseFind(chTemp);
	m_strLogFile = strFileName.Mid(0, nFind+1) + today + strFileName.Mid(nFind+1);
}

/***********************************************************
* Function : �α� �ۼ��� ���� ���ο��� ȣ��Ǵ� �޼ҵ�
* Parameter : �α׷� ������ ������
* ReturnType : 
*
* 20100107 kimjiyoung 
* - ������ �α� ���Ͽ� Write�ϴ� �޼ҵ�
* 20100823 kimjiyoung
* - �ܺο��� ������ �α� ���ϸ����� �α� ó���ϵ��� ����
***********************************************************/
void CProcessLog::WriteMsgLog(char* szLogBuff)
{
	
	char	tmpbuf[128];
	DWORD	dwWrite;
	
	try
	{
		// 20100823 kimjiyoung search file name
		GetFileName();
		
// 		if(bBiz == FALSE)
// 			m_strLogFile = CUtilConfig::GetInstance()->GetLogPath() + "\\" + today + "IBP.txt";
// 		else
// 			m_strLogFile = CUtilConfig::GetInstance()->GetLogPath() + "\\" + today + "BizLog.txt";

		FILE* fpLog;
		fpLog = fopen(m_strLogFile.GetBuffer(0), "a+b");
		if (fpLog == NULL)
			return;

		SYSTEMTIME t;
		GetLocalTime(&t);

		sprintf(tmpbuf, "[%02d/%02d/%02d %02d:%02d:%02d.%03d] ", t.wMonth, t.wDay, t.wYear%100, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
		dwWrite = lstrlen((LPCTSTR) tmpbuf);
		
		if(m_bLogEncryption == TRUE)
		{
			char	UserKey[16] = {0};
			CTime	ct;				

			ct = CTime::GetCurrentTime();			// Get Encrypt Key...
			sprintf(UserKey, "%04d%02d%02d", ct.GetYear(), ct.GetMonth(), ct.GetDay());
			char *lpEncBuffer;	
			long encLen = 0;
			
			dwWrite = lstrlen((LPCTSTR) szLogBuff);	// Logging Data
			
			lpEncBuffer = new char[(dwWrite + 16) * 2 + 2];
			
			// Logging Data ��ȣȭ(Encryption) ����...
#ifdef _DEBUG
			sprintf(lpEncBuffer, "%s", szLogBuff);
#else
			encLen = enc((LPSTR)szLogBuff, lpEncBuffer, (dwWrite + 16) * 2, UserKey);
#endif
			fprintf(fpLog, "%s%s\r\n", tmpbuf, lpEncBuffer);
			
			delete lpEncBuffer;
		}
		else
		{
			fprintf(fpLog, "%s%s\r\n", tmpbuf, szLogBuff);
		}

		fclose(fpLog);
	}
	catch(...)
	{
	}
}


// void CProcessLog::MaintenceLogFiles()
// {
// 	// ���� ��¥
// 	CTime ctime = CTime::GetCurrentTime();
// 	// �α� ���� �Ⱓ
// 	int nKeepDay = CUtilConfig::GetInstance()->GetLogKeepDay();
// 
// 	CTimeSpan timeSpan(nKeepDay, 0, 0, 0);
// 	CTime keepLastDay = ctime - timeSpan;
// 	CString strYesterday;
// 	strYesterday.Format(_T("%d-%d-%d"), keepLastDay.GetYear(), keepLastDay.GetMonth(), keepLastDay.GetDay());
// 
// 	// log files
// 	
// 	CString strPath = CUtilConfig::GetInstance()->GetLogPath();
// 
// 	CFileFind finder;
// 	BOOL bWorking = finder.FindFile( strPath  + "\\IBP_*.log");
// 	while ( bWorking )
// 	{
// 		bWorking = finder.FindNextFile();
// 		if ( !(finder.IsDots() && finder.IsDirectory()) )
// 		{
// 			CString strFileName = (LPCTSTR)finder.GetFileName();
// 			int nStart = strFileName.Find('_')+1;
// 			int nYear = atoi(strFileName.Mid(nStart, 4));
// 			int nMonth = atoi(strFileName.Mid(nStart+4, 2));
// 			int nDay = atoi(strFileName.Mid(nStart+6, 2));
// 
// 			CTime fileDay(nYear, nMonth, nDay, 0, 0, 0);
// 
// 			if (fileDay < keepLastDay)
// 			{
// 				char chDeleteFilePath[MAX_PATH];
// 				strcpy(chDeleteFilePath, strPath + "\\" + strFileName);
// 				BOOL b = DeleteFile(chDeleteFilePath);
// 			}
// 		}
// 	}
// 	finder.Close();
// }

/***********************************************************
* Function : Hexa code log �޼ҵ�
* Parameter : strAlias	: �α������� ����(Map�� ���� ���ϸ� lookup �� ��� key) -> �������� log ���� ó���� ����
			szDumpTitle	: Hexa code ������ �պκ� comment
			data		: BYTE Data
			nSize		: data length
* ReturnType : 
*
* 20100823 kimjiyoung 
* - 
***********************************************************/
void CProcessLog::Dump(CString strAlias, char* szDumpTitle, BYTE *data, int nSize)
{	
	//m_cs.Lock();
	::EnterCriticalSection( &m_cs );

	// 20100823 kimjiyoung search file name
	m_strAlias = strAlias;
	GetFileName();

// 	SYSTEMTIME t;
// 	::GetLocalTime(&t);
// 	CString today;
// 	today.Format("%04d%02d%02d", t.wYear, t.wMonth, t.wDay);
// 
// 	m_strLogFile = CUtilConfig::GetInstance()->GetLogPath() + "\\" + today + "IBP.txt";

	FILE* fpLog;
	fpLog = fopen(m_strLogFile.GetBuffer(0), "a+b");
	if (fpLog == NULL)
	{
		::LeaveCriticalSection(&m_cs);
		return;
	}

	SYSTEMTIME t;
	GetLocalTime(&t);
	fprintf(fpLog, "[%02d/%02d/%02d %02d:%02d:%02d.%03d] %s\tLength = %d\r\n", 
		t.wMonth, t.wDay, t.wYear%100,
		t.wHour, t.wMinute, t.wSecond, t.wMilliseconds,
		szDumpTitle, nSize);
	fflush(stdout);
	fflush(fpLog);	

	// ���� Dumping
	fprintf(fpLog, "  ------------------------------------------------------------------------\r\n");
	fflush(fpLog);	
	

	//20100714 hgkang �״°�찡 �־� tryCatch
	try
	{
		const BYTE* pData = (const BYTE*)data;
		
		CString strDataPart; // left
		CString strViewPart; // right

		// �ѱ��� ©���� ��� ����
		BYTE byteHigh = 0; // 0 �ƴϸ� ���� �ѱ� �����̴�...
		for (int nPos = 0; nPos < nSize; nPos++) {
			// data �κ�
			BYTE b = pData[nPos];
			CString strHex;
			strHex.Format("%02X", b);
			strDataPart += " " + strHex;
			// view �κ�
			if (b < 0x20) { // Ư������
				strViewPart += '.';
			} else {
				if (byteHigh) {
					strViewPart += byteHigh;
					byteHigh = 0;
					strViewPart += b;
				} else {
					if (127 < b) { // hangul
						byteHigh = b;
					} else {
						strViewPart += b;
					}
				}
			}
			// �� ���� ���
			if (((nPos + 1) % 16) == 0) {
				CString strLine;
				strLine.Format("  %04x:%s : %s\r\n", (nPos / 16) * 16, strDataPart, strViewPart);
				fprintf(fpLog, "%s", strLine.GetBuffer(0));
				
				fflush(fpLog);	
				strDataPart.Empty();
				strViewPart.Empty();
				
			}
		}
		// ¥���� ���
		if (0 != (nSize % 16)) {
			// ���� �����..
			strDataPart += CString(' ', 3 * (16 - (nSize % 16)));
			CString strLine;
			strLine.Format("  %04x:%s : %s\r\n", (nSize / 16) * 16, strDataPart, strViewPart);
			fprintf(fpLog, "%s", strLine.GetBuffer(0));
			fflush(fpLog);	
			strDataPart.Empty();
			strViewPart.Empty();
		}
	}
	catch(CException *e)
	{
		TCHAR szError[1024];
		memset(szError, 0x00, sizeof(szError));
		
		e->GetErrorMessage(szError, sizeof(szError));
//		CProcessLog::GetInstance()->WriteLog("[CProcessLog::Dump] Dump Write�� ����(%s)", szError);
	}

	fprintf(fpLog, "  ------------------------------------------------------------------------\r\n");
	fflush(fpLog);	
	fclose(fpLog);

	//m_cs.Unlock();
	::LeaveCriticalSection(&m_cs);
	return;	
}
