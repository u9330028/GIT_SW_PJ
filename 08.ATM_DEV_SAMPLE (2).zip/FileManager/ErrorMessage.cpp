// ErrorMessage.cpp: implementation of the CError class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ErrorMessage.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CErrorMessage::CErrorMessage()
{
}

CErrorMessage::~CErrorMessage()
{
}

CString CErrorMessage::GetErrorMessage(DWORD dwError)
{
	LPVOID lpMessage;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				  FORMAT_MESSAGE_FROM_SYSTEM |
				  FORMAT_MESSAGE_IGNORE_INSERTS,
				  NULL,
				  dwError,
				  MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
				  (LPTSTR) &lpMessage,
				  0,
				  NULL 
	);


	CString strMessage = "";
	strMessage.Format(_T("[%05d] %s"), dwError, (LPCTSTR)lpMessage);
	LocalFree(lpMessage);

	strMessage.TrimLeft();
	strMessage.TrimRight();

	return strMessage;
}

CString CErrorMessage::GetErrorMessage(CException *pException)
{
	CString strErrorMessage = "�˼����� ����";
	
	if(pException != NULL)
	{
		TCHAR szError[1024];
		
		memset(szError, 0x00, sizeof(szError));
		pException->GetErrorMessage(szError, sizeof(szError), NULL);
		
		strErrorMessage = szError;
		strErrorMessage.TrimLeft();
		strErrorMessage.TrimRight();
	}
	
	return strErrorMessage;
}

CString CErrorMessage::GetErrorMessage(IXMLDOMParseErrorPtr pErrorPtr)
{
	CString strErrorMessage = "�˼����� ����";

	if(pErrorPtr != NULL)
	{
		BSTR sourceString;
		BSTR errorString;
		long lErrorCode = -1;
		long lErrorLine = -1;
		long lErrorLinePos = -1;
		
		pErrorPtr->get_srcText(&sourceString);
		pErrorPtr->get_reason(&errorString);
		pErrorPtr->get_errorCode(&lErrorCode);
		pErrorPtr->get_line(&lErrorLine);
		pErrorPtr->get_linepos(&lErrorLinePos);


		strErrorMessage.Format(_T("ERROR:\nSRC:[%s]\nCODE:0x%02X\nSOURCE LINE:[%ld] CHAR:[%ld]\nDESCRIPTION:%s"),
			(TCHAR*)sourceString, lErrorCode, lErrorLine, lErrorLinePos, (char*)errorString);
	}

	return strErrorMessage;
}

CString CErrorMessage::GetErrorMessage(_com_error e)
{
	CString szTemp;
	CString strErrorMessage = "�˼����� ����";

	_bstr_t bstrSource(e.Source()); 
	_bstr_t bstrDescription(e.Description()); 
	
	szTemp.Format(_T("���� �ڵ� : 0x%08X\n"), e.Error()); 
	strErrorMessage += szTemp;
	szTemp.Format(_T("���� ���� : %s\n"), e.ErrorMessage()); 
	strErrorMessage += szTemp; 
	szTemp.Format(_T("���� �ҽ� : %s\n"), bstrSource.length() ? (LPCTSTR)bstrSource :_T("����")); 
	strErrorMessage += szTemp; 
	szTemp.Format(_T("���� ���� : %s\n"), bstrDescription.length() ?(LPCTSTR)bstrDescription :_T("����")); 
	strErrorMessage += szTemp; 

	return strErrorMessage;
}