#pragma once

// PATH ����
////////////////////////////////////////////////////////////////////////////
#define PATH_ROOT							_T("c:\\atm_main")
#define PATH_BIN							PATH_ROOT _T("\\bin")
#define PATH_INI							PATH_ROOT _T("\\ini")
#define PATH_LOG							PATH_ROOT _T("\\log\\afm")


#define ATOM_INFO_INI						PATH_INI _T("\\info.ini")
#define ATOM_VERSION_INI					PATH_INI _T("\\version.ini")
#define ATOM_FILEMANAGER_INI				PATH_INI _T("\\FileManager.ini")
#define ATOM_IBP_INI						PATH_INI _T("\\ibp_config.ini")

#define FM_LOG								_T("FileClient.txt")
#define FS_LOG								_T("FileSave.txt")
#define ATOM_FILEMANAGER_LOG				PATH_LOG _T("\\") FM_LOG
#define ATOM_FILESAVE_LOG					PATH_LOG _T("\\") FS_LOG


// EXE ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_OM_FILE						_T("aom.exe")
#define ATOM_RM_FILE						_T("arm.exe")
#define ATOM_FC_FILE						_T("afm.exe")
#define ATOM_IIM_FILE						_T("iim.exe")
#define ATOM_IBP_FILE						_T("IntegratedBizProcessor.exe")
#define ATOM_IPF_FILE						_T("ipf.exe")
#define ATOM_ADP_FILE						_T("AdvertisPlayer.exe")
#define ATOM_OM_EXE							PATH_BIN _T("\\") ATOM_OM_FILE
#define ATOM_RM_EXE							PATH_BIN _T("\\") ATOM_RM_FILE
#define ATOM_FM_EXE							PATH_BIN _T("\\") ATOM_FC_FILE
#define ATOM_ADP_EXE						PATH_BIN _T("\\") ATOM_ADP_FILE


// WINDOWS TITLE ����
////////////////////////////////////////////////////////////////////////////
#define TITLE_IBP							_T("PTComm")		//
#define TITLE_IIM							_T("MWComm")
#define TITLE_IPF							_T("MainWindow")
#define TITLE_ADP							_T("AdvertisPlayer")
#define TITLE_ARM							_T("ATOM Reboot Manager")
#define TITLE_AFM							_T("ATOM File Manager")

#define ARM_COMMAND							26		// ���ȭ�� ǥ�ÿ�
#define IPF_COMMAND							27		// IPF�� ȭ�� ��û��
#define IIM_COMMAND							28		// OSREBOOT, RESTART ���� Ŀ�ǵ�
#define IBP_COMMAND							28		// ��ֺ��� ���� Ŀ�ǵ�
#define POLL_COMMAND						29
#define POLL_RESPONSE						30

#define MESSAGE_TIMEOUT						20000


// ����� �޽��� ����
////////////////////////////////////////////////////////////////////////////
#define UM_SESSION_CONNECTED				WM_USER + 100
#define UM_SESSION_DISCONNECTED				WM_USER + 101
#define UM_SESSION_RECEIVE					WM_USER + 102
#define UM_FILESERVER_CONNECT				WM_USER + 103


// TIMER ����
////////////////////////////////////////////////////////////////////////////
#define TIMER_FILE_RECEIVE_TIMEOUT			1


// FILE FORMAT
////////////////////////////////////////////////////////////////////////////
#define FILEFORMAT_TEMP						_T("%s.tmp")
#define FILEFORMAT_BACK						_T("%s.bak")



// ERRORCODE ����
////////////////////////////////////////////////////////////////////////////
#define LENGTH_ERROR_CODE					3
#define FILE_OPEN_ERROR						"001" // file open fail
#define FILE_SIZE_ERROR						"002" // ��û�� file size�� ���� file���� Ŭ�� 
#define MSG_FORMAT_ERROR					"003" // message format error
#define ZIP_CREATE_ERROR					"004" // zip file ����ٰ� ���н�.
#define FILE_GAP_ERROR						"005" // file �������� �ٸ� ��.
#define FILE_CREATE_ERROR					"021" // file ����� ����
#define FILE_WRITE_ERROR					"022" // file ���� ����
#define BACKUP_ERROR						"023" // ���� -> ��� ���� 
#define UPDATE_ERROR						"024" // Temp -> ���� ���� 
#define RECOVERY_ERROR						"025" // ��� -> ���� ����
#define UNZIP_ERROR							"026" // ����ȭ�� Ǯ�ٰ� ����
#define FILE_SAVE_ERROR						"027" // ETC(file size �� �ٸ���..)
#define FILE_ETC_ERROR						"100" // File���� ��Ÿ error
#define SAVE_SUCCESS						"999" // save success


// NETWORK ����
////////////////////////////////////////////////////////////////////////////
#define MAX_QUEUE_LENGTH					50
#define MAX_BUFFER_LENGTH					10240
#define MAX_PACKET_LENGTH					4096
#define MAX_SESSIONCOUNT					10

#define PACKET_EXIST						1
#define PACKET_INVALID_PACKET_LENGTH		0


#define MAX_CONNECT							100		// Max connection 
#define SVR_PORT_LOG						8400	// Server port number (ȭ�� ����)
#define SVR_PORT_SAVE						8300	// Server port number (ȭ�� ����)
#define FILESERVER_PORT						9510

#define BASE_DIR							_T("")

#define LENGTH_CDNUM						4
#define LENGTH_VERSION						6
#define LENGTH_FILE_COUNT					2

#define LENGTH_MAX_BUFFER					2024
#define LENGTH_FILE_BUFFER					512

#define FS									0x1C
#define STX									0x02
#define ETX									0x03

#define LENGTH_STX							1
#define LENGTH_FS							1
#define LENGTH_ETX							1
#define LENGTH_MSG_LEN						4
#define LENGTH_MSG_TYPE						2

#define MAX_FILE_COUNT						32
#define MAX_FILE_NAME						512

	
#define BUFFER_SIZE							1024 // read file per BUF_SIZE ( in zip)

/* ----------------------------------------------------------------------
 ���� header�κ�
 STX(1) + ��������(4) + ����TYPE(2) + CD NAME(4) + Buffer size(4)
 body 
 file name(var) + FS + Data(var) + ETX(1)
------------------------------------------------------------------------- */
#define REQ_REBOOT							"00"

#define REQ_ERROR							"10"
#define REQ_FILE_SIZE						"11"
#define REQ_FILE_DATA						"12"
#define REQ_FILE_END						"13"
#define REQ_VERSION							"15"


#define REP_ERROR							"20"
#define REP_FILE_SIZE						"21"
#define REP_FILE_DATA						"22"
#define REP_FILE_END						"23"

#define SND_FILE_DEL						"30"
#define SND_FILE_SIZE						"31"
#define SND_FILE_DATA						"32"
#define SND_FILE_END						"33"

#define REP_FILE_SAVE						"40"

#define REQ_SAVE_START						"01"
#define REP_FILE_LIST						"02"

// --------------------------
#pragma pack(push, 1)

typedef struct tagPACKET_HEADER
{
	char stx[1];					// STX
	char length[4];					// Total length
	char type[2];					// type (00,11,12)
	char cdname[4];					// cdname
	char size[4];					// buffer size
} PACKET_HEADER, *LPPACKET_HEADER; 


// PACKET ���� ���� 
typedef struct tagPACKET_INFO
{
	char type[2];					// type(21,22)
	char cdname[4];					// cdname
	char size[4];					// buffer size
	char filepath[256];				// file path
	int	 nFilePathLength;			// length of filepath
	char data[LENGTH_MAX_BUFFER];	// send data
	int	 nDataLength;				// length of data
} PACKET_INFO, *LPPACKET_INFO;


typedef struct tagFILEINFO
{
	char szFilePath[MAX_PATH];
	LONGLONG lFileSize;
	LONGLONG lSentBytes;
} FILEINFO, *LPFILEINFO;

#pragma pack(pop)