// FileManager.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FileManager.h"
#include "FileManagerDlg.h"
#include "ExecVersion.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileManagerApp

BEGIN_MESSAGE_MAP(CFileManagerApp, CWinApp)
	//{{AFX_MSG_MAP(CFileManagerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileManagerApp construction

CFileManagerApp::CFileManagerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFileManagerApp object

CFileManagerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFileManagerApp initialization

BOOL CFileManagerApp::InitInstance()
{
	TCHAR szValue[24] = {0x00,};
	BOOL bEncrypt = TRUE;
	
	CDirectory::MakeDirectory(PATH_LOG);
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString(_T("ENCRYPT"), _T("IS_LOCAL"), _T("FALSE"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(lstrcmp(szValue, _T("TRUE")) == 0 || lstrcmp(szValue, _T("true")) == 0)
	{
		bEncrypt = FALSE;
	}
	CProcessLog::GetInstance()->SetFileName(ATOM_FILEMANAGER_LOG, FM_LOG, bEncrypt);
	CProcessLog::GetInstance()->SetFileName(ATOM_FILESAVE_LOG, FS_LOG, bEncrypt);
	
	CProcessLog::GetInstance()->WriteLog(FM_LOG, "=< START >=============================================================================");
	CProcessLog::GetInstance()->WriteLog(FS_LOG, "=< START >=============================================================================");

	CExecVersion ver(ATOM_FM_EXE);
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T(" AFM VERSION:%s DESC:%s"), ver.GetFileVersion(), ver.GetSpecialBuild());
	CProcessLog::GetInstance()->WriteLog(FS_LOG, _T(" AFM VERSION:%s DESC:%s"), ver.GetFileVersion(), ver.GetSpecialBuild());
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("=============================================================================="));
	CProcessLog::GetInstance()->WriteLog(FS_LOG, _T("=============================================================================="));



	// ���߽��� ����
	m_hMutex = ::CreateMutex(NULL, FALSE, "ATOM FM PROGRAM");
	if( ::WaitForSingleObject(m_hMutex, 0) != WAIT_OBJECT_0 )
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "���� �������� AFM�� �����մϴ�. ���α׷��� �������� �ʽ��ϴ�.");
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "==============================================================================");
		return FALSE;
	}



	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CFileManagerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CFileManagerApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hMutex)
	{
		CloseHandle(m_hMutex);
	}
	
	CProcessLog::GetInstance()->WriteLog(FM_LOG, "==============================================================================");

	return CWinApp::ExitInstance();
}
