#pragma once

class CCritical
{
public:
	CCritical(void)
	{
		InitializeCriticalSection(&m_cs);
	}

	~CCritical(void)
	{
		DeleteCriticalSection(&m_cs);
	}

public:
	inline void Enter(void)
	{
		EnterCriticalSection(&m_cs);
	}

	inline void Leave(void)
	{
		LeaveCriticalSection(&m_cs);
	}

private:
	CRITICAL_SECTION	m_cs;
};