// Directory.h: interface for the CDirectory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIRECTORY_H__57361EFF_6423_4739_A2F3_CCD6B1F68B6D__INCLUDED_)
#define AFX_DIRECTORY_H__57361EFF_6423_4739_A2F3_CCD6B1F68B6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDirectory  
{
public:
	CDirectory();
	virtual ~CDirectory();

public:
	static BOOL GetFileName(CString strFilePath, CString &strFileName);
	static BOOL GetDirectory(CString strFilePath, CString &strDirectoryPath);
	static CString GetDirectory(CString strFilePath);
	static BOOL MakeDirectory(const CString strDirectory);

	static BOOL DeleteDirectory(CString strPath, BOOL bRemoveDirectory = TRUE);
};

#endif // !defined(AFX_DIRECTORY_H__57361EFF_6423_4739_A2F3_CCD6B1F68B6D__INCLUDED_)
