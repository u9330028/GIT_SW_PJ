// FileSendServer.cpp: implementation of the CFileSendServer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FileManager.h"
#include "FileSendServer.h"
#include "ZipFile.h"
#include "Process.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFileSendServer::CFileSendServer()
{
	m_bZipFile = TRUE;
	memset(m_szNumberCD, 0x20, sizeof(m_szNumberCD));
}

CFileSendServer::~CFileSendServer()
{

}

BOOL CFileSendServer::IsNumber(char *pszData, int nLength)
{
	if(pszData == NULL)
		return FALSE;
	
	for(int i=0; i<nLength; i++)
	{
		if(!isdigit(pszData[i]))
			return FALSE;
	}
	
	return TRUE;
}

LPCTSTR CFileSendServer::GetNumberCD()
{
	TCHAR szValue[20] = {0x00,};
	CString strValue = _T("");
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("Local", "CDnumber", "", szValue, sizeof(szValue), ATOM_INFO_INI);
	if(strlen(szValue) == LENGTH_CDNUM) 
	{
		memset(m_szNumberCD, 0x00, sizeof(m_szNumberCD));
		memcpy(m_szNumberCD, szValue, strlen(szValue));
	}
	else 
	{
		memset(m_szNumberCD, 0x20, sizeof(m_szNumberCD));
		CProcessLog::GetInstance()->WriteLog(FM_LOG,  "[Failure] Fail to get cdnumber");
	}
	
	return m_szNumberCD;
}

BOOL CFileSendServer::Reboot()
{
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileSendServer::Reboot] REBOOT ����"));
	
	BOOL bResult = FALSE;


	// IIM�� OSREBOOT�� �˸���.
	SendCommandToBiz(_T("OSREBOOT"));
	Sleep(3000);
	
	
	// �⺻ ���α׷��� �ϴ� ������.
	CProcess::KillProcess(ATOM_IBP_FILE);
	CProcess::KillProcess(ATOM_IIM_FILE);
	CProcess::KillProcess(ATOM_IPF_FILE);
	CProcess::KillProcess(ATOM_ADP_FILE);
	
	
	// OS ������ ���´�.
	OSVERSIONINFO osVersion;
	osVersion.dwOSVersionInfoSize = sizeof(osVersion);
	GetVersionEx(&osVersion);
	
	// Win95 / Win98 �� ��� (��Ȥ ������ ���ϴ� ��찡 �ְŵ�...)
	if (VER_PLATFORM_WIN32_WINDOWS == osVersion.dwPlatformId)
	{
		bResult = ExitWindowsEx(EWX_REBOOT|EWX_FORCE, 0);
		CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileSendServer::Reboot] WIN95 �Ǵ� WIN98 �ý������� ���� ����� ����[%d]"), bResult);
		return bResult;
	}
	
	
	HANDLE hToken;              // handle to process token 
	TOKEN_PRIVILEGES tkp;       // pointer to token structure 
	
	OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES|TOKEN_QUERY, &hToken);
	
	// Get the LUID for shutdown privilege. 
	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid); 
	
	tkp.PrivilegeCount = 1;  // one privilege to set    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 
	
	// Get shutdown privilege for this process. 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES) NULL, 0); 
	
	bResult = ExitWindowsEx(EWX_REBOOT|EWX_FORCE, 0);
	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileSendServer::Reboot] REBOOT ���� �Ϸ�[%d]"), bResult);
	
	return bResult;
}

int CFileSendServer::GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int iLen = strlen((char*)sMsg);
	for(int i=0; i < iLen; i++)
	{
		if(sMsg[i] == fs)
		{
			return i; // length of token
		}
		else
		{
			sToken[i] = sMsg[i];
		}
	}
	
	// GetToken failure
	return 0;
}

int CFileSendServer::GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int i,j;
	int iLen = strlen((char*)sMsg);
	i= iLen; j=0;
	
	for(i; i >= 0 ; i--)
	{
		if(sMsg[i] == fs) {
			wsprintf(sToken,"%s",&sMsg[i+1]);
			return i;
		}
	}
	
	// GetToken failure
	return -1;
}

void CFileSendServer::ProcessPacket(CConnectedSession *pConnectedSession, BYTE *pPacket, DWORD dwPacketLength)
{
//	STX(1) + LENGTH(4) + CMD(2) + CDNUMBER(4) + BUFFER SIZE(4) + FILENAME(N) + FS(1) + DATA(N) + ETX(1)

//	CProcessLog::GetInstance()->WriteLog(FM_LOG, _T("[CFileSendServer::ProcessPacket] CMD:%s ó�� ����"), szProtocol);
#ifdef _DEBUG
	CProcessLog::GetInstance()->Dump(FM_LOG, "���ŵ�����", pPacket, dwPacketLength);
#endif

	PACKET_HEADER header;
	PACKET_INFO info;
	BYTE btSendPacket[MAX_PACKET_LENGTH] = {0x00,};
	DWORD dwSendLength = 0;
	
	memset(&header, 0x00, sizeof(header));
	memset(&info, 0x00, sizeof(info));
	
	// PACKET FORMAT CHECK
	if(IsValidPacket(pPacket, dwPacketLength, header, info) == FALSE)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[ERROR] Msg Format error");
		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeErrorPacket(btSendPacket, REP_ERROR, MSG_FORMAT_ERROR);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();

		return;
	}


	// reboot command
	if(memcmp(header.type, REQ_REBOOT, LENGTH_MSG_TYPE) == 0)
	{
		Reboot();
		return;
	}
	// request file size
	else if(memcmp(header.type, REQ_FILE_SIZE, LENGTH_MSG_TYPE) == 0)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "FILE_SIZE PACKET ����");

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileSizePacket(pConnectedSession, btSendPacket, info.filepath);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();

		CProcessLog::GetInstance()->WriteLog(FM_LOG, "FILE_SIZE PACKET ����");
	}
	// request file data 
	else if(memcmp(header.type, REQ_FILE_DATA, LENGTH_MSG_TYPE) == 0)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "FILE_DATA PACKET ����");

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileDataPacket(pConnectedSession, btSendPacket, info);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();

		CProcessLog::GetInstance()->WriteLog(FM_LOG, "FILE_DATA PACKET ����");
	}
	// undefined type
	else
	{ 
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[ERROR] Undefined message type(%s) rcv", header.type);

		dwSendLength = MakeErrorPacket(btSendPacket, REP_ERROR, MSG_FORMAT_ERROR);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();
	}
}

BOOL CFileSendServer::IsValidPacket(const BYTE *pPacket,
									DWORD dwPacketLength,
									PACKET_HEADER &header,
									PACKET_INFO &info)
{
	int nLength = 0;
	int nIndex = 0;
	int nFilePathLength = 0;
	int nDataLength = 0;
	TCHAR szLength[10] = {0x00,};
	TCHAR szFilePath[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR szData[LENGTH_MAX_BUFFER] = {0x00,}; 

	if(dwPacketLength <= sizeof(header))
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[CFileSendServer::IsValidPacket] [ERROR] Packet Format error[Length <= Header size]");
		return FALSE;
	}

	memset(&header, 0x00, sizeof(header));
	memcpy(&header, pPacket, sizeof(header));

	// STX ERROR
	if(header.stx[0] != STX)	 
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[CFileSendServer::IsValidPacket] [ERROR] Packet Format error[STX]");
		return FALSE;
	}

	// LENGTH DATA ERROR
	if(!IsNumber(header.length, sizeof(header.length)))
	{
		// length error
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[CFileSendServer::IsValidPacket] [ERROR] Packet Format error[Length field error]");
		return FALSE;
	}

	memset(szLength, 0x00, sizeof(szLength));
	memcpy(szLength, header.length, sizeof(header.length));
	nLength = atoi(szLength);

	// PACKET LENGTH ERROR
	if(nLength != dwPacketLength)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[CFileSendServer::IsValidPacket] [ERROR] Packet Format error[not same length]");
		return FALSE;
	}

	// ETX ERROR
	if(pPacket[dwPacketLength - 1] != ETX)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG, "[CFileSendServer::IsValidPacket] [ERROR] Packet Format error[ETX]");
		return FALSE;
	}

	memset(&info, 0x00, sizeof(info));
	memset(szFilePath, 0x00, sizeof(szFilePath));
	memset(szData, 0x00, sizeof(szData));

	// GET FILEPATH
	nFilePathLength = GetFirstToken(szFilePath, &pPacket[sizeof(header)], dwPacketLength - sizeof(header), FS);
	nIndex = sizeof(header) + LENGTH_FS + nFilePathLength;

	// GET DATA
	//nDataLength = GetFirstToken(szData, &pPacket[nIndex], dwPacketLength - nIndex, ETX);
	nDataLength = dwPacketLength - nIndex - 1; // -1 //ETX
	if(nDataLength > 0)
	{
		memcpy(szData, &pPacket[nIndex], nDataLength);
	}

	memcpy(info.cdname, header.cdname, sizeof(header.cdname));
	memcpy(info.size, header.size, sizeof(header.size));
	memcpy(info.filepath, szFilePath, nFilePathLength);
	memcpy(info.data, szData, nDataLength);
	info.nFilePathLength = nFilePathLength;
	info.nDataLength = nDataLength;

	return TRUE;
}

// FILEPATH���� .zip Ȯ���� ����
int CFileSendServer::GetZipFileName(LPCTSTR szFilePath, TCHAR *szZipFileName)
{
	int nLength = 0;
	CString strPostFix = _T("");

	nLength = strlen(szFilePath);
	if(nLength < 4)
	{
		memcpy(szZipFileName, szFilePath, nLength);
		return 0;
	}

	strPostFix.Format("%s", &szFilePath[nLength - 4]);
	strPostFix.MakeLower();
	if(strPostFix.Compare(_T(".zip")) == 0)
	{
		memcpy(szZipFileName, szFilePath, nLength - 4);
		return 1;
	}

	memcpy(szZipFileName, szFilePath, nLength);
	return 0;
}

int CFileSendServer::MakeZipFile(char* szFullFilePath)
{
	TCHAR szZipFileName[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR sTempFile[LENGTH_MAX_BUFFER] = {0x00,};
	int nFileCount = 0;
	int nFilePos = 0;
	
	CFileFind filefinder;
	TCHAR szSelectedFiles[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR szLastFileName[LENGTH_MAX_BUFFER] = {0x00,};
	
	memset(szLastFileName, 0x00, sizeof(szLastFileName));
	nFilePos = GetLastToken(szLastFileName, (BYTE*)szFullFilePath, strlen(szFullFilePath), '\\');
	
	memset(szZipFileName, 0x00, sizeof(szZipFileName));
	wsprintf(szZipFileName, "%s.zip", szFullFilePath);
	
	// szFullFilename �� ����ִ� ��� ȭ���� ����... 2002-05-17
	memset(szSelectedFiles, 0x00, sizeof(szSelectedFiles));
	memcpy(&szSelectedFiles, szFullFilePath, nFilePos + 1);
	wsprintf(&szSelectedFiles[nFilePos +1 ], "*%s*.*", szLastFileName);
	// ------------------------------------------------------------
	
	try
	{
		if (filefinder.FindFile(szSelectedFiles, 0) == TRUE)
		{
			// create zip file (no append)
			CZipFile zipfile(szZipFileName, 0); 
			BOOL bFlag = TRUE;
			
			while(bFlag == TRUE)
			{
				bFlag = filefinder.FindNextFile();
				wsprintf(sTempFile,"%s",filefinder.GetFilePath());
				if(filefinder.IsDots() == 1)
					continue;
				else if (filefinder.IsDirectory() == 1 )
					continue;	// dir -- ignore	
				else if(GetZipFileName(sTempFile, sTempFile))
					continue;	// zip file -- ignore
				else
				{		
					nFileCount++;
					zip_fileinfo zipInfo;
					
					try
					{
						int nReadBytes = 0;
						char buf[BUFFER_SIZE] = {0x00,};
						CFile TargetFile(filefinder.GetFilePath(), CFile::modeRead|CFile::shareDenyWrite);

						zipfile.UpdateZipInfo(zipInfo, TargetFile);
						// sFilename : ��θ� ������ filename..�ȱ׷��� ��� ���� ����.
						zipfile.OpenNewFileInZip(filefinder.GetFileName(), zipInfo, Z_BEST_COMPRESSION);
						
						
						do
						{
							memset(buf, 0x00, sizeof(buf));
							nReadBytes = TargetFile.Read(buf, BUFFER_SIZE);
							if (nReadBytes)
							{
								zipfile.WriteInFileInZip(buf, nReadBytes);
							}
						}
						while (nReadBytes == BUFFER_SIZE);
						
						TargetFile.Close();
						CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Success] Compressed file(%s)", filefinder.GetFilePath());
					}
					catch (CException* e)
					{
						CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Failure] Compressed file(%s) ERROR:%d", filefinder.GetFilePath(), GetLastError());
						e->Delete();
						return -1;
					}
				}
			}
			
			zipfile.Close();
			if( nFileCount ==0 )
				_unlink(szZipFileName);
		}
	}
	catch(...) {}

		
	return nFileCount;
}

DWORD CFileSendServer::MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	int nIndex = 0;
	DWORD dwPacketLength = 0;
	TCHAR szLength[5] = {0x00,};
	PACKET_HEADER header;

	dwPacketLength = sizeof(header) + info.nFilePathLength + LENGTH_FS + info.nDataLength + LENGTH_ETX;
	
	memset(szLength, 0x00, sizeof(szLength));
	wsprintf(szLength, "%04d", dwPacketLength);
	
	memset(&header, 0x00, sizeof(PACKET_HEADER));	
	memcpy(header.length, szLength, sizeof(header.length));
	memset(header.stx, STX, LENGTH_STX);
	memcpy(header.type, info.type, LENGTH_MSG_TYPE);
	memcpy(header.cdname, info.cdname, sizeof(header.cdname));
	memcpy(header.size, info.size, sizeof(header.size));
	
	memcpy(pPacketBuffer, &header, sizeof(header));
	nIndex += sizeof(header);

	memcpy(pPacketBuffer + nIndex, info.filepath, info.nFilePathLength);
	nIndex += info.nFilePathLength;

	memset(pPacketBuffer + nIndex, FS, LENGTH_FS);
	nIndex += LENGTH_FS;

	memcpy(pPacketBuffer + nIndex, info.data, info.nDataLength);
	nIndex += info.nDataLength;

	memset(pPacketBuffer + nIndex, ETX, LENGTH_ETX);
	
	// retrun packet length 
	return dwPacketLength;
}

DWORD CFileSendServer::MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode)
{
	PACKET_INFO info;
	memset(&info, 0x00, sizeof(info));
	
	info.nFilePathLength = 0;
	memcpy(info.type, lpszType, LENGTH_MSG_TYPE);
	memcpy(info.data, lpszErrorCode, LENGTH_ERROR_CODE);
	memcpy(info.cdname, GetNumberCD(), LENGTH_CDNUM);	// temp
	memcpy(info.size, "0512", 4);						// temp
	
	info.nDataLength = LENGTH_ERROR_CODE;
	
	return MakePacket(pPacketBuffer, info);
}


DWORD CFileSendServer::MakeFileSizePacket(CConnectedSession *pSession, BYTE *pPacketBuffer, LPCTSTR lpszFilePath)
{
	PACKET_INFO info;
	FILEINFO fileinfo;

	long lFileSize = 0;
	TCHAR szValue[20] = {0x00,};
	TCHAR szTargetPath[MAX_PATH] = {0x00,};
	TCHAR szFileSize[20] = {0x00,};

	memset(&info, 0x00, sizeof(info));
	memset(szFileSize, 0x00, sizeof(szFileSize));

	memcpy(info.type, REP_FILE_SIZE, LENGTH_MSG_TYPE);
	memcpy(info.cdname, GetNumberCD(), LENGTH_CDNUM);
	memcpy(info.size, "0512", 4);
	strcpy(info.filepath, lpszFilePath);
	info.nFilePathLength = strlen(lpszFilePath);

	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("FileManager", "zip", "", szValue, sizeof(szValue), ATOM_FILEMANAGER_INI);
	if(strlen(szValue) > 0 && (szValue[0] == 'F' || szValue[0] == 'f'))
		m_bZipFile = FALSE;

	memset(szTargetPath, 0x00, sizeof(szTargetPath));
	if(m_bZipFile && GetZipFileName(lpszFilePath, szTargetPath))
	{
		int nResult = MakeZipFile(szTargetPath);
		if(nResult > 0)
		{
			CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Success] Zip file (%s.zip)", szTargetPath);

			lFileSize = GetFileSize(lpszFilePath);
			memset(szFileSize, 0x00, sizeof(szFileSize));
			wsprintf(szFileSize, "%ld", lFileSize);
			memcpy(info.data, szFileSize, strlen(szFileSize));
			info.nDataLength = strlen(szFileSize);

			memset(&fileinfo, 0x00, sizeof(fileinfo));
			wsprintf(fileinfo.szFilePath, "%s.zip", szTargetPath);
			fileinfo.lFileSize = lFileSize;
			pSession->SetFileInfo(fileinfo);
		}
		else if(nResult == -1)
		{
			// fail 
			CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Failure] Zip file (%s.zip)", szTargetPath);
			memcpy(info.type, REP_ERROR, LENGTH_MSG_TYPE);
			memcpy(info.data, ZIP_CREATE_ERROR, LENGTH_ERROR_CODE);
			info.nDataLength = LENGTH_ERROR_CODE;
		}
		else
		{
			// file size = 0 -- no file -- not error
			// send -- Type:REP_FILE_SIZE data size : 0 
			CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Error] There is no file (%s.*)", szTargetPath);
			wsprintf(info.data, "%d", 0);
			info.nDataLength = 1;
		}
	}
	else
	{
		lFileSize = GetFileSize(lpszFilePath);
		wsprintf(szFileSize, "%ld", lFileSize);
		memcpy(info.data, szFileSize, strlen(szFileSize));
		info.nDataLength = strlen(szFileSize);

		memset(&fileinfo, 0x00, sizeof(fileinfo));
		wsprintf(fileinfo.szFilePath, "%s", lpszFilePath);
		fileinfo.lFileSize = lFileSize;
		pSession->SetFileInfo(fileinfo);
	}

	CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileSizePacket FILE:%s SIZE:%s", info.filepath, info.data);

	return MakePacket(pPacketBuffer, info);
}

DWORD CFileSendServer::MakeFileDataPacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;
	FILEINFO fileinfo = pSession->GetFileInfo();
	
	memcpy(&packet, &info, sizeof(info));
	memcpy(packet.type, REP_FILE_DATA, LENGTH_MSG_TYPE);

	char szReadBuffer[LENGTH_MAX_BUFFER] = {0x00,};
	char szSize[10] = {0x00, };
	char szData[LENGTH_MAX_BUFFER] = {0x00,};
	char szFilePath[MAX_PATH] = {0x00,};
	LONGLONG lFilePtr = 0;
	int nBufferSize = 0;
	int nReadBytes = 0;

	memset(szReadBuffer, 0x00, sizeof(szReadBuffer));

	memset(szFilePath, 0x00, sizeof(szFilePath));
	memcpy(szFilePath, info.filepath, info.nFilePathLength);

	memset(szData, 0x00, sizeof(szData));
	memcpy(szData, info.data, info.nDataLength);
	lFilePtr = _atoi64(szData);

	memset(szSize, 0x00, sizeof(szSize));
	memcpy(szSize, info.size, sizeof(info.size));
	nBufferSize = atoi(szSize); // �ѹ��� ���� buffer size.


	CFile file;
	BOOL bOpened = file.Open(szFilePath, CFile::modeRead);
	if(!bOpened)
	{
		// file �� open ���� ���� ��� file open
		memcpy(packet.type, REP_ERROR, LENGTH_MSG_TYPE);
		memcpy(packet.data, FILE_OPEN_ERROR, LENGTH_ERROR_CODE);
		packet.nDataLength = LENGTH_ERROR_CODE;

		CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileDataPacket FILE_OPEN_ERROR FILE:%s", packet.filepath);
	}
	else
	{
		// File size�� �����ϰ� ���� ���� �ʾ��� �� ..
		// ����Ÿ ó�� ��û�� check ���� ���� -- �̾�ޱ� ���ɼ�.
		if( fileinfo.lSentBytes && (lFilePtr != fileinfo.lSentBytes))
		{
			// size �̻�� ..
			memcpy(packet.type, REP_ERROR, LENGTH_MSG_TYPE);
			memcpy(packet.data, FILE_GAP_ERROR, LENGTH_ERROR_CODE);
			packet.nDataLength = LENGTH_ERROR_CODE;
		}
		else
		{
			fileinfo.lSentBytes = lFilePtr;

			long lRemainData = 0;
			long lReadSize = 0;
			lRemainData = fileinfo.lFileSize - lFilePtr;
			
			if(lRemainData > nBufferSize)
				lReadSize = nBufferSize;
			else
				lReadSize = lRemainData;
		
			nReadBytes = ReadFile(&file, lFilePtr, lReadSize, szReadBuffer);
			file.Close();
		
			// ������ ����Ÿ ���۽� - 2002-04-23 - �Ǹ����� ���� size "23"
			//if(iReadBytes < iBufSize)
			if( fileinfo.lSentBytes + nReadBytes == fileinfo.lFileSize)
			{
				CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileDataPacket REP_FILE_END FILE:%s", packet.filepath);

				memcpy(packet.type, REP_FILE_END, LENGTH_MSG_TYPE);
				memcpy(packet.data, szReadBuffer, nReadBytes);
				packet.nDataLength = nReadBytes;
				fileinfo.lSentBytes += nReadBytes;

				// zip file ���� .
				if(m_bZipFile && PathFileExists(szFilePath))
				{
					if(_unlink(szFilePath) == 0)
						CProcessLog::GetInstance()->WriteLog(FM_LOG, "[Success] Delete file(%s)", szFilePath);	
					else
						CProcessLog::GetInstance()->WriteLog(FM_LOG, "[ERROR] Delete file(%s) fail.", szFilePath);	
				}
			}
			// �߰� ����Ÿ ���۽�..
			else if(nReadBytes == nBufferSize) 
			{
				memcpy(packet.data, szReadBuffer, nReadBytes);
				packet.nDataLength = nReadBytes;
				fileinfo.lSentBytes += nReadBytes;

				CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileDataPacket REP_FILE_DATA FILE:%s POSITION:%ld", packet.filepath, fileinfo.lSentBytes);
			}
			// File open error
			else if(nReadBytes == -1)
			{
				memcpy(packet.type, REP_ERROR, LENGTH_MSG_TYPE);
				memcpy(packet.data, FILE_OPEN_ERROR, LENGTH_ERROR_CODE);
				packet.nDataLength = LENGTH_ERROR_CODE;

				CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileDataPacket FILE_OPEN_ERROR FILE:%s", packet.filepath);
			}
			// file size error
			else if(nReadBytes == -2)
			{
				memcpy(packet.type, REP_ERROR, LENGTH_MSG_TYPE);
				memcpy(packet.data, FILE_SIZE_ERROR, LENGTH_ERROR_CODE);
				packet.nDataLength = LENGTH_ERROR_CODE;

				CProcessLog::GetInstance()->WriteLog(FM_LOG, "MakeFileDataPacket FILE_SIZE_ERROR FILE:%s", packet.filepath);
			}
		}
	}

	return MakePacket(pPacketBuffer, packet);
}

ULONG CFileSendServer::GetFileSize(LPCTSTR lpszFilePath)
{
	if(lpszFilePath == NULL || !PathFileExists(lpszFilePath))
		return 0;

	CFileStatus fs;

	if(CFile::GetStatus(lpszFilePath, fs))
	{
		return fs.m_size;
	}
	else
	{
		return 0;
	}
}


int CFileSendServer::ReadFile(CFile *pFile, LONGLONG lFilePtr, int nBytesToRead, char *szReadBuffer)
{
	char szFileBuffer[LENGTH_MAX_BUFFER] = {0x00,};
	int nReadBytes = 0;
	
	pFile->Seek(lFilePtr, 0);

	memset(szFileBuffer, 0x00, sizeof(szFileBuffer));
	if(nReadBytes = pFile->Read(szFileBuffer, nBytesToRead))
	{
		//CProcessLog::GetInstance()->WriteLog(ATOM_FILECLIENT_LOG, "[READ] file(%s) position(%ld) size(%d)",sFileName,lFilePointer,nBytesRead);
		memcpy(szReadBuffer, szFileBuffer, nReadBytes);		
		return nReadBytes;  // success
	}
	else 
	{	
		return 0; // no data
	}
}

BOOL CFileSendServer::SendCommandToBiz(LPCTSTR lpCommand)
{
	int nRetryCount = 0;
	
	if(lpCommand == NULL || lstrlen(lpCommand) <= 0)
		return FALSE;
	
	int nResult = SendMessageToBiz(lpCommand);
	if(nResult < 1)	// �ش� �����츦 ã�� ������ ���
		return FALSE;
	else
		return TRUE;
}


int CFileSendServer::SendMessageToBiz(CString strMessage)
{
	int nResult = 0;
	
	HWND hAgentWnd = ::FindWindow(NULL, TITLE_IIM);
	if(hAgentWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG,
			_T("[CServerIocp::SendMessageToBiz] %s �����츦 ã�� �� �����ϴ�."),
			TITLE_IIM);
		return -1;
	}
	
	DWORD dwResult = 0;
	COPYDATASTRUCT cds;
	cds.dwData = IIM_COMMAND;         
	cds.lpData = strMessage.GetBuffer(0);
	cds.cbData = strMessage.GetLength();
	
	nResult = ::SendMessageTimeout(hAgentWnd,
									WM_COPYDATA,
									0,
									(LPARAM)&cds,
									SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG,
									MESSAGE_TIMEOUT,
									&dwResult);
	strMessage.ReleaseBuffer();
	
	if(nResult == 0)
	{
		DWORD dwError = GetLastError();
		if(dwError == 0)
		{
			CProcessLog::GetInstance()->WriteLog(FM_LOG,
				_T("[CMainFrame::SendMessageToBiz] WM_COPYDATA ���� ����(Ÿ�Ӿƿ�)"));
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(FM_LOG,
				_T("[CMainFrame::SendMessageToBiz] WM_COPYDATA ���� ����(%s)"),
				CErrorMessage::GetErrorMessage(dwError));
		}
		return 0;
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(FM_LOG,
			_T("[CServerIocp::SendMessageToBiz] WM_COPYDATA ���� ����(%s)"),
			strMessage);
		return 1;
	}
	
	return 0;
}