#pragma once

class CPacketSession :	public CNetworkSession
{
public:
	CPacketSession(VOID);
	virtual ~CPacketSession(VOID);

private:
	BYTE				m_btPacketBuffer[MAX_BUFFER_LENGTH * 3];
	INT					m_nRemainLength;
	CCircularQueue		m_oWriteQueue;

public:
	BOOL	Begin(VOID);
	BOOL	End(VOID);
	
	UINT	GetPacket(BYTE *packet, DWORD &packetLength);

	BOOL	ReadPacketForIocp(DWORD readLength);
	BOOL	ReadPacketForEventSelect(VOID);


//protected:
	BOOL	WritePacket(const BYTE *pPacket, DWORD dwPacketLength);
	BOOL	WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength);
	BOOL	WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength);
	BOOL	WriteComplete(VOID);
};
