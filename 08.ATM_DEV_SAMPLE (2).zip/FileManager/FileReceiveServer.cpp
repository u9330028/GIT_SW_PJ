// FileReceiveServer.cpp: implementation of the CFileReceiveServer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FileManager.h"
#include "FileReceiveServer.h"
#include "FileManagerDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFileReceiveServer::CFileReceiveServer()
{
	m_bZipFile = TRUE;
	memset(m_szNumberCD, 0x20, sizeof(m_szNumberCD));
}

CFileReceiveServer::~CFileReceiveServer()
{

}

BOOL CFileReceiveServer::IsNumber(char *pszData, int nLength)
{
	if(pszData == NULL)
		return FALSE;
	
	for(int i=0; i<nLength; i++)
	{
		if(!isdigit(pszData[i]))
			return FALSE;
	}
	
	return TRUE;
}

LPCTSTR CFileReceiveServer::GetNumberCD()
{
	TCHAR szValue[20] = {0x00,};
	CString strValue = _T("");
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("Local", "CDnumber", "", szValue, sizeof(szValue), ATOM_INFO_INI);
	if(strlen(szValue) == LENGTH_CDNUM) 
	{
		memset(m_szNumberCD, 0x00, sizeof(m_szNumberCD));
		memcpy(m_szNumberCD, szValue, strlen(szValue));
	}
	else 
	{
		memset(m_szNumberCD, 0x20, sizeof(m_szNumberCD));
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "[Failure] Fail to get cdnumber");
	}
	
	return m_szNumberCD;
}

int CFileReceiveServer::GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int iLen = strlen((char*)sMsg);
	for(int i=0; i < iLen; i++)
	{
		if(sMsg[i] == fs)
		{
			return i; // length of token
		}
		else
		{
			sToken[i] = sMsg[i];
		}
	}
	
	// GetToken failure
	return 0;
}

int CFileReceiveServer::GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs)
{
	int i,j;
	int iLen = strlen((char*)sMsg);
	i= iLen; j=0;
	
	for(i; i >= 0 ; i--)
	{
		if(sMsg[i] == fs) {
			wsprintf(sToken,"%s",&sMsg[i+1]);
			return i;
		}
	}
	
	// GetToken failure
	return -1;
}

void CFileReceiveServer::ProcessPacket(CConnectedSession *pConnectedSession, BYTE *pPacket, DWORD dwPacketLength)
{
//	STX(1) + LENGTH(4) + CMD(2) + CDNUMBER(4) + BUFFER SIZE(4) + FILENAME(N) + FS(1) + DATA(N) + ETX(1)

#ifdef _DEBUG
	CProcessLog::GetInstance()->Dump(FS_LOG, "���ŵ�����", pPacket, dwPacketLength);
#endif

	PACKET_HEADER header;
	PACKET_INFO info;
	BYTE btSendPacket[MAX_PACKET_LENGTH] = {0x00,};
	DWORD dwSendLength = 0;
	
	memset(&header, 0x00, sizeof(header));
	memset(&info, 0x00, sizeof(info));
	
	// PACKET FORMAT CHECK
	if(IsValidPacket(pPacket, dwPacketLength, header, info) == FALSE)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Msg Format error");

		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeErrorPacket(btSendPacket, REP_FILE_SAVE, MSG_FORMAT_ERROR);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();

		return;
	}


	// File save Start
	if(memcmp(header.type, REQ_SAVE_START, LENGTH_MSG_TYPE) == 0)
	{
		ConnectToFileServer(pPacket, dwPacketLength);
		return;
	}
	// delete file..no response
	else if(memcmp(header.type, SND_FILE_DEL, LENGTH_MSG_TYPE) == 0)
	{
		if(_unlink(info.filepath) == 0) 
		{
			CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Success] Delete success. file(%s)", info.filepath);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Success] Delete failure. file(%s)", info.filepath);
		}

		pConnectedSession->End();
		return;
	}
	// file size
	else if(memcmp(header.type, SND_FILE_SIZE, LENGTH_MSG_TYPE) == 0)
	{	
		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileSizePacket(pConnectedSession, btSendPacket, info);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();
	}
	// file data
	else if(memcmp(header.type, SND_FILE_DATA, LENGTH_MSG_TYPE) == 0)
	{
		memset(btSendPacket, 0x00, sizeof(btSendPacket));
		dwSendLength = MakeFileDataPacket(pConnectedSession, btSendPacket, info);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();
	}
	// file data end
	else if(memcmp(header.type, SND_FILE_END, LENGTH_MSG_TYPE) == 0)
	{
		memset(btSendPacket, 0x00, sizeof(btSendPacket));

		dwSendLength = MakeFileDataPacket(pConnectedSession, btSendPacket, info);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();
	}
	// undefined type
	else
	{ 
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Undefined message type(%s) rcv", header.type);

		dwSendLength = MakeErrorPacket(btSendPacket, REP_FILE_SAVE, MSG_FORMAT_ERROR);
		if(!pConnectedSession->WritePacket(btSendPacket, dwSendLength))
			pConnectedSession->End();
	}
}

BOOL CFileReceiveServer::IsValidPacket(const BYTE *pPacket,
									DWORD dwPacketLength,
									PACKET_HEADER &header,
									PACKET_INFO &info)
{
	int nLength = 0;
	int nIndex = 0;
	int nFilePathLength = 0;
	int nDataLength = 0;
	TCHAR szLength[10] = {0x00,};
	TCHAR szFilePath[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR szData[LENGTH_MAX_BUFFER] = {0x00,}; 

	if(dwPacketLength <= sizeof(header))
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CFileReceiveServer::IsValidPacket] [ERROR] Packet Format error[Length <= Header size]");
		return FALSE;
	}

	memset(&header, 0x00, sizeof(header));
	memcpy(&header, pPacket, sizeof(header));

	// STX ERROR
	if(header.stx[0] != STX)	 
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CFileReceiveServer::IsValidPacket] [ERROR] Packet Format error[STX]");
		return FALSE;
	}

	// LENGTH DATA ERROR
	if(!IsNumber(header.length, sizeof(header.length)))
	{
		// length error
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CFileReceiveServer::IsValidPacket] [ERROR] Packet Format error[Length field error]");
		return FALSE;
	}

	memset(szLength, 0x00, sizeof(szLength));
	memcpy(szLength, header.length, sizeof(header.length));
	nLength = atoi(szLength);

	// PACKET LENGTH ERROR
	if(nLength != dwPacketLength)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CFileReceiveServer::IsValidPacket] [ERROR] Packet Format error[not same length]");
		return FALSE;
	}

	// ETX ERROR
	if(pPacket[dwPacketLength - 1] != ETX)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG, "[CFileReceiveServer::IsValidPacket] [ERROR] Packet Format error[ETX]");
		return FALSE;
	}

	memset(&info, 0x00, sizeof(info));
	memset(szFilePath, 0x00, sizeof(szFilePath));
	memset(szData, 0x00, sizeof(szData));

	// GET FILEPATH
	nFilePathLength = GetFirstToken(szFilePath, &pPacket[sizeof(header)], dwPacketLength - sizeof(header), FS);
	nIndex = sizeof(header) + LENGTH_FS + nFilePathLength;

	// GET DATA
	//nDataLength = GetFirstToken(szData, &pPacket[nIndex], dwPacketLength - nIndex, ETX);
	nDataLength = dwPacketLength - nIndex - 1; // -1 //ETX
	if(nDataLength > 0)
	{
		memcpy(szData, &pPacket[nIndex], nDataLength);
	}

	memcpy(info.cdname, header.cdname, sizeof(header.cdname));
	memcpy(info.size, header.size, sizeof(header.size));
	memcpy(info.filepath, szFilePath, nFilePathLength);
	memcpy(info.data, szData, nDataLength);
	info.nFilePathLength = nFilePathLength;
	info.nDataLength = nDataLength;

	return TRUE;
}

// FILEPATH���� .zip Ȯ���� ����
int CFileReceiveServer::GetZipFileName(LPCTSTR szFilePath, TCHAR *szZipFileName)
{
	int nLength = 0;
	CString strPostFix = _T("");

	nLength = strlen(szFilePath);
	if(nLength < 4)
	{
		memcpy(szZipFileName, szFilePath, nLength);
		return 0;
	}

	strPostFix.Format("%s", &szFilePath[nLength - 4]);
	strPostFix.MakeLower();
	if(strPostFix.Compare(_T(".zip")) == 0)
	{
		memcpy(szZipFileName, szFilePath, nLength - 4);
		return 1;
	}

	memcpy(szZipFileName, szFilePath, nLength);
	return 0;
}

int CFileReceiveServer::MakeZipFile(char* szFullFilePath)
{
	TCHAR szZipFileName[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR sTempFile[LENGTH_MAX_BUFFER] = {0x00,};
	int nFileCount = 0;
	int nFilePos = 0;
	
	CFileFind filefinder;
	TCHAR szSelectedFiles[LENGTH_MAX_BUFFER] = {0x00,};
	TCHAR szLastFileName[LENGTH_MAX_BUFFER] = {0x00,};
	
	memset(szLastFileName, 0x00, sizeof(szLastFileName));
	nFilePos = GetLastToken(szLastFileName, (BYTE*)szFullFilePath, strlen(szFullFilePath), '\\');
	
	memset(szZipFileName, 0x00, sizeof(szZipFileName));
	wsprintf(szZipFileName, "%s.zip", szFullFilePath);
	
	// szFullFilename �� ����ִ� ��� ȭ���� ����... 2002-05-17
	memset(szSelectedFiles, 0x00, sizeof(szSelectedFiles));
	memcpy(&szSelectedFiles, szFullFilePath, nFilePos + 1);
	wsprintf(&szSelectedFiles[nFilePos +1 ], "*%s*.*", szLastFileName);
	// ------------------------------------------------------------
	
	if (filefinder.FindFile(szSelectedFiles, 0) == TRUE)
	{
		// create zip file (no append)
		CZipFile zipfile(szZipFileName, 0); 
		BOOL bFlag = TRUE;
		
		while(bFlag == TRUE)
		{
			bFlag = filefinder.FindNextFile();
			wsprintf(sTempFile,"%s",filefinder.GetFilePath());
			if(filefinder.IsDots() == 1)
				continue;
			else if (filefinder.IsDirectory() == 1 )
				continue;	// dir -- ignore	
			else if(GetZipFileName(sTempFile, sTempFile))
				continue;	// zip file -- ignore
			else
			{		
				nFileCount++;
				CFile TargetFile(filefinder.GetFilePath(), CFile::modeRead);
				zip_fileinfo zipInfo;
				
				try
				{
					zipfile.UpdateZipInfo(zipInfo, TargetFile);
					// sFilename : ��θ� ������ filename..�ȱ׷��� ��� ���� ����.
					zipfile.OpenNewFileInZip(filefinder.GetFileName(), zipInfo, Z_BEST_COMPRESSION);
				}
				catch (CException* e)
				{
					e->Delete();
					return -1;
				}
				
				int size_read;
				char buf[BUFFER_SIZE] = {0x00,};
				
				do
				{
					memset(buf, 0x00, sizeof(buf));
					size_read = TargetFile.Read(buf, BUFFER_SIZE);
					if (size_read)
						zipfile.WriteInFileInZip(buf, size_read);
				}
				while (size_read == BUFFER_SIZE);
				
				TargetFile.Close();
				CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Success] Compressed file(%s)", filefinder.GetFilePath());
			}
		}
		
		zipfile.Close();
		if( nFileCount ==0 )
			_unlink(szZipFileName);
	}
		
	return nFileCount;
}

DWORD CFileReceiveServer::MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info)
{
	int nIndex = 0;
	DWORD dwPacketLength = 0;
	TCHAR szLength[5] = {0x00,};
	PACKET_HEADER header;

	dwPacketLength = sizeof(header) + info.nFilePathLength + LENGTH_FS + info.nDataLength + LENGTH_ETX;
	
	memset(szLength, 0x00, sizeof(szLength));
	wsprintf(szLength, "%04d", dwPacketLength);
	
	memset(&header, 0x00, sizeof(PACKET_HEADER));	
	memcpy(header.length, szLength, sizeof(header.length));
	memset(header.stx, STX, LENGTH_STX);
	memcpy(header.type, info.type, LENGTH_MSG_TYPE);
	memcpy(header.cdname, info.cdname, sizeof(header.cdname));
	memcpy(header.size, info.size, sizeof(header.size));
	
	memcpy(pPacketBuffer, &header, sizeof(header));
	nIndex += sizeof(header);

	memcpy(pPacketBuffer + nIndex, info.filepath, info.nFilePathLength);
	nIndex += info.nFilePathLength;

	memset(pPacketBuffer + nIndex, FS, LENGTH_FS);
	nIndex += LENGTH_FS;

	memcpy(pPacketBuffer + nIndex, info.data, info.nDataLength);
	nIndex += info.nDataLength;

	memset(pPacketBuffer + nIndex, ETX, LENGTH_ETX);
	
	// retrun packet length 
	return dwPacketLength;
}

DWORD CFileReceiveServer::MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode)
{
	PACKET_INFO info;
	memset(&info, 0x00, sizeof(info));
	
	info.nFilePathLength = 0;
	memcpy(info.type, lpszType, LENGTH_MSG_TYPE);
	memcpy(info.data, lpszErrorCode, LENGTH_ERROR_CODE);
	memcpy(info.cdname, GetNumberCD(), LENGTH_CDNUM);	// temp
	memcpy(info.size, "0512", 4);						// temp
	
	info.nDataLength = LENGTH_ERROR_CODE;
	
	return MakePacket(pPacketBuffer, info);
}


DWORD CFileReceiveServer::MakeFileSizePacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;

	TCHAR szTempFile[MAX_PATH] = {0x00,};

	memset(&packet, 0x00, sizeof(packet));
	memcpy(&packet, &info, sizeof(info));

	memcpy(packet.type, REP_FILE_SAVE, LENGTH_MSG_TYPE);
	memcpy(packet.data, SAVE_SUCCESS, LENGTH_ERROR_CODE);
//	memcpy(packet.size, "0512", 4);
//	strcpy(packet.filepath, lpszFilePath);
//	packet.nFilePathLength = strlen(lpszFilePath);

	// �ӽ������� �����ϸ� �����Ѵ�.
	memset(szTempFile, 0x00, sizeof(szTempFile));
	wsprintf(szTempFile, FILEFORMAT_TEMP, info.filepath);
	if(PathFileExists(szTempFile))
		_unlink(szTempFile);

	return MakePacket(pPacketBuffer, packet);
}

DWORD CFileReceiveServer::MakeFileDataPacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info)
{
	PACKET_INFO packet;
	TCHAR szFilePath[MAX_PATH] = {0x00,};
	TCHAR szTempFile[MAX_PATH] = {0x00,};
	TCHAR szBackFile[MAX_PATH] = {0x00,};

	memcpy(&packet, &info, sizeof(info));
	memcpy(packet.type, REP_FILE_SAVE, LENGTH_MSG_TYPE);

	// ���ϰ��
	memset(szFilePath, 0x00, sizeof(szFilePath));
	memcpy(szFilePath, info.filepath, info.nFilePathLength);

	// �ӽ����� ���
	memset(szTempFile, 0x00, sizeof(szTempFile));
	wsprintf(szTempFile, FILEFORMAT_TEMP, szFilePath);

	// ������� ���
	memset(szBackFile, 0x00, sizeof(szBackFile));
	wsprintf(szBackFile, FILEFORMAT_BACK, szFilePath);
	
	int nResult = WriteToFile(szTempFile, info.data, info.nDataLength);
	if(nResult >= 0)
	{
		memcpy(packet.type, REP_FILE_SAVE, LENGTH_MSG_TYPE);
		memcpy(packet.data, SAVE_SUCCESS, LENGTH_ERROR_CODE);
		packet.nDataLength = LENGTH_ERROR_CODE;

		if(memcmp(info.type, SND_FILE_END, LENGTH_MSG_TYPE) == 0)
		{
			// ���� ��������� �����ϸ� �����Ѵ�.
			if(PathFileExists(szBackFile))
				_unlink(szBackFile);

			if(PathFileExists(szFilePath) && rename(szFilePath, szBackFile) != 0)
			{
				// ���������� ������� ���� ���
				CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Backup error(org:%s bak:%s).", szFilePath, szBackFile);
				memcpy(packet.data, BACKUP_ERROR, LENGTH_ERROR_CODE);
			}
			else
			{
				// ���������� ����� ���
				// �ӽ������� �������Ϸ� �����Ѵ�.
				if(rename(szTempFile, szFilePath) != 0)
				{
					CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Rename error(temp:%s org:%s).", szTempFile, szFilePath);
					memcpy(packet.data, UPDATE_ERROR, LENGTH_ERROR_CODE);

					if(rename(szBackFile, szFilePath) != 0)
					{
						CProcessLog::GetInstance()->WriteLog(FS_LOG, "[ERROR] Recovery error(org:%s bak:%s).", szFilePath, szBackFile);
						memcpy(packet.data, RECOVERY_ERROR, LENGTH_ERROR_CODE);
					}
				}
				else
				{
					CProcessLog::GetInstance()->WriteLog(FS_LOG, "[Success] File Update (tmp:%s org:%s).", szTempFile, szFilePath);
					memcpy(packet.data, SAVE_SUCCESS, LENGTH_ERROR_CODE);
				}
			}
		}
	}
	else if(nResult == -1)
	{
		// file write fail
		memcpy(packet.type, REP_FILE_SAVE, LENGTH_MSG_TYPE);
		memcpy(packet.data, FILE_WRITE_ERROR, LENGTH_ERROR_CODE);
		packet.nDataLength = LENGTH_ERROR_CODE;
	}
	else if(nResult == -2)
	{
		// file create fail
		memcpy(packet.type, REP_FILE_SAVE, LENGTH_MSG_TYPE);
		memcpy(packet.data, FILE_CREATE_ERROR, LENGTH_ERROR_CODE);
		packet.nDataLength = LENGTH_ERROR_CODE;
	}

	return MakePacket(pPacketBuffer, packet);
}

ULONG CFileReceiveServer::GetFileSize(LPCTSTR lpszFilePath)
{
	if(lpszFilePath == NULL || !PathFileExists(lpszFilePath))
		return 0;

	CFileStatus fs;

	if(CFile::GetStatus(lpszFilePath, fs))
	{
		return fs.m_size;
	}
	else
	{
		return 0;
	}
}


int CFileReceiveServer::ReadFile(CFile *pFile, LONGLONG lFilePtr, int nBytesToRead, char *szReadBuffer)
{
	char szFileBuffer[LENGTH_MAX_BUFFER] = {0x00,};
	int nReadBytes = 0;
	
	pFile->Seek(lFilePtr, 0);

	memset(szFileBuffer, 0x00, sizeof(szFileBuffer));
	if(nReadBytes = pFile->Read(szFileBuffer, nBytesToRead))
	{
		//CProcessLog::GetInstance()->WriteLog(ATOM_FILECLIENT_LOG, "[READ] file(%s) position(%ld) size(%d)",sFileName,lFilePointer,nBytesRead);
		memcpy(szReadBuffer, szFileBuffer, nReadBytes);		
		return nReadBytes;  // success
	}
	else 
	{	
		return 0; // no data
	}
}

int CFileReceiveServer::WriteToFile(LPCTSTR lpszFilePath, char *pszData, int nDataLength)
{
	HANDLE hFile = INVALID_HANDLE_VALUE;
	DWORD dwWritten = 0;
	int nResult = 0;

	if(nDataLength <= 0)
		return 0;
	
    if ((hFile = CreateFile(lpszFilePath,
							GENERIC_READ | GENERIC_WRITE,
							FILE_SHARE_READ | FILE_SHARE_WRITE,  // exclusive access
							NULL,                 // no security attrs
							OPEN_ALWAYS,
							FILE_ATTRIBUTE_ARCHIVE,
							NULL)) == INVALID_HANDLE_VALUE)
    {
        return -2;
    }
	
    SetFilePointer(hFile, 0, NULL, FILE_END);
	
    if(WriteFile(hFile, pszData, nDataLength, &dwWritten, NULL))
		nResult = dwWritten;
	else
		nResult = -1;
	
	CloseHandle(hFile);
	
	return nResult;

/*
	CFile file;
	CFileException ex;
	TCHAR szError[1024] = {0x00,};

	CDirectory::MakeDirectory(CDirectory::GetDirectory(lpszFilePath));
	
	BOOL bOpened = file.Open(lpszFilePath, 
							 CFile::modeCreate|CFile::modeWrite|CFile::shareExclusive|CFile::modeNoTruncate,
							 &ex);
	if(!bOpened)
	{
		memset(szError, 0x00, sizeof(szError));
		ex.GetErrorMessage(szError, sizeof(szError));

		CProcessLog::GetInstance()->WriteLog(FS_LOG, "File(%s) Write Error:%s", lpszFilePath, szError);
		return -1;
	}
	
	file.Write(pszData, nDataLength);
	file.Close();
	
	return nDataLength;
*/
}

/* ====================================================================================== 
STX[1] + MsgLen[4] +  MSG_TYPE[2] + FS[1] + IP[15] + FS[1] + PORT[4] + ETX[1]
* ====================================================================================== */
int CFileReceiveServer::ConnectToFileServer(BYTE *pPacket, DWORD dwPacketLength)
{
	CString strServerIP = ""; 
	int nServerPort = 0;	
	char szValue[20] = {0x00,};
	
	memset(szValue, 0x00, sizeof(szValue));
	memcpy(szValue, &pPacket[8], 15);
	
	strServerIP = szValue;
	strServerIP.TrimLeft();
	strServerIP.TrimRight();
	
	memset(szValue, 0x00, sizeof(szValue));
	memcpy(szValue, &pPacket[24], 4);
	nServerPort = atoi(szValue);
	
	if(strServerIP.GetLength() && nServerPort > 0)
	{
		ConnectToFileServer(strServerIP, nServerPort);
		return 1;
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "Invalid IP(%s) or Port number(%d).", strServerIP, nServerPort);
		return 0;
	}
}

int CFileReceiveServer::ConnectToFileServer(LPCTSTR lpszAddress, int nPort)
{
	CFileManagerDlg *pMainWnd = (CFileManagerDlg*) theApp.GetMainWnd();
	if(pMainWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(FS_LOG,  "MainWnd Find Failure.(IP:%s, Port:%d)", lpszAddress, nPort);
		return 0;
	}

	CProcessLog::GetInstance()->WriteLog(FS_LOG,  "FileServer Info set.(IP:%s, Port:%d)", lpszAddress, nPort);
	pMainWnd->SetFileServerInfo(lpszAddress, nPort);
	pMainWnd->PostMessage(UM_FILESERVER_CONNECT, 0, 0);

	return 1;
}