// FileSendServer.h: interface for the CFileSendServer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILESENDSERVER_H__1CDFE5E0_DBA6_4EA5_A7DC_D6722E164C0E__INCLUDED_)
#define AFX_FILESENDSERVER_H__1CDFE5E0_DBA6_4EA5_A7DC_D6722E164C0E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ServerIocp.h"

class CFileSendServer : public CServerIocp  
{
public:
	CFileSendServer();
	virtual ~CFileSendServer();

private:
	TCHAR m_szNumberCD[20];
	BOOL m_bZipFile;

public:
	ULONG GetFileSize(LPCTSTR lpszFilePath);
	BOOL IsNumber(char *pszData, int nLength);
	LPCTSTR GetNumberCD();

	DWORD MakeFileSizePacket(CConnectedSession *pSession, BYTE *pPacketBuffer, LPCTSTR lpszFilePath);
	DWORD MakeFileDataPacket(CConnectedSession *pSession, BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD MakePacket(BYTE *pPacketBuffer, PACKET_INFO &info);
	DWORD MakeErrorPacket(BYTE *pPacketBuffer, LPCTSTR lpszType, LPCTSTR lpszErrorCode);

protected:
	// ��Ŷ ó���� �� �Լ�
	void ProcessPacket(CConnectedSession *pConnectedSession, BYTE *pPacket, DWORD dwPacketLength);

	BOOL IsValidPacket(const BYTE *pPacket, DWORD dwPacketLength, PACKET_HEADER &header, PACKET_INFO &info);
	BOOL Reboot();

	int GetFirstToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	int GetLastToken(char *sToken, const BYTE *sMsg, int nLength, int fs);
	int GetZipFileName(LPCTSTR szFilePath, TCHAR *szZipFileName);
	int MakeZipFile(char* szFullFilePath);
	int ReadFile(CFile *pFile, LONGLONG lFilePtr, int nBytesToRead, char *szReadBuffer);

	BOOL SendCommandToBiz(LPCTSTR lpCommand);
	int SendMessageToBiz(CString strMessage);
};

#endif // !defined(AFX_FILESENDSERVER_H__1CDFE5E0_DBA6_4EA5_A7DC_D6722E164C0E__INCLUDED_)
