// OperationManager.h : main header file for the OPERATIONMANAGER application
//

#if !defined(AFX_OPERATIONMANAGER_H__2ACD7EAB_FE40_48A9_BE58_AF94F8FED279__INCLUDED_)
#define AFX_OPERATIONMANAGER_H__2ACD7EAB_FE40_48A9_BE58_AF94F8FED279__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// COperationManagerApp:
// See OperationManager.cpp for the implementation of this class
//

class COperationManagerApp : public CWinApp
{
public:
	COperationManagerApp();

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COperationManagerApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(COperationManagerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	ULONG_PTR	m_gdiplusToken;
	HANDLE		m_hMutex;
	HMODULE		m_hEncrypt;
	BOOL LoadEncryptLibrary();

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPERATIONMANAGER_H__2ACD7EAB_FE40_48A9_BE58_AF94F8FED279__INCLUDED_)
