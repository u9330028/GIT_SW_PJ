// TandemSocket.h: interface for the CTandemSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TANDEMSOCKET_H__DAA2E213_7CAD_4E0C_B8CE_60081983DD8E__INCLUDED_)
#define AFX_TANDEMSOCKET_H__DAA2E213_7CAD_4E0C_B8CE_60081983DD8E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTandemSocket : public CObject  
{
public:

	
	
	CTandemSocket();
	virtual ~CTandemSocket();


public:
	int Send(LPCTSTR lpDataBuffer, DWORD dwDataLength);
	int Create();
	void Destroy();
	int Connect(LPCTSTR lpRemoteIP, int nRemotePort);
	void Close();
	int SendErrorCode(LPCTSTR lpErrorCode);

private:
	SOCKET	m_hSocket;
	CString m_strRemoteIP;
	int		m_nRemotePort;

	BOOL	m_bStartup;
	BOOL	m_bConnected;
};

#endif // !defined(AFX_TANDEMSOCKET_H__DAA2E213_7CAD_4E0C_B8CE_60081983DD8E__INCLUDED_)
