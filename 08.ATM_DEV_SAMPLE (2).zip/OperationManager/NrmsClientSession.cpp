#include "stdafx.h"
#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "EventSelect.h"
#include "NrmsPacketSession.h"
#include "NrmsClientSession.h"
#include "Shortcut.h"

CNrmsClientSession::CNrmsClientSession(void)
{
	m_nCurrentState = NRMS_STATE_REQUEST;
	m_hParentWnd = NULL;
}

CNrmsClientSession::CNrmsClientSession(HWND hParentWnd)
{
	m_nCurrentState = NRMS_STATE_REQUEST;
	m_hParentWnd = hParentWnd;
}

CNrmsClientSession::~CNrmsClientSession(void)
{
}

BOOL CNrmsClientSession::Begin(LPSTR remoteAddress, USHORT remotePort)
{
	if (!remoteAddress || remotePort <= 0)
		return FALSE;

	if (!mSession.Begin())
	{
		End();

		return FALSE;
	}

	if (!mSession.TcpBind())
	{
		End();

		return FALSE;
	}

	if (!CEventSelect::Begin(mSession.GetSocket()))
	{
		End();

		return FALSE;
	}

	if (!mSession.Connect(remoteAddress, remotePort))
	{
		End();

		return FALSE;
	}

	return TRUE;
}


BOOL CNrmsClientSession::End(void)
{
	mSession.End();

	CEventSelect::End();

	return TRUE;
}

BOOL CNrmsClientSession::GetLocalIP(WCHAR* pIP)
{
    return mSession.GetLocalIP(pIP);
}

BOOL CNrmsClientSession::GetLocalIP(TCHAR* pIP)
{
    return mSession.GetLocalIP(pIP);
}

USHORT CNrmsClientSession::GetLocalPort(void)
{
	return mSession.GetLocalPort();
}

BOOL CNrmsClientSession::ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength)
{
	void *Object = NULL;

	return mReadPacketQueue.Pop(&Object, protocol, packet, packetLength);
}

BOOL CNrmsClientSession::WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength)
{
	if (!mSession.WritePacket(lpCommand, pData, dwDataLength))
		return FALSE;

	if (!mSession.WriteComplete())
		return FALSE;

	return TRUE;
}


void CNrmsClientSession::OnIoRead(void)
{
	BYTE	btPacket[MAX_BUFFER_LENGTH]	= {0,};
	DWORD	dwPacketLength				= 0;

	DWORD	dwProtocol					= 0;

	if (mSession.ReadPacketForEventSelect())
	{
		while (mSession.GetPacket(dwProtocol, btPacket, dwPacketLength))
		{
			mReadPacketQueue.Push(this, dwProtocol, btPacket, dwPacketLength);
			ProcessPacket();
			//SendMessageToParent(UM_NRMS_RECEIVE, 0, 0);
		}
	}
}

// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
void CNrmsClientSession::OnIoConnected(DWORD dwError)
{
	SendMessageToParent(UM_NRMS_CONNECTED, 0, dwError);
}

// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
void CNrmsClientSession::OnIoDisconnected(void)
{
	TRACE(_T("OnIoDisconnected\n"));
}

void CNrmsClientSession::OnIoError(DWORD dwError)
{
	TRACE(_T("OnIoError(%d)\n"), dwError);

	switch(dwError)
	{
	case WSAETIMEDOUT:	// ����ð� �ʰ�

		break;


	default:
		break;
	}
		
}

void CNrmsClientSession::SetParentWnd(HWND hParentWnd)
{
	m_hParentWnd  = hParentWnd;
}

void CNrmsClientSession::SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(m_hParentWnd == NULL || !IsWindow(m_hParentWnd))
		return;
	
	::PostMessage(m_hParentWnd, uMsg, wParam, lParam);
}

void CNrmsClientSession::SendTextToParent(LPCTSTR lpszText)
{
	if(m_hParentWnd == NULL || !IsWindow(m_hParentWnd) || lpszText == NULL)
		return;
	
	COPYDATASTRUCT cds;
	cds.dwData = DISPLAY_STATUS;
	cds.lpData = (LPVOID) lpszText;
	cds.cbData = lstrlen(lpszText);
	
	::SendMessage(m_hParentWnd, WM_COPYDATA, 0, (LPARAM) &cds);	
}

BOOL CNrmsClientSession::SendRequestFileInfoPacket()
{
	// ��Ŷ�� ������ ����ϴ� ����
	TCHAR szLocalIP[100] = {0x00, };

	memset(szLocalIP, 0x00, sizeof(szLocalIP));
	GetLocalIP(szLocalIP);
	if(strlen(szLocalIP) <= 0 || strcmp(szLocalIP, "0.0.0.0") == 0)
	{
		GetPrivateProfileString("LOCAL", "IP", "", szLocalIP, sizeof(szLocalIP), ATOM_IBP_INI);
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::SendRequestFileInfoPacket] LOCALIP:%s"), szLocalIP);

	m_nCurrentState = NRMS_STATE_REQUEST;
	
	BOOL bResult = WritePacket(REQ_FILE_INFO, (LPBYTE)szLocalIP, strlen(szLocalIP));
	if(bResult)
	{
		SetReceiveTimeOut(ELAPSE_NRMS_RECEIVE_TIMEOUT);
	}

	return bResult;
}

BOOL CNrmsClientSession::SendFormatErrorPacket()
{
	TCHAR szData[BUFFER_SIZE] = {0x00, };
	
	memset(szData, 0x00, sizeof(szData));
	strcpy(szData, FORMAT_ERROR);
	
	m_nCurrentState = NRMS_STATE_FORMAT_ERROR;
	
	BOOL bResult = WritePacket(RES_ERROR, (LPBYTE)szData, strlen(szData));
	//SetReceiveTimeOut(ELAPSE_NRMS_RECEIVE_TIMEOUT);
	
	return bResult;
}

BOOL CNrmsClientSession::SendWriteErrorPacket()
{
	TCHAR szData[BUFFER_SIZE] = {0x00, };
	
	memset(szData, 0x00, sizeof(szData));
	strcpy(szData, WRITE_ERROR);
	
	m_nCurrentState = NRMS_STATE_WRITE_ERROR;
	
	BOOL bResult = WritePacket(RES_ERROR, (LPBYTE)szData, strlen(szData));
	//SetReceiveTimeOut(ELAPSE_NRMS_RECEIVE_TIMEOUT);
	
	return bResult;
}

void CNrmsClientSession::ProcessPacket()
{
	LPVOID pObject = NULL;
	DWORD dwPacketLength = 0;
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	BYTE btData[MAX_BUFFER_LENGTH] = {0x00, };
	BYTE btCommand[128] = {0x00, };
	TCHAR szDataCount[128] = {0x00, };
	int nTokenLength = 0;
	int nDataCount = 33;
	int nDataLength = 0;
	int nDataPosition = 0;
	BOOL bResult = FALSE;
	CString strMessage = _T("");

//	BYTE btData[] = {
//	dwPacketLength = 961;
	BYTE btSample[] = {
0x02,0x30,0x39,0x36,0x31,0x36,0x33,0x1C,0x33,0x33,0x1D,0x69,0x6E,0x66,0x6F,0x2E,
0x69,0x6E,0x69,0x1E,0x4C,0x4F,0x43,0x41,0x4C,0x1E,0x63,0x64,0x6E,0x75,0x6D,0x62,
0x65,0x72,0x1E,0x43,0x30,0x30,0x31,0x1D,0x69,0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,
0x1E,0x48,0x4F,0x53,0x54,0x1E,0x74,0x61,0x6E,0x64,0x65,0x6D,0x73,0x76,0x72,0x1E,
0x31,0x37,0x32,0x2E,0x31,0x36,0x2E,0x31,0x2E,0x39,0x30,0x1D,0x69,0x6E,0x66,0x6F,
0x2E,0x69,0x6E,0x69,0x1E,0x48,0x4F,0x53,0x54,0x1E,0x74,0x61,0x6E,0x64,0x65,0x6D,
0x73,0x76,0x72,0x70,0x6F,0x72,0x74,0x1E,0x31,0x30,0x30,0x30,0x32,0x1D,0x69,0x6E,
0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x4E,0x52,0x4D,0x53,0x1E,0x74,0x79,0x70,0x65,
0x1E,0x54,0x45,0x53,0x54,0x1D,0x62,0x75,0x73,0x2E,0x69,0x6E,0x69,0x1E,0x54,0x52,
0x41,0x4E,0x1E,0x54,0x45,0x52,0x5F,0x49,0x44,0x1E,0x1D,0x62,0x75,0x73,0x2E,0x69,
0x6E,0x69,0x1E,0x54,0x52,0x41,0x4E,0x1E,0x43,0x44,0x49,0x44,0x1E,0x1D,0x43,0x6F,
0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x54,0x49,0x43,0x4B,0x45,0x54,0x1E,
0x42,0x75,0x73,0x54,0x72,0x61,0x6E,0x1E,0x46,0x1D,0x49,0x6E,0x66,0x6F,0x2E,0x69,
0x6E,0x69,0x1E,0x4C,0x4F,0x43,0x41,0x4C,0x1E,0x43,0x44,0x4F,0x50,0x54,0x49,0x4D,
0x45,0x1E,0x46,0x1D,0x49,0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x4C,0x4F,0x43,
0x41,0x4C,0x1E,0x4F,0x50,0x54,0x49,0x4D,0x45,0x1E,0x1D,0x43,0x6F,0x6E,0x66,0x69,
0x67,0x2E,0x69,0x6E,0x69,0x1E,0x50,0x41,0x52,0x4B,0x1E,0x4C,0x6F,0x74,0x74,0x65,
0x54,0x72,0x61,0x6E,0x1E,0x46,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,
0x69,0x1E,0x54,0x49,0x43,0x4B,0x45,0x54,0x1E,0x4B,0x74,0x78,0x54,0x72,0x61,0x6E,
0x1E,0x46,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x54,0x49,
0x43,0x4B,0x45,0x54,0x1E,0x41,0x73,0x69,0x61,0x6E,0x61,0x54,0x72,0x61,0x6E,0x1E,
0x46,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x54,0x49,0x43,
0x4B,0x45,0x54,0x1E,0x53,0x70,0x6F,0x72,0x74,0x73,0x54,0x72,0x61,0x6E,0x1E,0x54,
0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x4D,0x45,0x4E,0x55,
0x1E,0x4A,0x69,0x72,0x6F,0x54,0x72,0x61,0x6E,0x1E,0x54,0x1D,0x43,0x6F,0x6E,0x66,
0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x4D,0x45,0x4E,0x55,0x1E,0x49,0x6E,0x73,0x75,
0x72,0x65,0x54,0x72,0x61,0x6E,0x1E,0x54,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,
0x69,0x6E,0x69,0x1E,0x54,0x49,0x43,0x4B,0x45,0x54,0x1E,0x43,0x47,0x56,0x54,0x72,
0x61,0x6E,0x1E,0x54,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,
0x4D,0x45,0x4E,0x55,0x1E,0x49,0x43,0x54,0x72,0x61,0x6E,0x1E,0x54,0x1D,0x43,0x61,
0x73,0x68,0x69,0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x42,0x52,0x55,0x1E,0x44,
0x45,0x50,0x4F,0x53,0x49,0x54,0x1E,0x54,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,
0x69,0x6E,0x69,0x1E,0x4D,0x45,0x4E,0x55,0x1E,0x57,0x69,0x72,0x65,0x54,0x72,0x61,
0x6E,0x1E,0x54,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x4D,
0x45,0x4E,0x55,0x1E,0x42,0x61,0x6E,0x6B,0x42,0x6F,0x6F,0x6B,0x54,0x72,0x61,0x6E,
0x1E,0x54,0x1D,0x49,0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x44,0x45,0x56,0x49,
0x43,0x45,0x1E,0x42,0x52,0x55,0x5F,0x4C,0x45,0x56,0x45,0x4C,0x1E,0x32,0x1D,0x49,
0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x4C,0x4F,0x43,0x41,0x4C,0x1E,0x4F,0x57,
0x4E,0x45,0x52,0x1E,0x42,0x4B,0x39,0x31,0x1D,0x53,0x74,0x61,0x72,0x74,0x70,0x72,
0x6F,0x67,0x72,0x61,0x6D,0x2E,0x69,0x6E,0x69,0x1E,0x44,0x56,0x52,0x1E,0x44,0x56,
0x52,0x5F,0x53,0x45,0x54,0x1E,0x46,0x1D,0x53,0x74,0x61,0x72,0x74,0x70,0x72,0x6F,
0x67,0x72,0x61,0x6D,0x2E,0x69,0x6E,0x69,0x1E,0x44,0x56,0x52,0x1E,0x44,0x56,0x52,
0x5F,0x49,0x50,0x1E,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,
0x4D,0x45,0x4E,0x55,0x1E,0x48,0x69,0x50,0x61,0x73,0x73,0x54,0x72,0x61,0x6E,0x1E,
0x54,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x44,0x45,0x56,
0x49,0x43,0x45,0x1E,0x54,0x59,0x50,0x45,0x1E,0x48,0x41,0x54,0x4D,0x1D,0x49,0x6E,
0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x4C,0x4F,0x43,0x41,0x4C,0x1E,0x4A,0x45,0x48,
0x59,0x55,0x1E,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,0x69,0x1E,0x4D,
0x45,0x4E,0x55,0x1E,0x48,0x61,0x6E,0x61,0x43,0x61,0x70,0x69,0x74,0x61,0x6C,0x1E,
0x46,0x1D,0x63,0x61,0x73,0x68,0x69,0x6E,0x66,0x6F,0x2E,0x69,0x6E,0x69,0x1E,0x4F,
0x55,0x54,0x43,0x4F,0x55,0x4E,0x54,0x49,0x4E,0x46,0x4F,0x1E,0x44,0x42,0x5F,0x35,
0x30,0x30,0x30,0x30,0x1E,0x1D,0x63,0x61,0x73,0x68,0x69,0x6E,0x66,0x6F,0x2E,0x69,
0x6E,0x69,0x1E,0x43,0x41,0x53,0x53,0x45,0x54,0x54,0x45,0x49,0x4E,0x46,0x4F,0x1E,
0x43,0x53,0x54,0x31,0x1E,0x31,0x1D,0x63,0x61,0x73,0x68,0x69,0x6E,0x66,0x6F,0x2E,
0x69,0x6E,0x69,0x1E,0x43,0x41,0x53,0x53,0x45,0x54,0x54,0x45,0x49,0x4E,0x46,0x4F,
0x1E,0x43,0x53,0x54,0x32,0x1E,0x1D,0x63,0x61,0x73,0x68,0x69,0x6E,0x66,0x6F,0x2E,
0x69,0x6E,0x69,0x1E,0x43,0x41,0x53,0x53,0x45,0x54,0x54,0x45,0x49,0x4E,0x46,0x4F,
0x1E,0x43,0x53,0x54,0x33,0x1E,0x1D,0x43,0x6F,0x6E,0x66,0x69,0x67,0x2E,0x69,0x6E,
0x69,0x1E,0x4D,0x45,0x4E,0x55,0x1E,0x53,0x68,0x69,0x6E,0x48,0x61,0x6E,0x43,0x61,
0x72,0x64,0x41,0x70,0x70,0x6C,0x69,0x63,0x61,0x74,0x69,0x6F,0x6E,0x1E,0x54,0x1D,
0x03};




	memset(btPacket, 0x00, sizeof(btPacket));
	if(mReadPacketQueue.Pop(&pObject, btPacket, dwPacketLength))
	{
		// ���� ���� ������� Ÿ�Ӿƿ� ����
		ClearReceiveTimeOut();
		SendTextToParent(_T("�������� ���� �Ϸ�(����Ÿ�Ӿƿ� ����)"));
		
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::ProcessPacket] ���� ��Ŷ ó�� ����"));
		CProcessLog::GetInstance()->Dump(LOGFILE, "", btPacket, dwPacketLength);

		////////////////////////////////////////////////////////////////////////
		// ���� ���� üũ
		////////////////////////////////////////////////////////////////////////
		if (btPacket[0] != STX)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[ERROR] Receive Data Format (STX) Error"));
			SendFormatErrorPacket();
			return;
		}

		if (btPacket[dwPacketLength - 1] != ETX) 
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[ERROR] Receive Data Format (ETX) Error"));
			SendFormatErrorPacket();

			strMessage.Format(_T("[NRMS] DATA FORMAT ERROR ����"));
			SendTextToParent(strMessage);
			SendMessageToParent(UM_START_PROGRAM, 600, MAX_PROGRESS_STEP);
			return;
		}

		// ���� Ÿ�� STX(1) + LENGTH(4) + COMMAND(2)
		memset(btCommand, 0x00, sizeof(btCommand));
		memcpy(btCommand, &btPacket[5], 2);

		memset(szDataCount, 0x00, sizeof(szDataCount));
		nTokenLength = GetFirstToken(szDataCount, (TCHAR*)&btPacket[8], GS);
		nDataCount = atoi(szDataCount);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("���� ������ ī��Ʈ:%d TOKENLENGTH:%d"), nDataCount, nTokenLength);

		// ����Ÿ��
		nDataPosition = 8 + nTokenLength + 1;
		nDataLength = dwPacketLength - nDataPosition;
		memset(btData, 0x00, sizeof(btData));
		memcpy(btData, &btPacket[nDataPosition], nDataLength);

//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::ProcessPacket] ���� ��Ŷ ����Ÿ"));
//		CProcessLog::GetInstance()->Dump(LOGFILE, "", btData, nDataLength);


		if(memcmp(btCommand, RES_NRMS_INFO, 2) == 0)
		{
			// �������� Ÿ��: "62"
			if(nDataCount == 0)
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("���� ������ ī��Ʈ:0"));
				SendMessageToParent(UM_START_PROGRAM, 0, MAX_PROGRESS_STEP);
				return;
			}

			int nPosition = 0;
			TCHAR szFileName[100] = {0x00, };
			TCHAR szSection[100] = {0x00, };
			TCHAR szKey[100] = {0x00, };
			TCHAR szValue[100] = {0x00, };
			TCHAR szFirstUpdate[100] = {0x00, };
			CString strIniFile = _T("");
			CString strVersionFile = _T("");

			// 2010.09.06 ghk@kci.co.kr
			// CDNUMBER KEY�� ���� ������ INI WRITE�����ʴ´�.
			CString strSection = _T("");
			CString strKey = _T("");
			CString strValue = _T("");

			for(int i=0; i<nDataCount; i++)
			{
				memset(szFileName, 0x00, sizeof(szFileName));
				memset(szSection, 0x00, sizeof(szSection));
				memset(szKey, 0x00, sizeof(szKey));
				memset(szValue, 0x00, sizeof(szValue));
				memset(szFirstUpdate, 0x00, sizeof(szFirstUpdate));

				nPosition += GetFirstToken(szFileName, (TCHAR*)&btData[nPosition++], RS);
				nPosition += GetFirstToken(szSection, (TCHAR*)&btData[nPosition++], RS);
				nPosition += GetFirstToken(szKey, (TCHAR*)&btData[nPosition++], RS);
				nPosition += GetFirstToken(szValue, (TCHAR*)&btData[nPosition++], GS);

				strIniFile.Format(_T("%s\\%s"), PATH_INI, szFileName);
				strIniFile.MakeLower();

				strVersionFile.Format(_T("%s\\%s"), PATH_INI, _T("version.ini"));

				strSection = szSection;

				strKey = szKey;
				strKey.TrimLeft();
				strKey.TrimRight();

				strValue = szValue;
				strValue.TrimLeft();
				strValue.TrimRight();
				
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("SECTION[%s] KEY[%s] VALUE[%s] FILE[%s]"), szSection, szKey, szValue, szFileName);

				// 2009-10-08 : CST������ ó�� �Է������� ���� �����ϴ� ��ġ ����
				//              [1] CASHINFO.ini ���Ͽ� CST1, CST2, CST3 ���� ó�� INSERT�ϴ��� ���� �Ǵ�
				//                  (FIRSTUPDATE �� T�̸� ó������, �̿ܿ��� ó���ƴ�)
				//              FIRSTUPDATE�� T�ΰ��, sSection, sKey, sValue, strFilePath ��ġ�� ����
				//==========================================================================
				if(!memcmp(szKey, "CST1", 4) || !memcmp(szKey, "CST2", 4) || !memcmp(szKey, "CST3", 4))
				{
					GetPrivateProfileString("NRMS", "FIRSTUPDATE", "F", szFirstUpdate, sizeof(szFirstUpdate), strVersionFile);
					
					if(!memcmp(szFirstUpdate, "T", 1))
					{
						// FIRSTUPDATE�� T�ΰ��, NRMS SERVER�� ���� ���ŵ� VALUE �����ϰ�
						// DEFAULT�� "1" "1" "1"�� ����
						bResult = WritePrivateProfileString(szSection, szKey, "1", strIniFile);
					}
					else
					{
						bResult = WritePrivateProfileString(szSection, szKey, szValue, strIniFile);
					}
				}
				else
				{
					// 2010.09.06 ghk@kci.co.kr
					// info.ini ������ [LOCAL] CDNUBER ���� �����̸� ó������ �ʴ´�.
					if(strIniFile.Find(_T("info.ini")) != -1 &&
						strSection.CompareNoCase(_T("LOCAL")) == 0 &&
						strKey.CompareNoCase(_T("CDNUMBER")) == 0 &&
						strValue.IsEmpty())
					{
						CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Error] CDNUMBER���� �������� SKIP"));
						continue;
					}

					bResult = WritePrivateProfileString(szSection, szKey, szValue, strIniFile);				
				}
				
				if(bResult == FALSE)
				{
					CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Error] INI File Write Error"));
					SendWriteErrorPacket();

					strMessage.Format(_T("[NRMS] DATA WRITE ERROR ����"));
					SendTextToParent(strMessage);
					SendMessageToParent(UM_START_PROGRAM, _ttoi(WRITE_ERROR), MAX_PROGRESS_STEP);
					return;
				}
				
				//==========================================================================			
				// [1] OWNER ���� : CD_INFO Table�� OWNER(BBxx) Flag ���� (Default : BK91)
				//     : Info.ini - [LOCAL] - OWNER
				//==========================================================================
				if(!memcmp(szKey, "OWNER", 5))
				{
					// KEY�� OWNER�� ���...
					// VALUE�� ���� ȭ�� ��� ���ޱ�� �̹��� ��� ����
					SaveAllianceImage(szValue);
				}
			}

			// 2010.08.05 ghk@kci.co.kr
			// INFO.INI ���� ������ real / test mode üũ�Ͽ�
			// ibp_config.ini ������ [ENCRYPT] ������ is_local Ű���� �����Ѵ�.
			//2011.01.02 jeongmin@kci.co.kr
			//�ѳ�Ʈ���� ��ȣȭ�� �ȵȴٰ� ������ ��� ���Ƴ���

			//ChanageEncryptMode();

			// DELETE NtComportDeep .. ������ ���� �����ÿ���...
			DeleteDeepFile();
			
			// Delete Bank Secret Key...(hnd.dat, KJ.dat...)
			DeleteSecretKey();
			//////////////////////////////////////////////////////////////////


			/*============================================================================
			 ������ ��� �߻� �� ����ȭ�� ������ ��µǴ� ������ ����
			 [1] ������ ����ȭ�鿡 ����ڰ� ������ ���� ���� ����
			 [2] ������ ���� ���α׷� �޴��� NRMS ���α׷� ���� ���翩�� Ȯ�� ����
			 [3] ������ ����ȭ�� ������ Hidden����	 
			============================================================================*/
			// ���� NewNRMS
			//CShortcut::RemoveDesktopShortcut(ATOM_OM_FILE);	// ������ ����ȭ�鿡 ����ڰ� ������ ���� ���� ����
			//CShortcut::RemoveStartupShortcut(ATOM_OM_FILE);	// ������ ���� ���α׷� �޴��� NRMS ���α׷� ���� ���翩�� Ȯ�� ����

			SendMessageToParent(UM_CHECK_HARDWARE, 0, 0);
		}
		else if(memcmp(btCommand, RES_NRMS_ERROR, 2) == 0)
		{
			// �������� Ÿ��: "60"
			TCHAR szError[5] = {0x00, };
			CString strMessage = _T("");
			
			memset(szError, 0x00, sizeof(szError));
			
			if(dwPacketLength >= 11)
			{
				memcpy(szError, &btPacket[8], 3);
			}
			
			if(lstrcmp(szError, "600") == 0)
			{
				strMessage = _T("[ERROR] �������(600:Format Error) ����");
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("Message Format Error Receive(600) - StartProgram"));
				
				// ���� �޽��� ��� �ʿ�
				WriteStatus(szError, strMessage);
				SendMessageToParent(UM_START_PROGRAM, 600, MAX_PROGRESS_STEP);
				return;
			}
			else if(lstrcmp(szError, "800") == 0)
			{
				strMessage = _T("[ERROR] �������(800:�̵��) ����");
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("DB Record Empty Error Receive(800) - StartProgram"));

				// ���� �޽��� ��� �ʿ�
				WriteStatus(szError, strMessage);
				SendMessageToParent(UM_START_PROGRAM, 800, MAX_PROGRESS_STEP);
				return;
			}
			else if(lstrcmp(szError, "801") == 0)
			{
				// IP_CD Table�� ImsiChulsu�� T�� �����̸� Error Code 801����/////
				strMessage = _T("[ERROR] �������(801:�ӽ�ö��) ����");
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("DB ImsiChulsu = T, Error Receive(801) - StartProgram"));

				// ���� �޽��� ��� �ʿ�
				WriteStatus(szError, strMessage);
				SendMessageToParent(UM_START_PROGRAM, 801, MAX_PROGRESS_STEP);
				return;
			}
			else if(lstrcmp(szError, "802") == 0)
			{
				// IP_CD Table�� ImsiChulsu�� T�� �����̸� Error Code 801����/////
				strMessage = _T("[ERROR] �������(802:�ý����۾�) ����");
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("DB ImsiChulsu = T, Error Receive(802) - StartProgram"));
				
				// ���� �޽��� ��� �ʿ�
				WriteStatus(szError, strMessage);
				SendMessageToParent(UM_START_PROGRAM, 802, MAX_PROGRESS_STEP);
				return;
			}
			else
			{
				strMessage.Format(_T("[ERROR] ��Ÿ���(%s) ����"), szError);
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("NRMS ETC Error Receive(%s) - StartProgram"), szError);

				// ���� �޽��� ��� �ʿ�
				WriteStatus(szError, strMessage);
				SendMessageToParent(UM_START_PROGRAM, _ttoi(szError), MAX_PROGRESS_STEP);
				return;
			}
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::ProcessPacket] �������� �ڵ�[%s] ����"), btCommand);

			strMessage.Format(_T("[ERROR] �������� �ڵ�[%s] ����"), btCommand);
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("NRMS %s Receive(%s) - StartProgram"), strMessage);
			
			// ���� �޽��� ��� �ʿ�
			WriteStatus(_T("500"), strMessage);
			SendMessageToParent(UM_START_PROGRAM, 500, MAX_PROGRESS_STEP);
		}
	}
}


int CNrmsClientSession::GetFirstToken(TCHAR *pszToken, TCHAR *pszMsg, int nDelimeter)
{
	int nLength = strlen(pszMsg);

	for(int i=0; i < nLength ; i++)
	{
		if(pszMsg[i] == nDelimeter)
			return i; // length of token
		else
			pszToken[i] = pszMsg[i];
	}

	// GetToken failure
	return 0;
}

void CNrmsClientSession::SaveAllianceImage(CString strAllianceCode)
{
	BOOL		bResult = FALSE;
	CString		strAdvertisementadFile = _T("");
	CString		strOwnerFile = "C:\\cd2k\\page\\cd2k\\blank.html";
	
	
	if(strAllianceCode.Compare(_T("BK91")) == 0 || strAllianceCode.Compare(_T("    ")) == 0) 
	{	
		// OWNER 4�ڸ��� "BK91" �Ǵ� "    "�̸� �ѳ�Ʈ
		bResult = CopyFile("C:\\cd2k\\ad_txt\\BK91.html", strOwnerFile, FALSE);
		if(bResult == FALSE)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Failure] (c:\\cd2k\\ad_txt\\BK91.html) => (%s)"), strOwnerFile);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Success] (c:\\cd2k\\ad_txt\\BK91.html) => (%s)"), strOwnerFile);
		}
	}	
	else
	{		
		strAdvertisementadFile.Format("c:\\cd2k\\ad_txt\\%s.html", strAllianceCode);
		
		bResult = CopyFile(strAdvertisementadFile, strOwnerFile, FALSE);
		if(bResult == FALSE)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Failure] (%s) => (%s)"), strAdvertisementadFile, strOwnerFile);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Success] (%s) => (%s)"), strAdvertisementadFile, strOwnerFile);
		}
	}
}

void CNrmsClientSession::DeleteDeepFile()
{
	TCHAR szDeleteFile[MAX_PATH] = {0x00, };
	TCHAR szValue[32] = {0x00, };
	CString strServerType = _T("");

	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString("NRMS", "type", "", szValue, sizeof(szValue), ATOM_INFO_INI);
	strServerType = szValue;
	strServerType.MakeUpper();
	
	// REAL�̸�  ������ ����..
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("NRMS SERVER TYPE:%s"), strServerType);
	if(strServerType.Compare(_T("REAL")) == 0)
	{
		memset(szDeleteFile, 0x00, sizeof(szDeleteFile));
		strcpy(szDeleteFile, "c:\\documents and settings\\administrator\\���� ȭ��\\NtComportDeep.exe�� �ٷ� ����.lnk");
		
		if(PathFileExists(szDeleteFile))
		{
			if(!DeleteFile(szDeleteFile))
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Failure] ȭ�ϻ��� ����(%s)"), szDeleteFile);
			}
			else
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Success] ȭ�ϻ��� (%s)"), szDeleteFile);
			}
		}
		
		memset(szDeleteFile, 0x00, sizeof(szDeleteFile));
		strcpy(szDeleteFile, _T("c:\\cd2k\\NtComportDeep.exe"));
		
		if(PathFileExists(szDeleteFile))
		{
			if(!DeleteFile(szDeleteFile))
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Failure] ȭ�ϻ��� ����(%s)"), szDeleteFile);
			}
			else
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Success] ȭ�ϻ��� (%s)"), szDeleteFile);
			}
		}
	}
}

/*************************************************************************************
// 2003-11-26 : �������� ��ȣȭ Ű�� �����Ѵ�
// - BDMType.ini [SECRET_KEY] REMOVE=, FILE_PATH=�� �����Ͽ� ���� ���� ����
// 2003-12-30 : Delete File Count Loopó�� (USB Update�ÿ��� ����)
// - PATH_COUNT= �߰�
*************************************************************************************/
void CNrmsClientSession::DeleteSecretKey()
{
	TCHAR	szValue[MAX_PATH] = {0x00, };
	int		nPathCount = 0;
	int		nPathInfo = 0;
	CString strPath = _T("");
	
	memset(szValue, 0x00, sizeof(szValue));
	
	GetPrivateProfileString("SECRET_KEY", "REMOVE", "", szValue, sizeof(szValue), ATOM_BRM_INI);
	
	if(szValue[0] == 'T')	// Key Remove ����...
	{	
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] Get Secret_Key Remove Flag : %s"), szValue);
		
		nPathCount = GetPrivateProfileInt("SECRET_KEY", "PATH_COUNT", 0, ATOM_BRM_INI);
		nPathInfo = 1;
		
		while (nPathCount > 0)	// ���۽� iPathCount = 2
		{
			strPath.Format(_T("FILE_PATH%d"), nPathInfo);	// FILE_Path1, FILE_Path2...
			
			memset(szValue, 0x00, sizeof(szValue));
			GetPrivateProfileString("SECRET_KEY", strPath, "", szValue, sizeof(szValue), ATOM_BRM_INI);		
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] Get Delete FileName:%s"), szValue);
			
			if(strlen(szValue) != 0)
			{
				if(PathFileExists(szValue))
				{
					if(!DeleteFile(szValue))
					{
						CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] [Failure] ȭ�ϻ��� ����(%s)"), szValue);
					}
					else
					{
						CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] [Success] ȭ�ϻ��� (%s)"), szValue);
					}
				}
			}
			else
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] [Error] INI File_Path Value Empty"));
			}
			
			nPathCount--;	// 2���� 1����...
			nPathInfo++;	// 1���� 2����...
		}
		
		// Secret_Key Remove Flag �ʱ�ȭ...!
		WritePrivateProfileString("SECRET_KEY", "REMOVE", "F", ATOM_BRM_INI);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CNrmsClientSession::DeleteSecretKey] Set [SECRET_KEY] [REMOVE] FLAG:F"));
	}
}

void CNrmsClientSession::SetReceiveTimeOut(DWORD dwTimeOut)
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::SetTimer(m_hParentWnd, TIMER_NRMS_RECEIVE_TIMEOUT, dwTimeOut, NULL);
	}
}

void CNrmsClientSession::ClearReceiveTimeOut()
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::KillTimer(m_hParentWnd, TIMER_NRMS_RECEIVE_TIMEOUT);
	}
}

void CNrmsClientSession::WriteStatus(CString strCode, CString strText)
{
	WritePrivateProfileString(_T("STATUS"), _T("CODE"), strCode, ATOM_NRMS_INI);
	WritePrivateProfileString(_T("STATUS"), _T("TEXT"), strText, ATOM_NRMS_INI);
}

// 2010.08.05 ghk@kci.co.kr
// info.ini ������ [NRMS] ������ TYPE ���� real�� ���
// ibp_confi.ini ������ [ENCRYPT] ������ IS_LOCAL ���� FALSE�� �����Ͽ�
// ��ȣȭ�ϵ��� �����Ѵ�.
void CNrmsClientSession::ChanageEncryptMode()
{
	CString strMode = _T("");
	TCHAR szValue[MAX_PATH] = {0x00,};

	GetPrivateProfileString("NRMS", "TYPE", "real", szValue, sizeof(szValue), ATOM_INFO_INI);
	strMode = szValue;
	strMode.TrimLeft();
	strMode.TrimRight();

	if(strMode.CompareNoCase(_T("real")) == 0)
	{
		WritePrivateProfileString("ENCRYPT", "IS_LOCAL", "FALSE", ATOM_IBP_INI);
	}
}
