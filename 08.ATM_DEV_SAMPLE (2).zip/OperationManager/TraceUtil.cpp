// TraceUtil.cpp : implementation file
//

#include "stdafx.h"
#include "Define.h"
#include "TraceUtil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define __SPEED_MODE
#define __DAILY_LOGFILE

CTraceUtil	theTrace;



/////////////////////////////////////////////////////////////////////////////
// CTraceUtil

CTraceUtil::CTraceUtil()
{
	m_nBackupFileCount = 0;
	m_strFileDate = _T("00000000");
	m_strFilePath.Format(_T("%s\\aom.txt"), PATH_LOG);
	m_strBackupPath.Format(_T("%s\\aom.bak"), PATH_LOG);
	GenerateFileName();
}

CTraceUtil::~CTraceUtil()
{
}

void CTraceUtil::TraceHex(LPBYTE pData, int nLength)
{
	LPBYTE pStart = pData;
	TCHAR szAscii[256] = {0x00,};
	TCHAR szLine[256] = {0x00,};
	TCHAR szHex[256] = {0x00,};
	TCHAR szSpace[256] = {0x00, };
	
	try
	{
		int nLine = 0;
		int nRemain = nLength % 16;
		int nCompleteLine = (int) (nLength / 16);
		int nIndex = 0;
		
		memset(szLine, 0x00, sizeof(szLine));
		wsprintf(szLine, "LENGTH:%d REMAIN:%d", nLength, nRemain);
		TraceLog(szLine);

		TraceLog(_T("=========================================================================="));
		TraceLog(_T("POS  01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16"));
		TraceLog(_T("--------------------------------------------------------------------------"));
		
		for(nIndex=0; nIndex<nLength; nIndex+=16)
		{
			if( nIndex != 0 && ((nIndex) % 16) == 0 )
			{
				memset(szHex, 0x00, sizeof(szHex));

				for(int j=0; j<16; j++)
				{
					wsprintf((szHex + (j*3)), "%02X ", *(pData + (nLine * 16) + j));
				}

				memset(szAscii, 0x00, sizeof(szAscii));
				memcpy(szAscii, pStart, 16);
				
				pStart += 16;
				wsprintf(szLine, _T("[%03d] %s[%s]"), ++nLine, szHex, szAscii);
				TraceLog(szLine);
			}
		}

		if(nRemain > 0 && nRemain < 16)
		{
			int nSpaceCount = (16 - nRemain) * 3;
			memset(szSpace, 0x00, sizeof(szSpace));
			memset(szSpace, 0x20, nSpaceCount);

			memset(szAscii, 0x00, sizeof(szAscii));
			memcpy(szAscii, pData + (nCompleteLine * 16), nRemain);
			memset(szAscii + nRemain, 0x20, 16 - nRemain);

			for(int j=0; j<nRemain; j++)
			{
				wsprintf((szHex + (j*3)), "%02X ", *(pData + (nCompleteLine * 16) + j));
			}

			memset(szLine, 0x00, sizeof(szLine));
			wsprintf(szLine, "[%03d] %s%s[%s]", ++nLine, szHex, szSpace, szAscii);
			TraceLog(szLine);
		}

		TraceLog(_T("=========================================================================="));
	}
	catch(...)
	{
	}
}


void CTraceUtil::TraceLog(char *fmt, ... )
{
	try
	{
		TCHAR szDebugMsg[4096] = {0x00,};
		TCHAR *ptr = szDebugMsg;

		memset(szDebugMsg, 0x00, sizeof(szDebugMsg));
		
		va_list ap;
		va_start(ap, fmt);
		vsprintf(ptr, fmt, ap);  // %f ���� ���� �ȵ� 
		va_end(ap);

		SYSTEMTIME t;
		::GetLocalTime(&t);

		GenerateFileName();

#ifndef	__SPEED_MODE
		LogFileBackUp();
#endif
		
		CString trc;
		trc.Format("[%02d/%02d/%02d %02d:%02d:%02d.%03d] ", t.wMonth, t.wDay, t.wYear % 100, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
		trc += GetLoggingText(szDebugMsg, lstrlen(szDebugMsg));
		trc += "\r\n";

		___trace(trc.GetBuffer(0));
	}
	catch(...)
	{
	}
}

void CTraceUtil::___trace(LPCTSTR lptext)
{
	try
	{
		FILE *fp = NULL;

		if((fp = fopen(m_strFilePath, "a+")) == NULL) return;

		fwrite(lptext, sizeof(char), lstrlen(lptext), fp);
		fclose(fp);
	}
	catch(...)
	{

	}
}


void CTraceUtil::LogFileBackUp(void)
{
	try
	{
		//TCHAR szBackupFile[MAX_PATH] = {0x00,};
		CFileStatus rStatus;

		memset(&rStatus, 0x00, sizeof(rStatus));
		CFile::GetStatus(m_strFilePath, rStatus);
		if(rStatus.m_size > LOGFILE_MAXSIZE)	// 1MB �̸�   
		{
			m_nBackupFileCount++;
			::rename(m_strFilePath, m_strBackupPath);
		}
	}
	catch(...)
	{

	}
}

void CTraceUtil::GenerateFileName()
{
#ifdef __DAILY_LOGFILE
	CString strDate = _T("");
	SYSTEMTIME t;
	::GetLocalTime(&t);

	strDate.Format(_T("%04d%02d%02d"), t.wYear, t.wMonth, t.wDay);
	if(m_strFileDate.Compare(strDate) != 0)
	{
		// ��¥�� �ٸ���
		m_strFileDate = strDate;
		m_nBackupFileCount = CountExistFile(strDate);
		m_strFilePath.Format(_T("%s\\%saom.txt"), PATH_LOG, m_strFileDate);
		m_strBackupPath.Format(_T("%s\\%saom%02d.txt"), PATH_LOG, m_strFileDate, m_nBackupFileCount);
	}

#endif
}

int CTraceUtil::CountExistFile(LPCTSTR lpszDate)
{
	int nFileCount = 0;
	CString strFind = _T("");

	strFind.Format("%s\\%saom*.txt", PATH_LOG, lpszDate);
	CFileFind ff;

	BOOL bExist = ff.FindFile(strFind);
	while(bExist)
	{
		bExist = ff.FindNextFile();

		if(ff.IsDots() || ff.IsDirectory())
			continue;

		nFileCount++;
	}
	ff.Close();

	return nFileCount;
}

CString CTraceUtil::GetLoggingText(LPCTSTR szText, UINT nLength)
{
	BOOL bEncrypt = TRUE;
	CString strLog = szText;
	TCHAR szValue[24] = {0x00,};
	TCHAR szKey[128] = _T("");

	if(nLength <= 0)
		return strLog;
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString(_T("ENCRYPT"), _T("IS_LOCAL"), _T("FALSE"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(lstrcmp(szValue, _T("TRUE")) == 0 || lstrcmp(szValue, _T("true")) == 0)
		bEncrypt = FALSE;


	if(bEncrypt && EncryptAES != NULL)
	{
		int nBufferLength = nLength * 2 + 256;
		TCHAR *pPlain = new TCHAR[nLength + 2];
		TCHAR *pEncrypted = new TCHAR[nBufferLength];

		memset(pPlain, 0x00, nLength + 2);
		memset(pEncrypted, 0x00, nBufferLength);
		lstrcpy(pPlain, szText);

		memset(szKey, 0x00, sizeof(szKey));
		strcpy(szKey, m_strFileDate);

		long lResult = EncryptAES(pPlain, pEncrypted, nBufferLength, szKey);
		if(lResult)
		{
			strLog = CString(pEncrypted, lResult);
		}

		delete pPlain; pPlain = NULL;
		delete pEncrypted;  pEncrypted = NULL;
	}

	return strLog;
}
