#pragma once

class CCriticalSection
{
public:
	CCriticalSection(void)
	{
		InitializeCriticalSection(&m_cs);
	}

	~CCriticalSection(void)
	{
		DeleteCriticalSection(&m_cs);
	}

public:
	inline void Enter(void)
	{
		EnterCriticalSection(&m_cs);
	}

	inline void Leave(void)
	{
		LeaveCriticalSection(&m_cs);
	}

private:
	CRITICAL_SECTION	m_cs;
};