// stdafx.cpp : source file that includes just the standard includes
//	OperationManager.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#pragma warning(disable: 4098)

#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "mswsock.lib")
#pragma comment(lib, "Iphlpapi.lib")
#pragma comment(lib, "lib/aes.lib")


// �α����� ��ȣȭ
long (__cdecl *EncryptAES)(char* in, char* out, long outLen, char* key);

/*
#pragma comment(lib, "lib/zlib.lib")
#pragma comment(lib, "lib/zipfunc.lib")
*/

Bitmap* PngFromResource(IN HINSTANCE hInst, IN const LPTSTR pName, IN const LPTSTR pType )
{
	Bitmap* bitmap = NULL;
	HRSRC hResource = ::FindResource(hInst, pName, pType);
	if (!hResource)	return NULL;
	
	DWORD imageSize = ::SizeofResource(hInst, hResource);
	if (!imageSize) return NULL;
	
	const void* pResourceData = ::LockResource(::LoadResource(hInst, hResource));
	if (!pResourceData)	return NULL;
	
	HGLOBAL hBuffer  = ::GlobalAlloc(GMEM_MOVEABLE, imageSize);
	if (hBuffer)
	{
		void* pBuffer = ::GlobalLock(hBuffer);
		if (pBuffer)
		{
			CopyMemory(pBuffer, pResourceData, imageSize);
			
			IStream* pStream = NULL;
			if (::CreateStreamOnHGlobal(hBuffer, FALSE, &pStream) == S_OK)
			{
				bitmap = Bitmap::FromStream(pStream);
				pStream->Release();
				if (bitmap)
				{ 
					if (bitmap->GetLastStatus() != Ok)
					{
						delete bitmap;
						bitmap = NULL;
					}
				}
			}
			::GlobalUnlock(hBuffer);
		}
		::GlobalFree(hBuffer);			
	}
	
	return bitmap;
}

HBITMAP Create32BitBitmap( HDC hDCSource, int cx, int cy )
{
	// Create 32-bit bitmap
	BITMAPINFO bi = { 0 };
	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth = cx;
	bi.bmiHeader.biHeight = cy;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 32;
	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biSizeImage = 0;
	bi.bmiHeader.biXPelsPerMeter = 0;
	bi.bmiHeader.biYPelsPerMeter = 0;
	bi.bmiHeader.biClrUsed = 0;
	bi.bmiHeader.biClrImportant = 0;
	return ::CreateDIBSection( hDCSource, &bi, DIB_RGB_COLORS, NULL, NULL, 0);
}