// Processor.h: interface for the CProcessor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSOR_H__88F69ED1_C56C_44EC_95E5_E7C0126580E5__INCLUDED_)
#define AFX_PROCESSOR_H__88F69ED1_C56C_44EC_95E5_E7C0126580E5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CProcess  
{
public:
	CProcess();
	virtual ~CProcess();

public:
	static int Execute(CString strProcessPath,
					   CString strCommandParam,
					   BOOL bWaitUntilExit = FALSE,
					   DWORD *pExitCode = NULL,
					   WORD wShowWindow = SW_SHOW);

	static BOOL CreateProcess(DWORD dwFlag,
							  WORD dwShow,
							  LPCTSTR szCommand,
							  LPCTSTR pDir,
							  DWORD dwTimeOut,
							  BOOL bWait = FALSE);

	static BOOL CProcess::CreateProcess(DWORD dwFlag,
										WORD wShow,
										LPCTSTR szCommand,
										LPCTSTR szDirectory,
										BOOL bWait,
										DWORD dwTimeOut,
										DWORD *pExitCode);

	static BOOL KillProcess(CString strFileName, BOOL bAll = TRUE);
};

#endif // !defined(AFX_PROCESSOR_H__88F69ED1_C56C_44EC_95E5_E7C0126580E5__INCLUDED_)
