// Compression.cpp: implementation of the CCompression class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OperationManager.h"
#include "Compression.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCompression::CCompression()
{

}

CCompression::~CCompression()
{

}
