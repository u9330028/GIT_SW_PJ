#ifndef __DEFINE_H__
#define __DEFINE_H__

#pragma once
// TEST MODE
////////////////////////////////////////////////////////////////////////////
//#define __TEST_ONLY__


// ����� �޽��� ����
////////////////////////////////////////////////////////////////////////////
#define UM_NRMS_CONNECTED					WM_USER + 100
#define UM_NRMS_DISCONNECTED				WM_USER + 101
#define UM_NRMS_RECEIVE						WM_USER + 102

#define UM_CONTROLSERVER_CONNECTED			WM_USER + 105
#define UM_CONTROLSERVER_DISCONNECTED		WM_USER + 106
#define UM_CONTROLSERVER_RECEIVE			WM_USER + 107

#define UM_START_PROGRAM					WM_USER + 110
#define UM_CHECK_HARDWARE					WM_USER + 120

#define DISPLAY_STATUS						100




// ���丮 �н� ����
////////////////////////////////////////////////////////////////////////////
#define PATH_ROOT							_T("c:\\atm_main")
#define PATH_BIN							PATH_ROOT _T("\\bin")
#define PATH_INI							PATH_ROOT _T("\\ini")
#define PATH_LOG							PATH_ROOT _T("\\log\\aom")
#define PATH_RESOURCE						PATH_ROOT _T("\\media")
#define PATH_IMAGE							PATH_RESOURCE _T("\\image")
#define PATH_DOWN							PATH_ROOT _T("\\download")
#define PATH_FIRMWARE						PATH_ROOT _T("\\firmware")
#define PATH_UPDATE							PATH_DOWN _T("\\update")
#define PATH_BACKUP							PATH_DOWN _T("\\backup")
#define PATH_PRECOPY						PATH_UPDATE _T("\\download\\filecopy")




// INI ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_NRMS_INI						PATH_INI _T("\\nrms.ini")
#define ATOM_VERSION_INI					PATH_INI _T("\\version.ini")
#define ATOM_INFO_INI						PATH_INI _T("\\info.ini")
#define ATOM_CONFIG_INI						PATH_INI _T("\\config.ini")
#define ATOM_FIRMWARE_INI					PATH_INI _T("\\firmware.ini")
#define ATOM_KTX_INI						PATH_INI _T("\\ktx.ini")
#define ATOM_BRM_INI						PATH_INI _T("\\brmtype.ini")
#define ATOM_IBP_INI						PATH_INI _T("\\ibp_config.ini")
#define ATOM_IIM_INI						PATH_INI _T("\\iim_config.ini")
#define ATOM_COMMON_INI						PATH_INI _T("\\commonbatch.ini")
#define UPDATE_VERSION_INI					PATH_UPDATE _T("\\ini\\version.ini")
#define	COPYFILE_INI						PATH_PRECOPY _T("\\filecopy.ini")


// EXE ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_OM_FILE						_T("aom.exe")
#define ATOM_RM_FILE						_T("arm.exe")
#define ATOM_FM_FILE						_T("afm.exe")
#define ATOM_IIM_FILE						_T("iim.exe")
#define ATOM_IBP_FILE						_T("IntegratedBizProcessor.exe")
#define ATOM_IPF_FILE						_T("ipf.exe")
#define ATOM_ADP_FILE						_T("AdvertisPlayer.exe")
#define ATOM_BRMMGR_FILE					_T("LOGMGR.exe") 
#define ATOM_OM_EXE							PATH_BIN _T("\\") ATOM_OM_FILE
#define ATOM_RM_EXE							PATH_BIN _T("\\") ATOM_RM_FILE
#define ATOM_IPF_EXE						PATH_BIN _T("\\") ATOM_IPF_FILE
#define ATOM_BRMMGR_EXE						_T("c:\\atm\\exe\\") ATOM_BRMMGR_FILE


// DLL ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_ENC_LIBRARY					PATH_BIN _T("\\aes.dll")



// RESOURCE ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_DESKTOP_BACKGROUND_IMAGE		PATH_IMAGE _T("\\osbackground.bmp")		// DESKTOP BACKGROUND IMAGE



// LOG ����
////////////////////////////////////////////////////////////////////////////
#define LOGFILE								_T("aom.txt")
#define LOGBACK								_T("aom.bak")
#define ATOM_OM_LOG							PATH_LOG _T("\\") LOGFILE
#define LOGFILE_MAXSIZE						1024000



// UPDATE ���� ����
////////////////////////////////////////////////////////////////////////////
#define UPDATE_FILE_PREFIX					_T("atm_main_update_")
#define MASTER_FILE_PREFIX					_T("atm_main_master_")

#define UPDATE_FILE_PATH					PATH_UPDATE _T("\\atom.zip")
#define UPDATE_FILE_NAME					PATH_DOWN _T("\\atm_main_update_*.zip")		// ATM_MAIN_UPDATE_Vxxxxxx.zip
#define MASTER_FILE_NAME					PATH_DOWN _T("\\atm_main_master_*.zip")		// ATM_MAIN_MASTER_Vxxxxxx.zip
#define UPDATE_FILENAME_LENGTH				23//19



// �ϵ���� ���� ����
////////////////////////////////////////////////////////////////////////////
#define MIN_MEMORY_SIZE						110	// MB
#define MIN_HARDDISK_SIZE					15	// GB


// TIMER ID ����
////////////////////////////////////////////////////////////////////////////
#define TIMER_ATOM_OM_START					1
#define TIMER_NRMS_RECONNECT				2
#define TIMER_NRMS_RECEIVE_TIMEOUT			3
#define TIMER_KTX_RECONNECT					4
#define TIMER_CONTROLSERVER_RECONNECT		5

#define ELAPSE_ATOM_OM_START				1000
#define ELAPSE_KTX_RECONNECT				5000
#define ELAPSE_NRMS_RECONNECT				5000
#define ELAPSE_NRMS_RECEIVE_TIMEOUT			30000

#define ELAPSE_CONTROLSERVER_RECONNECT		5000
#define TIMER_CONTROLSERVER_RECEIVE_TIMEOUT	30000

#define	MAX_NRMS_CONNECT_RETRY				10
#define MAX_CONTROLSERVER_CONNECT_RETRY		3


#define TIMEOUT_TANDEM_CONNECT				10000
#define TIMEOUT_FIRMWARE_DOWNLOAD			300000	// 5��


// ZIP FILE BUFFER ����
////////////////////////////////////////////////////////////////////////////
#define BUFFER_SIZE							1024


// PROGRSS ����
////////////////////////////////////////////////////////////////////////////
#define MAX_PROGRESS_STEP					13


// NETWORK ����
////////////////////////////////////////////////////////////////////////////
#define MAX_QUEUE_LENGTH					50
#define MAX_BUFFER_LENGTH					10240


#define IP_NRMS_SERVER						_T("172.16.1.27")
#define IP_CONTROL_SERVER					_T("172.16.1.90")
#define PORT_NRMS_SERVER					7200
#define PORT_CONTROL_SERVER					10002
#define PORT_KTX_SERVER						9510

#define	NRMS_STATE_REQUEST					0
#define	NRMS_STATE_FORMAT_ERROR				1
#define	NRMS_STATE_WRITE_ERROR				2


#define REQ_FILE_INFO						"53"	
#define RES_ERROR							"50"
#define	FORMAT_ERROR						"003"
#define	WRITE_ERROR							"022"

#define	RES_NRMS_INFO						"63"
#define	RES_NRMS_ERROR						"60"

#define STX									0x02
#define	FS									0x1c
#define	ETX									0x03
#define	RS									0x1e
#define	GS									0x1d



// AP POLL ����
////////////////////////////////////////////////////////////////////////////
#define TITLE_IBP							_T("PTComm")		//
#define TITLE_IIM							_T("MWComm")
#define TITLE_IPF							_T("MainWindow")
#define TITLE_ADP							_T("AdvertisPlayer")	//_T("ManagerTP")
#define TITLE_ARM							_T("ATOM Reboot Manager")
#define TITLE_AOM							_T("ATOM Operation Manager")

#define ARM_COMMAND							26		// ���ȭ�� ǥ�ÿ�
#define IPF_COMMAND							27		// IPF�� ȭ�� ��û��
#define IIM_COMMAND							28		// OSREBOOT, RESTART ���� Ŀ�ǵ�
#define IBP_COMMAND							28		// ��ֺ��� ���� Ŀ�ǵ�
#define POLL_COMMAND						29
#define POLL_RESPONSE						30

#define IIM_COMMAND_RESPONSE				9		// OSREBOOT, RESTART ���� Ŀ�ǵ忡 ���� ����

#define POLL_IIM							31
#define POLL_IPF							32
#define POLL_IBP							33
#define POLL_ADP							34


#define POLL_IIM_RESPONSE					41
#define POLL_IPF_RESPONSE					42
#define POLL_IBP_RESPONSE					43
#define POLL_ADP_RESPONSE					44

#define ERR_IIM_DOWN						_T("6IIMERR")
#define ERR_IPF_DOWN						_T("6IPFERR")
#define ERR_IBP_DOWN						_T("6IBPERR")
#define ERR_ADP_DOWN						_T("6ADVERR")
#define ERR_IIM_RECOVER						_T("6IIMREP")
#define ERR_IPF_RECOVER						_T("6IPFREP")
#define ERR_IBP_RECOVER						_T("6IBPREP")
#define ERR_ADP_RECOVER						_T("6ADVREP")

// �߿��� �ٿ�ε� ���� �����ڵ�
////////////////////////////////////////////////////////////////////////////
#define ERR_FWDN_PROGRAM_NOTFOUND			-998
#define ERR_FWDN_BINARY_NOTFOUND			-999


// ���꺸�� �߿��� �ٿ�ε� ����ڵ�
#define ERR_SCB_FWDN_SUCCESS				0	//1
#define ERR_SCB_FWDN_PORT_OPEN_FAIL			1	//-2
#define ERR_SCB_FWDN_INVALID_ARGUMENT		2	//-3
#define ERR_SCB_FWDN_BOARD_ERROR			3	//-4
#define ERR_SCB_FWDN_TIMEOUT				4	//-5

#endif
