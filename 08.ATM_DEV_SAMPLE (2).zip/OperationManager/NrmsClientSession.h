#pragma once

#include "NrmsPacketSession.h"

class CNrmsClientSession : public CEventSelect
{
public:
	CNrmsClientSession(void);
	CNrmsClientSession(HWND hParentWnd);
	virtual ~CNrmsClientSession(void);

		void			ProcessPacket();

private:
	CNrmsPacketSession	mSession;
	CCircularQueue	mReadPacketQueue;

public:
	BOOL			Begin(LPSTR remoteAddress, USHORT remotePort);
	BOOL			End(void);

	BOOL			GetLocalIP(WCHAR* pIP);
	BOOL			GetLocalIP(TCHAR* pIP);
	USHORT			GetLocalPort(void);

	BOOL			ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength);
	BOOL			WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength);

public:
	void ChanageEncryptMode();
	void			ClearReceiveTimeOut();
	void			SaveAllianceImage(CString strAllianceCode);
	BOOL			SendWriteErrorPacket();
	BOOL			SendFormatErrorPacket();
	void			SetParentWnd(HWND hParentWnd);
	BOOL			SendRequestFileInfoPacket();

protected:
	void			OnIoRead(void);
	void			OnIoConnected(DWORD dwError);		// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoDisconnected(void);		// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoError(DWORD dwError);	// ���� �߻��� ȣ��Ǵ� �����Լ�

protected:
	void WriteStatus(CString strCode, CString strText);
	void			SetReceiveTimeOut(DWORD dwTimeOut);
	void			DeleteSecretKey();
	void			DeleteDeepFile();
//	void			ProcessPacket();
	void			SendTextToParent(LPCTSTR lpszText);
	void			SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam);
	int				GetFirstToken(TCHAR *pszToken, TCHAR *pszMsg, int nDelimeter);

private:
	HWND			m_hParentWnd;
	UINT			m_nCurrentState;
};
