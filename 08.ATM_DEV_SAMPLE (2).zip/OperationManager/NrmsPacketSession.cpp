#include "stdafx.h"
#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "NrmsPacketSession.h"

CNrmsPacketSession::CNrmsPacketSession(void)
{
	memset(mPacketBuffer, 0, sizeof(mPacketBuffer));

	mRemainLength			= 0;
	mCurrentPacketNumber	= 0;

	mLastReadPacketNumber	= 0;
}

CNrmsPacketSession::~CNrmsPacketSession(void)
{
}

BOOL CNrmsPacketSession::Begin(void)
{
	CThreadSync Sync;

	memset(mPacketBuffer, 0, sizeof(mPacketBuffer));

	mRemainLength			= 0;
	mCurrentPacketNumber	= 0;
	mLastReadPacketNumber	= 0;

	if (!WriteQueue.Begin())
		return FALSE;

	return CNetworkSession::Begin();
}

BOOL CNrmsPacketSession::End(void)
{
	CThreadSync Sync;

	if (!WriteQueue.End())
		return FALSE;

	return CNetworkSession::End();
}

BOOL CNrmsPacketSession::GetPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength)
{
	CThreadSync Sync;

	if (!packet)
		return FALSE;

	if (mRemainLength < sizeof(DWORD))
		return FALSE;

	TCHAR szPacketLength[10] = {0x00, };
	INT nPacketLength = 0;

	// STX(1) + LENGTH(4) + DATA(N) + ETX(1)
	memset(szPacketLength, 0x00, sizeof(szPacketLength));
	memcpy(szPacketLength, &mPacketBuffer[1], 4);
	nPacketLength = atoi(szPacketLength);

	if (nPacketLength > MAX_BUFFER_LENGTH || nPacketLength <= 0) // Invalid Packet
	{
		mRemainLength = 0;
		return FALSE;
	}

	if (nPacketLength <= mRemainLength)
	{
		packetLength = nPacketLength;
		memcpy(packet, mPacketBuffer, packetLength);

		if(mRemainLength - nPacketLength > 0)
		{
			memmove(mPacketBuffer, mPacketBuffer + nPacketLength, mRemainLength - nPacketLength);
		}

		mRemainLength -= nPacketLength;
		if (mRemainLength <= 0)
		{
			mRemainLength = 0;
			memset(mPacketBuffer, 0, sizeof(mPacketBuffer));
		}

		return TRUE;
	}

	return FALSE;
}


// ReadPacketForIocp�� FALSE�� �������� ���� while���� ������.
BOOL CNrmsPacketSession::ReadPacketForIocp(DWORD readLength)
{
	CThreadSync Sync;

	if (!CNetworkSession::ReadForIocp(mPacketBuffer + mRemainLength, readLength))
		return FALSE;

	mRemainLength	+= readLength;

	return TRUE;
}

// ReadPacketForEventSelect�� FALSE�� �������� ���� while���� ������.
BOOL CNrmsPacketSession::ReadPacketForEventSelect(void)
{
	CThreadSync Sync;

	DWORD ReadLength = 0;

	if (!CNetworkSession::ReadForEventSelect(mPacketBuffer + mRemainLength, ReadLength))
		return FALSE;

	mRemainLength	+= ReadLength;

	return TRUE;
}

// ReadPacketForIocp�� FALSE�� �������� ���� while���� ������.
BOOL CNrmsPacketSession::ReadFromPacketForIocp(LPSTR remoteAddress, USHORT &remotePort, DWORD readLength)
{
	CThreadSync Sync;

	if (!CNetworkSession::ReadFromForIocp(remoteAddress, remotePort, mPacketBuffer + mRemainLength, readLength))
		return FALSE;

	mRemainLength	+= readLength;

	return TRUE;
}

// ReadPacketForEventSelect�� FALSE�� �������� ���� while���� ������.
BOOL CNrmsPacketSession::ReadFromPacketForEventSelect(LPSTR remoteAddress, USHORT &remotePort)
{
	CThreadSync Sync;

	DWORD ReadLength = 0;

	if (!CNetworkSession::ReadFromForEventSelect(remoteAddress, remotePort, mPacketBuffer + mRemainLength, ReadLength))
		return FALSE;

	mRemainLength	+= ReadLength;

	return TRUE;
}

BOOL CNrmsPacketSession::WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;

	if (!lpCommand)
		return FALSE;

	// STX(1) + LENGTH(4) + COMMAND(2) + FS(1) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 9 + dwDataLength;

	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;

//	mCurrentPacketNumber++;

	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));

	sprintf(szLength, "%04d", dwPacketLength);

	btPacket[0] = STX;
	memcpy(&btPacket[1], szLength, 4);	// ��Ŷ���� 4�ڸ�
	memcpy(&btPacket[5], lpCommand, 2);	// ���ɾ� 2�ڸ�
	btPacket[7] = FS;
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[8], pData, dwDataLength);	// ���ɾ� 2�ڸ�
	}
	btPacket[8 + dwDataLength] = ETX;

	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = WriteQueue.Push(this, btPacket, dwPacketLength);

	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CNrmsPacketSession::WriteComplete(void)
{
	CThreadSync Sync;

	// WriteQueue���� Pop�� �� �ָ� �ȴ�.
	return WriteQueue.Pop();
}
