// StringTokenizer.h: interface for the CStringTokenizer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_STRINGTOKENIZER_H__5F9D5EE5_A585_47BE_8783_80611D57B835__INCLUDED_)
#define AFX_STRINGTOKENIZER_H__5F9D5EE5_A585_47BE_8783_80611D57B835__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CStringTokenizer  
{
public:
	CStringTokenizer();
	virtual ~CStringTokenizer();

public:
	static int GetTokens(CString src, CString del, CStringArray& ar);
};

#endif // !defined(AFX_STRINGTOKENIZER_H__5F9D5EE5_A585_47BE_8783_80611D57B835__INCLUDED_)
