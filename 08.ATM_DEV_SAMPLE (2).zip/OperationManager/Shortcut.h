// Shortcut.h: interface for the CShortcut class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHORTCUT_H__863A6D51_D559_46F2_B6C7_695C68F76F45__INCLUDED_)
#define AFX_SHORTCUT_H__863A6D51_D559_46F2_B6C7_695C68F76F45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CShortcut : public CObject  
{
public:
	CShortcut();
	virtual ~CShortcut();

public:
	static BOOL RemoveStartupShortcut(CString strTarget);
	static BOOL RemoveDesktopShortcut(CString strTarget);
	static BOOL RemoveShortcut(int nLocation, CString strTarget);
	static BOOL RemoveShortcut(CString strDirectory, CString strTarget);
	static BOOL GetLinkPath(LPCSTR lpszLink, LPSTR lpszPath);
	static BOOL CreateShortcut(LPCTSTR szPathObj, LPCTSTR szPathLink, LPCTSTR szShortcutTitle, LPCTSTR szDesc);
};

#endif // !defined(AFX_SHORTCUT_H__863A6D51_D559_46F2_B6C7_695C68F76F45__INCLUDED_)
