// ProgressDlg.cpp : implementation file
//

#include "stdafx.h"
#include "OperationManager.h"
#include "ProgressDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgressDlg dialog


CProgressDlg::CProgressDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgressDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProgressDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CProgressDlg::~CProgressDlg()
{

}

void CProgressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProgressDlg)
	DDX_Control(pDX, IDC_LIST_MESSAGE, m_wndMessage);
	DDX_Control(pDX, IDC_STATIC_PHONE, m_wndPhone);
	DDX_Control(pDX, IDC_STATIC_STATUS, m_wndStatus);
	DDX_Control(pDX, IDC_PROGRESS_STATUS, m_wndProgress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProgressDlg, CDialog)
	//{{AFX_MSG_MAP(CProgressDlg)
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgressDlg message handlers

BOOL CProgressDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CProgressDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_wndMessage.ResetContent();
}


BOOL CProgressDlg::SetRange(int nMin, int nMax)
{
	if(!IsWindow(m_wndProgress.GetSafeHwnd()))
		return FALSE;

	m_wndProgress.SetRange(nMin, nMax);
	return TRUE;
}

BOOL CProgressDlg::SetPos(int nPos)
{
	if(!IsWindow(m_wndProgress.GetSafeHwnd()))
		return FALSE;
	
	m_wndProgress.SetPos(nPos);
	return TRUE;
}

void CProgressDlg::SetStatusText(LPCTSTR lpszMessage)
{
	if(!IsWindow(m_wndStatus.GetSafeHwnd()))
		return;

	if(lpszMessage == NULL)
		return;

	m_wndStatus.SetWindowText(CString(lpszMessage));
}

void CProgressDlg::AddMessage(LPCTSTR lpszMessage)
{
	if(!IsWindow(m_wndMessage.GetSafeHwnd()))
		return;
	
	if(lpszMessage == NULL)
		return;

	m_wndMessage.InsertString(0, CString(lpszMessage));
}

void CProgressDlg::UpdateMessage(LPCTSTR lpszMessage)
{
	if(!IsWindow(m_wndMessage.GetSafeHwnd()))
		return;
	
	if(lpszMessage == NULL || m_wndMessage.GetCount() <= 0)
		return;
	
	m_wndMessage.DeleteString(0);
	m_wndMessage.InsertString(0, CString(lpszMessage));
}


BOOL CProgressDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
#ifndef __TEST_ONLY__
	if( pMsg->message==WM_KEYDOWN &&
		(pMsg->wParam==VK_ESCAPE || pMsg->wParam==VK_RETURN || pMsg->wParam == VK_F4))
	{
		return FALSE;
	}
#endif
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CProgressDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// TODO: Add your message handler code here and/or call default
	if(nID == SC_CLOSE)
		return;

	CDialog::OnSysCommand(nID, lParam);
}
