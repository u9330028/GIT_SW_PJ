#if !defined(AFX_PROGRESSDLG_H__3580A751_A31F_4AAA_AA48_F17C9535EB92__INCLUDED_)
#define AFX_PROGRESSDLG_H__3580A751_A31F_4AAA_AA48_F17C9535EB92__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgressDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProgressDlg dialog

class CProgressDlg : public CDialog
{
// Construction
public:
	CProgressDlg(CWnd* pParent = NULL);   // standard constructor
	~CProgressDlg();

// Dialog Data
	//{{AFX_DATA(CProgressDlg)
	enum { IDD = IDD_DIALOG_PROGRESS };
	CListBox		m_wndMessage;
	CStatic			m_wndPhone;
	CStatic			m_wndStatus;
	CProgressCtrl	m_wndProgress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgressDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


public:
	void AddMessage(LPCTSTR lpszMessage);
	void UpdateMessage(LPCTSTR lpszMessage);
	void SetStatusText(LPCTSTR lpszMessage);
	BOOL SetPos(int nPos);
	BOOL SetRange(int nMin, int nMax);


// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProgressDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGRESSDLG_H__3580A751_A31F_4AAA_AA48_F17C9535EB92__INCLUDED_)
