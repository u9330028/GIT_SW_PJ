#pragma once

#include <vector>
//#include <queue>

typedef struct tagREAD_PACKET_INFO
{
	CHAR	RemoteAddress[14];
	USHORT	RemotePort;
	DWORD	PacketNumber;
} READ_PACKET_INFO;

class CNrmsPacketSession :	public CNetworkSession
{
public:
	CNrmsPacketSession(void);
	virtual ~CNrmsPacketSession(void);

private:
	BYTE								mPacketBuffer[MAX_BUFFER_LENGTH * 3];
	INT									mRemainLength;
	DWORD								mCurrentPacketNumber;
	
	DWORD								mLastReadPacketNumber;

	CCircularQueue						WriteQueue;


public:
	BOOL	Begin(void);
	BOOL	End(void);

	BOOL	ReadPacketForIocp(DWORD readLength);
	BOOL	ReadPacketForEventSelect(void);

	BOOL	ReadFromPacketForIocp(LPSTR remoteAddress, USHORT &remotePort, DWORD readLength);
	BOOL	ReadFromPacketForEventSelect(LPSTR remoteAddress, USHORT &remotePort);

	BOOL	WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength);
	BOOL	WriteComplete(void);

	BOOL	GetPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength);
};
