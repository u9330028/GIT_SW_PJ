#include "stdafx.h"
#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "EventSelect.h"
#include "ControlPacketSession.h"
#include "ControlClientSession.h"
#include "StringTokenizer.h"

CControlClientSession::CControlClientSession(void)
{
	m_hParentWnd = NULL;
}

CControlClientSession::CControlClientSession(HWND hParentWnd)
{
	m_hParentWnd = hParentWnd;
}

CControlClientSession::~CControlClientSession(void)
{
}

BOOL CControlClientSession::Begin(LPSTR remoteAddress, USHORT remotePort)
{
	if (!remoteAddress || remotePort <= 0)
		return FALSE;

	if (!mSession.Begin())
	{
		End();

		return FALSE;
	}

	if (!mSession.TcpBind())
	{
		End();

		return FALSE;
	}

	if (!CEventSelect::Begin(mSession.GetSocket()))
	{
		End();

		return FALSE;
	}

	if (!mSession.Connect(remoteAddress, remotePort))
	{
		End();

		return FALSE;
	}

	return TRUE;
}


BOOL CControlClientSession::End(void)
{
	mSession.End();

	CEventSelect::End();

	return TRUE;
}

BOOL CControlClientSession::ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength)
{
	void *Object = NULL;

	return mReadPacketQueue.Pop(&Object, protocol, packet, packetLength);
}

BOOL CControlClientSession::WritePacket(const BYTE *pData, DWORD dwDataLength)
{
	if (!mSession.WritePacket(pData, dwDataLength))
		return FALSE;

	if (!mSession.WriteComplete())
		return FALSE;

	return TRUE;
}

void CControlClientSession::OnIoRead(void)
{
	BYTE	btPacket[MAX_BUFFER_LENGTH]	= {0,};
	DWORD	dwPacketLength				= 0;

	DWORD	dwProtocol					= 0;

	if (mSession.ReadPacketForEventSelect())
	{
		while (mSession.GetPacket(dwProtocol, btPacket, dwPacketLength))
		{
			mReadPacketQueue.Push(this, dwProtocol, btPacket, dwPacketLength);
			//SendMessageToParent(UM_NRMS_RECEIVE, 0, 0);
		}
	}
}

// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
void CControlClientSession::OnIoConnected(DWORD dwError)
{
	SendMessageToParent(UM_CONTROLSERVER_CONNECTED, 0, dwError);
}

// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
void CControlClientSession::OnIoDisconnected(void)
{
	SendMessageToParent(UM_CONTROLSERVER_DISCONNECTED, 0, 0);
	TRACE(_T("OnIoDisconnected\n"));
}

void CControlClientSession::OnIoError(DWORD dwError)
{
	TRACE(_T("OnIoError(%d)\n"), dwError);

	switch(dwError)
	{
	case WSAETIMEDOUT:	// ����ð� �ʰ�

		break;


	default:
		break;
	}
		
}

void CControlClientSession::SetParentWnd(HWND hParentWnd)
{
	m_hParentWnd  = hParentWnd;
}

void CControlClientSession::SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(m_hParentWnd == NULL || !IsWindow(m_hParentWnd))
		return;

	::PostMessage(m_hParentWnd, uMsg, wParam, lParam);
}

void CControlClientSession::SendTextToParent(LPCTSTR lpszText)
{
	if(m_hParentWnd == NULL || !IsWindow(m_hParentWnd) || lpszText == NULL)
		return;
	
	COPYDATASTRUCT cds;
	cds.dwData = DISPLAY_STATUS;
	cds.lpData = (LPVOID) lpszText;
	cds.cbData = lstrlen(lpszText);
	
	::SendMessage(m_hParentWnd, WM_COPYDATA, 0, (LPARAM) &cds);	
}

void CControlClientSession::SetReceiveTimeOut(DWORD dwTimeOut)
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::SetTimer(m_hParentWnd, TIMER_CONTROLSERVER_RECEIVE_TIMEOUT, dwTimeOut, NULL);
	}
}

void CControlClientSession::ClearReceiveTimeOut()
{
	if(m_hParentWnd != NULL && IsWindow(m_hParentWnd))
	{
		::KillTimer(m_hParentWnd, TIMER_CONTROLSERVER_RECEIVE_TIMEOUT);
	}
}

BOOL CControlClientSession::SendErrorCode(LPCTSTR lpszErrorCode)
{
	/* 2010.07.26 ghk@kci.co.kr
	// LOCALIP ��� CD��ȣ 15�ڸ� �ø�
	TCHAR szLocalIP[100] = {0x00,};
	TCHAR szData[BUFFER_SIZE] = {0x00, };

	memset(szLocalIP, 0x00, sizeof(szLocalIP));
	GetLocalIP(szLocalIP);
	
	memset(szData, 0x00, sizeof(szData));
	sprintf(szData, "7000%c%-15s%c%s%c%s", FS, szLocalIP, FS, _T("12"), FS, lpszErrorCode);
	
	BOOL bResult = WritePacket((BYTE*)szData, lstrlen(szData));

	return bResult;
	*/

	TCHAR szNumberCD[20] = {0x00,};
	TCHAR szData[BUFFER_SIZE] = {0x00, };
	
	memset(szNumberCD, 0x00, sizeof(szNumberCD));
	GetPrivateProfileString("LOCAL", "CDNUMBER", "", szNumberCD, sizeof(szNumberCD), ATOM_INFO_INI);
	
	memset(szData, 0x00, sizeof(szData));
	wsprintf(szData, "7000%c%-15s%c%s%c%s", FS, szNumberCD, FS, _T("12"), FS, lpszErrorCode);
	
	// 2010.07.28 ghk@kci.co.kr
	// �׽�Ʈ���� SLEEP �߰�
	Sleep(3000);
	BOOL bResult = WritePacket((BYTE*)szData, lstrlen(szData));
	
	return bResult;
}

int CControlClientSession::GetLocalIP(TCHAR *lpszAddress)
{
	TCHAR szLocalIP[20] = {0x00,};
	CStringArray sa;
	
	if(lpszAddress == NULL)
		return 0;
	
	memset(szLocalIP, 0x00, sizeof(szLocalIP));
	mSession.GetLocalIP(szLocalIP);

	int nToken = CStringTokenizer::GetTokens(szLocalIP, _T("."), sa);
	if(nToken == 4)
	{
		wsprintf(szLocalIP, "%03s.%03s.%03s.%03", sa.GetAt(0)
												, sa.GetAt(1)
												, sa.GetAt(2)
												, sa.GetAt(3));
	}
	else
	{
		strcpy(szLocalIP, "000.000.000.000");
	}

	return lstrlen(szLocalIP);
}
