// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4C2FA159_AFF1_4114_8DEB_DDB4F2C05D76__INCLUDED_)
#define AFX_STDAFX_H__4C2FA159_AFF1_4114_8DEB_DDB4F2C05D76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define WIN32_LEAN_AND_MEAN -
#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT




//#include <afxsock.h>		// MFC socket extensions
#include "Winsock2.h"
#include "mswsock.h"

#include "afxtempl.h"
#include "Define.h"
#include "ProcessLog.h"
//#include "TraceUtil.h"
#include "shlwapi.h"

#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "EventSelect.h"
#include "NetworkSession.h"
//#include "PacketSession.h"

// GDI�÷���
#include <GdiPlus.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")

//��ũ����

#pragma comment( lib,"kernel32")


extern Bitmap* PngFromResource(IN HINSTANCE hInst, IN const LPTSTR pName, IN LPTSTR pType );
extern HBITMAP Create32BitBitmap( HDC hDCSource, int cx, int cy );




// �α����� ��ȣȭ
extern long (__cdecl *EncryptAES)(char* in, char* out, long outLen, char* key);

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4C2FA159_AFF1_4114_8DEB_DDB4F2C05D76__INCLUDED_)
