#if !defined(AFX_TRACEUTIL_H__59739C1B_D952_4656_9B62_50CCBF7B6404__INCLUDED_)
#define AFX_TRACEUTIL_H__59739C1B_D952_4656_9B62_50CCBF7B6404__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TraceUtil.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTraceUtil window

class CTraceUtil 
{
public:
	CTraceUtil();
	virtual ~CTraceUtil();

	void LogFileBackUp(void);
	void TraceLog(char* fmt, ...);
	void TraceHex(LPBYTE pData, int nLength);

private:
	int m_nBackupFileCount;
	CString m_strFileDate;
	CString m_strFilePath;
	CString m_strBackupPath;

	void ___trace(LPCTSTR lptext);
protected:
	CString GetLoggingText(LPCTSTR szText, UINT nLength);
	void GenerateFileName();
	int CountExistFile(LPCTSTR lpszDate);
};

extern CTraceUtil theTrace;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACEUTIL_H__59739C1B_D952_4656_9B62_50CCBF7B6404__INCLUDED_)


