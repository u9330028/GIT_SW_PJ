// OperationManagerDlg.h : header file
//

#if !defined(AFX_OPERATIONMANAGERDLG_H__6D946CB0_9879_4E10_B78E_275CC551556D__INCLUDED_)
#define AFX_OPERATIONMANAGERDLG_H__6D946CB0_9879_4E10_B78E_275CC551556D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProgressDlg.h"
#include "NrmsClientSession.h"
#include "ControlClientSession.h"

/////////////////////////////////////////////////////////////////////////////
// COperationManagerDlg dialog

class COperationManagerDlg : public CDialog
{
// Construction
public:

	COperationManagerDlg(CWnd* pParent = NULL);	// standard constructor
	~COperationManagerDlg();

// Dialog Data
	//{{AFX_DATA(COperationManagerDlg)
	enum { IDD = IDD_OPERATIONMANAGER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COperationManagerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

public:
	int WaitingWindow(CString strWindowTitle, DWORD dwTimeOut);
	void OpenErrorScreen(CString strMessage);
	BOOL ProcessErrorReport();
	void WriteKtxErrorCode(LPCTSTR lpszError, LPCTSTR lpszCode);
	void CloseNrmsSession();
	BOOL CheckHardwareInfo();
	BOOL DeleteScreenKeyboard();
	void ExitProgram(int nExitCode = 0);
	void SleepEx(DWORD dwTimeOut);
	void DestroyProgressWindow();
	BOOL CreateProgressWindow();
	void ShowTray(BOOL bShow = TRUE);
	void SetStatusText(LPCTSTR lpszMessage, BOOL bList = FALSE);
	void AddMessage(LPCTSTR lpszMessage);
	void UpdateMessage(LPCTSTR lpszMessage);
	void SetProgressRange(int nMin, int nMax);
	void InitializeWindow();

// Implementation
protected:
	void KillProgram();
	BOOL IsRunningFile(CString strFilePath);
	void DeleteControlSession();
	BOOL SetRegistryMenu();
	BOOL SetRegistryMenu2();
	void UpdateRegistry();
	BOOL UpdateFiles();
	int UnzipFile(LPCTSTR lpszZipFile, LPCTSTR lpszDestPath);

	void DeleteNrmsSession();
	void DrawBackground();
	BOOL StartNetwork();
	BOOL ProcessNrms();
	BOOL UpdateFirmware();
	BOOL UpdateFirmware(CString strDevice, BOOL bComPort, long &lExitCode);
	BOOL DisableFTP();
	BOOL DisableTelnet();
	CString GetBackupPath(CString strPath,
						  CString strUpdate = PATH_UPDATE,
						  CString strBackup = PATH_BACKUP);
	
	void StartCommonProgram();
	BOOL StartProgram(int nCode);
	int MoveDirectory(CString strSourcePath, CString strDestPath, BOOL bRegisterOCX = FALSE);
	int ProcessBackup(LPCTSTR lpszDirectory);
	int RegisterOCX(CString strFilePath, char chAction);
	BOOL IsRegisterOCX(CString strFilePath);
	int ProcessUnzip();
	BOOL ProcessKtx();
	BOOL ProcessPreCopy();
	BOOL CheckUpdateVersion();
	BOOL CheckUpdateFile();
	void SetProgressPos(int nPos);
	BOOL SetRegistryBackgroundImage();
	BOOL SetRegistryPagingFile();
	BOOL SetRegistryRunnableProgram();
	BOOL SetRegistryKeepAlive();
	BOOL SetRegistryStartup();
	void Initialize();
	void Start();

	HICON m_hIcon;
	HBITMAP m_hBitmap;

	BOOL m_bExit;
	Bitmap *m_pBitmapBG;

	//CProgressDlg *m_pProgressWnd;
#ifdef __DEBUG_FAIL__
	CDialog *m_pProgressWnd;
#else
	CProgressDlg m_wndProgress;
#endif
	CString	m_strZipFileName;	// 2007-04-10 : atom_update(master)_vxxxxxx.zip Update ����(��������)
	CString m_strLocalVersion;	// ���� ����
	CString m_strUpdateVersion;	// ������Ʈ �Ϸ��� ����
	CString m_strErrorCode;
	CString m_strNrmsServerIP;
	CString m_strControlServerIP;
	int m_nNrmsPort;
	int m_nControlPort;

	BOOL m_bNetworkStartup;
	BOOL m_bNextStep;
	UINT m_nNrmsRetryCount;
	UINT m_nControlRetryCount;


	CNrmsClientSession *m_pNrmsClient;
	CControlClientSession *m_pControlClient;

	// Generated message map functions
	//{{AFX_MSG(COperationManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg LRESULT OnNrmsConnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnNrmsDisconnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnControlServerConnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnControlServerDisconnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnStartProgram(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnCheckHardware(WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPERATIONMANAGERDLG_H__6D946CB0_9879_4E10_B78E_275CC551556D__INCLUDED_)
