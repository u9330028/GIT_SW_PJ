// StringTokenizer.cpp: implementation of the CStringTokenizer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "StringTokenizer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStringTokenizer::CStringTokenizer()
{

}

CStringTokenizer::~CStringTokenizer()
{

}

/********************************************************************************************
 *  Module   : GetTokens()
 *  Synopsis : string�� delimiter�� tokenize �Ѵ�.
 *  Date     : 2007-09-22 
 *  Author   : ygchoi
 ********************************************************************************************/
int CStringTokenizer::GetTokens(CString src, CString del, CStringArray& ar)
{
	int nPos = -1;
	int	dellen = del.GetLength();
	CString strToken = src;

	ar.RemoveAll();
	ar.FreeExtra();
	
	while ((nPos = src.Find(del)) > -1) 
	{
		if(nPos == 0)
			strToken = "";
		else
			strToken = src.Left(nPos);

		int nLength = src.GetLength();
		if((nPos + dellen) >= nLength)
			src = "";
		else
			src = src.Mid(nPos + dellen);

		ar.Add(strToken);
		strToken = src;
	}

	if (!strToken.IsEmpty())
		ar.Add(strToken);

	return ar.GetSize();
}
