// TandemSocket.cpp: implementation of the CTandemSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "operationmanager.h"
#include "TandemSocket.h"
#include "Define.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTandemSocket::CTandemSocket()
{
	m_hSocket = INVALID_SOCKET;
	m_strRemoteIP = "";
	m_nRemotePort = 0;
	m_bStartup = FALSE;
	m_bConnected = FALSE;
}

CTandemSocket::~CTandemSocket()
{

}


int CTandemSocket::Create()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Create] ����");
	
	WSADATA wsaData;
	
	try
	{
		if(WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Create] WSAStartup ERROR[%d]", GetLastError());
			
			m_bStartup = FALSE;
			m_hSocket = INVALID_SOCKET;
			return FALSE;
		}
		
		m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
		if(m_hSocket == INVALID_SOCKET)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Create] socket ERROR[%d]", GetLastError());
			
			m_bStartup = FALSE;
			m_hSocket = INVALID_SOCKET;
			WSACleanup();
			return FALSE;
		}

		m_bStartup = TRUE;
	}
	catch(...)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Create] EXCEPTION[%d]", GetLastError());
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Create] ����");
	return TRUE;	
}


void CTandemSocket::Destroy()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Destroy] ����");

	Close();

	if(m_bStartup)
	{
		WSACleanup();
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Destroy] ����");
}


int CTandemSocket::Connect(LPCTSTR lpRemoteIP, int nRemotePort)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Connect] REMOTE[IP:%s PORT:%d] ����", lpRemoteIP, nRemotePort);

	m_strRemoteIP = lpRemoteIP;
	m_nRemotePort = nRemotePort;

	
	m_bConnected		 = FALSE;
	int nResult			 = SOCKET_ERROR;
	int nNonBlockingMode = TRUE;
	SOCKADDR_IN addr;
	
	try
	{
		memset( &addr, 0x00, sizeof(addr) );
		addr.sin_family      = AF_INET;
		addr.sin_addr.s_addr = inet_addr(lpRemoteIP);
		addr.sin_port        = htons(nRemotePort);
		
		ioctlsocket( m_hSocket, FIONBIO, (u_long FAR*) &nNonBlockingMode );	// NON-BLOCKING MODE�� ����
		
		if( connect( m_hSocket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR )
		{
			DWORD dwErrorCode = WSAGetLastError();
			if( dwErrorCode == WSAEWOULDBLOCK )
			{
				fd_set  writes;
				TIMEVAL timeout;
				
				FD_ZERO(&writes);
				FD_SET( m_hSocket, &writes );
				
				// writes = reads;
				timeout.tv_sec  = TIMEOUT_TANDEM_CONNECT;
				timeout.tv_usec = 0;
				
				DWORD dwStart = GetTickCount();
				nResult = select( m_hSocket, 0, &writes, 0, &timeout );
				
				if( nResult != SOCKET_ERROR )
				{
					if( writes.fd_count > 0 )
					{
						m_bConnected = TRUE;
					}
				}
			}
		}
		
		// BLOCKING MODE�� ����
		if(m_bConnected)
		{
			nNonBlockingMode = FALSE;
			nResult = ioctlsocket( m_hSocket, FIONBIO, (u_long FAR*) &nNonBlockingMode ); // BLOCKING MODE�� ����
		}
	}
	catch(...)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Connect] EXCEPTION[%d]", GetLastError());
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Connect] REMOTE[%s] ����[%d]", lpRemoteIP, m_bConnected);
	
	return m_bConnected;
}

void CTandemSocket::Close()
{
	if(m_hSocket != INVALID_SOCKET)
	{
		shutdown(m_hSocket, SD_BOTH);
		closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
		m_bConnected = FALSE;
	}
}

int CTandemSocket::SendErrorCode(LPCTSTR lpErrorCode)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::SendErrorCode] ERRORCODE[%s] ����", lpErrorCode);

	TCHAR szNumberCD[20] = {0x00,};
	TCHAR szData[BUFFER_SIZE] = {0x00, };
	
	memset(szNumberCD, 0x00, sizeof(szNumberCD));
	GetPrivateProfileString("LOCAL", "CDNUMBER", "", szNumberCD, sizeof(szNumberCD), ATOM_INFO_INI);
	
	memset(szData, 0x00, sizeof(szData));
	wsprintf(szData, "7000%c%-15s%c%s%c%s", FS, szNumberCD, FS, _T("12"), FS, lpErrorCode);
	
	int nByteSent = Send(szData, lstrlen(szData));


	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::SendErrorCode] ERRORCODE[%s] BYTES:%d ����", lpErrorCode, nByteSent);
	
	return nByteSent;
}

/******************************************************
* 20100729 kimjiyoung Send Data Length ����
*	- Data Length�� Length �ڽ��� ���� 4byte�� �������� �ʴ´�.
******************************************************/
int CTandemSocket::Send(LPCTSTR lpDataBuffer, DWORD dwDataLength)
{
	DWORD dwPacketLength = 4 + dwDataLength + 1;	// LENGTH(4) + DATA(n) + ETX(1)
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;

	char szLength[5] = {0x00, };
	char szPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(szPacket, 0x00, sizeof(szPacket));
	
	// 2010.08.05 ghk@kci.co.kr
	//sprintf(szLength, "%04d", dwPacketLength);
	wsprintf(szLength, "%04d", dwDataLength + 1);	// LENGTH�� ����Ÿ���� + ETX(1) ����Ʈ

	memcpy(&szPacket[0], szLength, 4);	// ��Ŷ���� 4�ڸ�
	
	if(dwDataLength > 0)
	{
		memcpy(&szPacket[4], lpDataBuffer, dwDataLength);	// ����Ÿ N�ڸ�
	}
	szPacket[4 + dwDataLength] = ETX;

	if(m_hSocket == INVALID_SOCKET)
		return -1;

	int nByteSent = send(m_hSocket, szPacket, dwPacketLength, 0);

	CProcessLog::GetInstance()->Dump(LOGFILE, "[CTandemSocket::Send]", (LPBYTE)szPacket, dwPacketLength);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CTandemSocket::Send] %d BYTES ���� �Ϸ�", nByteSent);

	return nByteSent;
}
