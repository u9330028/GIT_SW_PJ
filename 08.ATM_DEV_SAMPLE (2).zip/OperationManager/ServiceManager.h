// ServiceManager.h: interface for the CServiceManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVICEMANAGER_H__D90B8229_C389_4BEB_98E0_A8E6C68DDE1C__INCLUDED_)
#define AFX_SERVICEMANAGER_H__D90B8229_C389_4BEB_98E0_A8E6C68DDE1C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <winsvc.h>

#define SZ_ENUM_BUF						4096

#define SERVICE_CONTROL_STOP			0x00000001
#define SERVICE_CONTROL_PAUSE			0x00000002
#define SERVICE_CONTROL_CONTINUE		0x00000003
#define SERVICE_CONTROL_INTERROGATE		0x00000004
#define SERVICE_CONTROL_SHUTDOWN		0x00000005

#define SERVICE_CONTROL_PARAMCHANGE		0x00000006
#define SERVICE_CONTROL_NETBINDADD		0x00000007
#define SERVICE_CONTROL_NETBINDREMOVE	0x00000008
#define SERVICE_CONTROL_NETBINDENABLE	0x00000009
#define SERVICE_CONTROL_NETBINDDISABLE	0x0000000A

#define SERVICE_CONTROL_START			0x00000009


class CServiceManager : public CObject  
{
public:
	CServiceManager();
	virtual ~CServiceManager();


public:
	BOOL ChangeServiceConfig(CString strComputerName, CString strServiceName, DWORD dwStartType);
	BOOL ControlServiceStatus(CString strComputerName, CString strServiceName, LONG lnCtrlCode);
	BOOL CheckServiceStatus(CString strComputerName, CString strServiceName, LONG lnChkState);
	BOOL IsServiceExist(CString strComputerName, CString strServiceName);

	int GetServiceStatus(CString strComputerName, DWORD dwServiceType, LPSTR lpszEnumService, DWORD dwEnumServiceBufferSize);
	
protected:
	CString GetCurrentServiceStateStr(LONG lnCurrentState);
	CString GetServiceStartTypeStr(LONG lnStartServiceType);
	CString GetServiceErrCtrlTypeStr(LONG lnErrCtrlType);
	CString GetServiceNodeTypeStr(LONG lnNodeType);
	
private:
	LPTSTR GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize );
	
private:
	CString m_strPrevComputerName;	
	CString m_strLineBuffer;
	BOOL    m_bIsMoreData;
};

#endif // !defined(AFX_SERVICEMANAGER_H__D90B8229_C389_4BEB_98E0_A8E6C68DDE1C__INCLUDED_)
