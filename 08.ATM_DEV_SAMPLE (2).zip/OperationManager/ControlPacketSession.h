#pragma once

#include <vector>
//#include <queue>


class CControlPacketSession :	public CNetworkSession
{
public:
	CControlPacketSession(void);
	virtual ~CControlPacketSession(void);

private:
	BYTE			mPacketBuffer[MAX_BUFFER_LENGTH * 3];
	INT				mRemainLength;
	DWORD			mCurrentPacketNumber;
	DWORD			mLastReadPacketNumber;

	CCircularQueue	WriteQueue;


public:
	BOOL	Begin(void);
	BOOL	End(void);

	BOOL	ReadPacketForIocp(DWORD readLength);
	BOOL	ReadPacketForEventSelect(void);

	BOOL	ReadFromPacketForIocp(LPSTR remoteAddress, USHORT &remotePort, DWORD readLength);
	BOOL	ReadFromPacketForEventSelect(LPSTR remoteAddress, USHORT &remotePort);

	BOOL	WritePacket(const BYTE *pData, DWORD dwDataLength);
	BOOL	WriteComplete(void);

	BOOL	GetPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength);
};
