// Compression.h: interface for the CCompression class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPRESSION_H__E66D5021_05CC_4E6B_BDDB_67EF91BE4B5D__INCLUDED_)
#define AFX_COMPRESSION_H__E66D5021_05CC_4E6B_BDDB_67EF91BE4B5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCompression  : public CObject
{
public:
	CCompression();
	virtual ~CCompression();

};

#endif // !defined(AFX_COMPRESSION_H__E66D5021_05CC_4E6B_BDDB_67EF91BE4B5D__INCLUDED_)
