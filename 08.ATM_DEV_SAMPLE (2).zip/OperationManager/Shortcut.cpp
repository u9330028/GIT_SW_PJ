// Shortcut.cpp: implementation of the CShortcut class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "operationmanager.h"
#include "Shortcut.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CShortcut::CShortcut()
{

}

CShortcut::~CShortcut()
{

}

BOOL CShortcut::GetLinkPath(LPCSTR lpszLink, LPSTR lpszPath)
{
	WORD wszLink[MAX_PATH] = {0x00, };
    IShellLink *pShellLink = NULL;
    IPersistFile *pPF = NULL;
    HRESULT hResult = S_OK ;
    
	//�ʱ�ȭ
	hResult = CoInitialize(NULL);
    if(FAILED(hResult))
	{
		return FALSE;
	}

	//����
	hResult = CoCreateInstance(CLSID_ShellLink,
							   NULL, CLSCTX_INPROC_SERVER,
							   IID_IShellLink,
							   (LPVOID *)&pShellLink);
	if(hResult != S_OK)
	{
		CoUninitialize();
		return FALSE;
	}

	hResult = pShellLink->QueryInterface(IID_IPersistFile, (LPVOID *) &pPF);
	if(hResult != S_OK)
	{
		pShellLink->Release();
		CoUninitialize();
		return FALSE;
	}
	
	memset(wszLink, 0x00, sizeof(wszLink));
	MultiByteToWideChar(CP_ACP, 0, lpszLink, -1, LPWSTR(wszLink), MAX_PATH);
	hResult = pPF->Load(LPWSTR(wszLink), STGM_READ);
	if(hResult != S_OK)
	{
		pPF->Release();
		pShellLink->Release();
		CoUninitialize();
		return FALSE;
	}

	//2009.5.14 hgkang �߸��� ���� ������ ������ �����Ѵ�.
	hResult = pShellLink->Resolve(0, SLR_NO_UI);// |SLR_NOSEARCH | SLR_NOTRACK
	if(hResult != S_OK)
	{
		pPF->Release();
		pShellLink->Release();
		CoUninitialize();
		return FALSE;
	}

	hResult = pShellLink->GetPath(lpszPath, MAX_PATH, NULL, SLGP_UNCPRIORITY);
	pPF->Release();
	pShellLink->Release();
	CoUninitialize();

	if(hResult == S_OK)
	{
		return TRUE;
    }

    return FALSE;
}

BOOL CShortcut::CreateShortcut(LPCTSTR szPathObj, LPCTSTR szPathLink, LPCTSTR szShortcutTitle, LPCTSTR szDesc)
{
	BOOL bResult = FALSE;
    HRESULT hResult = S_OK;
    IShellLink *pShellLink = NULL;
	IPersistFile *pPF = NULL;

    TCHAR szFilePath[MAX_PATH + 2];
    TCHAR *pFileName = NULL;
	WORD wsz[MAX_PATH] = {0x00, };
	CString strLinkPath = szPathLink;
	
	
    
	
    //Init COM Object 
    CoInitialize(NULL);
	
    hResult = CoCreateInstance(CLSID_ShellLink,
							   NULL,
							   CLSCTX_INPROC_SERVER,
							   IID_IShellLink,
							   (LPVOID*) &pShellLink);
	
    if(FAILED(hResult) || pShellLink == NULL)
    {
		CoUninitialize();
		return FALSE;
	}
        
		
    pShellLink->SetPath(szPathObj);		//���� ���� ��Ʈ
    pShellLink->SetDescription(szDesc);	//��������� �̸�
		
		
	//������丮�ֱ�
	memset(szFilePath, 0x00, sizeof(szFilePath));
	strcpy(szFilePath, szPathObj);
	
	//���丮���
	pFileName = strrchr(szFilePath, '\\');
	if(pFileName != NULL)				//���� �̸�
	{
		*pFileName = '\0';
	}
	
	pShellLink->SetWorkingDirectory(szFilePath);	//���������� �ִ� ���丮
	
	hResult = pShellLink->QueryInterface(IID_IPersistFile, (LPVOID *) &pPF);
	if(hResult == S_OK)
	{
		strLinkPath += "\\";
		strLinkPath += szShortcutTitle;
		
		memset(wsz, 0x00, sizeof(wsz));
		MultiByteToWideChar(CP_ACP,
							MB_PRECOMPOSED,
							strLinkPath,
							-1,
							LPWSTR(wsz),
							MAX_PATH);
		
		hResult = pPF->Save(LPWSTR(wsz), TRUE);
		if(hResult == S_OK)
		{
			bResult = TRUE;
		}

		pPF->Release();
	}
	
	pShellLink->Release();
	CoUninitialize();

    return bResult;
}

BOOL CShortcut::RemoveShortcut(int nLocation, CString strTarget)
{
	TCHAR szLinkPath[MAX_PATH + 2] = {0x00, };
	TCHAR szDirectory[MAX_PATH + 2] = {0x00, };
	HRESULT hResult = S_OK;
	BOOL bResult = FALSE;
	BOOL bRemoved = TRUE;
	CString strFilePath = _T("");

	memset(szDirectory, 0x00, sizeof(szDirectory));
	hResult = SHGetSpecialFolderPath(NULL, szDirectory, nLocation, FALSE);
	if(!SUCCEEDED(hResult))
		return FALSE;

	bRemoved = RemoveShortcut(szDirectory, strTarget);
	return bRemoved;
}

BOOL CShortcut::RemoveShortcut(CString strDirectory, CString strTarget)
{
	TCHAR szLinkPath[MAX_PATH + 2] = {0x00, };
	TCHAR szDirectory[MAX_PATH + 2] = {0x00, };
	HRESULT hResult = S_OK;
	BOOL bResult = FALSE;
	BOOL bRemoved = TRUE;
	CString strFilePath = _T("");
	CString strFindDirectory = strDirectory;

	int nLength = strFindDirectory.GetLength();
	if(nLength <= 1)
	{
		return TRUE;
	}

	if(strFindDirectory.Right(1) == _T("\\") || strFindDirectory.Right(1) == _T("/"))
	{
		strFindDirectory = strFindDirectory.Left(nLength -1);
	}
	
	CFileFind ff;
	strFilePath.Format(_T("%s\\*.lnk"), strFindDirectory);
	BOOL bExist = ff.FindFile(strFilePath);	//��ũ ���� �˻�
	
	while(bExist)
	{
		bExist = ff.FindNextFile();
		if(ff.IsDots() || ff.IsHidden() || ff.IsDirectory())
		{
			continue;
		}
		else
		{
			strFilePath = ff.GetFilePath();
			memset(szLinkPath, 0x00, sizeof(szLinkPath));
			bResult = GetLinkPath(strFilePath, szLinkPath);//�ش� ����������� ���� ������ ����.
			
			if(bResult)
			{
				CString strLinkPath = szLinkPath;
				if(strLinkPath.Find(strTarget) != -1)
				{
					if(!DeleteFile(strFilePath))
					{
						bRemoved = FALSE;
					}
				}
			}
		}
	}
	
	ff.Close();
	
	return bRemoved;
}

BOOL CShortcut::RemoveDesktopShortcut(CString strTarget)
{
	BOOL bCurrentUserDesktop = RemoveShortcut(CSIDL_DESKTOPDIRECTORY, strTarget);
	BOOL bAllUserDesktop = RemoveShortcut(CSIDL_COMMON_DESKTOPDIRECTORY, strTarget);

	return (bCurrentUserDesktop && bAllUserDesktop);
}

BOOL CShortcut::RemoveStartupShortcut(CString strTarget)
{
	BOOL bCurrentUserStartup = RemoveShortcut(CSIDL_DESKTOPDIRECTORY, strTarget);
	BOOL bAllUserStartup = RemoveShortcut(CSIDL_COMMON_DESKTOPDIRECTORY, strTarget);
	
	return (bCurrentUserStartup && bAllUserStartup);
}
