// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__0BE70DBA_D87C_4633_8693_4C8120B3BBA1__INCLUDED_)
#define AFX_STDAFX_H__0BE70DBA_D87C_4633_8693_4C8120B3BBA1__INCLUDED_

#define _WIN32_WINNT		0x500

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#pragma warning( disable : 4786 )

#pragma once
#define	random(num)(rand()%(num))
#define randomize() srand((unsigned)time(NULL))


#include <vector>
#include <map>
#include "winsock2.h"
#include "mswsock.h"
#include "shlwapi.h"
#include "afxtempl.h"

#include "Resource.h"
#include "Define.h"
#include "ProcessLog.h"
#include "ErrorMessage.h"
#include "StringTokenizer.h"
#include "ServiceManager.h"
#include "Process.h"


#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "PacketSession.h"
#include "Iocp.h"


#include "ConnectedSession.h"
#include "ConnectedSessionManager.h"
#include "ServerIocp.h"

#include "EventSelect.h"
#include "ClientSession.h"

#include "DeleteLogThread.h"
#include "PollSendThread.h"
#include "ErrorReportThread.h"

#include "RebootManagerDlg.h"

// GDI�÷���
#include <GdiPlus.h>
#include <atlconv.h>
using namespace Gdiplus;
#pragma comment(lib, "gdiplus")


// �α����� ��ȣȭ
extern long (__cdecl *EncryptAES)(char* in, char* out, long outLen, char* key);


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__0BE70DBA_D87C_4633_8693_4C8120B3BBA1__INCLUDED_)
