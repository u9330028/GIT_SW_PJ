// RebootManagerDlg.h : header file
//

#if !defined(AFX_REBOOTMANAGERDLG_H__999D371D_0E7C_4E30_A814_B53A2FE6FB99__INCLUDED_)
#define AFX_REBOOTMANAGERDLG_H__999D371D_0E7C_4E30_A814_B53A2FE6FB99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "ErrorScreenDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerDlg dialog

class CRebootManagerDlg : public CDialog
{
// Construction
public:
	CRebootManagerDlg(CWnd* pParent = NULL);	// standard constructor
	~CRebootManagerDlg();


// Dialog Data
	//{{AFX_DATA(CRebootManagerDlg)
	enum { IDD = IDD_REBOOTMANAGER_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRebootManagerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON				m_hIcon;
	BOOL				m_bNetworkStartup;
	BOOL				m_bServerStartup;
	CServerIocp			m_server;

	CString				m_strNrmsServerIP;
	int					m_nNrmsServerPort;
	CClientSession		*m_pNrmsSession;
	CDeleteLogThread	*m_pThreadDeleteLog;	// �α����� ������ ������

	int					m_nPollSendFailIBP;		// IBP POLL ���� ���� ī����
	int					m_nPollSendFailIIM;		// IIM POLL ���� ���� ī����
	int					m_nPollSendFailIPF;		// IPF POLL ���� ���� ī����
	int					m_nPollSendFailADP;		// ADP POLL ���� ���� ī����

	BOOL				m_bPollFailReportADP;	// POLL FAIL ���۽� ����(RECOVERY ���� ����)


	CPollSendThread		*m_pThreadPollSend;

	CDialog				*m_pErrorScreen;
	CMap<DWORD, DWORD, CString, CString> m_mapError;


//	HMODULE				m_hUser32;
//	SLWA SetLayeredWindowAttributes;
//	void LoadLib();

public:
	void CaptureScreen();
	void OpenErrorScreen(CString strMessage);
	void PollSendResult(DWORD wPollID, BOOL bPollSent);
	int GetErrorCode(DWORD dwID, TCHAR *lpError, int nLength);
	int GetRecoveryCode(DWORD dwID, TCHAR *lpRecover, int nLength);
	void StartCommandResponseTimer(BOOL bReboot = TRUE);
	void KillTimerAll();
	void KillProcessAll();
	BOOL Reboot();
	BOOL ReportPollFailToServer(DWORD dwFailID);
	BOOL ReportPollFailToIBP(DWORD dwFailID);
	BOOL ReportRecoveryToIBP(DWORD dwRecoveryID);
	BOOL StartupPollSendThread();
	BOOL SendPagefileInfoToServer();
	void StartPagefileSendTimer();
	void ResetPollResponseTimeOut(UINT nTimerID, DWORD dwTimeOut);
	void ClearDeleteLogThread();
	BOOL StartManager();

protected:
	BOOL CreateErrorScreen();
	BOOL Restart();
	BOOL SendPollPacket(CString strWindowTitle);
	BOOL ProcessResponseIIM(CString strData);
	void DeleteNrmsSession();
	BOOL CreateNrmsSession();
	BOOL PollADP();
	BOOL PollIPF();
	BOOL PollIIM();
	BOOL PollIBP();
	void StartDeleteLogThread();
	BOOL StartupServer();
	BOOL StartupNetwork();


	// Generated message map functions
	//{{AFX_MSG(CRebootManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
	afx_msg LRESULT OnNrmsConnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnNrmsDisConnected(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnPollResult(WPARAM wParam, LPARAM lParam);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REBOOTMANAGERDLG_H__999D371D_0E7C_4E30_A814_B53A2FE6FB99__INCLUDED_)
