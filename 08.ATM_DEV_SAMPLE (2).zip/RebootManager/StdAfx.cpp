// stdafx.cpp : source file that includes just the standard includes
//	RebootManager.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "mswsock.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "User32.lib")
#pragma comment(lib, "lib/aes.lib")

// �α����� ��ȣȭ
long (__cdecl *EncryptAES)(char* in, char* out, long outLen, char* key);
