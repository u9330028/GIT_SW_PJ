#pragma once

class CPacketSession :	public CNetworkSession
{
public:
	CPacketSession(VOID);
	virtual ~CPacketSession(VOID);

private:
	BYTE								mPacketBuffer[MAX_BUFFER_LENGTH * 3];
	INT									mRemainLength;
	CCircularQueue						WriteQueue;

public:
	BOOL	Begin(VOID);
	BOOL	End(VOID);
	
	UINT	GetPacket(BYTE *packet, DWORD &packetLength);

	BOOL	ReadPacketForIocp(DWORD readLength);
	BOOL	ReadPacketForEventSelect(VOID);

	BOOL	ReadFromPacketForIocp(LPSTR remoteAddress, USHORT &remotePort, DWORD readLength);
	BOOL	ReadFromPacketForEventSelect(LPSTR remoteAddress, USHORT &remotePort);

//protected:
	BOOL	WritePacket(const BYTE *packet, DWORD packetLength);
	BOOL	WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength);
	BOOL	WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength);
	BOOL	WriteComplete(VOID);

};
