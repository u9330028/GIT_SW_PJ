#include "stdafx.h"
#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "PacketSession.h"

CPacketSession::CPacketSession(VOID)
{
	memset(mPacketBuffer, 0, sizeof(mPacketBuffer));
	mRemainLength			= 0;
}

CPacketSession::~CPacketSession(VOID)
{
}

BOOL CPacketSession::Begin(VOID)
{
	CThreadSync Sync;

	memset(mPacketBuffer, 0, sizeof(mPacketBuffer));
	mRemainLength			= 0;

	if (!WriteQueue.Begin())
		return FALSE;

	return CNetworkSession::Begin();
}

BOOL CPacketSession::End(VOID)
{
	CThreadSync Sync;

	if (!WriteQueue.End())
		return FALSE;

	return CNetworkSession::End();
}

UINT CPacketSession::GetPacket(BYTE *packet, DWORD &packetLength)
{
	CThreadSync Sync;

	if (!packet)
		return PACKET_INVALID_PACKET_LENGTH;

	UINT nRemainSize = sizeof(DWORD);
	if (mRemainLength < nRemainSize)
		return PACKET_INVALID_PACKET_LENGTH;

	TCHAR szPacketLength[10] = {0x00, };
	INT nPacketLength = 0;

	// STX(1) + LENGTH(4) + DATA(N) + ETX(1)
	// .005071.A001.C:\CD2K\Download_Dongle\download.a90.
	memset(szPacketLength, 0x00, sizeof(szPacketLength));
	memcpy(szPacketLength, &mPacketBuffer[1], 4);
	nPacketLength = atoi(szPacketLength);

	if (nPacketLength > MAX_BUFFER_LENGTH || nPacketLength <= 0) // Invalid Packet
	{
		mRemainLength = 0;
		return PACKET_INVALID_PACKET_LENGTH;
	}

	if (nPacketLength <= mRemainLength)
	{
		packetLength = nPacketLength;
		memcpy(packet, mPacketBuffer, packetLength);

		if(mRemainLength - nPacketLength > 0)
		{
			memmove(mPacketBuffer, mPacketBuffer + nPacketLength, mRemainLength - nPacketLength);
		}

		mRemainLength -= nPacketLength;
		if (mRemainLength <= 0)
		{
			mRemainLength = 0;
			memset(mPacketBuffer, 0, sizeof(mPacketBuffer));
		}

		return PACKET_EXIST;
	}

	return PACKET_INVALID_PACKET_LENGTH;
}

// ReadPacketForIocp�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadPacketForIocp(DWORD readLength)
{
	CThreadSync Sync;

	if (!CNetworkSession::ReadForIocp(mPacketBuffer + mRemainLength, readLength))
		return FALSE;

	mRemainLength	+= readLength;

	//return getPacket(protocol, packet, packetLength);
	return TRUE;
}

// ReadPacketForEventSelect�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadPacketForEventSelect(VOID)
{
	CThreadSync Sync;

	DWORD ReadLength = 0;

	if (!CNetworkSession::ReadForEventSelect(mPacketBuffer + mRemainLength, ReadLength))
		return FALSE;

	mRemainLength	+= ReadLength;

	//return getPacket(protocol, packet, packetLength);
	return TRUE;
}

// ReadPacketForIocp�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadFromPacketForIocp(LPSTR remoteAddress, USHORT &remotePort, DWORD readLength)
{
	CThreadSync Sync;

	if (!CNetworkSession::ReadFromForIocp(remoteAddress, remotePort, mPacketBuffer + mRemainLength, readLength))
		return FALSE;

	mRemainLength	+= readLength;

	//return getPacket(remoteAddress, remotePort, protocol, packet, packetLength);
	return TRUE;
}

// ReadPacketForEventSelect�� FALSE�� �������� ���� while���� ������.
BOOL CPacketSession::ReadFromPacketForEventSelect(LPSTR remoteAddress, USHORT &remotePort)
{
	CThreadSync Sync;

	DWORD ReadLength = 0;

	if (!CNetworkSession::ReadFromForEventSelect(remoteAddress, remotePort, mPacketBuffer + mRemainLength, ReadLength))
		return FALSE;

	mRemainLength	+= ReadLength;

	return TRUE;
}

BOOL CPacketSession::WritePacket(const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;
	
	// LENGTH(4) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 4 + dwDataLength + 1;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));
	
	sprintf(szLength, "%04d", dwPacketLength);
	memcpy(&btPacket[0], szLength, 4);	// ��Ŷ���� 4�ڸ�
	
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[4], pData, dwDataLength);	// ����Ÿ N�ڸ�
	}
	btPacket[4 + dwDataLength] = ETX;
	
	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = WriteQueue.Push(this, btPacket, dwPacketLength);
	
//	theTrace.TraceHex(btPacket, dwPacketLength);
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;
	
	if (!lpCommand)
		return FALSE;
	
	// STX(1) + LENGTH(4) + CMD(2) + FS(1) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 9 + dwDataLength;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));
	
	sprintf(szLength, "%04d", dwPacketLength);
	
	btPacket[0] = STX;
	memcpy(&btPacket[1], szLength, 4);	// ��Ŷ���� 4�ڸ�
	memcpy(&btPacket[5], lpCommand, 2);	// ���ɾ� 2�ڸ�
	btPacket[7] = FS;
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[8], pData, dwDataLength);	// ���ɾ� 2�ڸ�
	}
	btPacket[8 + dwDataLength] = ETX;
	
	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = WriteQueue.Push(this, btPacket, dwPacketLength);
	
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength)
{
	CThreadSync Sync;
	
	if (!lpCommand || !lpNumberCD)
		return FALSE;
	
	// STX(1) + LENGTH(4) + CMD(2) + FS(1) + CDNUMBER(4) + FS(1) + DATA(N) + ETX(1)
	DWORD dwPacketLength = 14 + dwDataLength;
	
	if (dwPacketLength >= MAX_BUFFER_LENGTH)
		return FALSE;
	
	TCHAR szLength[5] = {0x00, };
	BYTE btPacket[MAX_BUFFER_LENGTH] = {0x00, };
	
	memset(szLength, 0x00, sizeof(szLength));
	memset(btPacket, 0x00, sizeof(btPacket));
	
	wsprintf(szLength, "%04d", dwPacketLength);
	
	btPacket[0] = STX;
	memcpy(&btPacket[1], szLength, 4);	// ��Ŷ���� 4�ڸ�
	memcpy(&btPacket[5], lpCommand, 2);	// ���ɾ� 2�ڸ�
	btPacket[7] = FS;
	memcpy(&btPacket[8], lpNumberCD, 4);	// ���ɾ� 2�ڸ�
	btPacket[12] = FS;
	
	if(dwDataLength > 0)
	{
		memcpy(&btPacket[13], pData, dwDataLength);	// ���ɾ� 2�ڸ�
	}
	btPacket[13 + dwDataLength] = ETX;

	// WriteQueue�� �̿��ؼ� ��Ŷ�� ���� �Ϸᰡ �Ǿ������� �޸𸮸� ����д�.
	BYTE *pWriteData = WriteQueue.Push(this, btPacket, dwPacketLength);
	
	return CNetworkSession::Write(pWriteData, dwPacketLength);
}

BOOL CPacketSession::WriteComplete(VOID)
{
	CThreadSync Sync;

	// WriteQueue���� Pop�� �� �ָ� �ȴ�.
	return WriteQueue.Pop();
}
