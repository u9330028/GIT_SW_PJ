#if !defined(AFX_DELETELOGTHREAD_H__EBF0913B_0237_41BD_99D4_7C28F3A18757__INCLUDED_)
#define AFX_DELETELOGTHREAD_H__EBF0913B_0237_41BD_99D4_7C28F3A18757__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DeleteLogThread.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CDeleteLogThread thread

class CDeleteLogThread : public CWinThread
{
	DECLARE_DYNCREATE(CDeleteLogThread)
protected:
	CDeleteLogThread();           // protected constructor used by dynamic creation

// Attributes
public:

protected:
	BOOL m_bStop;
	HWND m_hParentWnd;

// Operations
public:
	void SetParentWnd(HWND hParentWnd);
	void Stop();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDeleteLogThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual int Run();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL IsDateFormat(CString strText);
	void DeleteFileRecursive(CString strPath, CTime ctMaxLogDate);
	void DeleteLogFile(BOOL bFlag);
	virtual ~CDeleteLogThread();

	// Generated message map functions
	//{{AFX_MSG(CDeleteLogThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DELETELOGTHREAD_H__EBF0913B_0237_41BD_99D4_7C28F3A18757__INCLUDED_)
