#include "stdafx.h"
#include "CriticalZone.h"
#include "MultiThreadSync.h"
#include "CircularQueue.h"
#include "NetworkSession.h"
#include "ErrorMessage.h"
#include "Iphlpapi.h"

#pragma comment(lib, "Iphlpapi.lib")


CNetworkSession::CNetworkSession(void)
{
	memset(&mAcceptOverlapped, 0, sizeof(mAcceptOverlapped));
	memset(&mReadOverlapped, 0, sizeof(mReadOverlapped));
	memset(&mWriteOverlapped, 0, sizeof(mWriteOverlapped));

	memset(mReadBuffer, 0, sizeof(mReadBuffer));
	memset(&mUdpRemoteInfo, 0, sizeof(mUdpRemoteInfo));

	m_hSocket						= NULL;
	mReliableUdpThreadHandle		= NULL;
	mReliableUdpThreadStartupEvent	= NULL;
	mReliableUdpThreadDestroyEvent	= NULL;
	mReliableUdpThreadWakeUpEvent	= NULL;
	mReliableUdpWriteCompleteEvent	= NULL;

	mIsReliableUdpSending			= FALSE;

	mAcceptOverlapped.IoType		= IO_ACCEPT;
	mReadOverlapped.IoType			= IO_READ;
	mWriteOverlapped.IoType			= IO_WRITE;

	mAcceptOverlapped.Object		= this;
	mReadOverlapped.Object			= this;
	mWriteOverlapped.Object			= this;
}

CNetworkSession::~CNetworkSession(void)
{

}

BOOL CNetworkSession::Begin(void)
{
	CThreadSync Sync;

	if (m_hSocket)
		return FALSE;

	memset(mReadBuffer, 0, sizeof(mReadBuffer));
	memset(&mUdpRemoteInfo, 0, sizeof(mUdpRemoteInfo));

	m_hSocket							= NULL;
	mReliableUdpThreadHandle		= NULL;
	mReliableUdpThreadStartupEvent	= NULL;
	mReliableUdpThreadDestroyEvent	= NULL;
	mReliableUdpThreadWakeUpEvent	= NULL;
	mReliableUdpWriteCompleteEvent	= NULL;

	mIsReliableUdpSending			= FALSE;

	return TRUE;
}

BOOL CNetworkSession::End(void)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	closesocket(m_hSocket);

	m_hSocket					= NULL;

	if (mReliableUdpThreadHandle)
	{
		SetEvent(mReliableUdpThreadDestroyEvent);

		WaitForSingleObject(mReliableUdpThreadHandle, INFINITE);

		CloseHandle(mReliableUdpThreadHandle);
		mReliableUdpThreadHandle = NULL;
	}

	if (mReliableUdpThreadDestroyEvent)
	{
		CloseHandle(mReliableUdpThreadDestroyEvent);
		mReliableUdpThreadDestroyEvent = NULL;
	}

	if (mReliableUdpThreadStartupEvent)
	{
		CloseHandle(mReliableUdpThreadStartupEvent);
		mReliableUdpThreadStartupEvent = NULL;
	}

	if (mReliableUdpThreadWakeUpEvent)
	{
		CloseHandle(mReliableUdpThreadWakeUpEvent);
		mReliableUdpThreadWakeUpEvent = NULL;
	}

	if (mReliableUdpWriteCompleteEvent)
	{
		CloseHandle(mReliableUdpWriteCompleteEvent);
		mReliableUdpWriteCompleteEvent = NULL;
	}

	mReliableWriteQueue.End();

	return TRUE;
}

BOOL CNetworkSession::Listen(USHORT port, INT backLog)
{
	CThreadSync Sync;

	if (port <= 0 || backLog <= 0)
		return FALSE;

	if (!m_hSocket)
		return FALSE;

	SOCKADDR_IN ListenSocketInfo;

	ListenSocketInfo.sin_family				= AF_INET;
	ListenSocketInfo.sin_port				= htons(port);
	ListenSocketInfo.sin_addr.S_un.S_addr	= htonl(INADDR_ANY);

	if (bind(m_hSocket, (struct sockaddr*) &ListenSocketInfo, sizeof(SOCKADDR_IN)) == SOCKET_ERROR)
	{
		End();

		return FALSE;
	}

	if (listen(m_hSocket, backLog) == SOCKET_ERROR)
	{
		End();

		return FALSE;
	}

	LINGER Linger;
	Linger.l_onoff	= 1;
	Linger.l_linger = 0;

	if (setsockopt(m_hSocket, SOL_SOCKET, SO_LINGER, (char*) &Linger, sizeof(LINGER)) == SOCKET_ERROR)
	{
		End();

		return FALSE;
	}

	return TRUE;
}

BOOL CNetworkSession::Accept(SOCKET listenSocket)
{
	CThreadSync Sync;

	if (!listenSocket)
		return FALSE;

	if (m_hSocket)
		return FALSE;

	m_hSocket	= WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);

	if (m_hSocket == INVALID_SOCKET)
	{
		End();

		return FALSE;
	}

	//BOOL NoDelay = TRUE;
	//setsockopt(m_hSocket, IPPROTO_TCP, TCP_NODELAY, (const char FAR *)&NoDelay, sizeof(NoDelay));

	if (!AcceptEx(listenSocket, 
				  m_hSocket,
				  mReadBuffer, 
				  0,
				  sizeof(sockaddr_in) + 16,
				  sizeof(sockaddr_in) + 16,
				  NULL,
				  &mAcceptOverlapped.Overlapped))
	{
		if (WSAGetLastError() != ERROR_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
		{
			End();

			return FALSE;
		}
	}

	return TRUE;
}

BOOL CNetworkSession::InitializeReadForIocp(void)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	WSABUF	WsaBuf;
	DWORD	ReadBytes	= 0;
	DWORD	ReadFlag	= 0;

	WsaBuf.buf			= (CHAR*) mReadBuffer;
	WsaBuf.len			= MAX_BUFFER_LENGTH;

	INT		ReturnValue = WSARecv(m_hSocket,
		&WsaBuf,
		1,
		&ReadBytes,
		&ReadFlag,
		&mReadOverlapped.Overlapped,
		NULL);

	if (ReturnValue == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	return TRUE;
}

BOOL CNetworkSession::ReadForIocp(BYTE *data, DWORD &dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!data || dataLength <= 0)
		return FALSE;

	memcpy(data, mReadBuffer, dataLength);

	return TRUE;
}

BOOL CNetworkSession::ReadForEventSelect(BYTE *data, DWORD &dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!data)
		return FALSE;

	if (!m_hSocket)
		return FALSE;

	WSABUF	WsaBuf;
	DWORD	ReadBytes	= 0;
	DWORD	ReadFlag	= 0;

	WsaBuf.buf			= (CHAR*) mReadBuffer;
	WsaBuf.len			= MAX_BUFFER_LENGTH;

	INT		ReturnValue = WSARecv(m_hSocket,
		&WsaBuf,
		1,
		&ReadBytes,
		&ReadFlag,
		&mReadOverlapped.Overlapped,
		NULL);

	if (ReturnValue == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	memcpy(data, mReadBuffer, ReadBytes);
	dataLength = ReadBytes;

	return TRUE;
}

BOOL CNetworkSession::Write(BYTE *data, DWORD dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!data || dataLength <=0)
		return FALSE;

	WSABUF	WsaBuf;
	DWORD	WriteBytes	= 0;
	DWORD	WriteFlag	= 0;

	WsaBuf.buf			= (CHAR*) data;
	WsaBuf.len			= dataLength;

	TCHAR szRemoteIP[20] = {0x00,};
	USHORT nRemotePort = 0;

	if(GetRemoteIP(szRemoteIP, nRemotePort))
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "������ ���� IP[%s] PORT[%d]", szRemoteIP, nRemotePort);
	}
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "�۽� ������", data, dataLength);

	INT	nReturnValue	= WSASend(m_hSocket,
								  &WsaBuf,
								  1,
								  &WriteBytes,
								  WriteFlag,
								  &mWriteOverlapped.Overlapped,
								  NULL);

	DWORD dwError = WSAGetLastError();
	if (nReturnValue == SOCKET_ERROR && dwError != WSA_IO_PENDING && dwError != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	return TRUE;
}

BOOL CNetworkSession::Connect(LPSTR address, USHORT port)
{
	CThreadSync Sync;

	if (!address || port <= 0)
		return FALSE;

	if (!m_hSocket)
		return FALSE;

	SOCKADDR_IN RemoteAddressInfo;

	RemoteAddressInfo.sin_family			= AF_INET;
	RemoteAddressInfo.sin_port				= htons(port);
	RemoteAddressInfo.sin_addr.S_un.S_addr	= inet_addr(address);

	if (WSAConnect(m_hSocket, (LPSOCKADDR) &RemoteAddressInfo, sizeof(SOCKADDR_IN), NULL, NULL, NULL, NULL) == SOCKET_ERROR)
	{
		DWORD dwError = WSAGetLastError();
		if (dwError != WSAEWOULDBLOCK)
		{
			End();

			return FALSE;
		}
	}

	return TRUE;
}

BOOL CNetworkSession::TcpBind(void)
{
	CThreadSync Sync;

	if (m_hSocket)
		return FALSE;

	m_hSocket	= WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
	
	if (m_hSocket == INVALID_SOCKET)
		return FALSE;

	//BOOL NoDelay = TRUE;
	//setsockopt(m_hSocket, IPPROTO_TCP, TCP_NODELAY, (const char FAR *)&NoDelay, sizeof(NoDelay));
	return TRUE;
}

BOOL CNetworkSession::GetLocalIP(WCHAR* pIP)
{
	CThreadSync Sync;

	if(!m_hSocket)
		return FALSE;

	CHAR szIP[20] = {0x00,};

	memset(szIP, 0x00, sizeof(szIP));
	BOOL bResult = GetLocalIP(szIP);
	if(bResult)
	{
		if(MultiByteToWideChar(CP_ACP, 0, szIP, -1, pIP, 32) > 0)
			return TRUE;
	}
	
	return FALSE;
}

BOOL CNetworkSession::GetLocalIP(TCHAR* pIP)
{
	CThreadSync Sync;
	
	
	// ȣ��Ʈ�� ����� IP �ּ� �߿��� default gw �� ������ ��Ʈ��ũ�� �����ϴ� IP �ּҸ� ã�Ƴ���.
	//	BOOL bResult = FALSE;
	DWORD dwErr, dwAdapterInfoSize = 0;
	PIP_ADAPTER_INFO pAdapterInfo, pAdapt;
	PIP_ADDR_STRING  pAddrStr;
	
	
	if( ( dwErr = GetAdaptersInfo( NULL, &dwAdapterInfoSize ) ) != 0 )
	{
		if( dwErr != ERROR_BUFFER_OVERFLOW )
		{
			return FALSE;
		}
		// QQQ: ERROR_BUFFER_OVERFLOW �� ��쿡�� ��� ó������??
	}
	
	// Allocate memory from sizing information
	if( ( pAdapterInfo = (PIP_ADAPTER_INFO) GlobalAlloc( GPTR, dwAdapterInfoSize )) == NULL )
	{
		return FALSE;
	}
	
	// Get actual adapter information
	if( ( dwErr = GetAdaptersInfo( pAdapterInfo, &dwAdapterInfoSize ) ) != 0 )
	{
		GlobalFree(pAdapterInfo);
		return FALSE;
	}
	
	for( pAdapt = pAdapterInfo; pAdapt; pAdapt = pAdapt->Next )
	{
		if( pAdapt->Type == MIB_IF_TYPE_ETHERNET)
		{
			// QQQ: �������� default GW �� ���� �� ������, ����� ù��° default GW �� �����Ѵ�.
			if( strlen( pAdapt->GatewayList.IpAddress.String ) > 0 )
			{
				DWORD dwGwIp = 0;
				DWORD dwMask = 0;
				DWORD dwIp = 0;
				DWORD dwGwNetwork = 0;
				DWORD dwNetwork = 0;
				
				dwGwIp = inet_addr( pAdapt->GatewayList.IpAddress.String );
				
				//printf( "Gateway address = [%s] ", pAdapt->GatewayList.IpAddress.String );
				//printf( "Gateway mask = [%s] ", pAdapt->GatewayList.IpMask.String );
				
				for( pAddrStr = &(pAdapt->IpAddressList); pAddrStr; pAddrStr = pAddrStr->Next )
				{
					if( strlen(pAddrStr->IpAddress.String) > 0 )
					{
						dwIp = inet_addr( pAddrStr->IpAddress.String );
						dwMask = inet_addr( pAddrStr->IpMask.String );
						dwNetwork = dwIp & dwMask;
						dwGwNetwork = dwGwIp & dwMask;
						
						//printf( "IP address = [%s], network = %08x ", pAddrStr->IpAddress.String, dwNetwork );
						
						if( dwGwNetwork == dwNetwork )
						{
							strcpy(pIP, pAddrStr->IpAddress.String);
							printf( "ip address = %s ", pAddrStr->IpAddress.String );
							GlobalFree(pAdapterInfo);
							return TRUE;
						}
					}
				}
			}
		}
	}
	
	GlobalFree(pAdapterInfo);
	return FALSE;
}

USHORT CNetworkSession::GetLocalPort(void)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return 0;

	SOCKADDR_IN Addr;
	ZeroMemory(&Addr, sizeof(Addr));

	INT AddrLength = sizeof(Addr);
	if (getsockname(m_hSocket, (sockaddr*) &Addr, &AddrLength) != SOCKET_ERROR)
		return ntohs(Addr.sin_port);

	return 0;
}

BOOL CNetworkSession::InitializeReadFromForIocp(void)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	WSABUF		WsaBuf;
	DWORD		ReadBytes				= 0;
	DWORD		ReadFlag				= 0;
	INT			RemoteAddressInfoSize	= sizeof(mUdpRemoteInfo);

	WsaBuf.buf			= (CHAR*) mReadBuffer;
	WsaBuf.len			= MAX_BUFFER_LENGTH;

	INT		ReturnValue = WSARecvFrom(m_hSocket,
		&WsaBuf,
		1,
		&ReadBytes,
		&ReadFlag,
		(SOCKADDR*) &mUdpRemoteInfo,
		&RemoteAddressInfoSize,
		&mReadOverlapped.Overlapped,
		NULL);

	if (ReturnValue == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	return TRUE;
}

BOOL CNetworkSession::ReadFromForIocp(LPSTR remoteAddress, USHORT &remotePort, BYTE *data, DWORD &dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!data || dataLength <= 0)
		return FALSE;

	memcpy(data, mReadBuffer, dataLength);

	//memcpy(remoteAddress, inet_ntoa(mUdpRemoteInfo.sin_addr), 32);
	strcpy(remoteAddress, inet_ntoa(mUdpRemoteInfo.sin_addr));
	remotePort	= ntohs(mUdpRemoteInfo.sin_port);

	USHORT Ack = 0;
	memcpy(&Ack, mReadBuffer, sizeof(USHORT));

	if (Ack == 9999)
	{
		SetEvent(mReliableUdpWriteCompleteEvent);

		return FALSE;
	}
	else
	{
		Ack = 9999;
		WriteTo2(remoteAddress, remotePort, (BYTE*) &Ack, sizeof(USHORT));
	}

	return TRUE;
}

BOOL CNetworkSession::ReadFromForEventSelect(LPSTR remoteAddress, USHORT &remotePort, BYTE *data, DWORD &dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!data)
		return FALSE;

	if (!m_hSocket)
		return FALSE;

	WSABUF		WsaBuf;
	DWORD		ReadBytes				= 0;
	DWORD		ReadFlag				= 0;
	INT			RemoteAddressInfoSize	= sizeof(mUdpRemoteInfo);

	WsaBuf.buf			= (CHAR*) mReadBuffer;
	WsaBuf.len			= MAX_BUFFER_LENGTH;

	INT		ReturnValue = WSARecvFrom(m_hSocket,
		&WsaBuf,
		1,
		&ReadBytes,
		&ReadFlag,
		(SOCKADDR*) &mUdpRemoteInfo,
		&RemoteAddressInfoSize,
		&mReadOverlapped.Overlapped,
		NULL);

	if (ReturnValue == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	memcpy(data, mReadBuffer, ReadBytes);
	dataLength	= ReadBytes;

	//memcpy(remoteAddress, inet_ntoa(mUdpRemoteInfo.sin_addr), 32);
	strcpy(remoteAddress, inet_ntoa(mUdpRemoteInfo.sin_addr));
	remotePort	= ntohs(mUdpRemoteInfo.sin_port);

	USHORT Ack = 0;
	memcpy(&Ack, mReadBuffer, sizeof(USHORT));

	if (Ack == 9999)
	{
		SetEvent(mReliableUdpWriteCompleteEvent);

		return FALSE;
	}
	else
	{
		Ack = 9999;
		WriteTo2(remoteAddress, remotePort, (BYTE*) &Ack, sizeof(USHORT));
	}

	return TRUE;
}

BOOL CNetworkSession::WriteTo(LPCSTR remoteAddress, USHORT remotePort, BYTE *data, DWORD dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!remoteAddress || remotePort <= 0 || !data || dataLength <=0)
		return FALSE;

	if (!mReliableWriteQueue.Push(this, data, dataLength, remoteAddress, remotePort))
		return FALSE;

	if (!mIsReliableUdpSending)
	{
		mIsReliableUdpSending = TRUE;
		SetEvent(mReliableUdpThreadWakeUpEvent);
	}

	return TRUE;
}

BOOL CNetworkSession::WriteTo2(LPSTR remoteAddress, USHORT remotePort, BYTE *data, DWORD dataLength)
{
	CThreadSync Sync;

	if (!m_hSocket)
		return FALSE;

	if (!remoteAddress || remotePort <= 0 || !data || dataLength <=0)
		return FALSE;

	WSABUF		WsaBuf;
	DWORD		WriteBytes					= 0;
	DWORD		WriteFlag					= 0;

	SOCKADDR_IN	RemoteAddressInfo;
	INT			RemoteAddressInfoSize		= sizeof(RemoteAddressInfo);

	WsaBuf.buf								= (CHAR*) data;
	WsaBuf.len								= dataLength;

	RemoteAddressInfo.sin_family			= AF_INET;
	RemoteAddressInfo.sin_addr.S_un.S_addr	= inet_addr(remoteAddress);
	RemoteAddressInfo.sin_port				= htons(remotePort);

	INT		ReturnValue	= WSASendTo(m_hSocket,
		&WsaBuf,
		1,
		&WriteBytes,
		WriteFlag,
		(SOCKADDR*) &RemoteAddressInfo,
		RemoteAddressInfoSize,
		&mWriteOverlapped.Overlapped,
		NULL);

	if (ReturnValue == SOCKET_ERROR && WSAGetLastError() != WSA_IO_PENDING && WSAGetLastError() != WSAEWOULDBLOCK)
	{
		End();

		return FALSE;
	}

	return TRUE;
}

BOOL CNetworkSession::GetRemoteIP(TCHAR *pIP, USHORT &nPort)
{
	CThreadSync Sync;
	
	if (!pIP)
		return FALSE;
	
	if (!m_hSocket)
		return FALSE;
	
	
	SOCKADDR_IN sockAddr;
	ZeroMemory(&sockAddr, sizeof(sockAddr));
	int size = sizeof( sockAddr );
	
	if(::getpeername( m_hSocket, ( SOCKADDR* )&sockAddr, &size ) != SOCKET_ERROR )
	{
		strcpy(pIP, ::inet_ntoa(sockAddr.sin_addr));
		nPort = ntohs(sockAddr.sin_port);
		return TRUE;
	}
	else
	{
		DWORD dwError = WSAGetLastError();
	}
	
	return FALSE;
}


BOOL CNetworkSession::GetRemoteAddressAfterAccept(LPTSTR remoteAddress, USHORT &remotePort)
{
	CThreadSync Sync;

	if (!remoteAddress)
		return FALSE;

	sockaddr_in		*Local			= NULL;
	INT				LocalLength		= 0;

	sockaddr_in		*Remote			= NULL;
	INT				RemoteLength	= 0;

	GetAcceptExSockaddrs(mReadBuffer,
						 0, 
						 sizeof(sockaddr_in) + 16,
						 sizeof(sockaddr_in) + 16,
						 (sockaddr **) &Local,
						 &LocalLength,
						 (sockaddr **) &Remote,
						 &RemoteLength);
	if(Remote)
	{
		_tcscpy(remoteAddress, (LPTSTR)(inet_ntoa(Remote->sin_addr)));
		remotePort = ntohs(Remote->sin_port);
	}

	return TRUE;
}

SOCKET CNetworkSession::GetSocket(void)
{
	CThreadSync Sync;

	return m_hSocket;
}