// PollThread.h: interface for the CPollThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POLLTHREAD_H__50BD96A3_DEB1_4536_973B_142E185CC942__INCLUDED_)
#define AFX_POLLTHREAD_H__50BD96A3_DEB1_4536_973B_142E185CC942__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPollThread : public CWinThread  
{
	DECLARE_DYNCREATE(CPollThread)

public:
	void Push(HWND hSendWnd, LPBYTE lpData, DWORD dwLength);
	void Stop(BOOL bStop);
	void SetParentWnd(HWND hParentWnd);
	CPollThread();
	virtual ~CPollThread();

private:
	CCircularQueue	mWritePacketQueue;
};

#endif // !defined(AFX_POLLTHREAD_H__50BD96A3_DEB1_4536_973B_142E185CC942__INCLUDED_)
