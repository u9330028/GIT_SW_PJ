#pragma once

#include "CircularQueue.h"


enum IO_TYPE
{
	IO_READ = 1,
	IO_WRITE,
	IO_ACCEPT
};

typedef struct tagOERLAPPEDEX
{
	OVERLAPPED	Overlapped;	// OVERLAPPED ����ü
	IO_TYPE		IoType;		// ����ü Ÿ��
							// IO_TYPE ����
							// IO_READ : �б� �۾��� �� ���
							// IO_WRITE: ���� �۾��� �� ���
							// IO_ACCEPT: ACCEPT ���� �� ���
	LPVOID		Object;		// �θ� ��ü �ּ�
} OVERLAPPEDEX;

class CNetworkSession : public CMultiThreadSync<CNetworkSession>
{
public:
	CNetworkSession(void);
	virtual ~CNetworkSession(void);

private:
	OVERLAPPEDEX	mAcceptOverlapped;
	OVERLAPPEDEX	mReadOverlapped;
	OVERLAPPEDEX	mWriteOverlapped;

	BYTE			mReadBuffer[MAX_BUFFER_LENGTH];
	SOCKADDR_IN		mUdpRemoteInfo;

	SOCKET			m_hSocket;

	HANDLE			mReliableUdpThreadHandle;
	HANDLE			mReliableUdpThreadStartupEvent;
	HANDLE			mReliableUdpThreadDestroyEvent;
	HANDLE			mReliableUdpThreadWakeUpEvent;
	HANDLE			mReliableUdpWriteCompleteEvent;

	CCircularQueue	mReliableWriteQueue;

	BOOL			mIsReliableUdpSending;

public:
	BOOL			Begin(void);
	BOOL			End(void);

	BOOL			Listen(USHORT port, INT backLog);
	BOOL			Accept(SOCKET listenSocket);
	BOOL			TcpBind(void);
	BOOL			UdpBind(USHORT port);

	BOOL			GetLocalIP(WCHAR* pIP);
	BOOL			GetLocalIP(TCHAR* pIP);
	USHORT			GetLocalPort(void);
	BOOL			GetRemoteIP(TCHAR *pIP, USHORT &nPort);

	
	BOOL			InitializeReadForIocp(void);
	BOOL			ReadForIocp(BYTE *data, DWORD &dataLength);
	BOOL			ReadForEventSelect(BYTE *data, DWORD &dataLength);

	BOOL			Write(BYTE *data, DWORD dataLength);

	BOOL			InitializeReadFromForIocp(void);
	BOOL			ReadFromForIocp(LPSTR remoteAddress, USHORT &remotePort, BYTE *data, DWORD &dataLength);
	BOOL			ReadFromForEventSelect(LPSTR remoteAddress, USHORT &remotePort, BYTE *data, DWORD &dataLength);

	BOOL			WriteTo(LPCSTR remoteAddress, USHORT remotePort, BYTE *data, DWORD dataLength);
	BOOL			WriteTo2(LPSTR remoteAddress, USHORT remotePort, BYTE *data, DWORD dataLength);

	BOOL			Connect(LPSTR address, USHORT port);

	SOCKET			GetSocket(void);

	BOOL			GetRemoteAddressAfterAccept(LPTSTR remoteAddress, USHORT &remotePort);

	inline void		SetUdpWriteCompleteEvent(void)
	{
		SetEvent(mReliableUdpWriteCompleteEvent);
	}
};
