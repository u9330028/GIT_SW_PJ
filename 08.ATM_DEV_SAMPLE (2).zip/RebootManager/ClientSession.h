#pragma once

class CClientSession : public CEventSelect
{
public:
//	CClientSession(void);
	CClientSession(HWND hParentWnd);
	virtual ~CClientSession(void);

		void			ProcessPacket();

private:
	CPacketSession	mSession;
	CCircularQueue	mReadPacketQueue;

public:
	BOOL			Begin(LPSTR remoteAddress, USHORT remotePort);
	BOOL			End(void);

	BOOL			GetLocalIP(WCHAR* pIP);
	BOOL			GetLocalIP(TCHAR* pIP);
	USHORT			GetLocalPort(void);

	BOOL			ReadPacket(DWORD &protocol, BYTE *packet, DWORD &packetLength);
	BOOL			WritePacket(const BYTE *pData, DWORD dwDataLength);
	BOOL			WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength);
	BOOL			WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength);

public:
	void			ClearReceiveTimeOut();
	BOOL			SendWriteErrorPacket();
	BOOL			SendFormatErrorPacket();
	void			SetParentWnd(HWND hParentWnd);

protected:
	void			OnIoRead(void);
	void			OnIoConnected(DWORD dwError);	// Ŭ���̾�Ʈ�� ���� �����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoDisconnected(void);			// Ŭ���̾�Ʈ�� ���� ����Ǿ����� ȣ��Ǵ� �����Լ�
	void			OnIoError(DWORD dwError);		// ���� �߻��� ȣ��Ǵ� �����Լ�

protected:
	void			SetReceiveTimeOut(DWORD dwTimeOut);
//	void			ProcessPacket();
	void			SendTextToParent(LPCTSTR lpszText);
	void			SendPacketToParent(LPCTSTR lpszText);
	void			SendMessageToParent(UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	HWND			m_hParentWnd;
	UINT			m_nCurrentState;
};
