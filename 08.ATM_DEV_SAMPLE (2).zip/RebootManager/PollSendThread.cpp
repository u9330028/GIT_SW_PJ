// PollSendThread.cpp : implementation file
//

#include "stdafx.h"
#include "RebootManager.h"
#include "PollSendThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPollSendThread

IMPLEMENT_DYNCREATE(CPollSendThread, CWinThread)

CPollSendThread::CPollSendThread()
{
	m_hParentWnd = NULL;
	m_hDestroyEventHandle = NULL;
	m_hQueueEventHandle = NULL;

	m_pWritePacketQueue = new CCircularQueue;
}

CPollSendThread::~CPollSendThread()
{
	if(m_pWritePacketQueue)
	{
		delete m_pWritePacketQueue;
		m_pWritePacketQueue = NULL;
	}

	if(m_hDestroyEventHandle)
	{
		CloseHandle(m_hDestroyEventHandle);
		m_hDestroyEventHandle = NULL;
	}

	if(m_hQueueEventHandle)
	{
		CloseHandle(m_hQueueEventHandle);
		m_hQueueEventHandle = NULL;
	}
}

BOOL CPollSendThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	m_hDestroyEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	if (m_hDestroyEventHandle == NULL)
	{
		return FALSE;
	}

	//m_hQueueEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	//�޴��� �������� ����
	//2010�� 12�� 15�� 
	m_hQueueEventHandle = CreateEvent(0, TRUE, FALSE, 0);
	if (m_hQueueEventHandle == NULL)
	{
		return FALSE;
	}

	return TRUE;
}

int CPollSendThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CPollSendThread, CWinThread)
	//{{AFX_MSG_MAP(CPollSendThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPollSendThread message handlers


void CPollSendThread::SetParentWnd(HWND hParentWnd)
{
	m_hParentWnd = hParentWnd;
}

void CPollSendThread::Stop()
{
	SetEvent(m_hDestroyEventHandle);
}

void CPollSendThread::Push(CWnd *pNotifyWnd, WORD wCommand, WORD wParam, LPBYTE lpData, DWORD dwLength)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::Push] WND:[%08x] CMD:%d PARAM:%d DATA:%s LENGTH:%d START"),
		pNotifyWnd, wCommand, wParam, lpData, dwLength);
	
	DWORD dwProtocol = MAKELONG(wCommand, wParam);
	m_pWritePacketQueue->Push((void*)pNotifyWnd, dwProtocol, lpData, dwLength);
	SetEvent(m_hQueueEventHandle);

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::Push] WND:[%08x] CMD:%d PARAM:%d DATA:%s LENGTH:%d END"),
		pNotifyWnd, wCommand, wParam, lpData, dwLength);
}

int CPollSendThread::Run() 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL bStop = FALSE;
	DWORD	dwEventID = 0;
	HANDLE	hThreadEvents[2] = {m_hDestroyEventHandle, m_hQueueEventHandle};
	
	while (TRUE)
	{
		dwEventID = ::WaitForMultipleObjects(2, hThreadEvents, FALSE, INFINITE);
		switch (dwEventID)
		{
		case WAIT_OBJECT_0:
			AfxEndThread(0);
			return CWinThread::Run();
			
		case WAIT_OBJECT_0 + 1:
			ResetEvent(m_hQueueEventHandle);
			ProcessPacket();
			
			break;

		default:
			break;
		}
	}

	AfxEndThread(0);
	return CWinThread::Run();
}

BOOL CPollSendThread::Pop(CWnd **pNotifyWnd, WORD &wCommand, WORD &wParam, CString &strData)
{
	void *Object = NULL;
	DWORD dwProtocol = 0;
	DWORD dwLength = 0;
	TCHAR szWindowTitle[100] = {0x00,};

	memset(szWindowTitle, 0x00, sizeof(szWindowTitle));
	BOOL bExist = m_pWritePacketQueue->Pop(&Object, dwProtocol, (LPBYTE) szWindowTitle, dwLength);
	if(bExist)
	{
		*pNotifyWnd = (CWnd*) Object;
		wCommand = LOWORD(dwProtocol);
		wParam = HIWORD(dwProtocol);
		strData = CString(szWindowTitle, dwLength);
	}

	return bExist;
}

void CPollSendThread::ProcessPacket()
{
//	HWND hNotifyWnd = NULL;
	WORD wCommand = 0;
	WORD wParam = 0;
	BOOL bResult = FALSE;
	CWnd *pNotifyWnd = NULL;
	CString strData = _T("");

	while(TRUE)
	{
		pNotifyWnd = NULL;
		wCommand = 0;
		strData = _T("");

		if(!Pop(&pNotifyWnd, wCommand, wParam, strData))
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::ProcessPacket] ó���� �����Ͱ� �������� ����"));
			break;
		}

		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::ProcessPacket] WND:%08x CMD:%d PARAM:%d DATA[%s]"),
			pNotifyWnd, wCommand, wParam, strData);

		switch(wCommand)
		{
		case POLL_COMMAND:
			bResult = SendPollPacket(strData);
			if(pNotifyWnd)
			{
				((CRebootManagerDlg*) pNotifyWnd)->PollSendResult(wParam, bResult);
			}
			break;

		case POLL_RESPONSE:
			ReceivePollPacket(pNotifyWnd, wParam, strData);
			break;

		default:
			break;
		}
	}
}

BOOL CPollSendThread::SendPollPacket(CString strWindowTitle)
{
	HWND hAgentWnd = ::FindWindow(NULL, strWindowTitle);
	if(hAgentWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ���� FINDWINDOW FAIL"), strWindowTitle);
		return FALSE;
	}

	int nResult = 0;
	DWORD dwResult = 0;
	TCHAR szCommand[10] = {0x00,};
	COPYDATASTRUCT cds;
	
	memset(szCommand, 0x00, sizeof(szCommand));
	wsprintf(szCommand, _T("%s"), _T("11"));

	cds.dwData = POLL_COMMAND;
	cds.lpData = szCommand;
	cds.cbData = lstrlen(szCommand) + 1;

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
	nResult = ::SendMessageTimeout(hAgentWnd, 
								   WM_COPYDATA,
								   0,
								   (LPARAM)&cds,
								   SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG,
								   ELAPSE_POLL_SEND,
								   &dwResult);
	
	if(nResult == 0)
	{
		DWORD dwError = GetLastError();
		if(dwError == 0)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����(Ÿ�Ӿƿ�)"), strWindowTitle);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����(%s)"),
				strWindowTitle, CErrorMessage::GetErrorMessage(dwError));
		}

		return FALSE;
	}
	else
	{
		//CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
		return TRUE;
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
	return FALSE;
}

BOOL CPollSendThread::ReceivePollPacket(CWnd *pNotifyWnd, WORD wPollID, CString strData)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::ReceivePollPacket] WND:%08x ID:%d DATA[%s]"),
		pNotifyWnd, wPollID, strData);

	switch(wPollID)
	{
	case POLL_IIM_RESPONSE:
		if(pNotifyWnd)
		{
			((CRebootManagerDlg*) pNotifyWnd)->KillTimer(TIMER_POLL_IIM_FAIL);
		}
		break;

	case POLL_IPF_RESPONSE:
		if(pNotifyWnd)
		{
			((CRebootManagerDlg*) pNotifyWnd)->KillTimer(TIMER_POLL_IPF_FAIL);
		}
		break;

	case POLL_IBP_RESPONSE:
		if(pNotifyWnd)
		{
			((CRebootManagerDlg*) pNotifyWnd)->KillTimer(TIMER_POLL_IBP_FAIL);
		}
		break;

	case POLL_ADP_RESPONSE:
		if(pNotifyWnd)
		{
			((CRebootManagerDlg*) pNotifyWnd)->KillTimer(TIMER_POLL_ADP_FAIL);
		}
		break;
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CPollSendThread::ReceivePollPacket] WND:%08x ID:%d DATA[%s] END"),
		pNotifyWnd, wPollID, strData);
	return TRUE;
}
