#if !defined(AFX_ERRORSCREENDLG_H__25BA4645_9397_4A6B_B78C_58DB93F87B63__INCLUDED_)
#define AFX_ERRORSCREENDLG_H__25BA4645_9397_4A6B_B78C_58DB93F87B63__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ErrorScreenDlg.h : header file
//
#define     SAVE_BMP    0
#define     SAVE_JPG    1
#define     SAVE_PNG    2
#define     SAVE_GIF    3

/////////////////////////////////////////////////////////////////////////////
// CErrorScreenDlg dialog

class CErrorScreenDlg : public CDialog
{
// Construction
public:
	CErrorScreenDlg(CWnd* pParent = NULL);   // standard constructor
	~CErrorScreenDlg();

// Dialog Data
	//{{AFX_DATA(CErrorScreenDlg)
	enum { IDD = IDD_DIALOG_ERROR };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorScreenDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CErrorScreenDlg)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	void CaptureScreen();
	void SetErrorText(CString strMessage);
	CString GetFilePath();
	int GetMonitorCount();
	
	void ResetMonitorCount();
	void IncreaseMonitorCount();

	static BOOL CALLBACK MonitorCaptureProc(HMONITOR hMonitor, HDC hMonitorDC, LPRECT lpMonitorRect, LPARAM lParam);


protected:
	HBITMAP m_hBitmap;
	Bitmap *m_pBitmapBG;
	CString m_strMessage;
	CFont	m_FontMessage;
	CString m_strFilePath;
	UINT	m_nMonitorCount;

	void DrawMessage(HDC hDC);
	void DrawBackground();
	HBITMAP Create32BitBitmap(HDC hDC, int cx, int cy);
	Bitmap* ImageFromResource(IN HINSTANCE hInst, IN const LPTSTR pName, IN const LPTSTR pType);
	int GetEncoderClsid(const WCHAR* format, CLSID* pClsid);
	BOOL CaptureToImage(HDC hDC, LPCSTR szFilePath, int nSaveFormat, int nLeft,
							int nTop, int nWidth, int nHeight, int nJpgQuality/*1-100*/);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ERRORSCREENDLG_H__25BA4645_9397_4A6B_B78C_58DB93F87B63__INCLUDED_)
