// ServiceManager.cpp: implementation of the CServiceManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RebootManager.h"
#include "ServiceManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CServiceManager::CServiceManager()
{
	m_strPrevComputerName = "";
	m_strLineBuffer = "";
	m_bIsMoreData = FALSE;
}

CServiceManager::~CServiceManager()
{

}

int CServiceManager::GetServiceStatus(CString strComputerName, DWORD dwServiceType, LPSTR lpszEnumService, DWORD dwEnumServiceBufferSize)
{
	int nRetVal = 0;
	
	CString strTempBuffer, strLineBuffer = "";

	///////////////////////////////////////////////////////////////////////////
	// �ٷ� ������ ���� ��ǻ�Ϳ� ���� �����͸� ���� ���� �ִٸ�
	if (m_strPrevComputerName == strComputerName && m_bIsMoreData == TRUE)
	{
		// lpszEnumService�� ũ��� ??	
		nRetVal = m_strLineBuffer.GetLength();
		if (lpszEnumService != NULL	&& nRetVal <= (long)dwEnumServiceBufferSize)
		{
			CopyMemory(lpszEnumService, m_strLineBuffer, nRetVal);
		
			m_bIsMoreData = FALSE;
			m_strPrevComputerName = "";
			m_strLineBuffer = "";

			return nRetVal;
		}
	}

	SC_HANDLE schSCManager = ::OpenSCManager(strComputerName, 0, SC_MANAGER_ALL_ACCESS);
	if (schSCManager) 
	{
		//////////////////////////////////////////
		// EnumServicesStatus
        ENUM_SERVICE_STATUS essServiceStatus[SZ_ENUM_BUF];
		DWORD   dwBufSize = sizeof(essServiceStatus);
		DWORD   dwBytesNeeded      = 0;
		DWORD   dwServicesReturned = 0;
		DWORD   dwResumeHandle     = 0;
		DWORD   dwI                = 0;
		BOOLEAN bFound = FALSE;
		
		BOOL bRetVal = EnumServicesStatus(schSCManager,
										dwServiceType,
										SERVICE_STATE_ALL,
										NULL,
										NULL,
										&dwBytesNeeded,
										&dwServicesReturned,
										&dwResumeHandle);
		if (GetLastError() == ERROR_MORE_DATA)
		{
			if (EnumServicesStatus(schSCManager,
									dwServiceType,
									SERVICE_STATE_ALL,	// SERVICE_ACTIVE,
									(LPENUM_SERVICE_STATUS)&essServiceStatus,
									dwBufSize,
									&dwBytesNeeded,
									&dwServicesReturned,
									&dwResumeHandle))
			{ 
				for (dwI = 0; dwI < dwServicesReturned; dwI++)     
				{ 
					SC_HANDLE schService =	::OpenService(schSCManager, 
														essServiceStatus[dwI].lpServiceName, 
														SERVICE_ALL_ACCESS);

					if( schService ) 
					{
						QUERY_SERVICE_CONFIG qscBuf[4096]; 
						DWORD dwBytesNeeded; 
						if (QueryServiceConfig(schService, 
												qscBuf, 
												4096, 
												&dwBytesNeeded)) 
						{
							// ���� ���
							strTempBuffer.Format("%s;", essServiceStatus[dwI].lpDisplayName);
							strLineBuffer += strTempBuffer;

							// ���񽺸�
							strTempBuffer.Format("%s;", essServiceStatus[dwI].lpServiceName);
							strLineBuffer += strTempBuffer;

							// ����
							strTempBuffer.Format("%s;", GetCurrentServiceStateStr(essServiceStatus[dwI].ServiceStatus.dwCurrentState));
							strLineBuffer += strTempBuffer;

							// ���� Ÿ��
							strTempBuffer.Format("%s;", GetServiceNodeTypeStr(essServiceStatus[dwI].ServiceStatus.dwServiceType));
							strLineBuffer += strTempBuffer;

							// ���� ����
							strTempBuffer.Format("%s;", GetServiceStartTypeStr(qscBuf->dwStartType));
							strLineBuffer += strTempBuffer;

							// ��� ����
							strTempBuffer.Format("%s;", GetServiceErrCtrlTypeStr(qscBuf->dwErrorControl));
							strLineBuffer += strTempBuffer;

							// ���
							strTempBuffer.Format("%s;", qscBuf->lpBinaryPathName);
							strLineBuffer += strTempBuffer;

							// ���� ���
							strTempBuffer.Format("%ld;", essServiceStatus[dwI].ServiceStatus.dwControlsAccepted);
							strLineBuffer += strTempBuffer;

							// �ε���� �׷�
							strTempBuffer.Format("%s;", qscBuf->lpLoadOrderGroup);
							strLineBuffer += strTempBuffer;

							// �±� ID
							strTempBuffer.Format("%ld;", qscBuf->dwTagId);
							strLineBuffer += strTempBuffer;

							// ����
							strTempBuffer.Format("%s;", qscBuf->lpDependencies);
							strLineBuffer += strTempBuffer;

							// �α׿� ����
							strTempBuffer.Format("%s", qscBuf->lpServiceStartName);
							if (strTempBuffer == "") strTempBuffer = "LocalSystem";
							strLineBuffer += strTempBuffer;		strLineBuffer += ";|";
						}
						::CloseServiceHandle(schService);
					} 
					else 
					{
						TCHAR szErr[256] = {0x00,};
						CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenService failed - %s"), GetLastErrorText(szErr, sizeof(szErr)));						
#ifdef _DEBUG
						TRACE(TEXT("OpenService failed - %s\n"), szErr);
#endif
					}
				}
			}
			else
				nRetVal = 0;
		}
		//////////////////////////////////////////

		::CloseServiceHandle(schSCManager);
    }
	else 
	{
		TCHAR szErr[256] = {0x00,};
		CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenSCManager failed - %s"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
		TRACE(TEXT("OpenSCManager failed - %s\n"), szErr);
#endif
	}

	// lpszEnumService�� ũ��� ??	
	nRetVal = strLineBuffer.GetLength();
	if (lpszEnumService != NULL	&& nRetVal <= (long)dwEnumServiceBufferSize)
	{
		CopyMemory(lpszEnumService, strLineBuffer, nRetVal);
	}
	else
	{
		// if (lpszEnumService == NULL || dwEnumServiceBufferSize == 0)
		{
		m_bIsMoreData = TRUE;
		m_strPrevComputerName = strComputerName;
		m_strLineBuffer = strLineBuffer;
		}
	}


	return nRetVal;
}

BOOL CServiceManager::CheckServiceStatus(CString strComputerName, CString strServiceName, LONG lnChkState)
{
	BOOL bRet = FALSE;

	SERVICE_STATUS m_ssStatus;			// current status of the service

	SC_HANDLE schSCManager = ::OpenSCManager(strComputerName, 0, /*SC_MANAGER_CONNECT*/ SC_MANAGER_ALL_ACCESS);
	if (schSCManager) 
	{
		SC_HANDLE schService =	::OpenService(schSCManager, strServiceName, SERVICE_ALL_ACCESS);

		if( schService ) 
		{
			if (::QueryServiceStatus(schService, &m_ssStatus))
			{
				if (m_ssStatus.dwCurrentState == (DWORD)lnChkState) 
					bRet = TRUE;
				else
					bRet = FALSE;
			}
			::CloseServiceHandle(schService);
		} 
		else 
		{
			TCHAR szErr[256] = {0x00,};
			CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenService failed - %s"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
			TRACE(TEXT("OpenService failed - %s\n"), szErr);
#endif
		}

		::CloseServiceHandle(schSCManager);
    }
	else 
	{
		TCHAR szErr[256] = {0x00,};
		CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
		TRACE(TEXT("OpenSCManager failed - %s\n"), szErr);
#endif
	}

	return bRet;
}

///////////////////////////////////////////////////////////////////
// ���� ���� ���� ���
//
// ���� ������ format
// ���� ���, ���񽺸�, ����, ���� Ÿ��, ���� ����, ��� ����, ���, ���� ���, �ε���� �׷�, �±� ID, ����, �α׿� ����
//

BOOL CServiceManager::ControlServiceStatus(CString strComputerName, CString strServiceName, LONG lnCtrlCode)
{
	BOOL bRet = FALSE;

	SERVICE_STATUS m_ssStatus;			// current status of the service
	
	LONG lnAccessType = 0;
	
	switch (lnCtrlCode)
	{
	case SERVICE_CONTROL_START:			lnAccessType = SERVICE_START;			break;
    case SERVICE_CONTROL_STOP:  		lnAccessType = SERVICE_STOP;			break;
	case SERVICE_CONTROL_PAUSE:			lnAccessType = SERVICE_PAUSE_CONTINUE;	break;
    case SERVICE_CONTROL_CONTINUE: 		lnAccessType = SERVICE_PAUSE_CONTINUE;	break;
    case SERVICE_CONTROL_INTERROGATE:	lnAccessType = SERVICE_INTERROGATE;		break;
	case SERVICE_CONTROL_SHUTDOWN:		lnAccessType = SERVICE_STOP;			break;
    default:
		if (lnCtrlCode >= 128 && lnCtrlCode <= 255)
			lnAccessType = SERVICE_USER_DEFINED_CONTROL;
		else
			return FALSE;
		break;
	}

	SC_HANDLE schSCManager = ::OpenSCManager(strComputerName, 0, SC_MANAGER_ALL_ACCESS);
	if (schSCManager) 
	{
		SC_HANDLE schService =	::OpenService(schSCManager, strServiceName, SERVICE_ALL_ACCESS);

		if( schService ) 
		{
			int nRetVal = 0;
			if (lnCtrlCode == SERVICE_CONTROL_START)
				nRetVal = StartService(schService, 0, 0);
			else
				nRetVal = ControlService(schService, lnCtrlCode, &m_ssStatus);
         
			if (nRetVal != 0)
			{
				bRet = TRUE;
			}
			else
			{
				DWORD dwError = GetLastError();
				if(lnCtrlCode == SERVICE_CONTROL_STOP && dwError == ERROR_SERVICE_NOT_ACTIVE)
				{
					bRet = TRUE;
				}
				else
				{
					TCHAR szErr[256];
					CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CServiceManager::ControlServiceStatus] ControlService failed - %d:%s\n"), GetLastError(), GetLastErrorText(szErr, 256));
				}
			}
			
			if (lnCtrlCode == SERVICE_CONTROL_START)
				::Sleep(1000);

			::CloseServiceHandle(schService);
		} 
		else 
		{
			TCHAR szErr[256];
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CServiceManager::ControlServiceStatus] OpenService failed - %s\n"), GetLastErrorText(szErr, 256));
		}

		::CloseServiceHandle(schSCManager);
    }
	else 
	{
		TCHAR szErr[256];
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CServiceManager::ControlServiceStatus] OpenSCManager failed - %s\n"), GetLastErrorText(szErr,256));
	}

	return bRet;
}

CString CServiceManager::GetCurrentServiceStateStr(LONG lnCurrentState)
{   
	CString strStateStr;

	switch (lnCurrentState)
	{
	case SERVICE_RUNNING:			strStateStr = "����";				break;
	case SERVICE_STOPPED:			strStateStr = "����";				break;
	case SERVICE_PAUSED:			strStateStr = "��� ����";			break;
	case SERVICE_START_PENDING:		strStateStr = "���� �۾���";		break;
	case SERVICE_STOP_PENDING:		strStateStr = "���� �۾���";		break;
	case SERVICE_CONTINUE_PENDING:	strStateStr = "��� �۾���";		break;
	case SERVICE_PAUSE_PENDING:		strStateStr = "��� ���� �۾���";	break;
	default:						strStateStr = "�˼� ����";			break;
	}

	return strStateStr;
}

CString CServiceManager::GetServiceStartTypeStr(LONG lnStartServiceType)
{   
	CString strStartTypeStr;

	switch (lnStartServiceType)
	{
	case SERVICE_BOOT_START:			strStartTypeStr = "��Ʈ";				break;
	case SERVICE_SYSTEM_START:			strStartTypeStr = "�ý���";				break;
	case SERVICE_AUTO_START:			strStartTypeStr = "�ڵ�";				break;
	case SERVICE_DEMAND_START:			strStartTypeStr = "����";				break;
	case SERVICE_DISABLED:				strStartTypeStr = "��� ����";			break;
	default:							strStartTypeStr = "�˼� ����";			break;
	}

	return strStartTypeStr;
}

CString CServiceManager::GetServiceErrCtrlTypeStr(LONG lnErrCtrlType)
{   
	CString strErrCtrlStr;

	switch (lnErrCtrlType)
	{
	case SERVICE_ERROR_IGNORE:			strErrCtrlStr = "��� ����";			break;
	case SERVICE_ERROR_NORMAL:			strErrCtrlStr = "�Ϲ� ��� ó��";		break;
	case SERVICE_ERROR_SEVERE:			strErrCtrlStr = "Ư�� ��� ó��";		break;
	case SERVICE_ERROR_CRITICAL:		strErrCtrlStr = "�߿� ��� ó��";		break;
	default:							strErrCtrlStr = "�˼� ����";			break;
	}

	return strErrCtrlStr;
}

CString CServiceManager::GetServiceNodeTypeStr(LONG lnNodeType)
{   
	CString strNodeTypeStr;

	switch (lnNodeType)
	{
	case SERVICE_KERNEL_DRIVER:				strNodeTypeStr = "NT ����̽� ����̹�";	break;
	case SERVICE_FILE_SYSTEM_DRIVER:		strNodeTypeStr = "NT ���� �ý���";			break;
	case SERVICE_WIN32_OWN_PROCESS:			strNodeTypeStr = "WIN32 ���� ���μ���";		break;
	case SERVICE_WIN32_SHARE_PROCESS:		strNodeTypeStr = "WIN32 ���� ���μ���";		break;
	case SERVICE_ADAPTER:					strNodeTypeStr = "Adapter ����̹�";	break;
	case SERVICE_RECOGNIZER_DRIVER:			strNodeTypeStr = "Recognizer ����̹�";	break;
	default:								strNodeTypeStr = "�˼� ����";			break;
	}

	return strNodeTypeStr;
}

LPTSTR CServiceManager::GetLastErrorText( LPTSTR lpszBuf, DWORD dwSize ) 
{
    LPTSTR lpszTemp = 0;

    DWORD dwRet =	::FormatMessage(
						FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
						0,
						GetLastError(),
						LANG_NEUTRAL,
						(LPTSTR)&lpszTemp,
						0,
						0
					);

    if( !dwRet || (dwSize < dwRet + 256) )
        lpszBuf[0] = TEXT('\0');
    else {
        lpszTemp[_tcsclen(lpszTemp)-2] = TEXT('\0');  //remove cr/nl characters
        _tcscpy(lpszBuf, lpszTemp);
    }

    if( lpszTemp )
        LocalFree(HLOCAL(lpszTemp));

    return lpszBuf;
}

BOOL CServiceManager::ChangeServiceConfig(CString strComputerName, CString strServiceName, DWORD dwStartType)
{
	BOOL bRet = FALSE;

	SC_HANDLE schSCManager = ::OpenSCManager(strComputerName, 0, /*SC_MANAGER_CONNECT*/ SC_MANAGER_ALL_ACCESS);
	if (schSCManager) 
	{
		SC_HANDLE schService =	::OpenService(schSCManager, strServiceName, SERVICE_ALL_ACCESS);

		if( schService ) 
		{
			bRet = ::ChangeServiceConfig(schService,
										SERVICE_NO_CHANGE,
										dwStartType,
										SERVICE_NO_CHANGE,
										NULL, NULL, NULL, NULL,
										NULL, NULL, NULL);

			::CloseServiceHandle(schService);
		} 
		else 
		{
			TCHAR szErr[256] = {0x00,};
			CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenService failed - %s\n"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
			TRACE(TEXT("OpenService failed - %s\n"), szErr);
#endif
		}

		::CloseServiceHandle(schSCManager);
    }
	else 
	{
		TCHAR szErr[256] = {0x00,};
		CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenSCManager failed - %s"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
		TRACE(TEXT("OpenSCManager failed - %s\n"), szErr);
#endif
	}

	return bRet;
}


BOOL CServiceManager::IsServiceExist(CString strComputerName, CString strServiceName)
{
	BOOL bExist = TRUE;
	
	SC_HANDLE schSCManager = ::OpenSCManager(strComputerName, 0, /*SC_MANAGER_CONNECT*/ SC_MANAGER_ALL_ACCESS);
	if (schSCManager) 
	{
		SC_HANDLE schService =	::OpenService(schSCManager, strServiceName, SERVICE_ALL_ACCESS);
		
		if( schService ) 
		{
			bExist = TRUE;
			::CloseServiceHandle(schService);
		} 
		else 
		{
			if(GetLastError() == ERROR_SERVICE_DOES_NOT_EXIST)
			{
				bExist = FALSE;
			}
		}
		
		::CloseServiceHandle(schSCManager);
    }
	else 
	{
		TCHAR szErr[256] = {0x00,};
		CProcessLog::GetInstance()->WriteLog(LOGFILE, TEXT("OpenSCManager failed - %s\n"), GetLastErrorText(szErr, sizeof(szErr)));
#ifdef _DEBUG
		TRACE(TEXT("OpenSCManager failed - %s\n"), szErr);
#endif
	}

	return bExist;
}