// ErrorReportThread.cpp : implementation file
//

#include "stdafx.h"
#include "RebootManager.h"
#include "ErrorReportThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CErrorReportThread

IMPLEMENT_DYNCREATE(CErrorReportThread, CWinThread)

CErrorReportThread::CErrorReportThread()
{
	m_hSocket = INVALID_SOCKET;
	m_hParentWnd = NULL;
	m_dwErrorCode = 0;
}

CErrorReportThread::~CErrorReportThread()
{
}

BOOL CErrorReportThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	return TRUE;
}

int CErrorReportThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CErrorReportThread, CWinThread)
	//{{AFX_MSG_MAP(CErrorReportThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorReportThread message handlers

void CErrorReportThread::SetParentWnd(HWND hParentWnd)
{
	m_hParentWnd = hParentWnd;
}

void CErrorReportThread::SetErrorCode(DWORD dwErrorCode)
{
	m_dwErrorCode = dwErrorCode;
}

CString CErrorReportThread::GetErrorCode()
{
	CString strErrorCode = _T("");

	switch(m_dwErrorCode)
	{
	case POLL_IBP:
		strErrorCode = ERR_IBP_DOWN;
		break;
		
	case POLL_IIM:
		strErrorCode = ERR_IIM_DOWN;
		break;

	case POLL_IPF:
		strErrorCode = ERR_IPF_DOWN;
		break;
	}

	return strErrorCode;
}

int CErrorReportThread::Run() 
{
	// TODO: Add your specialized code here and/or call the base class
	SOCKET hSocket = INVALID_SOCKET;
	TCHAR szRemoteIP[20] = {0x00,};
	BOOL bConnected = FALSE;
	int nRetryCount = 0;
	int nPort = 0;
	WSADATA wsaData;

 	if(m_dwErrorCode != 0)
	{
		if(WSAStartup(MAKEWORD(2, 2), &wsaData) == 0)
		{
			memset(szRemoteIP, 0x00, sizeof(szRemoteIP));
			GetPrivateProfileString("HOST", "controlsvr", IP_POLL_SERVER, szRemoteIP, sizeof(szRemoteIP), ATOM_INFO_INI);
			nPort = GetPrivateProfileInt("PollCD", "ServerPort", PORT_POLL_SERVER, ATOM_START_INI);

			CreateSocket();

			while(TRUE)
			{
				bConnected = ConnectSocket(szRemoteIP, nPort);
				if(!bConnected)
				{
					if(++nRetryCount < MAX_POLLSERVER_CONNECT_RETRY)
					{
						Sleep(10000);
						continue;
					}
					else
					{
						// ���� ���� ���� ���� ���н�
						break;
					}
				}

				// ���� ������ ���
				break;
			}

			if(bConnected)
			{
				SendErrorPacket();
				CloseSocket();
			}

			WSACleanup();
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorReportThread::Run] WSAStartup FAIL[%d]"), WSAGetLastError());
		}
	}

	AfxEndThread(0);
	return CWinThread::Run();
}


BOOL CErrorReportThread::CreateSocket()
{
	m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
	if(m_hSocket == INVALID_SOCKET)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CIQSIPSendClientDlg::CreateSocket] socket ERROR[%d]", GetLastError());
		m_hSocket = INVALID_SOCKET;
		return FALSE;
	}
	
	return TRUE;
}


BOOL CErrorReportThread::ConnectSocket(CString strRemoteIP, int nPort)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ConnectSocket] REMOTE[%s] ����", strRemoteIP);
	
	BOOL bConnected		 = FALSE;
	int nResult			 = SOCKET_ERROR;
	int nNonBlockingMode = TRUE;
	SOCKADDR_IN addr;
	
	try
	{
		memset(&addr, 0x00, sizeof(addr));
		addr.sin_family      = AF_INET;
		addr.sin_addr.s_addr = inet_addr(strRemoteIP);
		addr.sin_port        = htons(nPort);
		
		// NON-BLOCKING MODE�� ����
		::ioctlsocket(m_hSocket, FIONBIO, (u_long FAR*) &nNonBlockingMode);
		
		if(::connect(m_hSocket, (SOCKADDR*)&addr, sizeof(addr)) == SOCKET_ERROR)
		{
			DWORD dwErrorCode = WSAGetLastError();
			if( dwErrorCode == WSAEWOULDBLOCK )
			{
				fd_set  writes;
				TIMEVAL timeout;
				
				FD_ZERO(&writes);
				FD_SET(m_hSocket, &writes);
				
				// writes = reads;
				timeout.tv_sec  = TIMEOUT_CONNECT;
				timeout.tv_usec = 0;
				
				nResult = ::select(m_hSocket, 0, &writes, 0, &timeout);
				if(nResult != SOCKET_ERROR)
				{
					if(writes.fd_count > 0)
					{
						bConnected = TRUE;
					}
				}
			}
		}
		
		// BLOCKING MODE�� ����
		if(bConnected)
		{
			nNonBlockingMode = FALSE;
			nResult = ioctlsocket(m_hSocket, FIONBIO, (u_long FAR*) &nNonBlockingMode); // BLOCKING MODE�� ����
		}
	}
	catch(...)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ConnectSocket] EXCEPTION[%d]", WSAGetLastError());
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ConnectSocket] REMOTE[%s] ����[%d]", strRemoteIP, bConnected);
	
	return bConnected;
}

void CErrorReportThread::CloseSocket()
{
	if(m_hSocket != INVALID_SOCKET)
	{
		::shutdown(m_hSocket, SD_BOTH);
		::closesocket(m_hSocket);
		m_hSocket = INVALID_SOCKET;
	}
}

BOOL CErrorReportThread::SendErrorPacket()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::SendErrorPacket] ����");
	
	int nResult = 0;
	int nLength = 0;
	TCHAR szData[MAX_PACKET_LENGTH] = {0x00,};
	
	CString strData = GetErrorCode();
	strcpy(szData, strData);
	nLength = lstrlen(szData);

	if(nLength <= 0 || nLength > MAX_PACKET_LENGTH)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::SendErrorPacket] �۽� ������ ũ�� ���� SIZE[%d]", nLength);
		return FALSE;
	}
	
	if(m_hSocket != INVALID_SOCKET)
	{
		int timeout = TIMEOUT_SEND * 1000;

		::setsockopt(m_hSocket, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout)); 
		nResult = send(m_hSocket, szData, nLength, 0);
		
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::SendErrorPacket] �۽� ������[%s], ���[%d]", szData, nResult);
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::SendErrorPacket]  INVALID_SOCKET");
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::SendErrorPacket] ����");
	return  (nResult > 0 ? TRUE : FALSE);
}

BOOL CErrorReportThread::ReceivePacket()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ReceivePacket] ����");
	
	int nResult = 0;
	TCHAR szBuffer[MAX_PACKET_LENGTH] = {0x00,};
	
	try
	{
		if(m_hSocket != INVALID_SOCKET)
		{
			int timeout = TIMEOUT_RECEIVE * 1000;
			::setsockopt(m_hSocket, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout)); 
			
			memset(szBuffer, 0x00, sizeof(szBuffer));
			nResult = recv(m_hSocket, szBuffer, sizeof(szBuffer), 0);
			if(nResult > 0)
				CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ReceivePacket] RECEIVE LEN[%d] BUFFER[%s]", nResult, szBuffer);
			else
				CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ReceivePacket] RECEIVE ERROR[%d]", GetLastError());
		}
	}
	catch(...)
	{
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, "[CErrorReportThread::ReceivePacket] ����");
	return  (nResult > 0 ? TRUE : FALSE);
}
