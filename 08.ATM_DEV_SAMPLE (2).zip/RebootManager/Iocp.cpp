#include "stdafx.h"
#include "Iocp.h"

DWORD WINAPI WorkerThreadCallback(LPVOID parameter)
{
	CIocp *pOwner = (CIocp*) parameter;
	if(pOwner)
	{
		pOwner->WorkerThreadCallback();
	}
	
	return 0;
}

CIocp::CIocp(VOID)
{
	mIocpHandle			= NULL;
	mWorkerThreadCount	= 0;

	mStartupEventHandle	= NULL;
}

CIocp::~CIocp(VOID)
{
}

BOOL CIocp::Begin(VOID)
{
	mIocpHandle			= NULL;

	SYSTEM_INFO SystemInfo;
	GetSystemInfo(&SystemInfo);

	mWorkerThreadCount	= SystemInfo.dwNumberOfProcessors * 2;
	mIocpHandle			= CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0);

	if (!mIocpHandle)
		return FALSE;

	mStartupEventHandle = CreateEvent(0, FALSE, FALSE, 0);
	if (mStartupEventHandle == NULL)
	{
		End();

		return FALSE;
	}

	for (DWORD i=0; i<mWorkerThreadCount; i++)
	{
		HANDLE hWorkerThread = CreateThread(NULL, 0, ::WorkerThreadCallback, this, 0, NULL);
		mWorkerThreadVector.push_back(hWorkerThread);

		WaitForSingleObject(mStartupEventHandle, INFINITE);
	}

	return TRUE;
}

BOOL CIocp::End(VOID)
{
	DWORD i = 0;
	for (i=0;i<mWorkerThreadVector.size();i++)
		PostQueuedCompletionStatus(mIocpHandle, 0, 0, NULL);

	for (i=0;i<mWorkerThreadVector.size();i++)
	{
		WaitForSingleObject(mWorkerThreadVector[i], INFINITE);

		CloseHandle(mWorkerThreadVector[i]);

		// 2010.07.28 ghk@kci.co.kr
		// ����� ������ �ڵ� �ʱ�ȭ
		mWorkerThreadVector[i] = NULL;
	}

	if (mIocpHandle)
	{
		CloseHandle(mIocpHandle);

		// 2010.07.28 ghk@kci.co.kr
		// ����� �ڵ� �ʱ�ȭ
		mIocpHandle = NULL;
	}

	mWorkerThreadVector.clear();

	if (mStartupEventHandle)
	{
		CloseHandle(mStartupEventHandle);
		// 2010.07.28 ghk@kci.co.kr
		// ����� �ڵ� �ʱ�ȭ
		mStartupEventHandle = NULL;
	}

	return TRUE;
}

BOOL CIocp::RegisterSocketToIocp(SOCKET hSocket, ULONG_PTR completionKey)
{
	if (!hSocket || !completionKey)
		return FALSE;

	mIocpHandle = CreateIoCompletionPort((HANDLE) hSocket, mIocpHandle, completionKey, 0);

	if (!mIocpHandle)
		return FALSE;

	return TRUE;
}

VOID CIocp::WorkerThreadCallback(VOID)
{
	BOOL			bSuccessed					= FALSE;
	DWORD			dwNumberOfByteTransfered	= 0;
	VOID			*CompletionKey				= NULL;
	OVERLAPPED		*Overlapped					= NULL;
	OVERLAPPEDEX	*OverlappedEx				= NULL;
	VOID			*Object						= NULL;

	while (TRUE)
	{
		SetEvent(mStartupEventHandle);

		bSuccessed = GetQueuedCompletionStatus(mIocpHandle,
											   &dwNumberOfByteTransfered,
											   (LPDWORD) &CompletionKey,
											   &Overlapped,
											   INFINITE);

		if (!CompletionKey)
			return;

		OverlappedEx	= (OVERLAPPEDEX*) Overlapped;
		Object			= OverlappedEx->Object;

		if (!bSuccessed || (bSuccessed && !dwNumberOfByteTransfered))
		{
			if (OverlappedEx->IoType == IO_ACCEPT)
				OnIoConnected(Object);
			else
				OnIoDisconnected(Object);

			continue;
		}

		switch (OverlappedEx->IoType)
		{
		case IO_READ:
			OnIoRead(Object, dwNumberOfByteTransfered);
			break;

		case IO_WRITE:
			OnIoWrote(Object, dwNumberOfByteTransfered);
			break;
		}
	}
}