// RebootManagerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RebootManager.h"
#include "RebootManagerDlg.h"
#include "ErrorScreenDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerDlg dialog

CRebootManagerDlg::CRebootManagerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRebootManagerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRebootManagerDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_bNetworkStartup = FALSE;
	m_bServerStartup = FALSE;

	m_pThreadDeleteLog = NULL;
	m_pThreadPollSend = NULL;
	m_pNrmsSession = NULL;

	m_nPollSendFailIBP = 0;
	m_nPollSendFailIIM = 0;
	m_nPollSendFailIPF = 0;
	m_nPollSendFailADP = 0;

	m_bPollFailReportADP = FALSE;

	m_pErrorScreen = NULL;

	// 2010.06.16 ghk@kci.co.kr
	// ������� ���� ���¸� �ʱ�ȭ �Ѵ�.
	WritePrivateProfileString(_T("ERROR_SEND"), ERR_IIM_DOWN, _T("F"), ATOM_IBP_INI);
	WritePrivateProfileString(_T("ERROR_SEND"), ERR_IPF_DOWN, _T("F"), ATOM_IBP_INI);
	WritePrivateProfileString(_T("ERROR_SEND"), ERR_IBP_DOWN, _T("F"), ATOM_IBP_INI);
	WritePrivateProfileString(_T("ERROR_SEND"), ERR_ADP_DOWN, _T("F"), ATOM_IBP_INI);
}

CRebootManagerDlg::~CRebootManagerDlg()
{
	if(m_pErrorScreen)
	{
		if(IsWindow(m_pErrorScreen->GetSafeHwnd()))
			m_pErrorScreen->DestroyWindow();

		delete m_pErrorScreen;
		m_pErrorScreen = NULL;
	}

	if(m_bNetworkStartup)
	{
		m_server.End();
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::~CRebootManagerDlg] ���� ���� �Ϸ�"));

		WSACleanup();
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::~CRebootManagerDlg] WSACleanup �Ϸ�"));
	}
}

void CRebootManagerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRebootManagerDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRebootManagerDlg, CDialog)
	//{{AFX_MSG_MAP(CRebootManagerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_WM_COPYDATA()
	ON_MESSAGE(UM_NRMS_CONNECTED, OnNrmsConnected)
	ON_MESSAGE(UM_NRMS_DISCONNECTED, OnNrmsDisConnected)
	ON_MESSAGE(UM_POLL_RESULT, OnPollResult)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerDlg message handlers

BOOL CRebootManagerDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if(pMsg->message == WM_KEYDOWN && (pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_F4))
	{
		// ESCAPE, ENTER KeyDown ����
		return TRUE;
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}


BOOL CRebootManagerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	int nWidth = GetSystemMetrics(SM_CXSCREEN);
	int nHeight = GetSystemMetrics(SM_CYSCREEN);

	SetWindowText(TITLE_ARM);

	// Set WS_EX_LAYERED on this window 
	SetWindowLong(GetSafeHwnd(), GWL_EXSTYLE, GetWindowLong(GetSafeHwnd(), GWL_EXSTYLE) | WS_EX_LAYERED);
	
	// Make this window 1% alpha
	SetLayeredWindowAttributes(GetSafeHwnd(), 0, (255 * 1) / 100, LWA_ALPHA);
	
	// ������ �����
	SetWindowPos(&CWnd::wndTopMost, 0, nHeight - 30, 95, 30, SWP_SHOWWINDOW);
	StartManager();

// TEST CODE
//	SetTimer(TIMER_SEND_PAGINGFILE_NRMSSERVER, 10, NULL);

	// ��� ǥ�ÿ� ȭ�� ����
	CreateErrorScreen();


// TEST CODE
//	OpenErrorScreen("���ȭ�� ĸ�� �׽�Ʈ");
//	CaptureScreen();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRebootManagerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		// ALT + F4 ����
		if(nID == SC_CLOSE)
			return;

		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRebootManagerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRebootManagerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CRebootManagerDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	switch(nIDEvent)
	{
	case TIMER_POLL_SERVER:
		KillTimer(TIMER_POLL_SERVER);
// 2010.05.21 ghk@kci.co.kr
// ��Ʈ�Ѽ��� POLL ������
// ��Ʈ�Ѽ��� POLL�� IBP���� ������
//		StartPollSession();
		break;

	case TIMER_POLL_IBP:
		KillTimer(TIMER_POLL_IBP);
		PollIBP();
		SetTimer(TIMER_POLL_IBP, ELAPSE_POLL_IBP, NULL);
		break;

	case TIMER_POLL_IIM:
		KillTimer(TIMER_POLL_IIM);
		PollIIM();
		SetTimer(TIMER_POLL_IIM, ELAPSE_POLL_IIM, NULL);
		break;

	case TIMER_POLL_IPF:
		KillTimer(TIMER_POLL_IPF);
		PollIPF();
		SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_IPF, NULL);
		break;

	case TIMER_POLL_ADP:
		KillTimer(TIMER_POLL_ADP);
		PollADP();
		SetTimer(TIMER_POLL_ADP, ELAPSE_POLL_ADP, NULL);
		break;


	case TIMER_POLL_IBP_FAIL:
		KillTimer(TIMER_POLL_IBP_FAIL);

		// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
		KillTimer(TIMER_POLL_IBP);
		SetTimer(TIMER_POLL_IBP, ELAPSE_POLL_IBP_AFTERREP, NULL);

		// ������ POLL FAIL �����Ѵ�.
		//ReportPollFailToServer(POLL_IBP);

		// ���ȭ�� ���� ���ؼ�
		ReportPollFailToIBP(POLL_IBP);
		break;


	case TIMER_POLL_IIM_FAIL:
		KillTimer(TIMER_POLL_IIM_FAIL);

		// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
		KillTimer(TIMER_POLL_IIM);
		SetTimer(TIMER_POLL_IIM, ELAPSE_POLL_IIM_AFTERREP, NULL);

		// ������ POLL FAIL �����Ѵ�.
		//ReportPollFailToServer(POLL_IIM);

		// IBP���� POLL FAIL �����Ѵ�.
		ReportPollFailToIBP(POLL_IIM);
		break;


	case TIMER_POLL_IPF_FAIL:
		KillTimer(TIMER_POLL_IPF_FAIL);

		// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
		KillTimer(TIMER_POLL_IPF);
		SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_IPF_AFTERREP, NULL);

		// ������ POLL FAIL �����Ѵ�.
		//ReportPollFailToServer(POLL_IPF);

		// IBP���� POLL FAIL �����Ѵ�.
		ReportPollFailToIBP(POLL_IPF);
		break;


	case TIMER_POLL_ADP_FAIL:
		KillTimer(TIMER_POLL_ADP_FAIL);
		
		// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
		KillTimer(TIMER_POLL_IPF);
		SetTimer(TIMER_POLL_ADP, ELAPSE_POLL_ADP_AFTERREP, NULL);

		// IBP���� POLL FAIL �����Ѵ�.
		if(ReportPollFailToIBP(POLL_ADP))
			m_bPollFailReportADP = TRUE;

		CProcess::KillProcess(ATOM_ADP_FILE);
		CProcess::Execute(ATOM_ADP_EXE);
		break;


	case TIMER_DELETE_LOGFILE:
		KillTimer(TIMER_DELETE_LOGFILE);
		StartDeleteLogThread();
		break;


	case TIMER_SEND_PAGINGFILE_NRMSSERVER:
		KillTimer(TIMER_SEND_PAGINGFILE_NRMSSERVER);
		CreateNrmsSession();
		StartPagefileSendTimer();
		break;

	// 2010.07.10 ghk@kci.co.kr
	// REBOOT/RESTART Ÿ�Ӿƿ� ���� �и�
	case TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT:
		KillTimer(TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT);
		m_server.SendResponsePacket(REBOOT_ERR_INFO, "055");
		break;


	// 2010.07.10 ghk@kci.co.kr
	// REBOOT/RESTART Ÿ�Ӿƿ� ���� �и�
	case TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT:
		KillTimer(TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT);
		m_server.SendResponsePacket(REP_ERR_INFO, "055");
		break;
	}
	
	CDialog::OnTimer(nIDEvent);
}

LRESULT CRebootManagerDlg::OnNrmsConnected(WPARAM wParam, LPARAM lParam)
{
	CString strMessage = _T("");

	if(lParam != ERROR_SUCCESS)
	{
		strMessage.Format(_T("SERVER IP:%s PORT:%d ���� ����(%d)"), m_strNrmsServerIP, m_nNrmsServerPort, lParam);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnNrmsConnected] %s"), strMessage);
		
		DeleteNrmsSession();
		return 0L;
	}
	
	strMessage.Format(_T("SERVER IP:%s PORT:%d ���� �Ϸ�"), m_strNrmsServerIP, m_nNrmsServerPort);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CManagerTPDlg::OnConnected] %s"), strMessage);

	SendPagefileInfoToServer();

	return 1L;
}

LRESULT CRebootManagerDlg::OnNrmsDisConnected(WPARAM wParam, LPARAM lParam)
{
	
	return 1L;
}

LRESULT CRebootManagerDlg::OnPollResult(WPARAM wParam, LPARAM lParam)
{
	BOOL bPollSent = (BOOL) lParam;
	PollSendResult(wParam, bPollSent);

	return 1L;
}

BOOL CRebootManagerDlg::StartupNetwork()
{
	WSADATA WsaData;
	
	int nStartup = WSAStartup(MAKEWORD(2, 2), &WsaData);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::StartupNetwork] WSAStartup %s"), (nStartup == 0 ? _T("����"): _T("����")));

	if(nStartup != 0)
	{
		return FALSE;
	}

	
	m_bNetworkStartup = TRUE;

	return TRUE;
}

BOOL CRebootManagerDlg::StartManager()
{
	if(!StartupNetwork())
		return FALSE;

	// 2010.05.21 ghk@kci.co.kr
	// ���������� ���Ұ��� �ϴ��� �ٸ� ����� �����Ѵ�.
	//if(!StartupServer())
	//	return FALSE;
	StartupServer();


	// 2010.05.24 ghk@kci.co.kr
	// IBP, IIM, IPF �� ���� �����带 �����ϴ�.
	// ���� ������ �����͸� QUEUE�� �ִ� ���� �����Ѵ�.
	StartupPollSendThread();


	TCHAR szFlag[10] = {0x00, };

	// Agent ���� �� DefaultBW ini�� "T"�� ��� "F"�� �����Ѵ�
	memset(szFlag, 0x00, sizeof(szFlag));
	GetPrivateProfileString("CONTROL", "DefaultBW", "F", szFlag, sizeof(szFlag), ATOM_INFO_INI);
	if (szFlag[0] == 'T')
	{
		WritePrivateProfileString ("CONTROL", "DefaultBW", "F", ATOM_INFO_INI);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[DefaultBW=F] �ʱ�ȭ"));
	}
	
	WritePrivateProfileString ("CONTROL", "POLL_LINEDOWN", "F", ATOM_INFO_INI);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[POLL_LINEDOWN=F] �ʱ�ȭ"));
	
	WritePrivateProfileString ("CONTROL", "LineDown", "F", ATOM_INFO_INI);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[LineDown=F] �ʱ�ȭ"));


	// 5�� �� NRMS ������ ���������� ����� �����Ѵ�.
	// ���� ����ô� ������ �ð��� ���
	//SetTimer(TIMER_SEND_PAGINGFILE_NRMSSERVER, 5000, NULL);
	//CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[5����  Pagefile Send Start!]"));
	StartPagefileSendTimer();
	

	// 2010.05.21 ghk@kci.co.kr
	// ��Ʈ�Ѽ��� POLL�� IBP���� �����Ѵ�.
	// 15�� �� Server Polling ����
	//SetTimer(TIMER_POLL_SERVER, 15000, NULL);
	//CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[15����  Polling Start!]"));

	// 24�ð� ���� �α����� ���� ��� ����
	//SetTimer(TIMER_DELETE_LOGFILE, ELAPSE_DELETE_LOGFILE, NULL);
	SetTimer(TIMER_DELETE_LOGFILE, 1000, NULL);

	// IBP POLL ����
	SetTimer(TIMER_POLL_IBP, ELAPSE_POLL_IBP_FIRST, NULL);

	// IIM POLL ����
	SetTimer(TIMER_POLL_IIM, ELAPSE_POLL_IIM_FIRST, NULL);

	// IPF POLL ����
	SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_IPF_FIRST, NULL);
	
	// ADP POLL ����
	SetTimer(TIMER_POLL_ADP, ELAPSE_POLL_ADP_FIRST, NULL);
	
	return TRUE;
}

BOOL CRebootManagerDlg::StartupServer()
{
	if(!m_server.Begin(PORT_LISTEN_SERVER))
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::StartupServer] ���� ���� ����"));
		return FALSE;
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::StartupServer] ���� ���� ����"));
	m_bServerStartup = TRUE;

	return TRUE;
}

void CRebootManagerDlg::StartDeleteLogThread()
{
	m_pThreadDeleteLog = (CDeleteLogThread*) AfxBeginThread(RUNTIME_CLASS(CDeleteLogThread),
															THREAD_PRIORITY_NORMAL,
															0,
															CREATE_SUSPENDED,
															NULL);
	if(m_pThreadDeleteLog)
	{
		m_pThreadDeleteLog->SetParentWnd(GetSafeHwnd());
		m_pThreadDeleteLog->ResumeThread();
	}
}

void CRebootManagerDlg::ClearDeleteLogThread()
{
	if(m_pThreadDeleteLog)
	{
		//CloseHandle(m_pThreadDeleteLog->m_hThread);
		m_pThreadDeleteLog = NULL;
	}
}

BOOL CRebootManagerDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	// TODO: Add your message handler code here and/or call default
	CString strData = _T("");
	DWORD dwCommand = pCopyDataStruct->dwData;

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] DWDATA:%d"), dwCommand);

	switch(dwCommand)
	{
	case IIM_COMMAND_RESPONSE:
		strData = CString((TCHAR*) pCopyDataStruct->lpData);//, pCopyDataStruct->cbData);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] IIM_COMMAND_RESPONSE[%s]"), strData);


		// ������ ���Ź��� ��� ���ɿ� ���� Ÿ�̸Ӹ� CLEAR����.
		if(strData.Find(_T("RESTART")) != -1)
			KillTimer(TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT);
		else
			KillTimer(TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT);

		ProcessResponseIIM(strData);
		break;

	case ARM_COMMAND:
		strData = CString((TCHAR*) pCopyDataStruct->lpData);//, pCopyDataStruct->cbData);
		OpenErrorScreen(strData);
		break;

	case POLL_IIM_RESPONSE:
		// 2010.12.02 ghk@kci.co.kr
		KillTimer(TIMER_POLL_IIM_FAIL);

		if(m_pThreadPollSend)
		{
			m_pThreadPollSend->Push(this, POLL_RESPONSE, POLL_IIM_RESPONSE, (LPBYTE) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
		}
		
//		strData = CString((TCHAR*) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] POLL_IIM_RESPONSE[%s]"), strData);
		break;

	case POLL_IPF_RESPONSE:
		// 2010.12.02 ghk@kci.co.kr
		KillTimer(TIMER_POLL_IPF_FAIL);

		if(m_pThreadPollSend)
		{
			m_pThreadPollSend->Push(this, POLL_RESPONSE, POLL_IPF_RESPONSE, (LPBYTE) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
		}
		
//		strData = CString((TCHAR*) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] POLL_IPF_RESPONSE[%s]"), strData);
		break;

	case POLL_IBP_RESPONSE:
		// 2010.12.02 ghk@kci.co.kr
		KillTimer(TIMER_POLL_IBP_FAIL);

		if(m_pThreadPollSend)
		{
			m_pThreadPollSend->Push(this, POLL_RESPONSE, POLL_IBP_RESPONSE, (LPBYTE) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
		}
		
//		strData = CString((TCHAR*) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] POLL_IBP_RESPONSE[%s]"), strData);
		break;
		
	case POLL_ADP_RESPONSE:
		// 2010.12.02 ghk@kci.co.kr
		KillTimer(TIMER_POLL_ADP_FAIL);

		if(m_pThreadPollSend)
		{
			m_pThreadPollSend->Push(this, POLL_RESPONSE, POLL_ADP_RESPONSE, (LPBYTE) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
		}

		// ��� ������ �� ��� ������ �����Ѵ�.
		// 2010.11.23 ghk@kci.co.kr
		// �������� �����ϴ� ������ ���ۿ��θ� INI ���Ϸ� �Ǵ��Ѵ�.
		//if(m_bPollFailReportADP)
		//{
		//	m_bPollFailReportADP = FALSE;
			ReportRecoveryToIBP(POLL_ADP);
		//}
		
//		strData = CString((TCHAR*) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnCopyData] POLL_ADP_RESPONSE[%s]"), strData);
		break;
		
	default:
		break;
	}
		

	return CDialog::OnCopyData(pWnd, pCopyDataStruct);
}

BOOL CRebootManagerDlg::PollIBP()
{
	// 2010.06.15 ghk@kci.co.kr
	// �����ڵ尡 �����ڵ尡 �ƴϸ� POLL �������� �ʴ´�.
	int nStatus = GetPrivateProfileInt(_T("STATUS"), _T("CODE"), 0, ATOM_NRMS_INI);
	if(nStatus != 0)
		return FALSE;


	if(m_pThreadPollSend)
	{
		m_pThreadPollSend->Push(this, POLL_COMMAND, POLL_IBP, (LPBYTE) TITLE_IBP, lstrlen(TITLE_IBP));
		return TRUE;
	}

	return FALSE;
}

BOOL CRebootManagerDlg::PollIIM()
{
	// 2010.06.15 ghk@kci.co.kr
	// �����ڵ尡 �����ڵ尡 �ƴϸ� POLL �������� �ʴ´�.
	int nStatus = GetPrivateProfileInt(_T("STATUS"), _T("CODE"), 0, ATOM_NRMS_INI);
	if(nStatus != 0)
		return FALSE;


	if(m_pThreadPollSend)
	{
		m_pThreadPollSend->Push(this, POLL_COMMAND, POLL_IIM, (LPBYTE) TITLE_IIM, lstrlen(TITLE_IIM));
		return TRUE;
	}
	
	return FALSE;
}

BOOL CRebootManagerDlg::PollIPF()
{
	// 2010.06.15 ghk@kci.co.kr
	// �����ڵ尡 �����ڵ尡 �ƴϸ� POLL �������� �ʴ´�.
	int nStatus = GetPrivateProfileInt(_T("STATUS"), _T("CODE"), 0, ATOM_NRMS_INI);
	if(nStatus != 0)
		return FALSE;


	if(m_pThreadPollSend)
	{
		m_pThreadPollSend->Push(this, POLL_COMMAND, POLL_IPF, (LPBYTE) TITLE_IPF, lstrlen(TITLE_IPF));
		return TRUE;
	}

	return FALSE;
}

BOOL CRebootManagerDlg::PollADP()
{
	// 2010.06.15 ghk@kci.co.kr
	// �����ڵ尡 �����ڵ尡 �ƴϸ� POLL �������� �ʴ´�.
	int nStatus = GetPrivateProfileInt(_T("STATUS"), _T("CODE"), 0, ATOM_NRMS_INI);
	if(nStatus != 0)
		return FALSE;

	if(m_pThreadPollSend)
	{
		m_pThreadPollSend->Push(this, POLL_COMMAND, POLL_ADP, (LPBYTE) TITLE_ADP, lstrlen(TITLE_ADP));
		return TRUE;
	}
	
	return FALSE;
}

void CRebootManagerDlg::ResetPollResponseTimeOut(UINT nTimerID, DWORD dwTimeOut)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ResetPollResponseTimeOut] TIMERID:%d"), nTimerID);
	KillTimer(nTimerID);
	SetTimer(nTimerID, dwTimeOut, NULL);
}

BOOL CRebootManagerDlg::SendPollPacket(CString strWindowTitle)
{
	HWND hAgentWnd = ::FindWindow(NULL, strWindowTitle);
	if(hAgentWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ���� FINDWINDOW FAIL"), strWindowTitle);
		return FALSE;
	}
	
	int nResult = 0;
	DWORD dwResult = 0;
	TCHAR szCommand[10] = {0x00,};
	COPYDATASTRUCT cds;
	
	memset(szCommand, 0x00, sizeof(szCommand));
	wsprintf(szCommand, _T("%s"), _T("11"));
	
	cds.dwData = POLL_COMMAND;
	cds.lpData = szCommand;
	cds.cbData = lstrlen(szCommand) + 1;
	
	//CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
	nResult = ::SendMessageTimeout(hAgentWnd, 
		WM_COPYDATA,
		0,
		(LPARAM)&cds,
		SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG,
		5000,
		&dwResult);
	
	if(nResult == 0)
	{
		DWORD dwError = GetLastError();
		if(dwError == 0)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����(Ÿ�Ӿƿ�)"), strWindowTitle);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����(%s)"),
				strWindowTitle, CErrorMessage::GetErrorMessage(dwError));
		}
		
		return FALSE;
	}
	else
	{
		//CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
		return TRUE;
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPollPacket] WM_COPYDATA TITLE[%s] ���� ����"), strWindowTitle);
	return FALSE;
}

void CRebootManagerDlg::StartPagefileSendTimer()
{
	TCHAR szDownGroup[10] = {0x00,};
	TCHAR szTempGroup[10] = {0x00,};

	memset(szDownGroup, 0x00, sizeof(szDownGroup));
	memset(szTempGroup, 0x00, sizeof(szTempGroup));
	GetPrivateProfileString(_T("HOST"), _T("controlsvrport"), _T("7023"), szTempGroup, sizeof(szTempGroup), ATOM_INFO_INI);
	strncpy(szDownGroup, szTempGroup + 2, strlen(szTempGroup));

	int nGroupTime = GetPrivateProfileInt("GourpTime", szDownGroup, 110, ATOM_AGENT_INI);
	int nMemoryTime = GetPrivateProfileInt("SendTime", "TIME", 3, ATOM_AGENT_INI);
	
	// ���� �ð��� �ʷ� ȯ�� �� ���
	CTime ctRightNow = CTime::GetCurrentTime();
	UINT nNowTime = (ctRightNow.GetHour() * 60 * 60) + (ctRightNow.GetMinute() * 60) + ctRightNow.GetSecond();
	UINT nNextSendTime = (24 * 60 * 60) - nNowTime + (nMemoryTime * 60 * 60);

	randomize();
	int nRandomValue = (random(300) + 1);
	UINT nFinalMemorySendTime = (nNextSendTime + (nGroupTime * 60) + nRandomValue) * 1000;
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Memory ����] Send Time:%d, Group:%s, Group Time:%d"), nMemoryTime, szDownGroup, nGroupTime);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[Memory ����] ����:%d, NEXT:%d�� �� ����"), nRandomValue, nFinalMemorySendTime/1000);
	
	SetTimer(TIMER_SEND_PAGINGFILE_NRMSSERVER, nFinalMemorySendTime, NULL);
}

BOOL CRebootManagerDlg::SendPagefileInfoToServer()
{
	if(!m_pNrmsSession)
		return FALSE;

	TCHAR szNumberCD[10] = {0x00,};
	TCHAR szUsedPageFile[20] = {0x00,};
	TCHAR szTotalPageFile[20] = {0x00,};
	TCHAR szData[MAX_PACKET_LENGTH] = {0x00,};

	MEMORYSTATUSEX ms;
	memset(&ms, 0x00, sizeof(ms));
	ms.dwLength = sizeof(ms);
	GlobalMemoryStatusEx(&ms);
	ULONG uUsedPageFile = ms.ullTotalPageFile - ms.ullAvailPageFile;

	memset(szUsedPageFile, 0x00, sizeof(szUsedPageFile));
	memset(szTotalPageFile, 0x00, sizeof(szTotalPageFile));
	memset(szData, 0x00, sizeof(szData));

	// 20110217 kimjiyoung �޸� üũ 1000M�� �����Ǿ� ������ �ҽ� ���ʿ�
// 	////////////////////////////////////////////////////////////////////////////////////
// 	// 20110114 kimjiyoung �޸� 500M �̻� ��� �� reboot �߻��Ͽ� 
// 	//                     �ӽ÷� �޸� ���� ����(���� ��뷮���� 500M ����) ó��
// 	wsprintf(szUsedPageFile, "%u", uUsedPageFile);
// 	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPagefileInfoToServer] ����������(BYTE) �ѷ�:%s, ��뷮:%s, ������:%u"),
// 		szTotalPageFile, szUsedPageFile, ms.ullAvailPageFile);
// 	uUsedPageFile = uUsedPageFile / 10;
// 	////////////////////////////////////////////////////////////////////////////////////

	wsprintf(szUsedPageFile, "%u", uUsedPageFile);
	wsprintf(szTotalPageFile, "%u", ms.ullTotalPageFile);
	wsprintf(szData, "%s%c%s", szUsedPageFile, FS, szTotalPageFile);
	int nDataLength = lstrlen(szUsedPageFile) + 1 + lstrlen(szTotalPageFile);

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPagefileInfoToServer] ����������(BYTE) �ѷ�:%s, ��뷮:%s, ������:%u"),
		szTotalPageFile, szUsedPageFile, ms.ullAvailPageFile);


	// ATM ��ȣ
	memset(szNumberCD, 0x00, sizeof(szNumberCD));
	GetPrivateProfileString("LOCAL", "cdnumber", "****", szNumberCD, sizeof(szNumberCD), ATOM_INFO_INI);

	BOOL bResult = m_pNrmsSession->WritePacket(REP_MEMORY_INFO, szNumberCD, (LPBYTE)szData, nDataLength);
	DeleteNrmsSession();

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::SendPagefileInfoToServer] ���������� ���� ����[%d] �Ϸ�"), bResult); 

	return bResult;
}

BOOL CRebootManagerDlg::CreateNrmsSession()
{
	TCHAR szServerIP[20] = {0x00,};
	CString strMessage = _T("");

	DeleteNrmsSession();
	m_pNrmsSession = new CClientSession(GetSafeHwnd());

	// NRMS ���� IP ���� �б�
	memset(szServerIP, 0x00, sizeof(szServerIP));

	//20110112 hgkang Tandom������ �߸� �����ϱ��־ ����
	//GetPrivateProfileString("HOST", "TANDEMSVR", IP_NRMS_SERVER, szServerIP, sizeof(szServerIP), ATOM_INFO_INI);
	GetPrivateProfileString("NRMS-SERVER", "ip", IP_NRMS_SERVER, szServerIP, sizeof(szServerIP), ATOM_NRMS_INI);
	m_strNrmsServerIP = szServerIP;
	
	// NRMS ���� PORT ���� �б�
	//20110112 hgkang Tandom������ �߸� �����ϱ��־ ����
	//m_nNrmsServerPort = GetPrivateProfileInt("HOST", "TANDEMSVRPORT", PORT_NRMS_SERVER, ATOM_INFO_INI);
	m_nNrmsServerPort = GetPrivateProfileInt("NRMS-SERVER", "port", PORT_NRMS_SERVER, ATOM_NRMS_INI);
	
	strMessage.Format(_T("NRMS SERVER IP:%s PORT:%d ���� ����"),  m_strNrmsServerIP, m_nNrmsServerPort);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::CreateNrmsSession] %s"), strMessage);
	
	if(!m_pNrmsSession->Begin((LPTSTR)(LPCTSTR)m_strNrmsServerIP, m_nNrmsServerPort))
	{
		strMessage.Format(_T("NRMS SERVER IP:%s PORT:%d ���� ����"), m_strNrmsServerIP, m_nNrmsServerPort);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[COperationManagerDlg::ProcessNrms] %s"), strMessage);
		
//		SetTimer(TIMER_POLLSERVER_RECONNECT, ELAPSE_POLLSERVER_RECONNECT, NULL);
		DeleteNrmsSession();
		return FALSE;
	}
	
	return TRUE;
}

void CRebootManagerDlg::DeleteNrmsSession()
{
	if(m_pNrmsSession)
	{
		m_pNrmsSession->End();
		delete m_pNrmsSession;
		m_pNrmsSession = NULL;
	}
}

BOOL CRebootManagerDlg::StartupPollSendThread()
{
	m_pThreadPollSend = (CPollSendThread*) AfxBeginThread(RUNTIME_CLASS(CPollSendThread),
														  THREAD_PRIORITY_NORMAL,
														  0,
														  CREATE_SUSPENDED,
														  NULL);
	if(m_pThreadPollSend)
	{
		m_pThreadPollSend->SetParentWnd(GetSafeHwnd());
		m_pThreadPollSend->ResumeThread();
		
		return TRUE;
	}

	return FALSE;
}

BOOL CRebootManagerDlg::ReportPollFailToServer(DWORD dwFailID)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToServer] ID:%d ����"), dwFailID);

	CErrorReportThread *pThread = (CErrorReportThread*) AfxBeginThread(RUNTIME_CLASS(CErrorReportThread),
																	   THREAD_PRIORITY_NORMAL,
																	   0,
																	   CREATE_SUSPENDED,
																	   NULL);
	if(pThread)
	{
		pThread->SetParentWnd(GetSafeHwnd());
		pThread->SetErrorCode(dwFailID);
		pThread->ResumeThread();

		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToServer] ID:%d �Ϸ�"), dwFailID);
		return TRUE;
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToServer] ID:%d ����[%d]"), dwFailID, GetLastError());
	return FALSE;
}

BOOL CRebootManagerDlg::ReportPollFailToIBP(DWORD dwFailID)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] ID:%d ����"), dwFailID);
	
	int nResult = 0;
	int nLength = 0;
	DWORD dwResult = 0;
	TCHAR szError[20] = {0x00,};
	TCHAR szValue[20] = {0x00,};
	
	memset(szError, 0x00, sizeof(szError));
	nLength = GetErrorCode(dwFailID, szError, sizeof(szError));
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] ERRORCODE:[%s]"), szError);

	// 2010.06.16 ghk@kci.co.kr
	// �������� �����Ŀ��� �ٽ� ������ �ʴ´�.
	GetPrivateProfileString(_T("ERROR_SEND"), szError, _T("F"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(szValue[0] == 'T' || szValue[0] == 't')
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] ERROR:%s ���۾���[%s]"), szError,  szValue);
		return FALSE; 
	}

	// IBP�� ����̸� ��������� ������ �� �����Ƿ� INI�� ���� ����Ͽ�
	// ������ ��� �߻��� ���ȭ���� ǥ������ �ʴ´�.
	if(dwFailID == POLL_IBP)
	{
		WritePrivateProfileString(_T("ERROR_SEND"), szError, _T("T"), ATOM_IBP_INI);
	}

	// 2010.10.05 ghk@kci.co.kr
	// ADP ������ ��쿡�� ȭ��ĸ�ĸ� ����
	if(dwFailID == POLL_ADP)
	{
		CaptureScreen();
	}
	else
	{
		CString strErrorCode = _T("");
		if(!m_mapError.Lookup(dwFailID, strErrorCode))
		{
			m_mapError.SetAt(dwFailID, szError);
			
			CString strMessage = _T("");
			strMessage.Format(_T("[ERROR] PROCESS POLL FAIL:%s"), szError);
			OpenErrorScreen(strMessage);
		}
//		else
//		{
//			CaptureScreen();
//		}
	}



	HWND hAgentWnd = ::FindWindow(NULL, TITLE_IBP);
	if(hAgentWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] ID:%d ���� IBP FINDWINDOW FAIL ����"), dwFailID);
		return FALSE;	
	}

	
	COPYDATASTRUCT cds;
	cds.dwData = IBP_COMMAND;
	cds.lpData = szError;
	cds.cbData = lstrlen(szError) + 1;
	
	nResult = ::SendMessageTimeout(hAgentWnd,
								   WM_COPYDATA,
								   0,
								   (LPARAM)&cds,
								   SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG,
								   5000,
								   &dwResult);
	
	if(nResult == 0)
	{
		DWORD dwError = GetLastError();
		if(dwError == 0)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] WM_COPYDATA TITLE[%s] ���� ����(Ÿ�Ӿƿ�)"),
				TITLE_IBP);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] WM_COPYDATA TITLE[%s] ���� ����(%s)"),
				TITLE_IBP, CErrorMessage::GetErrorMessage(dwError));
		}
		
		return FALSE;
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] WM_COPYDATA TITLE[%s] DATA[%s] ���� ����"), TITLE_IBP, szError);
		return TRUE;
	}
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportPollFailToIBP] ID:%d DATA[%s] ����[%d]"), dwFailID, szError, GetLastError());
	return FALSE;
}

BOOL CRebootManagerDlg::ReportRecoveryToIBP(DWORD dwRecoeryID)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] ID:%d ����"), dwRecoeryID);
	
	int nResult = 0;
	int nLength = 0;
	DWORD dwResult = 0;
	TCHAR szRecovery[20] = {0x00,};
	TCHAR szValue[20] = {0x00,};

	memset(szRecovery, 0x00, sizeof(szRecovery));
	nLength = GetRecoveryCode(dwRecoeryID, szRecovery, sizeof(szRecovery));


	// 2010.06.16 ghk@kci.co.kr
	// �������� �����Ŀ��� �ٽ� ������ �ʴ´�.
	GetPrivateProfileString(_T("ERROR_SEND"), szRecovery, _T("F"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(szValue[0] == 'T' || szValue[0] == 't')
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] RECOVERY:%s ���۾���[%s]"), szRecovery,  szValue);
		return FALSE;
	}


	HWND hAgentWnd = ::FindWindow(NULL, TITLE_IBP);
	if(hAgentWnd == NULL)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] ID:%d ���� IBP FINDWINDOW FAIL ����"), dwRecoeryID);
		return FALSE;	
	}
	

	COPYDATASTRUCT cds;
	cds.dwData = IBP_COMMAND;
	cds.lpData = szRecovery;
	cds.cbData = lstrlen(szRecovery) + 1;

	nResult = ::SendMessageTimeout(hAgentWnd, 
								   WM_COPYDATA,
								   0,
								   (LPARAM)&cds,
								   SMTO_ABORTIFHUNG|SMTO_NOTIMEOUTIFNOTHUNG,
								   5000,
								   &dwResult);
	
	if(nResult == 0)
	{
		DWORD dwError = GetLastError();
		if(dwError == 0)
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] WM_COPYDATA TITLE[%s] ���� ����(Ÿ�Ӿƿ�)"),
				TITLE_IBP);
		}
		else
		{
			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] WM_COPYDATA TITLE[%s] ���� ����(%s)"),
				TITLE_IBP, CErrorMessage::GetErrorMessage(dwError));
		}
		
		return FALSE;
	}
	else
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] WM_COPYDATA TITLE[%s] DATA[%s] ���� ����"), TITLE_IBP, szRecovery);
		return TRUE;
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::ReportRecoveryToIBP] ID:%d ����[%d]"), dwRecoeryID, GetLastError());
	return FALSE;
}

BOOL CRebootManagerDlg::ProcessResponseIIM(CString strData)
{
	CStringArray sa;
	
	int nTokenCount = CStringTokenizer::GetTokens(strData, "|", sa);
	if(nTokenCount >= 2)
	{
		CString strCommand = sa.GetAt(0);
		CString strResponse = sa.GetAt(1);

		if(strCommand.Compare("REBOOT") == 0)
		{
			if (strResponse.Compare("50") == 0)
			{
				//OS REBOOT_OK
				m_server.SendResponsePacket(REP_REBOOT_INFO, "000");	//Error ����!
				Reboot();
				return TRUE;
			}
			else if (strResponse.Compare("52") == 0)
			{
				// C/C���� �ŷ� ���� ���� ������ ���		
				m_server.SendResponsePacket(REBOOT_ERR_INFO, "052");	//Error ����!
				return TRUE;
			}
			else if (strResponse.Compare("53") == 0)
			{
				// C/C���� REBOOT ����(12/G0001) ���� ���� ������ ���
				m_server.SendResponsePacket(REBOOT_ERR_INFO, "053");	//Error ����!
				return TRUE;
			}
			else if (strResponse.Compare("54") == 0)
			{
				// C/C���� POWERFAIL OR DOWNLOAD
				m_server.SendResponsePacket(REP_REBOOT_INFO, "054");	//Error ����!
// 2010.07.08 ghk@kci.co.kr
// PF/DL ������ ���� REBOOT ���� �ʴ´�.
//				Reboot();
// 2010.07.08 �ٽ� REBOOT
				Reboot();
				return TRUE;
			}

			// ���䰪�� ���ǵ��� ���� ���� �� ���
			m_server.SendResponsePacket(REBOOT_ERR_INFO, "055");
		}
		else if(strCommand.Compare("RESTART") == 0)
		{
			if (strResponse.Compare("50") == 0)
			{		
				// RESTART OK
				m_server.SendResponsePacket(REP_RESTART_INFO, "000");
				Restart();
				return TRUE;
			}
			else if (strResponse.Compare("52") == 0)
			{
				// C/C���� �ŷ� ���� ���� ������ ���
				// 2010.06.15 ghk@kci.co.kr
				// REBOOT_ERR_INFO -> REP_ERR_INFO
				m_server.SendResponsePacket(REP_ERR_INFO, "052");	//Error ����!
				return TRUE;
			}
			else if (strResponse.Compare("53") == 0)
			{
				// C/C���� REBOOT ����(12/G0001) ���� ���� ������ ���
				// 2010.06.15 ghk@kci.co.kr
				// REBOOT_ERR_INFO -> REP_ERR_INFO
				m_server.SendResponsePacket(REP_ERR_INFO, "053");	//Error ����!
				return TRUE;
			}
			else if (strResponse.Compare("54") == 0)
			{
				// C/C���� POWERFAIL OR DOWNLOAD
				m_server.SendResponsePacket(REP_RESTART_INFO, "054");	//Error ����!
// 2010.07.08 ghk@kci.co.kr
// PF/DL ������ ���� REBOOT ���� �ʴ´�.
//				Reboot();
				// 2010.07.08 �ٽ� REBOOT
				// 2010.07.15 ghk@kci.co.kr
				// ���� ���� ��û���� PF/DL ���¿����� RESTART�ϵ��� ����
				//Reboot();
				Restart();
				return TRUE;
			}
			else if (strResponse.Compare("99") == 0)
			{
				// 2010.06.08 ghk@kci.co.kr
				// ������ ��忡�� ���� ���α׷� ����� ��û��
				Restart();
				return TRUE;
			}

			// ���䰪�� ���ǵ��� ���� ���� �� ���
			m_server.SendResponsePacket(REP_ERR_INFO, "055");
		}
	}

	return FALSE;
}

BOOL CRebootManagerDlg::Reboot()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::Reboot] REBOOT ����"));

	BOOL bResult = FALSE;
	KillTimerAll();
	KillProcessAll();
	

	// OS ������ ���´�.
	OSVERSIONINFO osVersion;
	osVersion.dwOSVersionInfoSize = sizeof(osVersion);
	GetVersionEx(&osVersion);
	
	// Win95 / Win98 �� ��� (��Ȥ ������ ���ϴ� ��찡 �ְŵ�...)
	if (VER_PLATFORM_WIN32_WINDOWS == osVersion.dwPlatformId)
	{
		bResult = ExitWindowsEx(EWX_REBOOT|EWX_FORCE, 0);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::Reboot] WIN95 �Ǵ� WIN98 �ý������� ���� ����� ����[%d]"), bResult);
		return bResult;
	}
	

	HANDLE hToken;              // handle to process token 
	TOKEN_PRIVILEGES tkp;       // pointer to token structure 

	OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken);

	// Get the LUID for shutdown privilege. 
	LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid); 

	tkp.PrivilegeCount = 1;  // one privilege to set    
	tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED; 

	// Get shutdown privilege for this process. 
	AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES) NULL, 0); 

	bResult = ExitWindowsEx(EWX_REBOOT | EWX_FORCE, 0);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::Reboot] REBOOT ���� �Ϸ�[%d]"), bResult);

	return bResult;
}

void CRebootManagerDlg::KillProcessAll()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::KillProcessAll] ����"));

	TCHAR szProgram[MAX_PATH] = {0x00,};
	TCHAR szKey[10] = {0x00,};
	
	int nCount = GetPrivateProfileInt("KILL", "TOT", 0, ATOM_RESTART_INI);
	
	// �⺻ ���α׷��� �ϴ� ������.
	CProcess::KillProcess(ATOM_IBP_FILE);
	CProcess::KillProcess(ATOM_IIM_FILE);
	CProcess::KillProcess(ATOM_IPF_FILE);
	CProcess::KillProcess(ATOM_ADP_FILE);
	
	for(int i=0; i<nCount; i++)
	{
		memset(szKey, 0x00, sizeof(szKey));
		memset(szProgram, 0x00, sizeof(szProgram));
		
		wsprintf(szKey, "%d", i + 1);
		GetPrivateProfileString("KILL", szKey, "", szProgram, sizeof(szProgram), ATOM_RESTART_INI);
		if(lstrlen(szProgram))
		{
			CProcess::KillProcess(szProgram);
		}
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::KillProcessAll] ����"));
}

void CRebootManagerDlg::KillTimerAll()
{
	KillTimer(TIMER_POLL_IBP);
	KillTimer(TIMER_POLL_IIM);
	KillTimer(TIMER_POLL_IPF);
	KillTimer(TIMER_POLL_ADP);

	KillTimer(TIMER_POLL_IBP_FAIL);
	KillTimer(TIMER_POLL_IIM_FAIL);
	KillTimer(TIMER_POLL_IPF_FAIL);
	KillTimer(TIMER_POLL_ADP_FAIL);
	
	KillTimer(TIMER_SEND_PAGINGFILE_NRMSSERVER);
	KillTimer(TIMER_DELETE_LOGFILE);
}

BOOL CRebootManagerDlg::Restart()
{
	KillProcessAll();

	// AOM�� �����Ų��.
	CProcess::Execute(ATOM_OM_EXE);

	// ���� �����Ѵ�.
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::Restart] RESTART INFO SEND AND PROGRAM EXIT"));
	m_server.End();
	exit(0);

	return TRUE;
}

void CRebootManagerDlg::StartCommandResponseTimer(BOOL bReboot)
{
	if(bReboot)
	{
		KillTimer(TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT);
		SetTimer(TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT, ELAPSE_COMMAND_RESPONSE_TIMEOUT, NULL);
	}
	else
	{
		KillTimer(TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT);
		SetTimer(TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT, ELAPSE_COMMAND_RESPONSE_TIMEOUT, NULL);
	}
}


int CRebootManagerDlg::GetErrorCode(DWORD dwFailID, TCHAR *lpError, int nLength)
{
	// ���� ���۰� NULL �̰ų� ���̰� ������
	if(lpError == NULL || nLength < 7)
		return 0;

	memset(lpError, 0x00, nLength);

	if(dwFailID == POLL_IBP)
		wsprintf(lpError, "%s", ERR_IBP_DOWN);
	else if(dwFailID == POLL_IIM)
		wsprintf(lpError, "%s", ERR_IIM_DOWN);
	else if(dwFailID == POLL_IPF)
		wsprintf(lpError, "%s", ERR_IPF_DOWN);
	else if(dwFailID == POLL_ADP)
		wsprintf(lpError, "%s", ERR_ADP_DOWN);

	return lstrlen(lpError);
}

int CRebootManagerDlg::GetRecoveryCode(DWORD dwRecoveryID, TCHAR *lpRecovery, int nLength)
{
	// ���� ���۰� NULL �̰ų� ���̰� ������
	if(lpRecovery == NULL || nLength < 7)
		return 0;
	
	memset(lpRecovery, 0x00, nLength);
	
	if(dwRecoveryID == POLL_IBP)
		wsprintf(lpRecovery, "%s", ERR_IBP_RECOVER);
	else if(dwRecoveryID == POLL_IIM)
		wsprintf(lpRecovery, "%s", ERR_IIM_RECOVER);
	else if(dwRecoveryID == POLL_IPF)
		wsprintf(lpRecovery, "%s", ERR_IPF_RECOVER);
	else if(dwRecoveryID == POLL_ADP)
		wsprintf(lpRecovery, "%s", ERR_ADP_RECOVER);
	
	return lstrlen(lpRecovery);
}

void CRebootManagerDlg::PollSendResult(DWORD dwPollID, BOOL bPollSent)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] ���� ID:%d RESULT:%d"), dwPollID, bPollSent);

	switch(dwPollID)
	{
	case POLL_IBP:
		if(!bPollSent)
		{
			m_nPollSendFailIBP++;
			if(m_nPollSendFailIBP >= MAX_POLL_RETRY)
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] IBP POLL FAIL[%d]"), m_nPollSendFailIBP);

				// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
				KillTimer(TIMER_POLL_IBP);
				SetTimer(TIMER_POLL_IBP, ELAPSE_POLL_IBP_FIRST, NULL);
				
				// Ÿ�̸Ӹ� �̿��Ͽ� IBP�� POLL ���и� �����Ѵ�.
				SetTimer(TIMER_POLL_IBP_FAIL, 100, NULL);
				m_nPollSendFailIBP = 0;
			}
			else
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] IBP POLL FAIL[%d]"), m_nPollSendFailIBP);
				// POLL ���� ���н� 5���� ��õ� �Ѵ�.
				KillTimer(TIMER_POLL_IBP);
				SetTimer(TIMER_POLL_IBP, ELAPSE_POLL_SEND_RETRY, NULL);
			}
		}
		else
		{
//			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnPollResult] IBP POLL FAIL TIMER RESET"));
			ResetPollResponseTimeOut(TIMER_POLL_IBP_FAIL, ELAPSE_POLL_IBP_FAIL);
			m_nPollSendFailIBP = 0;
		}
		break;

	case POLL_IIM:
		if(!bPollSent)
		{
			m_nPollSendFailIIM++;
			if(m_nPollSendFailIIM >= MAX_POLL_RETRY)
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] IIM POLL FAIL[%d]"), m_nPollSendFailIIM);

				// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
				KillTimer(TIMER_POLL_IIM);
				SetTimer(TIMER_POLL_IIM, ELAPSE_POLL_IIM_FIRST, NULL);

				// Ÿ�̸Ӹ� �̿��Ͽ� IBP�� POLL ���и� �����Ѵ�.
				SetTimer(TIMER_POLL_IIM_FAIL, 100, NULL);
				m_nPollSendFailIIM = 0;
			}
			else
			{
				// POLL ���� ���н� 5���� ��õ� �Ѵ�.
				KillTimer(TIMER_POLL_IIM);
				SetTimer(TIMER_POLL_IIM, ELAPSE_POLL_SEND_RETRY, NULL);
			}
		}
		else
		{
//			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnPollResult] IIM POLL FAIL TIMER RESET"));
			ResetPollResponseTimeOut(TIMER_POLL_IIM_FAIL, ELAPSE_POLL_IIM_FAIL);
			m_nPollSendFailIIM = 0;
		}		
		break;

	case POLL_IPF:
		if(!bPollSent)
		{
			m_nPollSendFailIPF++;
			if(m_nPollSendFailIPF >= MAX_POLL_RETRY)
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] IPF POLL FAIL[%d]"), m_nPollSendFailIPF);

				// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
				KillTimer(TIMER_POLL_IPF);
				SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_IPF_FIRST, NULL);

				// Ÿ�̸Ӹ� �̿��Ͽ� IBP�� POLL ���и� �����Ѵ�.
				SetTimer(TIMER_POLL_IPF_FAIL, 100, NULL);
				m_nPollSendFailIPF = 0;
			}
			else
			{
				// POLL ���� ���н� 5���� ��õ� �Ѵ�.
				KillTimer(TIMER_POLL_IPF);
				SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_SEND_RETRY, NULL);
			}
		}
		else
		{
//			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnPollResult] IPF POLL FAIL TIMER RESET"));
			ResetPollResponseTimeOut(TIMER_POLL_IPF_FAIL, ELAPSE_POLL_IPF_FAIL);
			m_nPollSendFailIPF = 0;
		}		
		break;

	case POLL_ADP:
		if(!bPollSent)
		{
			m_nPollSendFailADP++;
			if(m_nPollSendFailADP >= MAX_POLL_RETRY)
			{
				CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] ADP POLL FAIL[%d]"), m_nPollSendFailADP);

				// POLL Ÿ�̸Ӹ� �ʱ�ȭ �Ѵ�.
				KillTimer(TIMER_POLL_ADP);
				SetTimer(TIMER_POLL_ADP, ELAPSE_POLL_ADP_FIRST, NULL);

				// Ÿ�̸Ӹ� �̿��Ͽ� IBP�� POLL ���и� �����Ѵ�.
				SetTimer(TIMER_POLL_ADP_FAIL, 100, NULL);
				m_nPollSendFailADP = 0;
			}
			else
			{
				// POLL ���� ���н� 5���� ��õ� �Ѵ�.
				KillTimer(TIMER_POLL_IPF);
				SetTimer(TIMER_POLL_IPF, ELAPSE_POLL_SEND_RETRY, NULL);
			}
		}
		else
		{
//			CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::OnPollResult] ADP POLL FAIL TIMER RESET"));
			ResetPollResponseTimeOut(TIMER_POLL_ADP_FAIL, ELAPSE_POLL_ADP_FAIL);
			m_nPollSendFailADP = 0;
		}		
		break;
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::PollSendResult] �Ϸ�"));
}

BOOL CRebootManagerDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
//	return TRUE;
	return CDialog::OnEraseBkgnd(pDC);
}

// ��� ȭ���� ����� �ʰ� ���ĸ� �Ѵ�.
void CRebootManagerDlg::CaptureScreen()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::CaptureScreen] ����"));

	if(CreateErrorScreen())
	{
		CErrorScreenDlg *pErrorScreen = (CErrorScreenDlg*) m_pErrorScreen;
		pErrorScreen->CaptureScreen();
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::CaptureScreen] �Ϸ�"));
}

void CRebootManagerDlg::OpenErrorScreen(CString strMessage)
{
	if(CreateErrorScreen())
	{
		CErrorScreenDlg *pErrorScreen = (CErrorScreenDlg*) m_pErrorScreen;
		pErrorScreen->SetErrorText(strMessage);
		pErrorScreen->Invalidate();

		pErrorScreen->ShowWindow(SW_SHOW);
		pErrorScreen->CaptureScreen();
	}
}

BOOL CRebootManagerDlg::CreateErrorScreen()
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::CreateErrorScreen] ����"));

	BOOL bCreated = TRUE;
	// ��� ǥ�ÿ� ȭ�� ����
	if(m_pErrorScreen == NULL)
	{
		m_pErrorScreen = new CErrorScreenDlg;
		bCreated = m_pErrorScreen->Create(CErrorScreenDlg::IDD, this);
	}

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerDlg::CreateErrorScreen] �Ϸ�(%d)"), bCreated);

	return bCreated;
}
