#if !defined(AFX_POLLSENDTHREAD_H__8AADA533_DDF4_45B7_8635_828790DD9080__INCLUDED_)
#define AFX_POLLSENDTHREAD_H__8AADA533_DDF4_45B7_8635_828790DD9080__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PollSendThread.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CPollSendThread thread

class CPollSendThread : public CWinThread
{
	DECLARE_DYNCREATE(CPollSendThread)
protected:
	CPollSendThread();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	void Push(CWnd *pNotifyWnd, WORD wCommand, WORD wParam, LPBYTE lpData, DWORD dwLength);
	void Stop();
	void SetParentWnd(HWND hParentWnd);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPollSendThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual int Run();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL SendPollPacket(CString strWindowTitle);
	BOOL ReceivePollPacket(CWnd *pNotifyWnd, WORD wPollID, CString strData);
	void ProcessPacket();
	BOOL Pop(CWnd **pNotifyWnd, WORD &wCommand, WORD &wParam, CString &strData);

	virtual ~CPollSendThread();

	// Generated message map functions
	//{{AFX_MSG(CPollSendThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	HWND			m_hParentWnd;
	HANDLE			m_hDestroyEventHandle;
	HANDLE			m_hQueueEventHandle;

	CCircularQueue	*m_pWritePacketQueue;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POLLSENDTHREAD_H__8AADA533_DDF4_45B7_8635_828790DD9080__INCLUDED_)
