#if !defined(AFX_ERRORREPORTTHREAD_H__6FA1DB76_90C3_4B20_B958_E64F813807FE__INCLUDED_)
#define AFX_ERRORREPORTTHREAD_H__6FA1DB76_90C3_4B20_B958_E64F813807FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ErrorReportThread.h : header file
//



/////////////////////////////////////////////////////////////////////////////
// CErrorReportThread thread

class CErrorReportThread : public CWinThread
{
	DECLARE_DYNCREATE(CErrorReportThread)
protected:
	CErrorReportThread();           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	CString GetErrorCode();
	void SetErrorCode(DWORD dwErrorCode);
	void SetParentWnd(HWND hParentWnd);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CErrorReportThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	virtual int Run();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL CreateSocket();
	BOOL ReceivePacket();
	BOOL SendErrorPacket();
	void CloseSocket();
	BOOL ConnectSocket(CString strRemoteIP, int nPort);
	virtual ~CErrorReportThread();

	// Generated message map functions
	//{{AFX_MSG(CErrorReportThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

private:
	SOCKET m_hSocket;
	HWND m_hParentWnd;
	DWORD m_dwErrorCode;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ERRORREPORTTHREAD_H__6FA1DB76_90C3_4B20_B958_E64F813807FE__INCLUDED_)
