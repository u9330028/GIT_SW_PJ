// RebootManager.h : main header file for the REBOOTMANAGER application
//

#if !defined(AFX_REBOOTMANAGER_H__51B3D0F3_5A6E_4FF5_9751_B8EFC01205FC__INCLUDED_)
#define AFX_REBOOTMANAGER_H__51B3D0F3_5A6E_4FF5_9751_B8EFC01205FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerApp:
// See RebootManager.cpp for the implementation of this class
//

class CRebootManagerApp : public CWinApp
{
public:
	CRebootManagerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRebootManagerApp)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRebootManagerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	HANDLE		m_hMutex;
	HMODULE		m_hEncrypt;
	ULONG_PTR	m_gdiplusToken;

	BOOL LoadEncryptLibrary();

};

extern CRebootManagerApp theApp;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REBOOTMANAGER_H__51B3D0F3_5A6E_4FF5_9751_B8EFC01205FC__INCLUDED_)
