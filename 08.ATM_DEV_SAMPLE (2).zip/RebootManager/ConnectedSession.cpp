#include "stdafx.h"
#include "ConnectedSession.h"
#include "RebootManager.h"

CConnectedSession::CConnectedSession(VOID)
{
	// ���� �Ǿ����� �Ǻ��ϴ� ����
	m_bConnected = FALSE;

	LoadDefaultNameCD();
}

CConnectedSession::~CConnectedSession(VOID)
{
}

BOOL CConnectedSession::Restart(SOCKET hListenSocket)
{
	// ����ȭ ��ü
	CThreadSync Sync;

	// ��ü�� ������ �ݴϴ�.
	End();

	// ��ü�� �ٽ� �����ϰ� Accept���·� ����� �ݴϴ�.
	// Accept�� �ϱ����ؼ��� �ݵ�� hListenSocket ���� �ʿ��մϴ�.
	// �� ���� CServerIocp�� ����� m_pListen�� GetSocket���� �޾ƿ� �� �ֽ��ϴ�.
	return Begin() && Accept(hListenSocket);
}

BOOL CConnectedSession::WritePacket(const BYTE *pData, DWORD dwDataLength)
{
	if (!CPacketSession::WritePacket(pData, dwDataLength))
		return FALSE;
	
	if (!CPacketSession::WriteComplete())
		return FALSE;
	
	return TRUE;
}

BOOL CConnectedSession::WritePacket(LPCTSTR lpCommand, const BYTE *pData, DWORD dwDataLength)
{
	if(strlen(lpCommand) < 2)
		return FALSE;
	
	if (!CPacketSession::WritePacket(lpCommand, pData, dwDataLength))
		return FALSE;
	
	if (!CPacketSession::WriteComplete())
		return FALSE;
	
	return TRUE;
}

BOOL CConnectedSession::WritePacket(LPCTSTR lpCommand, LPCTSTR lpNumberCD, const BYTE *pData, DWORD dwDataLength)
{
	if(strlen(lpCommand) < 2 || strlen(lpNumberCD) < 4)
		return FALSE;
	
	if (!CPacketSession::WritePacket(lpCommand, lpNumberCD, pData, dwDataLength))
		return FALSE;
	
	if (!CPacketSession::WriteComplete())
		return FALSE;
	
	return TRUE;
}

void CConnectedSession::SetNameCD(CString strNameCD)
{
	m_strNameCD = strNameCD;
}

BOOL CConnectedSession::SendDataPacket(CString strPacketType, CString strData)
{
	TCHAR szData[MAX_PACKET_LENGTH] = {0x00,};
	
	int nDataLength = strData.GetLength();
	strcpy(szData, strData);

	BOOL bResult = WritePacket(strPacketType, GetNameCD(), (LPBYTE)szData, nDataLength);

	return bResult;
}

CString CConnectedSession::GetNameCD()
{
	if(m_strNameCD.IsEmpty() || m_strNameCD.GetLength() != 4)
	{
		LoadDefaultNameCD();
	}

	return m_strNameCD;
}

void CConnectedSession::LoadDefaultNameCD()
{
	TCHAR szValue[20] = {0x00,};
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString(_T("LOCAL"), _T("cdnumber"), _T("****"), szValue, sizeof(szValue), ATOM_INFO_INI);
	m_strNameCD = szValue;
}
