// ProcessLog.h: interface for the CProcessLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROCESSLOG_H__62E72329_1D52_4840_BB2F_1ABFFAF6FBDB__INCLUDED_)
#define AFX_PROCESSLOG_H__62E72329_1D52_4840_BB2F_1ABFFAF6FBDB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Define.h"
#include "aes.h"

#define BUFSIZE			4096

// 2010.05.03 ghk@kci.co.kr
// stdafx.cpp�� �̵�
//#pragma comment (lib, "aes.lib")
AES_API long enc(char* in, char* out, long outLen, char* key);
AES_API long dec(char* in, char* out, long outLen, char* key);

class CProcessLog  
{
public:
	CProcessLog();
	virtual ~CProcessLog();

public:
//	void MaintenceLogFiles();
	static CProcessLog* GetInstance();
	CString m_strLogFile;

	void SetFileName(CString strFileName, CString strAlias, BOOL isEncrypt);	
	void WriteLog(CString strAlias, char* szLogFmt, ...);
//	void WriteBizLog(char* szLogFmt, ...);
	void Dump(CString strAlias, char* szDumpTitle, BYTE *data, int nSize);

private:
	//CCriticalSection m_cs;
	CRITICAL_SECTION		m_cs;
	CMap<CString, LPCSTR, CString, CString&> m_mapFileName;

	CString	m_strAlias;
	BOOL m_bLogEncryption;
	void GetFileName();
	void WriteMsgLog(char* szLogBuff);

};

#endif // !defined(AFX_PROCESSLOG_H__62E72329_1D52_4840_BB2F_1ABFFAF6FBDB__INCLUDED_)
