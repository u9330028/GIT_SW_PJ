#ifndef __DEFINE_H__
#define __DEFINE_H__

#pragma once
// TEST MODE
////////////////////////////////////////////////////////////////////////////
#define __TEST_ONLY__


// ����� �޽��� ����
////////////////////////////////////////////////////////////////////////////
#define UM_NRMS_CONNECTED					WM_USER + 100
#define UM_NRMS_DISCONNECTED				WM_USER + 101
#define UM_NRMS_RECEIVE						WM_USER + 102
#define UM_NRMS_ERROR						WM_USER + 103

#define UM_CONTROLSERVER_CONNECTED			WM_USER + 105
#define UM_CONTROLSERVER_DISCONNECTED		WM_USER + 106
#define UM_CONTROLSERVER_RECEIVE			WM_USER + 107

#define UM_START_PROGRAM					WM_USER + 110
#define UM_CHECK_HARDWARE					WM_USER + 120

#define UM_DELETELOG_THREAD_END				WM_USER + 130

// �� �޽��� ���� ���
#define UM_POLL_RESULT						WM_USER + 140




#define MAX_POLL_RETRY						3
#define MAX_COMMAND_RETRY					3

#define DISPLAY_STATUS						100
#define DISPLAY_PACKET						101






// ���丮 �н� ����
////////////////////////////////////////////////////////////////////////////
#define PATH_ROOT							_T("c:\\atm_main")
#define PATH_BIN							PATH_ROOT _T("\\bin")
#define PATH_INI							PATH_ROOT _T("\\ini")
#define PATH_LOG							PATH_ROOT _T("\\log\\arm")
#define PATH_CAPTURE						PATH_ROOT _T("\\capture")
#define PATH_RESOURCE						PATH_ROOT _T("\\res")
#define PATH_IMAGE							PATH_RESOURCE _T("\\image")
#define PATH_DOWN							PATH_ROOT _T("\\download")
#define PATH_UPDATE							PATH_DOWN _T("\\update")
#define PATH_BACKUP							PATH_DOWN _T("\\backup")
#define PATH_PRECOPY						PATH_UPDATE _T("\\download\\filecopy")




// INI ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_OM_INI							PATH_INI _T("\\aom.ini")
#define ATOM_NRMS_INI						PATH_INI _T("\\nrms.ini")
#define ATOM_VERSION_INI					PATH_INI _T("\\version.ini")
#define ATOM_INFO_INI						PATH_INI _T("\\info.ini")
#define ATOM_CONFIG_INI						PATH_INI _T("\\config.ini")
#define ATOM_FIRMWARE_INI					PATH_INI _T("\\firmware.ini")
#define ATOM_RF_FIRMWARE_INI				PATH_INI _T("\\rf.ini")
#define ATOM_PRT_FIRMWARE_INI				PATH_INI _T("\\receipterprinter.ini")
#define ATOM_BRM_FIRMWARE_INI				PATH_INI _T("\\brm.ini")
#define ATOM_KTX_INI						PATH_INI _T("\\ktx.ini")
#define ATOM_BRM_INI						PATH_INI _T("\\brmtype.ini")
#define ATOM_IBP_INI						PATH_INI _T("\\ibp_config.ini")
#define ATOM_START_INI						PATH_INI _T("\\startprogram.ini")
#define ATOM_DELINFO_INI					PATH_INI _T("\\delinfo.ini")
#define ATOM_AGENT_INI						PATH_INI _T("\\agent.ini")
#define ATOM_RESTART_INI					PATH_INI _T("\\restart.ini")
#define UPDATE_VERSION_INI					PATH_UPDATE _T("\\ini\\version.ini")
#define	COPYFILE_INI						PATH_PRECOPY _T("\\filecopy.ini")


// EXE ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_OM_FILE						_T("aom.exe")
#define ATOM_RM_FILE						_T("arm.exe")
#define ATOM_FC_FILE						_T("afm.exe")
#define ATOM_IIM_FILE						_T("iim.exe")
#define ATOM_IBP_FILE						_T("IntegratedBizProcessor.exe")
#define ATOM_IPF_FILE						_T("ipf.exe")
#define ATOM_ADP_FILE						_T("AdvertisPlayer.exe")
#define ATOM_OM_EXE							PATH_BIN _T("\\") ATOM_OM_FILE
#define ATOM_RM_EXE							PATH_BIN _T("\\") ATOM_RM_FILE
#define ATOM_ADP_EXE						PATH_BIN _T("\\") ATOM_ADP_FILE


// DLL ����
////////////////////////////////////////////////////////////////////////////
#define ATOM_ENC_LIBRARY					PATH_BIN _T("\\aes.dll")


// LOG ����
////////////////////////////////////////////////////////////////////////////
#define LOGFILE								_T("arm.txt")
#define LOGBACK								_T("arm.bak")
#define ATOM_RM_LOG							PATH_LOG _T("\\") LOGFILE
#define LOGFILE_MAXSIZE						1024000



// UPDATE ���� ����
////////////////////////////////////////////////////////////////////////////
#define UPDATE_FILE_PATH					PATH_UPDATE _T("\\atom.zip")
#define UPDATE_FILE_NAME					PATH_DOWN _T("\\atom_update_*.zip")		// ATOM_UPDATE_Vxxxxxx.zip
#define MASTER_FILE_NAME					PATH_DOWN _T("\\atom_master_*.zip")		// ATOM_MASTER_Vxxxxxx.zip
#define UPDATE_FILENAME_LENGTH				19


// �ϵ���� ���� ����
////////////////////////////////////////////////////////////////////////////
#define MIN_MEMORY_SIZE						110	// MB
#define MIN_HARDDISK_SIZE					15	// GB


// TIMER ID ����
////////////////////////////////////////////////////////////////////////////
#define TIMER_NRMS_RECEIVE_TIMEOUT			3
#define TIMER_SEND_PAGINGFILE_NRMSSERVER	6
#define TIMER_DELETE_LOGFILE				8

#define TIMER_POLL_SERVER					9
#define TIMER_POLL_IBP						10		// IBP POLL �޽��� ���� Ÿ�̸�
#define TIMER_POLL_IIM						11		// IIM POLL �޽��� ���� Ÿ�̸�
#define TIMER_POLL_IPF						12		// IPF POLL �޽��� ���� Ÿ�̸�
#define TIMER_POLL_ADP						13		// ADP POLL �޽��� ���� Ÿ�̸�

#define TIMER_POLL_IBP_FAIL					15		// IBP POLL FAIL Ÿ�̸�
#define TIMER_POLL_IIM_FAIL					16
#define TIMER_POLL_IPF_FAIL					17
#define TIMER_POLL_ADP_FAIL					18

#define TIMER_COMMAND_REBOOT_RESPONSE_TIMEOUT		19
#define TIMER_COMMAND_RESTART_RESPONSE_TIMEOUT		20



#define ELAPSE_ATOM_OM_START				1000
#define ELAPSE_KTX_RECONNECT				5000
#define ELAPSE_NRMS_RECONNECT				5000
#define ELAPSE_NRMS_RECEIVE_TIMEOUT			30000

#define ELAPSE_CONTROLSERVER_RECONNECT		5000
#define TIMER_CONTROLSERVER_RECEIVE_TIMEOUT	30000

#define ELAPSE_DELETE_LOGFILE				86400000	// 1��

#define ELAPSE_POLL_IBP						60000		// 60��
#define ELAPSE_POLL_IIM						60000		// 60��
#define ELAPSE_POLL_IPF						60000		// 60��
#define ELAPSE_POLL_ADP						60000		// 60��

#define ELAPSE_POLL_IBP_FIRST				80000		// 80��
#define ELAPSE_POLL_IIM_FIRST				80000		// 80��
#define ELAPSE_POLL_IPF_FIRST				80000		// 80��
#define ELAPSE_POLL_ADP_FIRST				80000		// 80��

#define ELAPSE_POLL_IBP_AFTERREP			120000		// 2��
#define ELAPSE_POLL_IIM_AFTERREP			120000		// 2��
#define ELAPSE_POLL_IPF_AFTERREP			120000		// 2��
#define ELAPSE_POLL_ADP_AFTERREP			120000		// 2��

#define ELAPSE_POLL_IBP_FAIL				30000
#define ELAPSE_POLL_IIM_FAIL				30000
#define ELAPSE_POLL_IPF_FAIL				30000
#define ELAPSE_POLL_ADP_FAIL				30000

#define ELAPSE_POLL_SEND					10000
#define ELAPSE_POLL_SEND_RETRY				10000		// 10�� �� POLL ���� ��õ�

#define ELAPSE_COMMAND_RESPONSE_TIMEOUT		20000


#define	MAX_NRMS_CONNECT_RETRY				10
#define MAX_CONTROLSERVER_CONNECT_RETRY		3
#define MAX_POLLSERVER_CONNECT_RETRY		3

#define MESSAGE_TIMEOUT						20000

// ZIP FILE BUFFER ����
////////////////////////////////////////////////////////////////////////////
#define BUFFER_SIZE							1024


// PROGRSS ����
////////////////////////////////////////////////////////////////////////////
#define MAX_PROGRESS_STEP					13


// NETWORK ����
////////////////////////////////////////////////////////////////////////////
#define MAX_QUEUE_LENGTH					50
#define MAX_BUFFER_LENGTH					10240
#define MAX_PACKET_LENGTH					4096
#define MAX_SESSIONCOUNT					10


#define IP_NRMS_SERVER						_T("172.16.1.27")
#define IP_CONTROL_SERVER					_T("172.16.1.90")
#define IP_POLL_SERVER						_T("172.16.1.90")
#define PORT_NRMS_SERVER					7200
#define PORT_CONTROL_SERVER					10002
#define PORT_KTX_SERVER						9510
#define PORT_LISTEN_SERVER					8500
#define PORT_POLL_SERVER					8001


#define	NRMS_STATE_REQUEST					0
#define	NRMS_STATE_FORMAT_ERROR				1
#define	NRMS_STATE_WRITE_ERROR				2


#define TIMEOUT_CONNECT						10		// ��
#define TIMEOUT_SEND						10		// ��
#define TIMEOUT_RECEIVE						30		// ��


// AP POLL ����
////////////////////////////////////////////////////////////////////////////
#define TITLE_IBP							_T("PTComm")		//
#define TITLE_IIM							_T("MWComm")
#define TITLE_IPF							_T("MainWindow")
#define TITLE_ADP							_T("AdvertisPlayer")	//_T("ManagerTP")
#define TITLE_ARM							_T("ATOM Reboot Manager")

#define ARM_COMMAND							26		// ���ȭ�� ǥ�ÿ�
#define IPF_COMMAND							27		// IPF�� ȭ�� ��û��
#define IIM_COMMAND							28		// OSREBOOT, RESTART ���� Ŀ�ǵ�
#define IBP_COMMAND							28		// ��ֺ��� ���� Ŀ�ǵ�
#define POLL_COMMAND						29
#define POLL_RESPONSE						30

#define IIM_COMMAND_RESPONSE				9		// OSREBOOT, RESTART ���� Ŀ�ǵ忡 ���� ����

#define POLL_IIM							31
#define POLL_IPF							32
#define POLL_IBP							33
#define POLL_ADP							34


#define POLL_IIM_RESPONSE					41
#define POLL_IPF_RESPONSE					42
#define POLL_IBP_RESPONSE					43
#define POLL_ADP_RESPONSE					44

#define ERR_IIM_DOWN						_T("6IIMERR")
#define ERR_IPF_DOWN						_T("6IPFERR")
#define ERR_IBP_DOWN						_T("6IBPERR")
#define ERR_ADP_DOWN						_T("6ADVERR")
#define ERR_IIM_RECOVER						_T("6IIMREP")
#define ERR_IPF_RECOVER						_T("6IPFREP")
#define ERR_IBP_RECOVER						_T("6IBPREP")
#define ERR_ADP_RECOVER						_T("6ADVREP")


#define REP_MEMORY_INFO						_T("40")

#define REQ_FILE_INFO						_T("53")
#define RES_ERROR							_T("50")
#define	FORMAT_ERROR						_T("003")
#define	WRITE_ERROR							_T("022")

#define	RES_NRMS_INFO						_T("63")
#define	RES_NRMS_ERROR						_T("60")

#define	REP_ERR_INFO						_T("80")
#define	REP_RESTART_INFO					_T("81")

#define	REBOOT_ERR_INFO						_T("82")
#define	REP_REBOOT_INFO						_T("83")

#define	TELNETSTART_ERR_INFO				_T("84")
#define	TELNETSTART_INFO					_T("85")

#define	FTPSTART_ERR_INFO   				_T("86")
#define	FTPSTART_INFO		    			_T("87")

#define	TELNETSTOP_ERR_INFO		    		_T("88")
#define	TELNETSTOP_INFO						_T("89")

#define	FTPSTOP_ERR_INFO   		    		_T("90")
#define	FTPSTOP_INFO		    			_T("91")




#define STX									0x02
#define	FS									0x1c
#define	ETX									0x03
#define	RS									0x1e
#define	GS									0x1d


#define PACKET_EXIST						1
#define PACKET_INVALID_PACKET_LENGTH		0



#endif
