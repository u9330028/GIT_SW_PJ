// RebootManager.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "RebootManager.h"
#include "RebootManagerDlg.h"
#include "ExecVersion.h"
#include "Directory.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerApp

BEGIN_MESSAGE_MAP(CRebootManagerApp, CWinApp)
	//{{AFX_MSG_MAP(CRebootManagerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerApp construction

CRebootManagerApp::CRebootManagerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_hMutex = NULL;
	m_hEncrypt = NULL;
	m_gdiplusToken = 0;

//	LoadEncryptLibrary();
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRebootManagerApp object

CRebootManagerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRebootManagerApp initialization

BOOL CRebootManagerApp::InitInstance()
{
	CDirectory::MakeDirectory(PATH_INI);
	CDirectory::MakeDirectory(PATH_LOG);

	TCHAR szValue[24] = {0x00,};
	BOOL bEncrypt = TRUE;
	
	memset(szValue, 0x00, sizeof(szValue));
	GetPrivateProfileString(_T("ENCRYPT"), _T("IS_LOCAL"), _T("FALSE"), szValue, sizeof(szValue), ATOM_IBP_INI);
	if(lstrcmp(szValue, _T("TRUE")) == 0 || lstrcmp(szValue, _T("true")) == 0)
	{
		bEncrypt = FALSE;
	}
	CProcessLog::GetInstance()->SetFileName(ATOM_RM_LOG, LOGFILE, bEncrypt);


	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T(" "));
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("=< START >===================================================================="));
	
	// ���߽��� ����
	m_hMutex = ::CreateMutex(NULL, FALSE, "ATOM REBOOT MANAGER PROGRAM");
	if( ::WaitForSingleObject(m_hMutex, 0) != WAIT_OBJECT_0 )
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("���� �������� ARM�� �����մϴ�. ���α׷��� �������� �ʽ��ϴ�."));
//		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("=============================================================================="));
		return FALSE;
	}


	CExecVersion ver(ATOM_RM_EXE);
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T(" ARM VERSION:%s DESC:%s"), ver.GetFileVersion(), ver.GetSpecialBuild());
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("=============================================================================="));


	// GDI+ �ʱ�ȭ
	GdiplusStartupInput gdiplusStartupInput;
	if(GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL) != Ok)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("GDI+ ���̺귯���� �ʱ�ȭ�� �� �����ϴ�."));
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CRebootManagerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CRebootManagerApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(m_hMutex)
	{
		CloseHandle(m_hMutex);
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CRebootManagerApp::ExitInstance] MUTEX CLOSE �Ϸ�"));
	}
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("=< END   >======================================================================"));

	if(m_hEncrypt)
	{
		FreeLibrary(m_hEncrypt);
		m_hEncrypt = NULL;
	}

	if(m_gdiplusToken)
	{
		GdiplusShutdown(m_gdiplusToken);
	}
	
	return CWinApp::ExitInstance();
}


BOOL CRebootManagerApp::LoadEncryptLibrary()
{
	m_hEncrypt = LoadLibrary(ATOM_ENC_LIBRARY);
	if(m_hEncrypt)
	{
		EncryptAES = (long (__cdecl *)(char*, char*, long, char*))GetProcAddress(m_hEncrypt, _T("?enc@@YAJPAD0J0@Z"));
		if(EncryptAES)
		{
			return TRUE;
		}
	}
	
	return FALSE;
}
