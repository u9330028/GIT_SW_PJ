// ErrorScreenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RebootManager.h"
#include "ErrorScreenDlg.h"
#include "Directory.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CErrorScreenDlg dialog

const CHAR* g_szImageFormat[4] =		
{
		"image/bmp",
		"image/jpeg",
		"image/png",
		"image/gif",
};


CErrorScreenDlg::CErrorScreenDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CErrorScreenDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CErrorScreenDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pBitmapBG = NULL;
	m_hBitmap = NULL;

	m_strMessage = _T("");
}

CErrorScreenDlg::~CErrorScreenDlg()
{
	m_FontMessage.DeleteObject();
}

void CErrorScreenDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CErrorScreenDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CErrorScreenDlg, CDialog)
	//{{AFX_MSG_MAP(CErrorScreenDlg)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CErrorScreenDlg message handlers

void CErrorScreenDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CDialog::OnPaint() for painting messages
	DrawBackground();
//	DrawMessage();
}

void CErrorScreenDlg::DrawBackground()
{
	HDC hDC = ::GetDC(m_hWnd);
	SIZE sz = { m_pBitmapBG->GetWidth() , m_pBitmapBG->GetHeight() };
	
	RECT rc={0};
	POINT zpt={0};	
	::GetWindowRect(m_hWnd, &rc);
	Rect rect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
	
	HDC hMemDC = CreateCompatibleDC( hDC );
	HBITMAP hOldBitmap = (HBITMAP)SelectObject(hMemDC, m_hBitmap);
	Graphics G2(hMemDC);
	
	// ���� ȭ���� ����� ��� ǰ���� ���δ�.
	G2.Clear(Color(0, 0, 0, 0));
	G2.SetInterpolationMode(InterpolationModeHighQuality);
	
	// ��� �׸���.
	int nWidth = m_pBitmapBG->GetWidth();
	int nHeight = m_pBitmapBG->GetHeight();
	//G2.DrawImage(m_pBitmapBG, 0, 0, nWidth, nHeight);
	G2.DrawImage(m_pBitmapBG, rect, 0, 0, nWidth, nHeight, UnitPixel);
	
	// ȭ�� ����
	/*
	HDC hdcsrc = G2.GetHDC();
	BLENDFUNCTION blendfunction= { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
	BOOL bRet= ::UpdateLayeredWindow(m_hWnd, hDC, ((LPPOINT)&rc), &sz, hdcsrc, &zpt, 0, &blendfunction, ULW_ALPHA);
	G2.ReleaseHDC( hdcsrc );
	*/

	DrawMessage(hMemDC);
	
	//::BitBlt(hDC, 0, 0, sz.cx, sz.cy, hMemDC, 0, 0, SRCCOPY);
	::BitBlt(hDC, 0, 0, rc.right - rc.left, rc.bottom - rc.top, hMemDC, 0, 0, SRCCOPY);
	
	// �ڿ�ȯ��
	SelectObject(hMemDC, hOldBitmap);
	DeleteDC(hMemDC);
	
	::ReleaseDC(m_hWnd, hDC);
}

BOOL CErrorScreenDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	HDC hDC = ::GetDC(GetSafeHwnd());
	LOGFONT lf;

	memset(&lf, 0x00, sizeof(lf));
	lstrcpy(lf.lfFaceName, _T("����ü"));
	lf.lfHeight = -MulDiv(20, GetDeviceCaps(hDC, LOGPIXELSY), 72);
	lf.lfWeight = FW_BOLD;
	lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;
	m_FontMessage.CreateFontIndirect(&lf);

	m_pBitmapBG = ImageFromResource(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_PNG_BACKGROUND), _T("PNG"));

	int nWidth = ::GetSystemMetrics(SM_CXSCREEN);
	int nHeight = ::GetSystemMetrics(SM_CYSCREEN);
	
	SetWindowPos(&CWnd::wndTopMost, 0, 0, nWidth, nHeight, SWP_HIDEWINDOW);

	m_hBitmap = Create32BitBitmap( hDC, nWidth, nHeight );
	::ReleaseDC( GetSafeHwnd(), hDC );

	// 2010.06.21 ghk@kci.co.kr
	// ���ȭ�鿡�� Ŀ���� �����.
	ShowCursor(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

Bitmap* CErrorScreenDlg::ImageFromResource(IN HINSTANCE hInst, IN const LPTSTR pName, IN const LPTSTR pType )
{
	Bitmap* bitmap = NULL;
	HRSRC hResource = ::FindResource(hInst, pName, pType);
	if (!hResource)	return NULL;
	
	DWORD imageSize = ::SizeofResource(hInst, hResource);
	if (!imageSize) return NULL;
	
	const void* pResourceData = ::LockResource(::LoadResource(hInst, hResource));
	if (!pResourceData)	return NULL;
	
	HGLOBAL hBuffer  = ::GlobalAlloc(GMEM_MOVEABLE, imageSize);
	if (hBuffer)
	{
		void* pBuffer = ::GlobalLock(hBuffer);
		if (pBuffer)
		{
			CopyMemory(pBuffer, pResourceData, imageSize);
			
			IStream* pStream = NULL;
			if (::CreateStreamOnHGlobal(hBuffer, FALSE, &pStream) == S_OK)
			{
				bitmap = Bitmap::FromStream(pStream);
				pStream->Release();
				if (bitmap)
				{ 
					if (bitmap->GetLastStatus() != Ok)
					{
						delete bitmap;
						bitmap = NULL;
					}
				}
			}
			::GlobalUnlock(hBuffer);
		}
		::GlobalFree(hBuffer);			
	}
	
	return bitmap;
}

HBITMAP CErrorScreenDlg::Create32BitBitmap(HDC hDC, int cx, int cy )
{
	// Create 32-bit bitmap
	BITMAPINFO bi = { 0 };
	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth = cx;
	bi.bmiHeader.biHeight = cy;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 32;
	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biSizeImage = 0;
	bi.bmiHeader.biXPelsPerMeter = 0;
	bi.bmiHeader.biYPelsPerMeter = 0;
	bi.bmiHeader.biClrUsed = 0;
	bi.bmiHeader.biClrImportant = 0;

	return ::CreateDIBSection(hDC, &bi, DIB_RGB_COLORS, NULL, NULL, 0);
}

BOOL CErrorScreenDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	DrawBackground();
//	DrawMessage();
	return TRUE;

	return CDialog::OnEraseBkgnd(pDC);
}

BOOL CErrorScreenDlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if( pMsg->message==WM_KEYDOWN &&
		(pMsg->wParam==VK_ESCAPE || pMsg->wParam==VK_RETURN))
	{
		return FALSE;
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CErrorScreenDlg::OnSysCommand(UINT nID, LPARAM lParam) 
{
	// TODO: Add your message handler code here and/or call default
	if(nID == SC_CLOSE)
		return;

	CDialog::OnSysCommand(nID, lParam);
}

void CErrorScreenDlg::SetErrorText(CString strMessage)
{
	m_strMessage = CString(strMessage);
	Invalidate();
}

CString CErrorScreenDlg::GetFilePath()
{
	return m_strFilePath;
}

int CErrorScreenDlg::GetMonitorCount()
{
	return m_nMonitorCount;
}

void CErrorScreenDlg::IncreaseMonitorCount()
{
	m_nMonitorCount++;
}

void CErrorScreenDlg::ResetMonitorCount()
{
	m_nMonitorCount = 0;
}


BOOL CErrorScreenDlg::MonitorCaptureProc(HMONITOR hMonitor, 
										 HDC hMonitorDC,
										 LPRECT lpMonitorRect,
										 LPARAM lParam)
{
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorScreenDlg::MonitorCaptureProc] ����(%x)"), lParam);

	CErrorScreenDlg *pErrorScreenDlg = (CErrorScreenDlg*) lParam;
	
	if(pErrorScreenDlg == NULL)
		return TRUE;
	
	CString strFullPath = "";
	CString strFilePath = pErrorScreenDlg->GetFilePath();
	int nMonitorCount = pErrorScreenDlg->GetMonitorCount();
	
	pErrorScreenDlg->IncreaseMonitorCount();
	strFullPath.Format("%s%dERR.jpg", strFilePath, ++nMonitorCount);

	BOOL bResult = TRUE;
	MONITORINFO monitor;

	memset(&monitor, 0x00, sizeof(monitor));
	monitor.cbSize = sizeof(monitor);
	bResult = GetMonitorInfo(hMonitor, &monitor);
	if(!bResult)
	{
		CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorScreenDlg::MonitorCaptureProc] GetMonitorInfo ���� ����"));
		return TRUE;
	}

	int nX = monitor.rcWork.left;
	int nY = monitor.rcWork.top;
	int nWidth = monitor.rcWork.right - monitor.rcWork.left;
	int nHeight = monitor.rcWork.bottom - monitor.rcWork.top;

	HDC hDC = ::GetDC(NULL);
	bResult = pErrorScreenDlg->CaptureToImage(hDC, 
									strFullPath,
									SAVE_JPG,
									nX,
									nY,
									nWidth,
									nHeight,
									100);
	::ReleaseDC(NULL, hDC);
	
	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorScreenDlg::MonitorCaptureProc] �Ϸ�(RESULT:%d %s)"), bResult, strFullPath);
	return TRUE;
}


void CErrorScreenDlg::CaptureScreen()
{
	SYSTEMTIME t;
	TCHAR szNumberCD[10] = {0x00,};
	CString strDirectory = _T("");
	CString strFilePath = _T("");

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorScreenDlg::CaptureScreen] ����"));
	
	GetLocalTime(&t);

	strDirectory.Format(_T("%s\\%04d%02d%02d"), PATH_CAPTURE, t.wYear, t.wMonth, t.wDay);
	CDirectory::MakeDirectory(strDirectory);


	memset(szNumberCD, 0x00, sizeof(szNumberCD));
	GetPrivateProfileString("LOCAL", "cdnumber", "****", szNumberCD, sizeof(szNumberCD), ATOM_INFO_INI);
	
	m_strFilePath.Format(_T("%s\\%s%04d%02d%02d%02d%02d%02d"),
							strDirectory, szNumberCD, t.wYear, t.wMonth, t.wDay,
							t.wHour, t.wMinute, t.wSecond);

	ResetMonitorCount();
	//EnumDisplayMonitors(hDC, NULL, MonitorCaptureProc, (LPARAM)this);
	EnumDisplayMonitors(NULL, NULL, MonitorCaptureProc, (LPARAM)this);

	CProcessLog::GetInstance()->WriteLog(LOGFILE, _T("[CErrorScreenDlg::CaptureScreen] �Ϸ�"));

/*
	HDC hDC = ::GetDC(NULL);
	SYSTEMTIME t;

	int nWidth = ::GetSystemMetrics(SM_CXSCREEN);
	int nHeight = ::GetSystemMetrics(SM_CYSCREEN);


	GetLocalTime(&t);
	CString strDirectory = _T("");
	CString strFilePath = _T("");

	strDirectory.Format(_T("%s\\%04d%02d%02d"), PATH_CAPTURE, t.wYear, t.wMonth, t.wDay);
	CDirectory::MakeDirectory(strDirectory);
		
		
	strFilePath.Format(_T("%s\\%04d%02d%02d%02d%02d%02dERR.jpg"),
		strDirectory, t.wYear, t.wMonth, t.wDay,
		t.wHour, t.wMinute, t.wSecond);//, t.wMilliseconds);

	CaptureToImage(hDC, strFilePath, SAVE_JPG, 0, 0, 2704, nHeight, 100);

	::ReleaseDC(NULL, hDC);
*/
}

void CErrorScreenDlg::DrawMessage(HDC hDC)
{
//	HDC hDC = ::GetDC(m_hWnd);

	CRect rcClient(0,0,0,0);
	CRect rcText(210, 380, 800, 530);

	GetClientRect(&rcClient);

	int nWidth = rcClient.Width();
	int nHeight = rcClient.Height();
	rcText.left = (nWidth * 220) / 1024;
	rcText.top = (nHeight * 380) / 768;
	rcText.right = rcText.left + (nWidth * 580) / 1024;
	rcText.bottom = rcText.top + (nHeight * 160) / 768;

	int nMode = ::SetBkMode(hDC, TRANSPARENT);

	CFont *pOldFont = (CFont*) ::SelectObject(hDC, m_FontMessage);

	DrawText(hDC, m_strMessage, m_strMessage.GetLength(), rcText, DT_LEFT|DT_NOPREFIX|DT_WORDBREAK);

	::SelectObject(hDC, pOldFont);

	::SetBkMode(hDC, nMode);
//	::ReleaseDC(m_hWnd, hDC);
}

BOOL CErrorScreenDlg::CaptureToImage(HDC hDC,  
									 LPCSTR szFilePath, 
									 int nSaveFormat,
									 int nLeft,
									 int nTop,
									 int nWidth,
									 int nHeight,
									 int nJpgQuality/*1-100*/)

{
    /**
        �����ϴ� �̹��� �迭 �ε����� �ʰ��ϸ�  ����
    */
    if(nSaveFormat < 0 || nSaveFormat > SAVE_GIF)
        return FALSE;


    USES_CONVERSION;

    CLSID encoderClsid;

    // get a handle to the Desktop Device Context, and create a
    // compatible DC to copy into
    HDC hDest = CreateCompatibleDC(hDC);

    // create a bitmap,
    HBITMAP hbDesktop = CreateCompatibleBitmap(hDC, nWidth, nHeight);

    // associate our own Device Context to the bitmap
    SelectObject(hDest, hbDesktop);


    // copy from one DC to the other
    BitBlt(hDest, 0, 0, nWidth, nHeight, hDC, nLeft, nTop, SRCCOPY);


    HPALETTE hPalette = (HPALETTE) GetCurrentObject(hDC, OBJ_PAL);
    Bitmap myBitMap(hbDesktop, hPalette);

//    if(NULL == myBitMap)
  //      return FALSE;



    // ���ڴ� ����
    const CHAR*  szMime = g_szImageFormat[nSaveFormat];
    const WCHAR* wcMime = A2W(szMime);

    GetEncoderClsid(wcMime, &encoderClsid);

    EncoderParameters encoderParameters;
    ULONG             Quality = nJpgQuality;

    encoderParameters.Count = 1;
    encoderParameters.Parameter[0].Guid = EncoderQuality;
    encoderParameters.Parameter[0].Type = EncoderParameterValueTypeLong;
    encoderParameters.Parameter[0].NumberOfValues = 1;
    encoderParameters.Parameter[0].Value = &Quality;


    // ����
    Gdiplus::Status  status = myBitMap.Save(A2W(szFilePath),
											&encoderClsid,
											(nSaveFormat == SAVE_JPG ? &encoderParameters : NULL));


//    delete  myBitMap;

    DeleteDC(hDest);
    DeleteObject(hPalette);
    DeleteObject(hbDesktop);    

    return status == Gdiplus::Ok;
}

int CErrorScreenDlg::GetEncoderClsid(const WCHAR* format, CLSID* pClsid)
{
    UINT  num = 0;          // number of image encoders
    UINT  size = 0;         // size of the image encoder array in bytes
	
    ImageCodecInfo* pImageCodecInfo = NULL;
	
    GetImageEncodersSize(&num, &size);
	
    if(size == 0)
        return -1;  // Failure
	
    pImageCodecInfo = (ImageCodecInfo*)(malloc(size));
    if(pImageCodecInfo == NULL)
        return -1;  // Failure
	
	
    GetImageEncoders(num, size, pImageCodecInfo);
	
    for(UINT j = 0; j < num; ++j)
    {
        if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
        {
            *pClsid = pImageCodecInfo[j].Clsid;
            free(pImageCodecInfo);
            return j;  // Success
        }    
    }
	
    free(pImageCodecInfo);
    return -1;  // Failure
}